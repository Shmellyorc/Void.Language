; ModuleID = '/main.void'
source_filename = "/main.void"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%"/@stdlib/console.void::io_error" = type { ptr, ptr, %"/@stdlib/console.void::io_error_kind", i64, ptr, i64, ptr, i64, i64 }
%"/@stdlib/console.void::io_error_kind" = type { i32 }
%"/@stdlib/console.void::_reply" = type { i64, i64, i64, i64, i64, i1, ptr, ptr, i64, i64 }
%"/@stdlib/console.void::output" = type { i64 }
%"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, i64, %"/@stdlib/console.void::io_error" }
%"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, i1, %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::input" = type { i64 }
%"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, %"/@stdlib/console.void::text_read", %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::text_read" = type { i32, ptr }
%"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, %"/@stdlib/console.void::bytes_read", %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::bytes_read" = type { i32, ptr }
%"/@stdlib/console.void::color" = type { i32 }
%"/@stdlib/console.void::terminal_capabilities" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1 }
%"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, %"/@stdlib/console.void::terminal_size", %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::terminal_size" = type { i64, i64 }
%"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, %"/@stdlib/console.void::terminal_position", %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::terminal_position" = type { i64, i64 }
%"/@stdlib/console.void::terminal_session" = type { i64 }
%"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, ptr, %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::key" = type { i32 }
%"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" = type { i32, %"/@stdlib/console.void::key_event", %"/@stdlib/console.void::io_error" }
%"/@stdlib/console.void::key_event" = type { ptr, %"/@stdlib/console.void::key", i1, i1, i1, i1, i1, i1, i64, ptr }

@async.generation = private constant i8 0
@0 = private unnamed_addr constant [83 x i8] c"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@1 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@2 = private unnamed_addr constant [343 x i8] c"80:8|4:$tag|82:$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|82:$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable|4:bool|1:4|4:$err|82:$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|1:8\00", align 1
@gc.offsets = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@3 = private unnamed_addr constant [108 x i8] c"void.array.element.v1/12:$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@4 = private unnamed_addr constant [83 x i8] c"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@5 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@6 = private unnamed_addr constant [343 x i8] c"88:8|4:$tag|82:$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|82:$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i64|1:8|4:$err|82:$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:16\00", align 1
@gc.offsets.1 = private constant [4 x i64] [i64 16, i64 24, i64 48, i64 64]
@7 = private unnamed_addr constant [108 x i8] c"void.array.element.v1/12:$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@8 = private unnamed_addr constant [117 x i8] c"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@9 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@10 = private unnamed_addr constant [479 x i8] c"120:8|4:$tag|116:$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|116:$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable|32:/@stdlib/console.void::key_event|1:8|4:$err|116:$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:48\00", align 1
@gc.offsets.2 = private constant [6 x i64] [i64 8, i64 40, i64 48, i64 56, i64 80, i64 96]
@11 = private unnamed_addr constant [142 x i8] c"void.array.element.v1/12:$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@12 = private unnamed_addr constant [117 x i8] c"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@13 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@14 = private unnamed_addr constant [478 x i8] c"96:8|4:$tag|116:$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|116:$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable|32:/@stdlib/console.void::text_read|1:8|4:$err|116:$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:24\00", align 1
@gc.offsets.3 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@15 = private unnamed_addr constant [142 x i8] c"void.array.element.v1/12:$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@16 = private unnamed_addr constant [118 x i8] c"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@17 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@18 = private unnamed_addr constant [482 x i8] c"96:8|4:$tag|117:$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|117:$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable|33:/@stdlib/console.void::bytes_read|1:8|4:$err|117:$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:24\00", align 1
@gc.offsets.4 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@19 = private unnamed_addr constant [143 x i8] c"void.array.element.v1/12:$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@20 = private unnamed_addr constant [121 x i8] c"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@21 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@22 = private unnamed_addr constant [494 x i8] c"96:8|4:$tag|120:$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|120:$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable|36:/@stdlib/console.void::terminal_size|1:8|4:$err|120:$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:24\00", align 1
@gc.offsets.5 = private constant [4 x i64] [i64 24, i64 32, i64 56, i64 72]
@23 = private unnamed_addr constant [146 x i8] c"void.array.element.v1/12:$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@24 = private unnamed_addr constant [124 x i8] c"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@25 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@26 = private unnamed_addr constant [506 x i8] c"88:8|4:$tag|123:$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|123:$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable|39:/@stdlib/console.void::terminal_session|1:8|4:$err|123:$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:16\00", align 1
@gc.offsets.6 = private constant [5 x i64] [i64 8, i64 16, i64 24, i64 48, i64 64]
@27 = private unnamed_addr constant [149 x i8] c"void.array.element.v1/12:$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@28 = private unnamed_addr constant [125 x i8] c"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@29 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@30 = private unnamed_addr constant [510 x i8] c"96:8|4:$tag|124:$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable|3:i32|1:0|3:$ok|124:$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable|40:/@stdlib/console.void::terminal_position|1:8|4:$err|124:$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable|31:/@stdlib/console.void::io_error|2:24\00", align 1
@gc.offsets.7 = private constant [4 x i64] [i64 24, i64 32, i64 56, i64 72]
@31 = private unnamed_addr constant [150 x i8] c"void.array.element.v1/12:$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable\00", align 1
@32 = private unnamed_addr constant [30 x i8] c"/@stdlib/console.void::_reply\00", align 1
@33 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@34 = private unnamed_addr constant [553 x i8] c"80:8|4:kind|29:/@stdlib/console.void::_reply|3:i64|1:0|7:os_code|29:/@stdlib/console.void::_reply|3:i64|1:8|8:progress|29:/@stdlib/console.void::_reply|3:i64|2:16|12:cleanup_code|29:/@stdlib/console.void::_reply|3:i64|2:24|19:partial_utf16_units|29:/@stdlib/console.void::_reply|3:i64|2:32|3:eof|29:/@stdlib/console.void::_reply|4:bool|2:40|4:text|29:/@stdlib/console.void::_reply|6:string|2:48|5:bytes|29:/@stdlib/console.void::_reply|4:[u8]|2:56|5:first|29:/@stdlib/console.void::_reply|3:i64|2:64|6:second|29:/@stdlib/console.void::_reply|3:i64|2:72\00", align 1
@gc.offsets.8 = private constant [2 x i64] [i64 48, i64 56]
@35 = private unnamed_addr constant [55 x i8] c"void.array.element.v1/12:/@stdlib/console.void::_reply\00", align 1
@36 = private unnamed_addr constant [34 x i8] c"/@stdlib/console.void::bytes_read\00", align 1
@37 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@38 = private unnamed_addr constant [122 x i8] c"16:8|4:$tag|33:/@stdlib/console.void::bytes_read|3:i32|1:0|11:$data$value|33:/@stdlib/console.void::bytes_read|4:[u8]|1:8\00", align 1
@gc.offsets.9 = private constant [1 x i64] [i64 8]
@39 = private unnamed_addr constant [59 x i8] c"void.array.element.v1/12:/@stdlib/console.void::bytes_read\00", align 1
@40 = private unnamed_addr constant [29 x i8] c"/@stdlib/console.void::color\00", align 1
@41 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@42 = private unnamed_addr constant [53 x i8] c"4:4|4:$tag|28:/@stdlib/console.void::color|3:i32|1:0\00", align 1
@gc.offsets.10 = private constant [0 x i64] zeroinitializer
@43 = private unnamed_addr constant [54 x i8] c"void.array.element.v1/12:/@stdlib/console.void::color\00", align 1
@44 = private unnamed_addr constant [29 x i8] c"/@stdlib/console.void::input\00", align 1
@45 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@46 = private unnamed_addr constant [52 x i8] c"8:8|3:_id|28:/@stdlib/console.void::input|3:i64|1:0\00", align 1
@gc.offsets.11 = private constant [0 x i64] zeroinitializer
@47 = private unnamed_addr constant [54 x i8] c"void.array.element.v1/12:/@stdlib/console.void::input\00", align 1
@48 = private unnamed_addr constant [32 x i8] c"/@stdlib/console.void::io_error\00", align 1
@49 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@50 = private unnamed_addr constant [589 x i8] c"72:8|9:operation|31:/@stdlib/console.void::io_error|6:string|1:0|6:stream|31:/@stdlib/console.void::io_error|6:string|1:8|4:kind|31:/@stdlib/console.void::io_error|36:/@stdlib/console.void::io_error_kind|2:16|7:os_code|31:/@stdlib/console.void::io_error|3:i64|2:24|7:message|31:/@stdlib/console.void::io_error|6:string|2:32|17:bytes_transferred|31:/@stdlib/console.void::io_error|3:i64|2:40|7:partial|31:/@stdlib/console.void::io_error|13:readonly [u8]|2:48|12:cleanup_code|31:/@stdlib/console.void::io_error|3:i64|2:56|19:partial_utf16_units|31:/@stdlib/console.void::io_error|3:i64|2:64\00", align 1
@gc.offsets.12 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@51 = private unnamed_addr constant [57 x i8] c"void.array.element.v1/12:/@stdlib/console.void::io_error\00", align 1
@52 = private unnamed_addr constant [37 x i8] c"/@stdlib/console.void::io_error_kind\00", align 1
@53 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@54 = private unnamed_addr constant [61 x i8] c"4:4|4:$tag|36:/@stdlib/console.void::io_error_kind|3:i32|1:0\00", align 1
@gc.offsets.13 = private constant [0 x i64] zeroinitializer
@55 = private unnamed_addr constant [62 x i8] c"void.array.element.v1/12:/@stdlib/console.void::io_error_kind\00", align 1
@56 = private unnamed_addr constant [27 x i8] c"/@stdlib/console.void::key\00", align 1
@57 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@58 = private unnamed_addr constant [51 x i8] c"4:4|4:$tag|26:/@stdlib/console.void::key|3:i32|1:0\00", align 1
@gc.offsets.14 = private constant [0 x i64] zeroinitializer
@59 = private unnamed_addr constant [52 x i8] c"void.array.element.v1/12:/@stdlib/console.void::key\00", align 1
@60 = private unnamed_addr constant [33 x i8] c"/@stdlib/console.void::key_event\00", align 1
@61 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@62 = private unnamed_addr constant [631 x i8] c"40:8|9:character|32:/@stdlib/console.void::key_event|6:string|1:0|3:key|32:/@stdlib/console.void::key_event|26:/@stdlib/console.void::key|1:8|5:shift|32:/@stdlib/console.void::key_event|4:bool|2:12|3:alt|32:/@stdlib/console.void::key_event|4:bool|2:13|7:control|32:/@stdlib/console.void::key_event|4:bool|2:14|15:modifiers_known|32:/@stdlib/console.void::key_event|4:bool|2:15|14:key_down_known|32:/@stdlib/console.void::key_event|4:bool|2:16|8:key_down|32:/@stdlib/console.void::key_event|4:bool|2:17|12:repeat_count|32:/@stdlib/console.void::key_event|3:i64|2:24|5:bytes|32:/@stdlib/console.void::key_event|13:readonly [u8]|2:32\00", align 1
@gc.offsets.15 = private constant [2 x i64] [i64 0, i64 32]
@63 = private unnamed_addr constant [58 x i8] c"void.array.element.v1/12:/@stdlib/console.void::key_event\00", align 1
@64 = private unnamed_addr constant [30 x i8] c"/@stdlib/console.void::output\00", align 1
@65 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@66 = private unnamed_addr constant [53 x i8] c"8:8|3:_id|29:/@stdlib/console.void::output|3:i64|1:0\00", align 1
@gc.offsets.16 = private constant [0 x i64] zeroinitializer
@67 = private unnamed_addr constant [55 x i8] c"void.array.element.v1/12:/@stdlib/console.void::output\00", align 1
@68 = private unnamed_addr constant [45 x i8] c"/@stdlib/console.void::terminal_capabilities\00", align 1
@69 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@70 = private unnamed_addr constant [789 x i8] c"11:1|10:text_input|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:0|11:text_output|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:1|9:key_input|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:2|11:input_modes|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:3|4:size|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:4|15:cursor_position|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:5|17:cursor_visibility|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:6|5:color|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:7|5:clear|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:8|5:title|44:/@stdlib/console.void::terminal_capabilities|4:bool|1:9|4:bell|44:/@stdlib/console.void::terminal_capabilities|4:bool|2:10\00", align 1
@gc.offsets.17 = private constant [0 x i64] zeroinitializer
@71 = private unnamed_addr constant [70 x i8] c"void.array.element.v1/12:/@stdlib/console.void::terminal_capabilities\00", align 1
@72 = private unnamed_addr constant [41 x i8] c"/@stdlib/console.void::terminal_position\00", align 1
@73 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@74 = private unnamed_addr constant [128 x i8] c"16:8|6:column|40:/@stdlib/console.void::terminal_position|3:i64|1:0|3:row|40:/@stdlib/console.void::terminal_position|3:i64|1:8\00", align 1
@gc.offsets.18 = private constant [0 x i64] zeroinitializer
@75 = private unnamed_addr constant [66 x i8] c"void.array.element.v1/12:/@stdlib/console.void::terminal_position\00", align 1
@76 = private unnamed_addr constant [40 x i8] c"/@stdlib/console.void::terminal_session\00", align 1
@77 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@78 = private unnamed_addr constant [66 x i8] c"8:8|6:_token|39:/@stdlib/console.void::terminal_session|3:i64|1:0\00", align 1
@gc.offsets.19 = private constant [0 x i64] zeroinitializer
@79 = private unnamed_addr constant [65 x i8] c"void.array.element.v1/15:/@stdlib/console.void::terminal_session\00", align 1
@80 = private unnamed_addr constant [37 x i8] c"/@stdlib/console.void::terminal_size\00", align 1
@81 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@82 = private unnamed_addr constant [122 x i8] c"16:8|7:columns|36:/@stdlib/console.void::terminal_size|3:i64|1:0|4:rows|36:/@stdlib/console.void::terminal_size|3:i64|1:8\00", align 1
@gc.offsets.20 = private constant [0 x i64] zeroinitializer
@83 = private unnamed_addr constant [62 x i8] c"void.array.element.v1/12:/@stdlib/console.void::terminal_size\00", align 1
@84 = private unnamed_addr constant [33 x i8] c"/@stdlib/console.void::text_read\00", align 1
@85 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@86 = private unnamed_addr constant [122 x i8] c"16:8|4:$tag|32:/@stdlib/console.void::text_read|3:i32|1:0|11:$text$value|32:/@stdlib/console.void::text_read|6:string|1:8\00", align 1
@gc.offsets.21 = private constant [1 x i64] [i64 8]
@87 = private unnamed_addr constant [58 x i8] c"void.array.element.v1/12:/@stdlib/console.void::text_read\00", align 1
@__vd_types__v1 = constant [22 x { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 }] [{ ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @0, ptr @1, ptr @2, i64 80, ptr @gc.offsets, i64 4, ptr @3, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @4, ptr @5, ptr @6, i64 88, ptr @gc.offsets.1, i64 4, ptr @7, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @8, ptr @9, ptr @10, i64 120, ptr @gc.offsets.2, i64 6, ptr @11, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @12, ptr @13, ptr @14, i64 96, ptr @gc.offsets.3, i64 5, ptr @15, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @16, ptr @17, ptr @18, i64 96, ptr @gc.offsets.4, i64 5, ptr @19, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @20, ptr @21, ptr @22, i64 96, ptr @gc.offsets.5, i64 4, ptr @23, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @24, ptr @25, ptr @26, i64 88, ptr @gc.offsets.6, i64 5, ptr @27, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @28, ptr @29, ptr @30, i64 96, ptr @gc.offsets.7, i64 4, ptr @31, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @32, ptr @33, ptr @34, i64 80, ptr @gc.offsets.8, i64 2, ptr @35, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @36, ptr @37, ptr @38, i64 16, ptr @gc.offsets.9, i64 1, ptr @39, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @40, ptr @41, ptr @42, i64 4, ptr @gc.offsets.10, i64 0, ptr @43, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @44, ptr @45, ptr @46, i64 8, ptr @gc.offsets.11, i64 0, ptr @47, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @48, ptr @49, ptr @50, i64 72, ptr @gc.offsets.12, i64 4, ptr @51, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @52, ptr @53, ptr @54, i64 4, ptr @gc.offsets.13, i64 0, ptr @55, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @56, ptr @57, ptr @58, i64 4, ptr @gc.offsets.14, i64 0, ptr @59, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @60, ptr @61, ptr @62, i64 40, ptr @gc.offsets.15, i64 2, ptr @63, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @64, ptr @65, ptr @66, i64 8, ptr @gc.offsets.16, i64 0, ptr @67, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @68, ptr @69, ptr @70, i64 11, ptr @gc.offsets.17, i64 0, ptr @71, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @72, ptr @73, ptr @74, i64 16, ptr @gc.offsets.18, i64 0, ptr @75, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @76, ptr @77, ptr @78, i64 8, ptr @gc.offsets.19, i64 0, ptr @79, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @80, ptr @81, ptr @82, i64 16, ptr @gc.offsets.20, i64 0, ptr @83, i32 0 }, { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @84, ptr @85, ptr @86, i64 16, ptr @gc.offsets.21, i64 1, ptr @87, i32 0 }]
@__vd_type_count__v1 = constant i64 22
@dynamic_type_keys = private constant [22 x ptr] [ptr @0, ptr @4, ptr @8, ptr @12, ptr @16, ptr @20, ptr @24, ptr @28, ptr @32, ptr @36, ptr @40, ptr @44, ptr @48, ptr @52, ptr @56, ptr @60, ptr @64, ptr @68, ptr @72, ptr @76, ptr @80, ptr @84]
@__vd_witnesses__v1 = constant [0 x { ptr, ptr, ptr, ptr }] zeroinitializer
@__vd_witness_count__v1 = constant i64 0
@interface_binding_keys = private constant [0 x ptr] zeroinitializer
@gc.offsets.22 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.23 = private constant [1 x i64] zeroinitializer
@gc.offsets.24 = private constant [1 x i64] zeroinitializer
@gc.offsets.25 = private constant [1 x i64] zeroinitializer
@gc.offsets.26 = private constant [1 x i64] zeroinitializer
@gc.offsets.27 = private constant [1 x i64] zeroinitializer
@gc.offsets.28 = private constant [1 x i64] zeroinitializer
@gc.offsets.29 = private constant [1 x i64] zeroinitializer
@gc.offsets.30 = private constant [1 x i64] zeroinitializer
@gc.offsets.31 = private constant [1 x i64] zeroinitializer
@gc.offsets.32 = private constant [1 x i64] zeroinitializer
@gc.offsets.33 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.34 = private constant [1 x i64] zeroinitializer
@gc.offsets.35 = private constant [1 x i64] zeroinitializer
@gc.offsets.36 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.37 = private constant [1 x i64] zeroinitializer
@gc.offsets.38 = private constant [1 x i64] zeroinitializer
@gc.offsets.39 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.40 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.41 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.42 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.43 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.44 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.45 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.46 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.47 = private constant [1 x i64] zeroinitializer
@gc.offsets.48 = private constant [1 x i64] zeroinitializer
@gc.offsets.49 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.50 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.51 = private constant [1 x i64] zeroinitializer
@gc.offsets.52 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.53 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.54 = private constant [1 x i64] zeroinitializer
@gc.offsets.55 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.56 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.57 = private constant [1 x i64] zeroinitializer
@gc.offsets.58 = private constant [1 x i64] zeroinitializer
@gc.offsets.59 = private constant [1 x i64] zeroinitializer
@gc.offsets.60 = private constant [1 x i64] zeroinitializer
@gc.offsets.61 = private constant [1 x i64] zeroinitializer
@gc.offsets.62 = private constant [1 x i64] zeroinitializer
@gc.offsets.63 = private constant [1 x i64] zeroinitializer
@gc.offsets.64 = private constant [1 x i64] zeroinitializer
@gc.offsets.65 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.66 = private constant [1 x i64] zeroinitializer
@gc.offsets.67 = private constant [1 x i64] zeroinitializer
@88 = private unnamed_addr constant [7 x i8] c"stdout\00", align 1
@89 = private unnamed_addr constant [192 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:85:16: runtime error: String operation failed\0A        return \22stdout\22\0A               ^\0AIn function /@stdlib/console.void::_stream\0A\00", align 1
@90 = private unnamed_addr constant [7 x i8] c"stderr\00", align 1
@91 = private unnamed_addr constant [184 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:86:12: runtime error: String operation failed\0A    return \22stderr\22\0A           ^\0AIn function /@stdlib/console.void::_stream\0A\00", align 1
@gc.offsets.68 = private constant [1 x i64] zeroinitializer
@gc.offsets.69 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.70 = private constant [1 x i64] zeroinitializer
@gc.offsets.71 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.72 = private constant [1 x i64] zeroinitializer
@gc.offsets.73 = private constant [1 x i64] zeroinitializer
@gc.offsets.74 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.75 = private constant [1 x i64] zeroinitializer
@gc.offsets.76 = private constant [1 x i64] zeroinitializer
@gc.offsets.77 = private constant [1 x i64] zeroinitializer
@gc.offsets.78 = private constant [1 x i64] zeroinitializer
@gc.offsets.79 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.80 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.81 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.82 = private constant [1 x i64] zeroinitializer
@gc.offsets.83 = private constant [1 x i64] zeroinitializer
@gc.offsets.84 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.85 = private constant [1 x i64] zeroinitializer
@gc.offsets.86 = private constant [1 x i64] zeroinitializer
@gc.offsets.87 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.88 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.89 = private constant [4 x i64] [i64 16, i64 24, i64 48, i64 64]
@gc.offsets.90 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.91 = private constant [4 x i64] [i64 16, i64 24, i64 48, i64 64]
@92 = private unnamed_addr constant [199 x i8] c"Called from /@stdlib/console.void::output::method::write\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:91:17: source call\0A    var reply = _console_write(self, text)\0A                ^\0A\00", align 1
@93 = private unnamed_addr constant [6 x i8] c"write\00", align 1
@94 = private unnamed_addr constant [258 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:93:34: runtime error: String operation failed\0A        return Err(_error(reply, \22write\22, _stream(self)))\0A                                 ^\0AIn function /@stdlib/console.void::output::method::write\0A\00", align 1
@95 = private unnamed_addr constant [240 x i8] c"Called from /@stdlib/console.void::output::method::write\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:93:43: source call\0A        return Err(_error(reply, \22write\22, _stream(self)))\0A                                          ^\0A\00", align 1
@96 = private unnamed_addr constant [217 x i8] c"Called from /@stdlib/console.void::output::method::write\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:93:20: source call\0A        return Err(_error(reply, \22write\22, _stream(self)))\0A                   ^\0A\00", align 1
@gc.offsets.92 = private constant [1 x i64] zeroinitializer
@gc.offsets.93 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.94 = private constant [1 x i64] zeroinitializer
@gc.offsets.95 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.96 = private constant [1 x i64] zeroinitializer
@gc.offsets.97 = private constant [1 x i64] zeroinitializer
@gc.offsets.98 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.99 = private constant [1 x i64] zeroinitializer
@gc.offsets.100 = private constant [1 x i64] zeroinitializer
@gc.offsets.101 = private constant [1 x i64] zeroinitializer
@gc.offsets.102 = private constant [1 x i64] zeroinitializer
@gc.offsets.103 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.104 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.105 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.106 = private constant [1 x i64] zeroinitializer
@gc.offsets.107 = private constant [1 x i64] zeroinitializer
@gc.offsets.108 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.109 = private constant [1 x i64] zeroinitializer
@gc.offsets.110 = private constant [1 x i64] zeroinitializer
@gc.offsets.111 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.112 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.113 = private constant [4 x i64] [i64 16, i64 24, i64 48, i64 64]
@gc.offsets.114 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.115 = private constant [4 x i64] [i64 16, i64 24, i64 48, i64 64]
@97 = private unnamed_addr constant [212 x i8] c"Called from /@stdlib/console.void::output::method::write_bytes\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:98:17: source call\0A    var reply = _console_write_bytes(self, bytes)\0A                ^\0A\00", align 1
@98 = private unnamed_addr constant [12 x i8] c"write_bytes\00", align 1
@99 = private unnamed_addr constant [271 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:100:34: runtime error: String operation failed\0A        return Err(_error(reply, \22write_bytes\22, _stream(self)))\0A                                 ^\0AIn function /@stdlib/console.void::output::method::write_bytes\0A\00", align 1
@100 = private unnamed_addr constant [259 x i8] c"Called from /@stdlib/console.void::output::method::write_bytes\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:100:49: source call\0A        return Err(_error(reply, \22write_bytes\22, _stream(self)))\0A                                                ^\0A\00", align 1
@101 = private unnamed_addr constant [230 x i8] c"Called from /@stdlib/console.void::output::method::write_bytes\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:100:20: source call\0A        return Err(_error(reply, \22write_bytes\22, _stream(self)))\0A                   ^\0A\00", align 1
@gc.offsets.116 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.117 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.118 = private constant [1 x i64] zeroinitializer
@gc.offsets.119 = private constant [1 x i64] zeroinitializer
@gc.offsets.120 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.121 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.122 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.123 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.124 = private constant [1 x i64] zeroinitializer
@gc.offsets.125 = private constant [1 x i64] zeroinitializer
@gc.offsets.126 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.127 = private constant [1 x i64] zeroinitializer
@gc.offsets.128 = private constant [1 x i64] zeroinitializer
@gc.offsets.129 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.130 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.131 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@gc.offsets.132 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@102 = private unnamed_addr constant [194 x i8] c"Called from /@stdlib/console.void::output::method::flush\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:105:17: source call\0A    var reply = _console_flush(self)\0A                ^\0A\00", align 1
@103 = private unnamed_addr constant [6 x i8] c"flush\00", align 1
@104 = private unnamed_addr constant [259 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:107:34: runtime error: String operation failed\0A        return Err(_error(reply, \22flush\22, _stream(self)))\0A                                 ^\0AIn function /@stdlib/console.void::output::method::flush\0A\00", align 1
@105 = private unnamed_addr constant [241 x i8] c"Called from /@stdlib/console.void::output::method::flush\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:107:43: source call\0A        return Err(_error(reply, \22flush\22, _stream(self)))\0A                                          ^\0A\00", align 1
@106 = private unnamed_addr constant [218 x i8] c"Called from /@stdlib/console.void::output::method::flush\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:107:20: source call\0A        return Err(_error(reply, \22flush\22, _stream(self)))\0A                   ^\0A\00", align 1
@gc.offsets.133 = private constant [2 x i64] [i64 48, i64 56]
@107 = private unnamed_addr constant [228 x i8] c"Called from /@stdlib/console.void::output::method::is_redirected\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:112:16: source call\0A        return _console_redirected(self).progress != (0 as i64)\0A               ^\0A\00", align 1
@gc.offsets.134 = private constant [2 x i64] [i64 48, i64 56]
@108 = private unnamed_addr constant [227 x i8] c"Called from /@stdlib/console.void::input::method::is_redirected\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:116:16: source call\0A        return _console_redirected(self).progress != (0 as i64)\0A               ^\0A\00", align 1
@gc.offsets.135 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.136 = private constant [1 x i64] zeroinitializer
@gc.offsets.137 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.138 = private constant [1 x i64] zeroinitializer
@gc.offsets.139 = private constant [1 x i64] zeroinitializer
@gc.offsets.140 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.141 = private constant [1 x i64] [i64 8]
@gc.offsets.142 = private constant [1 x i64] zeroinitializer
@gc.offsets.143 = private constant [1 x i64] [i64 8]
@gc.offsets.144 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.145 = private constant [1 x i64] zeroinitializer
@gc.offsets.146 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.147 = private constant [1 x i64] zeroinitializer
@gc.offsets.148 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.149 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.150 = private constant [1 x i64] zeroinitializer
@gc.offsets.151 = private constant [1 x i64] zeroinitializer
@gc.offsets.152 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.153 = private constant [1 x i64] zeroinitializer
@gc.offsets.154 = private constant [1 x i64] zeroinitializer
@gc.offsets.155 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.156 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.157 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@gc.offsets.158 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.159 = private constant [1 x i64] [i64 8]
@gc.offsets.160 = private constant [1 x i64] [i64 8]
@gc.offsets.161 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@gc.offsets.162 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.163 = private constant [1 x i64] zeroinitializer
@gc.offsets.164 = private constant [1 x i64] zeroinitializer
@gc.offsets.165 = private constant [1 x i64] [i64 8]
@gc.offsets.166 = private constant [1 x i64] [i64 8]
@gc.offsets.167 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@109 = private unnamed_addr constant [6 x i8] c"stdin\00", align 1
@110 = private unnamed_addr constant [250 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:120:45: runtime error: String operation failed\0A        return Err(_error(reply, operation, \22stdin\22))\0A                                            ^\0AIn function /@stdlib/console.void::_text\0A\00", align 1
@111 = private unnamed_addr constant [198 x i8] c"Called from /@stdlib/console.void::_text\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:120:20: source call\0A        return Err(_error(reply, operation, \22stdin\22))\0A                   ^\0A\00", align 1
@gc.offsets.168 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.169 = private constant [1 x i64] zeroinitializer
@gc.offsets.170 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.171 = private constant [1 x i64] zeroinitializer
@gc.offsets.172 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.173 = private constant [1 x i64] zeroinitializer
@gc.offsets.174 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@112 = private unnamed_addr constant [229 x i8] c"Called from /@stdlib/console.void::input::method::read_char\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:128:18: source call\0A    return _text(_console_read_char(self, timeout_ms), \22read_char\22)\0A                 ^\0A\00", align 1
@113 = private unnamed_addr constant [10 x i8] c"read_char\00", align 1
@114 = private unnamed_addr constant [294 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:128:56: runtime error: String operation failed\0A    return _text(_console_read_char(self, timeout_ms), \22read_char\22)\0A                                                       ^\0AIn function /@stdlib/console.void::input::method::read_char\0A\00", align 1
@115 = private unnamed_addr constant [223 x i8] c"Called from /@stdlib/console.void::input::method::read_char\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:128:12: source call\0A    return _text(_console_read_char(self, timeout_ms), \22read_char\22)\0A           ^\0A\00", align 1
@gc.offsets.175 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.176 = private constant [1 x i64] zeroinitializer
@gc.offsets.177 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.178 = private constant [1 x i64] zeroinitializer
@gc.offsets.179 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.180 = private constant [1 x i64] zeroinitializer
@gc.offsets.181 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@116 = private unnamed_addr constant [242 x i8] c"Called from /@stdlib/console.void::input::method::read_text\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:132:18: source call\0A    return _text(_console_read_text(self, max_scalars, timeout_ms), \22read_text\22)\0A                 ^\0A\00", align 1
@117 = private unnamed_addr constant [10 x i8] c"read_text\00", align 1
@118 = private unnamed_addr constant [320 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:132:69: runtime error: String operation failed\0A    return _text(_console_read_text(self, max_scalars, timeout_ms), \22read_text\22)\0A                                                                    ^\0AIn function /@stdlib/console.void::input::method::read_text\0A\00", align 1
@119 = private unnamed_addr constant [236 x i8] c"Called from /@stdlib/console.void::input::method::read_text\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:132:12: source call\0A    return _text(_console_read_text(self, max_scalars, timeout_ms), \22read_text\22)\0A           ^\0A\00", align 1
@gc.offsets.182 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.183 = private constant [1 x i64] zeroinitializer
@gc.offsets.184 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.185 = private constant [1 x i64] zeroinitializer
@gc.offsets.186 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.187 = private constant [1 x i64] zeroinitializer
@gc.offsets.188 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@120 = private unnamed_addr constant [229 x i8] c"Called from /@stdlib/console.void::input::method::read_line\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:137:18: source call\0A    return _text(_console_read_line(self, timeout_ms), \22read_line\22)\0A                 ^\0A\00", align 1
@121 = private unnamed_addr constant [10 x i8] c"read_line\00", align 1
@122 = private unnamed_addr constant [294 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:137:56: runtime error: String operation failed\0A    return _text(_console_read_line(self, timeout_ms), \22read_line\22)\0A                                                       ^\0AIn function /@stdlib/console.void::input::method::read_line\0A\00", align 1
@123 = private unnamed_addr constant [223 x i8] c"Called from /@stdlib/console.void::input::method::read_line\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:137:12: source call\0A    return _text(_console_read_line(self, timeout_ms), \22read_line\22)\0A           ^\0A\00", align 1
@gc.offsets.189 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.190 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.191 = private constant [1 x i64] zeroinitializer
@gc.offsets.192 = private constant [1 x i64] zeroinitializer
@gc.offsets.193 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.194 = private constant [1 x i64] [i64 8]
@gc.offsets.195 = private constant [1 x i64] zeroinitializer
@gc.offsets.196 = private constant [1 x i64] [i64 8]
@gc.offsets.197 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.198 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.199 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.200 = private constant [1 x i64] zeroinitializer
@gc.offsets.201 = private constant [1 x i64] zeroinitializer
@gc.offsets.202 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.203 = private constant [1 x i64] zeroinitializer
@gc.offsets.204 = private constant [1 x i64] zeroinitializer
@gc.offsets.205 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.206 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.207 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@gc.offsets.208 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.209 = private constant [1 x i64] [i64 8]
@gc.offsets.210 = private constant [1 x i64] [i64 8]
@gc.offsets.211 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@gc.offsets.212 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.213 = private constant [1 x i64] zeroinitializer
@gc.offsets.214 = private constant [1 x i64] zeroinitializer
@gc.offsets.215 = private constant [1 x i64] [i64 8]
@gc.offsets.216 = private constant [1 x i64] [i64 8]
@gc.offsets.217 = private constant [5 x i64] [i64 16, i64 24, i64 32, i64 56, i64 72]
@124 = private unnamed_addr constant [226 x i8] c"Called from /@stdlib/console.void::input::method::read_bytes\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:141:17: source call\0A    var reply = _console_read_bytes(self, max_bytes, timeout_ms)\0A                ^\0A\00", align 1
@125 = private unnamed_addr constant [11 x i8] c"read_bytes\00", align 1
@126 = private unnamed_addr constant [262 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:143:34: runtime error: String operation failed\0A        return Err(_error(reply, \22read_bytes\22, \22stdin\22))\0A                                 ^\0AIn function /@stdlib/console.void::input::method::read_bytes\0A\00", align 1
@127 = private unnamed_addr constant [6 x i8] c"stdin\00", align 1
@128 = private unnamed_addr constant [276 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:143:48: runtime error: String operation failed\0A        return Err(_error(reply, \22read_bytes\22, \22stdin\22))\0A                                               ^\0AIn function /@stdlib/console.void::input::method::read_bytes\0A\00", align 1
@129 = private unnamed_addr constant [221 x i8] c"Called from /@stdlib/console.void::input::method::read_bytes\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:143:20: source call\0A        return Err(_error(reply, \22read_bytes\22, \22stdin\22))\0A                   ^\0A\00", align 1
@130 = private unnamed_addr constant [192 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:225:17: runtime error: Division by zero\0A    return mask / bit % 2 != 0\0A                ^\0AIn function /@stdlib/console.void::_flag\0A\00", align 1
@131 = private unnamed_addr constant [199 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:225:23: runtime error: Remainder by zero\0A    return mask / bit % 2 != 0\0A                      ^\0AIn function /@stdlib/console.void::_flag\0A\00", align 1
@gc.offsets.218 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.219 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.220 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.221 = private constant [2 x i64] [i64 48, i64 56]
@132 = private unnamed_addr constant [529 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:47: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                              ^\0A\00", align 1
@133 = private unnamed_addr constant [559 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:77: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                            ^\0A\00", align 1
@134 = private unnamed_addr constant [588 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:105: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                        ^\0A\00", align 1
@135 = private unnamed_addr constant [618 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:135: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                      ^\0A\00", align 1
@136 = private unnamed_addr constant [641 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:158: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                             ^\0A\00", align 1
@137 = private unnamed_addr constant [676 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:193: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                                                                ^\0A\00", align 1
@138 = private unnamed_addr constant [713 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:230: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                                                                                                     ^\0A\00", align 1
@139 = private unnamed_addr constant [738 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:255: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                                                                                                                              ^\0A\00", align 1
@140 = private unnamed_addr constant [764 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:281: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                                                                                                                                                        ^\0A\00", align 1
@141 = private unnamed_addr constant [790 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:307: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                                                                                                                                                                                  ^\0A\00", align 1
@142 = private unnamed_addr constant [815 x i8] c"Called from /@stdlib/console.void::_capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:229:332: source call\0A    return terminal_capabilities(text_input = _flag(mask, 1), text_output = _flag(mask, 2), key_input = _flag(mask, 4), input_modes = _flag(mask, 8), size = _flag(mask, 16), cursor_position = _flag(mask, 32), cursor_visibility = _flag(mask, 64), color = _flag(mask, 128), clear = _flag(mask, 256), title = _flag(mask, 512), bell = _flag(mask, 1024))\0A                                                                                                                                                                                                                                                                                                                                           ^\0A\00", align 1
@gc.offsets.222 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.223 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.224 = private constant [2 x i64] [i64 48, i64 56]
@143 = private unnamed_addr constant [226 x i8] c"Called from /@stdlib/console.void::input::method::capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:233:26: source call\0A    return _capabilities(_console_capabilities(self))\0A                         ^\0A\00", align 1
@144 = private unnamed_addr constant [212 x i8] c"Called from /@stdlib/console.void::input::method::capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:233:12: source call\0A    return _capabilities(_console_capabilities(self))\0A           ^\0A\00", align 1
@gc.offsets.225 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.226 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.227 = private constant [2 x i64] [i64 48, i64 56]
@145 = private unnamed_addr constant [227 x i8] c"Called from /@stdlib/console.void::output::method::capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:237:26: source call\0A    return _capabilities(_console_capabilities(self))\0A                         ^\0A\00", align 1
@146 = private unnamed_addr constant [213 x i8] c"Called from /@stdlib/console.void::output::method::capabilities\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:237:12: source call\0A    return _capabilities(_console_capabilities(self))\0A           ^\0A\00", align 1
@gc.offsets.228 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.229 = private constant [1 x i64] zeroinitializer
@gc.offsets.230 = private constant [1 x i64] zeroinitializer
@gc.offsets.231 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.232 = private constant [1 x i64] zeroinitializer
@gc.offsets.233 = private constant [1 x i64] zeroinitializer
@gc.offsets.234 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.235 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.236 = private constant [1 x i64] zeroinitializer
@gc.offsets.237 = private constant [1 x i64] zeroinitializer
@gc.offsets.238 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.239 = private constant [1 x i64] zeroinitializer
@gc.offsets.240 = private constant [1 x i64] zeroinitializer
@gc.offsets.241 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.242 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.243 = private constant [1 x i64] zeroinitializer
@gc.offsets.244 = private constant [1 x i64] zeroinitializer
@gc.offsets.245 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.246 = private constant [1 x i64] zeroinitializer
@gc.offsets.247 = private constant [1 x i64] zeroinitializer
@gc.offsets.248 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.249 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.250 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@gc.offsets.251 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@147 = private unnamed_addr constant [196 x i8] c"Called from /@stdlib/console.void::_ack\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:241:20: source call\0A        return Err(_error(reply, operation, stream))\0A                   ^\0A\00", align 1
@gc.offsets.252 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.253 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.254 = private constant [1 x i64] zeroinitializer
@gc.offsets.255 = private constant [1 x i64] zeroinitializer
@gc.offsets.256 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.257 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.258 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.259 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.260 = private constant [1 x i64] zeroinitializer
@gc.offsets.261 = private constant [1 x i64] zeroinitializer
@gc.offsets.262 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.263 = private constant [1 x i64] zeroinitializer
@gc.offsets.264 = private constant [1 x i64] zeroinitializer
@gc.offsets.265 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.266 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.267 = private constant [4 x i64] [i64 24, i64 32, i64 56, i64 72]
@gc.offsets.268 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.269 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.270 = private constant [4 x i64] [i64 24, i64 32, i64 56, i64 72]
@148 = private unnamed_addr constant [192 x i8] c"Called from /@stdlib/console.void::output::method::size\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:246:17: source call\0A    var reply = _console_size(self)\0A                ^\0A\00", align 1
@149 = private unnamed_addr constant [5 x i8] c"size\00", align 1
@150 = private unnamed_addr constant [257 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:248:34: runtime error: String operation failed\0A        return Err(_error(reply, \22size\22, _stream(self)))\0A                                 ^\0AIn function /@stdlib/console.void::output::method::size\0A\00", align 1
@151 = private unnamed_addr constant [238 x i8] c"Called from /@stdlib/console.void::output::method::size\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:248:42: source call\0A        return Err(_error(reply, \22size\22, _stream(self)))\0A                                         ^\0A\00", align 1
@152 = private unnamed_addr constant [216 x i8] c"Called from /@stdlib/console.void::output::method::size\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:248:20: source call\0A        return Err(_error(reply, \22size\22, _stream(self)))\0A                   ^\0A\00", align 1
@gc.offsets.271 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.272 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.273 = private constant [1 x i64] zeroinitializer
@gc.offsets.274 = private constant [1 x i64] zeroinitializer
@gc.offsets.275 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.276 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.277 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.278 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.279 = private constant [1 x i64] zeroinitializer
@gc.offsets.280 = private constant [1 x i64] zeroinitializer
@gc.offsets.281 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.282 = private constant [1 x i64] zeroinitializer
@gc.offsets.283 = private constant [1 x i64] zeroinitializer
@gc.offsets.284 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.285 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.286 = private constant [4 x i64] [i64 24, i64 32, i64 56, i64 72]
@gc.offsets.287 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.288 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.289 = private constant [4 x i64] [i64 24, i64 32, i64 56, i64 72]
@153 = private unnamed_addr constant [207 x i8] c"Called from /@stdlib/console.void::output::method::cursor_position\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:253:17: source call\0A    var reply = _console_position(self)\0A                ^\0A\00", align 1
@154 = private unnamed_addr constant [16 x i8] c"cursor_position\00", align 1
@155 = private unnamed_addr constant [279 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:255:34: runtime error: String operation failed\0A        return Err(_error(reply, \22cursor_position\22, _stream(self)))\0A                                 ^\0AIn function /@stdlib/console.void::output::method::cursor_position\0A\00", align 1
@156 = private unnamed_addr constant [271 x i8] c"Called from /@stdlib/console.void::output::method::cursor_position\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:255:53: source call\0A        return Err(_error(reply, \22cursor_position\22, _stream(self)))\0A                                                    ^\0A\00", align 1
@157 = private unnamed_addr constant [238 x i8] c"Called from /@stdlib/console.void::output::method::cursor_position\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:255:20: source call\0A        return Err(_error(reply, \22cursor_position\22, _stream(self)))\0A                   ^\0A\00", align 1
@gc.offsets.290 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.291 = private constant [1 x i64] zeroinitializer
@gc.offsets.292 = private constant [1 x i64] zeroinitializer
@gc.offsets.293 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.294 = private constant [1 x i64] zeroinitializer
@gc.offsets.295 = private constant [1 x i64] zeroinitializer
@gc.offsets.296 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.297 = private constant [1 x i64] zeroinitializer
@gc.offsets.298 = private constant [1 x i64] zeroinitializer
@gc.offsets.299 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@158 = private unnamed_addr constant [243 x i8] c"Called from /@stdlib/console.void::output::method::set_cursor\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:262:17: source call\0A    return _ack(_console_cursor(self, column, row), \22set_cursor\22, _stream(self))\0A                ^\0A\00", align 1
@159 = private unnamed_addr constant [11 x i8] c"set_cursor\00", align 1
@160 = private unnamed_addr constant [306 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:262:53: runtime error: String operation failed\0A    return _ack(_console_cursor(self, column, row), \22set_cursor\22, _stream(self))\0A                                                    ^\0AIn function /@stdlib/console.void::output::method::set_cursor\0A\00", align 1
@161 = private unnamed_addr constant [293 x i8] c"Called from /@stdlib/console.void::output::method::set_cursor\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:262:67: source call\0A    return _ack(_console_cursor(self, column, row), \22set_cursor\22, _stream(self))\0A                                                                  ^\0A\00", align 1
@162 = private unnamed_addr constant [238 x i8] c"Called from /@stdlib/console.void::output::method::set_cursor\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:262:12: source call\0A    return _ack(_console_cursor(self, column, row), \22set_cursor\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.300 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.301 = private constant [1 x i64] zeroinitializer
@gc.offsets.302 = private constant [1 x i64] zeroinitializer
@gc.offsets.303 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.304 = private constant [1 x i64] zeroinitializer
@gc.offsets.305 = private constant [1 x i64] zeroinitializer
@gc.offsets.306 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.307 = private constant [1 x i64] zeroinitializer
@gc.offsets.308 = private constant [1 x i64] zeroinitializer
@gc.offsets.309 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@163 = private unnamed_addr constant [253 x i8] c"Called from /@stdlib/console.void::output::method::set_cursor_visible\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:269:17: source call\0A    return _ack(_console_visible(self, flag), \22set_cursor_visible\22, _stream(self))\0A                ^\0A\00", align 1
@164 = private unnamed_addr constant [19 x i8] c"set_cursor_visible\00", align 1
@165 = private unnamed_addr constant [310 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:269:47: runtime error: String operation failed\0A    return _ack(_console_visible(self, flag), \22set_cursor_visible\22, _stream(self))\0A                                              ^\0AIn function /@stdlib/console.void::output::method::set_cursor_visible\0A\00", align 1
@166 = private unnamed_addr constant [305 x i8] c"Called from /@stdlib/console.void::output::method::set_cursor_visible\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:269:69: source call\0A    return _ack(_console_visible(self, flag), \22set_cursor_visible\22, _stream(self))\0A                                                                    ^\0A\00", align 1
@167 = private unnamed_addr constant [248 x i8] c"Called from /@stdlib/console.void::output::method::set_cursor_visible\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:269:12: source call\0A    return _ack(_console_visible(self, flag), \22set_cursor_visible\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.310 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.311 = private constant [1 x i64] zeroinitializer
@gc.offsets.312 = private constant [1 x i64] zeroinitializer
@gc.offsets.313 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.314 = private constant [1 x i64] zeroinitializer
@gc.offsets.315 = private constant [1 x i64] zeroinitializer
@gc.offsets.316 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.317 = private constant [1 x i64] zeroinitializer
@gc.offsets.318 = private constant [1 x i64] zeroinitializer
@gc.offsets.319 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@168 = private unnamed_addr constant [298 x i8] c"Called from /@stdlib/console.void::output::method::set_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:273:38: source call\0A    return _ack(_console_color(self, _color_code(foreground), _color_code(background)), \22set_color\22, _stream(self))\0A                                     ^\0A\00", align 1
@169 = private unnamed_addr constant [323 x i8] c"Called from /@stdlib/console.void::output::method::set_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:273:63: source call\0A    return _ack(_console_color(self, _color_code(foreground), _color_code(background)), \22set_color\22, _stream(self))\0A                                                              ^\0A\00", align 1
@170 = private unnamed_addr constant [277 x i8] c"Called from /@stdlib/console.void::output::method::set_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:273:17: source call\0A    return _ack(_console_color(self, _color_code(foreground), _color_code(background)), \22set_color\22, _stream(self))\0A                ^\0A\00", align 1
@171 = private unnamed_addr constant [10 x i8] c"set_color\00", align 1
@172 = private unnamed_addr constant [376 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:273:89: runtime error: String operation failed\0A    return _ack(_console_color(self, _color_code(foreground), _color_code(background)), \22set_color\22, _stream(self))\0A                                                                                        ^\0AIn function /@stdlib/console.void::output::method::set_color\0A\00", align 1
@173 = private unnamed_addr constant [363 x i8] c"Called from /@stdlib/console.void::output::method::set_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:273:102: source call\0A    return _ack(_console_color(self, _color_code(foreground), _color_code(background)), \22set_color\22, _stream(self))\0A                                                                                                     ^\0A\00", align 1
@174 = private unnamed_addr constant [272 x i8] c"Called from /@stdlib/console.void::output::method::set_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:273:12: source call\0A    return _ack(_console_color(self, _color_code(foreground), _color_code(background)), \22set_color\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.320 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.321 = private constant [1 x i64] zeroinitializer
@gc.offsets.322 = private constant [1 x i64] zeroinitializer
@gc.offsets.323 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.324 = private constant [1 x i64] zeroinitializer
@gc.offsets.325 = private constant [1 x i64] zeroinitializer
@gc.offsets.326 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.327 = private constant [1 x i64] zeroinitializer
@gc.offsets.328 = private constant [1 x i64] zeroinitializer
@gc.offsets.329 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@175 = private unnamed_addr constant [231 x i8] c"Called from /@stdlib/console.void::output::method::reset_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:277:17: source call\0A    return _ack(_console_reset(self), \22reset_color\22, _stream(self))\0A                ^\0A\00", align 1
@176 = private unnamed_addr constant [12 x i8] c"reset_color\00", align 1
@177 = private unnamed_addr constant [280 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:277:39: runtime error: String operation failed\0A    return _ack(_console_reset(self), \22reset_color\22, _stream(self))\0A                                      ^\0AIn function /@stdlib/console.void::output::method::reset_color\0A\00", align 1
@178 = private unnamed_addr constant [268 x i8] c"Called from /@stdlib/console.void::output::method::reset_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:277:54: source call\0A    return _ack(_console_reset(self), \22reset_color\22, _stream(self))\0A                                                     ^\0A\00", align 1
@179 = private unnamed_addr constant [226 x i8] c"Called from /@stdlib/console.void::output::method::reset_color\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:277:12: source call\0A    return _ack(_console_reset(self), \22reset_color\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.330 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.331 = private constant [1 x i64] zeroinitializer
@gc.offsets.332 = private constant [1 x i64] zeroinitializer
@gc.offsets.333 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.334 = private constant [1 x i64] zeroinitializer
@gc.offsets.335 = private constant [1 x i64] zeroinitializer
@gc.offsets.336 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.337 = private constant [1 x i64] zeroinitializer
@gc.offsets.338 = private constant [1 x i64] zeroinitializer
@gc.offsets.339 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@180 = private unnamed_addr constant [219 x i8] c"Called from /@stdlib/console.void::output::method::clear\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:281:17: source call\0A    return _ack(_console_clear(self), \22clear\22, _stream(self))\0A                ^\0A\00", align 1
@181 = private unnamed_addr constant [6 x i8] c"clear\00", align 1
@182 = private unnamed_addr constant [268 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:281:39: runtime error: String operation failed\0A    return _ack(_console_clear(self), \22clear\22, _stream(self))\0A                                      ^\0AIn function /@stdlib/console.void::output::method::clear\0A\00", align 1
@183 = private unnamed_addr constant [250 x i8] c"Called from /@stdlib/console.void::output::method::clear\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:281:48: source call\0A    return _ack(_console_clear(self), \22clear\22, _stream(self))\0A                                               ^\0A\00", align 1
@184 = private unnamed_addr constant [214 x i8] c"Called from /@stdlib/console.void::output::method::clear\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:281:12: source call\0A    return _ack(_console_clear(self), \22clear\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.340 = private constant [1 x i64] zeroinitializer
@gc.offsets.341 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.342 = private constant [1 x i64] zeroinitializer
@gc.offsets.343 = private constant [1 x i64] zeroinitializer
@gc.offsets.344 = private constant [1 x i64] zeroinitializer
@gc.offsets.345 = private constant [1 x i64] zeroinitializer
@gc.offsets.346 = private constant [1 x i64] zeroinitializer
@gc.offsets.347 = private constant [1 x i64] zeroinitializer
@gc.offsets.348 = private constant [1 x i64] zeroinitializer
@gc.offsets.349 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.350 = private constant [1 x i64] zeroinitializer
@gc.offsets.351 = private constant [1 x i64] zeroinitializer
@gc.offsets.352 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.353 = private constant [1 x i64] zeroinitializer
@gc.offsets.354 = private constant [1 x i64] zeroinitializer
@gc.offsets.355 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@185 = private unnamed_addr constant [233 x i8] c"Called from /@stdlib/console.void::output::method::set_title\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:285:17: source call\0A    return _ack(_console_title(self, text), \22set_title\22, _stream(self))\0A                ^\0A\00", align 1
@186 = private unnamed_addr constant [10 x i8] c"set_title\00", align 1
@187 = private unnamed_addr constant [288 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:285:45: runtime error: String operation failed\0A    return _ack(_console_title(self, text), \22set_title\22, _stream(self))\0A                                            ^\0AIn function /@stdlib/console.void::output::method::set_title\0A\00", align 1
@188 = private unnamed_addr constant [274 x i8] c"Called from /@stdlib/console.void::output::method::set_title\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:285:58: source call\0A    return _ack(_console_title(self, text), \22set_title\22, _stream(self))\0A                                                         ^\0A\00", align 1
@189 = private unnamed_addr constant [228 x i8] c"Called from /@stdlib/console.void::output::method::set_title\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:285:12: source call\0A    return _ack(_console_title(self, text), \22set_title\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.356 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.357 = private constant [1 x i64] zeroinitializer
@gc.offsets.358 = private constant [1 x i64] zeroinitializer
@gc.offsets.359 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.360 = private constant [1 x i64] zeroinitializer
@gc.offsets.361 = private constant [1 x i64] zeroinitializer
@gc.offsets.362 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.363 = private constant [1 x i64] zeroinitializer
@gc.offsets.364 = private constant [1 x i64] zeroinitializer
@gc.offsets.365 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@190 = private unnamed_addr constant [216 x i8] c"Called from /@stdlib/console.void::output::method::bell\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:289:17: source call\0A    return _ack(_console_bell(self), \22bell\22, _stream(self))\0A                ^\0A\00", align 1
@191 = private unnamed_addr constant [5 x i8] c"bell\00", align 1
@192 = private unnamed_addr constant [264 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:289:38: runtime error: String operation failed\0A    return _ack(_console_bell(self), \22bell\22, _stream(self))\0A                                     ^\0AIn function /@stdlib/console.void::output::method::bell\0A\00", align 1
@193 = private unnamed_addr constant [245 x i8] c"Called from /@stdlib/console.void::output::method::bell\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:289:46: source call\0A    return _ack(_console_bell(self), \22bell\22, _stream(self))\0A                                             ^\0A\00", align 1
@194 = private unnamed_addr constant [211 x i8] c"Called from /@stdlib/console.void::output::method::bell\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:289:12: source call\0A    return _ack(_console_bell(self), \22bell\22, _stream(self))\0A           ^\0A\00", align 1
@gc.offsets.366 = private constant [1 x i64] zeroinitializer
@gc.offsets.367 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.368 = private constant [1 x i64] zeroinitializer
@gc.offsets.369 = private constant [1 x i64] zeroinitializer
@gc.offsets.370 = private constant [1 x i64] zeroinitializer
@gc.offsets.371 = private constant [1 x i64] zeroinitializer
@gc.offsets.372 = private constant [1 x i64] zeroinitializer
@gc.offsets.373 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.374 = private constant [1 x i64] zeroinitializer
@gc.offsets.375 = private constant [1 x i64] zeroinitializer
@gc.offsets.376 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.377 = private constant [1 x i64] zeroinitializer
@gc.offsets.378 = private constant [1 x i64] zeroinitializer
@gc.offsets.379 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@195 = private unnamed_addr constant [259 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:297:17: runtime error: Invalid terminal session\0A    return _ack(_console_end_mode(self), \22close_mode\22, \22stdin\22)\0A                ^\0AIn function /@stdlib/console.void::terminal_session::method::close\0A\00", align 1
@196 = private unnamed_addr constant [231 x i8] c"Called from /@stdlib/console.void::terminal_session::method::close\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:297:17: source call\0A    return _ack(_console_end_mode(self), \22close_mode\22, \22stdin\22)\0A                ^\0A\00", align 1
@197 = private unnamed_addr constant [11 x i8] c"close_mode\00", align 1
@198 = private unnamed_addr constant [283 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:297:42: runtime error: String operation failed\0A    return _ack(_console_end_mode(self), \22close_mode\22, \22stdin\22)\0A                                         ^\0AIn function /@stdlib/console.void::terminal_session::method::close\0A\00", align 1
@199 = private unnamed_addr constant [6 x i8] c"stdin\00", align 1
@200 = private unnamed_addr constant [297 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:297:56: runtime error: String operation failed\0A    return _ack(_console_end_mode(self), \22close_mode\22, \22stdin\22)\0A                                                       ^\0AIn function /@stdlib/console.void::terminal_session::method::close\0A\00", align 1
@201 = private unnamed_addr constant [226 x i8] c"Called from /@stdlib/console.void::terminal_session::method::close\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:297:12: source call\0A    return _ack(_console_end_mode(self), \22close_mode\22, \22stdin\22)\0A           ^\0A\00", align 1
@gc.offsets.380 = private constant [1 x i64] zeroinitializer
@gc.offsets.381 = private constant [1 x i64] zeroinitializer
@202 = private unnamed_addr constant [150 x i8] c"Called from /@stdlib/console.void::terminal_session::method::deinit\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:299:30: source call\0A\00", align 1
@gc.offsets.382 = private constant [1 x i64] zeroinitializer
@gc.offsets.383 = private constant [1 x i64] zeroinitializer
@gc.offsets.384 = private constant [1 x i64] zeroinitializer
@gc.offsets.385 = private constant [1 x i64] zeroinitializer
@gc.offsets.386 = private constant [2 x i64] [i64 48, i64 56]
@203 = private unnamed_addr constant [210 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:300:5: runtime error: Invalid terminal session\0A    _console_restore(self)\0A    ^\0AIn function /@stdlib/console.void::terminal_session::method::deinit\0A\00", align 1
@204 = private unnamed_addr constant [182 x i8] c"Called from /@stdlib/console.void::terminal_session::method::deinit\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:300:5: source call\0A    _console_restore(self)\0A    ^\0A\00", align 1
@gc.offsets.387 = private constant [1 x i64] zeroinitializer
@gc.offsets.388 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.389 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.390 = private constant [1 x i64] zeroinitializer
@gc.offsets.391 = private constant [1 x i64] zeroinitializer
@gc.offsets.392 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.393 = private constant [1 x i64] zeroinitializer
@gc.offsets.394 = private constant [1 x i64] zeroinitializer
@gc.offsets.395 = private constant [1 x i64] zeroinitializer
@gc.offsets.396 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.397 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.398 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.399 = private constant [1 x i64] zeroinitializer
@gc.offsets.400 = private constant [1 x i64] zeroinitializer
@gc.offsets.401 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.402 = private constant [1 x i64] zeroinitializer
@gc.offsets.403 = private constant [1 x i64] zeroinitializer
@gc.offsets.404 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.405 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.406 = private constant [5 x i64] [i64 8, i64 16, i64 24, i64 48, i64 64]
@gc.offsets.407 = private constant [1 x i64] zeroinitializer
@gc.offsets.408 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.409 = private constant [1 x i64] zeroinitializer
@gc.offsets.410 = private constant [1 x i64] zeroinitializer
@gc.offsets.411 = private constant [1 x i64] zeroinitializer
@gc.offsets.412 = private constant [5 x i64] [i64 8, i64 16, i64 24, i64 48, i64 64]
@gc.offsets.413 = private constant [0 x i64] zeroinitializer
@205 = private unnamed_addr constant [40 x i8] c"/@stdlib/console.void::terminal_session\00", align 1
@206 = private unnamed_addr constant [252 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:311:19: runtime error: Managed construction allocation failed\0A    var session = terminal_session(_token = 0)\0A                  ^\0AIn function /@stdlib/console.void::input::method::begin_mode\0A\00", align 1
@207 = private unnamed_addr constant [204 x i8] c"Called from /@stdlib/console.void::input::method::begin_mode\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:312:17: source call\0A    var reply = _console_mode(self, flags)\0A                ^\0A\00", align 1
@208 = private unnamed_addr constant [11 x i8] c"begin_mode\00", align 1
@209 = private unnamed_addr constant [262 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:314:34: runtime error: String operation failed\0A        return Err(_error(reply, \22begin_mode\22, \22stdin\22))\0A                                 ^\0AIn function /@stdlib/console.void::input::method::begin_mode\0A\00", align 1
@210 = private unnamed_addr constant [6 x i8] c"stdin\00", align 1
@211 = private unnamed_addr constant [276 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:314:48: runtime error: String operation failed\0A        return Err(_error(reply, \22begin_mode\22, \22stdin\22))\0A                                               ^\0AIn function /@stdlib/console.void::input::method::begin_mode\0A\00", align 1
@212 = private unnamed_addr constant [221 x i8] c"Called from /@stdlib/console.void::input::method::begin_mode\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:314:20: source call\0A        return Err(_error(reply, \22begin_mode\22, \22stdin\22))\0A                   ^\0A\00", align 1
@213 = private unnamed_addr constant [183 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:314:16: runtime error: Null supplied for non-nullable field\0AIn function /@stdlib/console.void::input::method::begin_mode\0A\00", align 1
@214 = private unnamed_addr constant [207 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:315:5: runtime error: Null managed reference\0A    session._token = reply.first\0A    ^\0AIn function /@stdlib/console.void::input::method::begin_mode\0A\00", align 1
@215 = private unnamed_addr constant [183 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:316:12: runtime error: Null supplied for non-nullable field\0AIn function /@stdlib/console.void::input::method::begin_mode\0A\00", align 1
@gc.offsets.414 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.415 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.416 = private constant [1 x i64] zeroinitializer
@gc.offsets.417 = private constant [1 x i64] zeroinitializer
@gc.offsets.418 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.419 = private constant [1 x i64] zeroinitializer
@gc.offsets.420 = private constant [1 x i64] zeroinitializer
@gc.offsets.421 = private constant [1 x i64] zeroinitializer
@gc.offsets.422 = private constant [1 x i64] zeroinitializer
@gc.offsets.423 = private constant [2 x i64] [i64 0, i64 32]
@gc.offsets.424 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.425 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.426 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.427 = private constant [1 x i64] zeroinitializer
@gc.offsets.428 = private constant [1 x i64] zeroinitializer
@gc.offsets.429 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.430 = private constant [1 x i64] zeroinitializer
@gc.offsets.431 = private constant [1 x i64] zeroinitializer
@gc.offsets.432 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.433 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.434 = private constant [6 x i64] [i64 8, i64 40, i64 48, i64 56, i64 80, i64 96]
@gc.offsets.435 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.436 = private constant [1 x i64] zeroinitializer
@gc.offsets.437 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.438 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.439 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.440 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.441 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.442 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.443 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.444 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.445 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.446 = private constant [1 x i64] zeroinitializer
@gc.offsets.447 = private constant [1 x i64] zeroinitializer
@gc.offsets.448 = private constant [1 x i64] zeroinitializer
@gc.offsets.449 = private constant [1 x i64] zeroinitializer
@gc.offsets.450 = private constant [1 x i64] zeroinitializer
@gc.offsets.451 = private constant [2 x i64] [i64 0, i64 32]
@gc.offsets.452 = private constant [2 x i64] [i64 0, i64 32]
@gc.offsets.453 = private constant [6 x i64] [i64 8, i64 40, i64 48, i64 56, i64 80, i64 96]
@216 = private unnamed_addr constant [212 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:424:17: source call\0A    var reply = _console_key(self, flag, timeout_ms)\0A                ^\0A\00", align 1
@217 = private unnamed_addr constant [9 x i8] c"read_key\00", align 1
@218 = private unnamed_addr constant [258 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:426:34: runtime error: String operation failed\0A        return Err(_error(reply, \22read_key\22, \22stdin\22))\0A                                 ^\0AIn function /@stdlib/console.void::input::method::read_key\0A\00", align 1
@219 = private unnamed_addr constant [6 x i8] c"stdin\00", align 1
@220 = private unnamed_addr constant [270 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:426:46: runtime error: String operation failed\0A        return Err(_error(reply, \22read_key\22, \22stdin\22))\0A                                             ^\0AIn function /@stdlib/console.void::input::method::read_key\0A\00", align 1
@221 = private unnamed_addr constant [217 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:426:20: source call\0A        return Err(_error(reply, \22read_key\22, \22stdin\22))\0A                   ^\0A\00", align 1
@222 = private unnamed_addr constant [543 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:55: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                      ^\0A\00", align 1
@223 = private unnamed_addr constant [570 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:82: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                 ^\0A\00", align 1
@224 = private unnamed_addr constant [601 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:112: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                                               ^\0A\00", align 1
@225 = private unnamed_addr constant [635 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:146: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                                                                                 ^\0A\00", align 1
@226 = private unnamed_addr constant [677 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:188: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                                                                                                                           ^\0A\00", align 1
@227 = private unnamed_addr constant [718 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:229: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                                                                                                                                                                    ^\0A\00", align 1
@228 = private unnamed_addr constant [754 x i8] c"Called from /@stdlib/console.void::input::method::read_key\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:265: source call\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                                                                                                                                                                                                        ^\0A\00", align 1
@229 = private unnamed_addr constant [827 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:427:318: runtime error: Division by zero\0A    return Ok(key_event(character = reply.text, key = _key(reply.first), shift = _flag(reply.second, 1), alt = _flag(reply.second, 2), control = _flag(reply.second, 4), modifiers_known = _flag(reply.second, 8), key_down_known = _flag(reply.second, 16), key_down = _flag(reply.second, 32), repeat_count = reply.second / 256, bytes = reply.bytes))\0A                                                                                                                                                                                                                                                                                                                             ^\0AIn function /@stdlib/console.void::input::method::read_key\0A\00", align 1
@gc.offsets.454 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.455 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.456 = private constant [1 x i64] zeroinitializer
@gc.offsets.457 = private constant [1 x i64] zeroinitializer
@gc.offsets.458 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.459 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.460 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.461 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.462 = private constant [1 x i64] zeroinitializer
@gc.offsets.463 = private constant [1 x i64] zeroinitializer
@gc.offsets.464 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.465 = private constant [1 x i64] zeroinitializer
@gc.offsets.466 = private constant [1 x i64] zeroinitializer
@gc.offsets.467 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.468 = private constant [4 x i64] [i64 0, i64 8, i64 32, i64 48]
@gc.offsets.469 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@gc.offsets.470 = private constant [2 x i64] [i64 48, i64 56]
@gc.offsets.471 = private constant [4 x i64] [i64 8, i64 16, i64 40, i64 56]
@230 = private unnamed_addr constant [205 x i8] c"Called from /@stdlib/console.void::input::method::key_available\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:431:17: source call\0A    var reply = _console_available(self)\0A                ^\0A\00", align 1
@231 = private unnamed_addr constant [14 x i8] c"key_available\00", align 1
@232 = private unnamed_addr constant [268 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:433:34: runtime error: String operation failed\0A        return Err(_error(reply, \22key_available\22, \22stdin\22))\0A                                 ^\0AIn function /@stdlib/console.void::input::method::key_available\0A\00", align 1
@233 = private unnamed_addr constant [6 x i8] c"stdin\00", align 1
@234 = private unnamed_addr constant [285 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/console.void:433:51: runtime error: String operation failed\0A        return Err(_error(reply, \22key_available\22, \22stdin\22))\0A                                                  ^\0AIn function /@stdlib/console.void::input::method::key_available\0A\00", align 1
@235 = private unnamed_addr constant [227 x i8] c"Called from /@stdlib/console.void::input::method::key_available\0A/home/shmellyorc/Documents/Void.Language/stdlib/console.void:433:20: source call\0A        return Err(_error(reply, \22key_available\22, \22stdin\22))\0A                   ^\0A\00", align 1
@gc.offsets.472 = private constant [1 x i64] zeroinitializer
@gc.offsets.473 = private constant [1 x i64] zeroinitializer
@gc.offsets.474 = private constant [1 x i64] zeroinitializer
@gc.offsets.475 = private constant [1 x i64] zeroinitializer
@gc.offsets.476 = private constant [1 x i64] zeroinitializer
@gc.offsets.477 = private constant [1 x i64] zeroinitializer
@gc.offsets.478 = private constant [1 x i64] zeroinitializer
@gc.offsets.479 = private constant [1 x i64] zeroinitializer
@gc.offsets.480 = private constant [1 x i64] zeroinitializer
@gc.offsets.481 = private constant [1 x i64] zeroinitializer
@gc.offsets.482 = private constant [1 x i64] zeroinitializer
@gc.offsets.483 = private constant [1 x i64] zeroinitializer
@gc.offsets.484 = private constant [1 x i64] zeroinitializer
@gc.offsets.485 = private constant [1 x i64] zeroinitializer
@gc.offsets.486 = private constant [1 x i64] zeroinitializer
@gc.offsets.487 = private constant [1 x i64] zeroinitializer
@gc.offsets.488 = private constant [1 x i64] zeroinitializer
@gc.offsets.489 = private constant [1 x i64] zeroinitializer
@gc.offsets.490 = private constant [1 x i64] zeroinitializer
@gc.offsets.491 = private constant [1 x i64] zeroinitializer
@gc.offsets.492 = private constant [1 x i64] zeroinitializer
@gc.offsets.493 = private constant [1 x i64] zeroinitializer
@gc.offsets.494 = private constant [1 x i64] zeroinitializer
@gc.offsets.495 = private constant [1 x i64] zeroinitializer
@gc.offsets.496 = private constant [1 x i64] zeroinitializer
@gc.offsets.497 = private constant [1 x i64] zeroinitializer
@gc.offsets.498 = private constant [1 x i64] zeroinitializer
@gc.offsets.499 = private constant [1 x i64] zeroinitializer
@gc.offsets.500 = private constant [1 x i64] zeroinitializer
@gc.offsets.501 = private constant [1 x i64] zeroinitializer
@gc.offsets.502 = private constant [1 x i64] zeroinitializer
@gc.offsets.503 = private constant [1 x i64] zeroinitializer
@gc.offsets.504 = private constant [1 x i64] zeroinitializer
@gc.offsets.505 = private constant [1 x i64] zeroinitializer
@gc.offsets.506 = private constant [1 x i64] zeroinitializer
@gc.offsets.507 = private constant [1 x i64] zeroinitializer
@gc.offsets.508 = private constant [1 x i64] zeroinitializer
@gc.offsets.509 = private constant [1 x i64] zeroinitializer
@236 = private unnamed_addr constant [2 x i8] c" \00", align 1
@237 = private unnamed_addr constant [138 x i8] c"/tmp/VOID-console27-41977497569637/main.void:3:5: runtime error: String operation failed\0A    print()\0A    ^\0AIn function /main.void::entry\0A\00", align 1
@238 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@239 = private unnamed_addr constant [138 x i8] c"/tmp/VOID-console27-41977497569637/main.void:3:5: runtime error: String operation failed\0A    print()\0A    ^\0AIn function /main.void::entry\0A\00", align 1
@240 = private unnamed_addr constant [135 x i8] c"/tmp/VOID-console27-41977497569637/main.void:3:5: runtime error: Interpolation failed\0A    print()\0A    ^\0AIn function /main.void::entry\0A\00", align 1
@241 = private unnamed_addr constant [111 x i8] c"Called from /main.void::entry\0A/tmp/VOID-console27-41977497569637/main.void:3:5: source call\0A    print()\0A    ^\0A\00", align 1
@242 = private unnamed_addr constant [6 x i8] c"value\00", align 1
@243 = private unnamed_addr constant [183 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:11: runtime error: String operation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A          ^\0AIn function /main.void::entry\0A\00", align 1
@244 = private unnamed_addr constant [2 x i8] c"|\00", align 1
@245 = private unnamed_addr constant [207 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:35: runtime error: String operation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A                                  ^\0AIn function /main.void::entry\0A\00", align 1
@246 = private unnamed_addr constant [2 x i8] c"!\00", align 1
@247 = private unnamed_addr constant [218 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:46: runtime error: String operation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A                                             ^\0AIn function /main.void::entry\0A\00", align 1
@248 = private unnamed_addr constant [184 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:11: runtime error: Display operation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A          ^\0AIn function /main.void::entry\0A\00", align 1
@249 = private unnamed_addr constant [193 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:20: runtime error: Display operation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A                   ^\0AIn function /main.void::entry\0A\00", align 1
@250 = private unnamed_addr constant [196 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:23: runtime error: Display operation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A                      ^\0AIn function /main.void::entry\0A\00", align 1
@251 = private unnamed_addr constant [173 x i8] c"/tmp/VOID-console27-41977497569637/main.void:4:5: runtime error: Interpolation failed\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A    ^\0AIn function /main.void::entry\0A\00", align 1
@252 = private unnamed_addr constant [149 x i8] c"Called from /main.void::entry\0A/tmp/VOID-console27-41977497569637/main.void:4:5: source call\0A    print(\22value\22, n, true, sep = \22|\22, end = \22!\22)\0A    ^\0A\00", align 1
@253 = private unnamed_addr constant [4 x i8] c"ERR\00", align 1
@254 = private unnamed_addr constant [183 x i8] c"/tmp/VOID-console27-41977497569637/main.void:5:11: runtime error: String operation failed\0A    print(\22ERR\22, file = console.stderr, end = \22\22)\0A          ^\0AIn function /main.void::entry\0A\00", align 1
@255 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@256 = private unnamed_addr constant [219 x i8] c"/tmp/VOID-console27-41977497569637/main.void:5:47: runtime error: String operation failed\0A    print(\22ERR\22, file = console.stderr, end = \22\22)\0A                                              ^\0AIn function /main.void::entry\0A\00", align 1
@257 = private unnamed_addr constant [184 x i8] c"/tmp/VOID-console27-41977497569637/main.void:5:11: runtime error: Display operation failed\0A    print(\22ERR\22, file = console.stderr, end = \22\22)\0A          ^\0AIn function /main.void::entry\0A\00", align 1
@258 = private unnamed_addr constant [2 x i8] c" \00", align 1
@259 = private unnamed_addr constant [176 x i8] c"/tmp/VOID-console27-41977497569637/main.void:5:5: runtime error: String operation failed\0A    print(\22ERR\22, file = console.stderr, end = \22\22)\0A    ^\0AIn function /main.void::entry\0A\00", align 1
@260 = private unnamed_addr constant [173 x i8] c"/tmp/VOID-console27-41977497569637/main.void:5:5: runtime error: Interpolation failed\0A    print(\22ERR\22, file = console.stderr, end = \22\22)\0A    ^\0AIn function /main.void::entry\0A\00", align 1
@261 = private unnamed_addr constant [149 x i8] c"Called from /main.void::entry\0A/tmp/VOID-console27-41977497569637/main.void:5:5: source call\0A    print(\22ERR\22, file = console.stderr, end = \22\22)\0A    ^\0A\00", align 1

define internal %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %0, ptr %1, ptr %2, ptr %3) !dbg !3 {
block0:
  %4 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::io_error_kind", align 8
  store %"/@stdlib/console.void::io_error_kind" zeroinitializer, ptr %7, align 4
  %8 = alloca i64, align 8
  store i64 0, ptr %8, align 8
  %9 = alloca i64, align 8
  store i64 0, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca i64, align 8
  store i64 0, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = alloca i64, align 8
  store i64 0, ptr %15, align 8
  %16 = alloca ptr, align 8
  store ptr null, ptr %16, align 8
  %17 = alloca ptr, align 8
  store ptr null, ptr %17, align 8
  %18 = alloca %"/@stdlib/console.void::io_error_kind", align 8
  store %"/@stdlib/console.void::io_error_kind" zeroinitializer, ptr %18, align 4
  %19 = alloca i64, align 8
  store i64 0, ptr %19, align 8
  %20 = alloca ptr, align 8
  store ptr null, ptr %20, align 8
  %21 = alloca i64, align 8
  store i64 0, ptr %21, align 8
  %22 = alloca ptr, align 8
  store ptr null, ptr %22, align 8
  %23 = alloca i64, align 8
  store i64 0, ptr %23, align 8
  %24 = alloca i64, align 8
  store i64 0, ptr %24, align 8
  %25 = alloca ptr, align 8
  store ptr null, ptr %25, align 8
  %26 = alloca ptr, align 8
  store ptr null, ptr %26, align 8
  %27 = alloca %"/@stdlib/console.void::io_error_kind", align 8
  store %"/@stdlib/console.void::io_error_kind" zeroinitializer, ptr %27, align 4
  %28 = alloca i64, align 8
  store i64 0, ptr %28, align 8
  %29 = alloca ptr, align 8
  store ptr null, ptr %29, align 8
  %30 = alloca i64, align 8
  store i64 0, ptr %30, align 8
  %31 = alloca ptr, align 8
  store ptr null, ptr %31, align 8
  %32 = alloca i64, align 8
  store i64 0, ptr %32, align 8
  %33 = alloca i64, align 8
  store i64 0, ptr %33, align 8
  %34 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 80, 1
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, ptr @gc.offsets.22, 2
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 2, 3
  %38 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 8, 1
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, ptr @gc.offsets.23, 2
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 1, 3
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 8, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.24, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 1, 3
  %46 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %16, 0
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 8, 1
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, ptr @gc.offsets.25, 2
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 1, 3
  %50 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %17, 0
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 8, 1
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, ptr @gc.offsets.26, 2
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 1, 3
  %54 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %20, 0
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 8, 1
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, ptr @gc.offsets.27, 2
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 1, 3
  %58 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %22, 0
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, i64 8, 1
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, ptr @gc.offsets.28, 2
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 1, 3
  %62 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %25, 0
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 8, 1
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, ptr @gc.offsets.29, 2
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 1, 3
  %66 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %26, 0
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, i64 8, 1
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, ptr @gc.offsets.30, 2
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, i64 1, 3
  %70 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %29, 0
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 8, 1
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, ptr @gc.offsets.31, 2
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 1, 3
  %74 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %31, 0
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 8, 1
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, ptr @gc.offsets.32, 2
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, i64 1, 3
  %78 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" %0, ptr %78, align 8
  %79 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %78, 0
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 80, 1
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, ptr @gc.offsets.33, 2
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, i64 2, 3
  %83 = alloca ptr, align 8
  store ptr %1, ptr %83, align 8
  %84 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %83, 0
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 8, 1
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, ptr @gc.offsets.34, 2
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, i64 1, 3
  %88 = alloca ptr, align 8
  store ptr %2, ptr %88, align 8
  %89 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %88, 0
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 8, 1
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, ptr @gc.offsets.35, 2
  %92 = insertvalue { ptr, i64, ptr, i64 } %91, i64 1, 3
  %93 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %93, align 8
  %94 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %93, 0
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 80, 1
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, ptr @gc.offsets.36, 2
  %97 = insertvalue { ptr, i64, ptr, i64 } %96, i64 2, 3
  %98 = alloca ptr, align 8
  store ptr null, ptr %98, align 8
  %99 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %98, 0
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 8, 1
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, ptr @gc.offsets.37, 2
  %102 = insertvalue { ptr, i64, ptr, i64 } %101, i64 1, 3
  %103 = alloca ptr, align 8
  store ptr null, ptr %103, align 8
  %104 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %103, 0
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 8, 1
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, ptr @gc.offsets.38, 2
  %107 = insertvalue { ptr, i64, ptr, i64 } %106, i64 1, 3
  %108 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %108, align 8
  %109 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %108, 0
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, i64 80, 1
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, ptr @gc.offsets.39, 2
  %112 = insertvalue { ptr, i64, ptr, i64 } %111, i64 2, 3
  %113 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %113, align 8
  %114 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %113, 0
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, i64 80, 1
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, ptr @gc.offsets.40, 2
  %117 = insertvalue { ptr, i64, ptr, i64 } %116, i64 2, 3
  %118 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %118, align 8
  %119 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %118, 0
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, i64 80, 1
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, ptr @gc.offsets.41, 2
  %122 = insertvalue { ptr, i64, ptr, i64 } %121, i64 2, 3
  %123 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %123, align 8
  %124 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %123, 0
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, i64 80, 1
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, ptr @gc.offsets.42, 2
  %127 = insertvalue { ptr, i64, ptr, i64 } %126, i64 2, 3
  %128 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %128, align 8
  %129 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %128, 0
  %130 = insertvalue { ptr, i64, ptr, i64 } %129, i64 80, 1
  %131 = insertvalue { ptr, i64, ptr, i64 } %130, ptr @gc.offsets.43, 2
  %132 = insertvalue { ptr, i64, ptr, i64 } %131, i64 2, 3
  %133 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %133, align 8
  %134 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %133, 0
  %135 = insertvalue { ptr, i64, ptr, i64 } %134, i64 80, 1
  %136 = insertvalue { ptr, i64, ptr, i64 } %135, ptr @gc.offsets.44, 2
  %137 = insertvalue { ptr, i64, ptr, i64 } %136, i64 2, 3
  %138 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %138, align 8
  %139 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %138, 0
  %140 = insertvalue { ptr, i64, ptr, i64 } %139, i64 80, 1
  %141 = insertvalue { ptr, i64, ptr, i64 } %140, ptr @gc.offsets.45, 2
  %142 = insertvalue { ptr, i64, ptr, i64 } %141, i64 2, 3
  %143 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %143, align 8
  %144 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %143, 0
  %145 = insertvalue { ptr, i64, ptr, i64 } %144, i64 80, 1
  %146 = insertvalue { ptr, i64, ptr, i64 } %145, ptr @gc.offsets.46, 2
  %147 = insertvalue { ptr, i64, ptr, i64 } %146, i64 2, 3
  %148 = alloca ptr, align 8
  store ptr null, ptr %148, align 8
  %149 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %148, 0
  %150 = insertvalue { ptr, i64, ptr, i64 } %149, i64 8, 1
  %151 = insertvalue { ptr, i64, ptr, i64 } %150, ptr @gc.offsets.47, 2
  %152 = insertvalue { ptr, i64, ptr, i64 } %151, i64 1, 3
  %153 = alloca ptr, align 8
  store ptr null, ptr %153, align 8
  %154 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %153, 0
  %155 = insertvalue { ptr, i64, ptr, i64 } %154, i64 8, 1
  %156 = insertvalue { ptr, i64, ptr, i64 } %155, ptr @gc.offsets.48, 2
  %157 = insertvalue { ptr, i64, ptr, i64 } %156, i64 1, 3
  %158 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %158, align 8
  %159 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %158, 0
  %160 = insertvalue { ptr, i64, ptr, i64 } %159, i64 80, 1
  %161 = insertvalue { ptr, i64, ptr, i64 } %160, ptr @gc.offsets.49, 2
  %162 = insertvalue { ptr, i64, ptr, i64 } %161, i64 2, 3
  %163 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %163, align 8
  %164 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %163, 0
  %165 = insertvalue { ptr, i64, ptr, i64 } %164, i64 80, 1
  %166 = insertvalue { ptr, i64, ptr, i64 } %165, ptr @gc.offsets.50, 2
  %167 = insertvalue { ptr, i64, ptr, i64 } %166, i64 2, 3
  %168 = alloca ptr, align 8
  store ptr null, ptr %168, align 8
  %169 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %168, 0
  %170 = insertvalue { ptr, i64, ptr, i64 } %169, i64 8, 1
  %171 = insertvalue { ptr, i64, ptr, i64 } %170, ptr @gc.offsets.51, 2
  %172 = insertvalue { ptr, i64, ptr, i64 } %171, i64 1, 3
  %173 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %173, align 8
  %174 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %173, 0
  %175 = insertvalue { ptr, i64, ptr, i64 } %174, i64 80, 1
  %176 = insertvalue { ptr, i64, ptr, i64 } %175, ptr @gc.offsets.52, 2
  %177 = insertvalue { ptr, i64, ptr, i64 } %176, i64 2, 3
  %178 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %178, align 8
  %179 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %178, 0
  %180 = insertvalue { ptr, i64, ptr, i64 } %179, i64 80, 1
  %181 = insertvalue { ptr, i64, ptr, i64 } %180, ptr @gc.offsets.53, 2
  %182 = insertvalue { ptr, i64, ptr, i64 } %181, i64 2, 3
  %183 = alloca ptr, align 8
  store ptr null, ptr %183, align 8
  %184 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %183, 0
  %185 = insertvalue { ptr, i64, ptr, i64 } %184, i64 8, 1
  %186 = insertvalue { ptr, i64, ptr, i64 } %185, ptr @gc.offsets.54, 2
  %187 = insertvalue { ptr, i64, ptr, i64 } %186, i64 1, 3
  %188 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %188, align 8
  %189 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %188, 0
  %190 = insertvalue { ptr, i64, ptr, i64 } %189, i64 80, 1
  %191 = insertvalue { ptr, i64, ptr, i64 } %190, ptr @gc.offsets.55, 2
  %192 = insertvalue { ptr, i64, ptr, i64 } %191, i64 2, 3
  %193 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %193, align 8
  %194 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %193, 0
  %195 = insertvalue { ptr, i64, ptr, i64 } %194, i64 80, 1
  %196 = insertvalue { ptr, i64, ptr, i64 } %195, ptr @gc.offsets.56, 2
  %197 = insertvalue { ptr, i64, ptr, i64 } %196, i64 2, 3
  %198 = alloca ptr, align 8
  store ptr null, ptr %198, align 8
  %199 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %198, 0
  %200 = insertvalue { ptr, i64, ptr, i64 } %199, i64 8, 1
  %201 = insertvalue { ptr, i64, ptr, i64 } %200, ptr @gc.offsets.57, 2
  %202 = insertvalue { ptr, i64, ptr, i64 } %201, i64 1, 3
  %203 = alloca ptr, align 8
  store ptr null, ptr %203, align 8
  %204 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %203, 0
  %205 = insertvalue { ptr, i64, ptr, i64 } %204, i64 8, 1
  %206 = insertvalue { ptr, i64, ptr, i64 } %205, ptr @gc.offsets.58, 2
  %207 = insertvalue { ptr, i64, ptr, i64 } %206, i64 1, 3
  %208 = alloca ptr, align 8
  store ptr null, ptr %208, align 8
  %209 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %208, 0
  %210 = insertvalue { ptr, i64, ptr, i64 } %209, i64 8, 1
  %211 = insertvalue { ptr, i64, ptr, i64 } %210, ptr @gc.offsets.59, 2
  %212 = insertvalue { ptr, i64, ptr, i64 } %211, i64 1, 3
  %213 = alloca ptr, align 8
  store ptr null, ptr %213, align 8
  %214 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %213, 0
  %215 = insertvalue { ptr, i64, ptr, i64 } %214, i64 8, 1
  %216 = insertvalue { ptr, i64, ptr, i64 } %215, ptr @gc.offsets.60, 2
  %217 = insertvalue { ptr, i64, ptr, i64 } %216, i64 1, 3
  %218 = alloca ptr, align 8
  store ptr null, ptr %218, align 8
  %219 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %218, 0
  %220 = insertvalue { ptr, i64, ptr, i64 } %219, i64 8, 1
  %221 = insertvalue { ptr, i64, ptr, i64 } %220, ptr @gc.offsets.61, 2
  %222 = insertvalue { ptr, i64, ptr, i64 } %221, i64 1, 3
  %223 = alloca ptr, align 8
  store ptr null, ptr %223, align 8
  %224 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %223, 0
  %225 = insertvalue { ptr, i64, ptr, i64 } %224, i64 8, 1
  %226 = insertvalue { ptr, i64, ptr, i64 } %225, ptr @gc.offsets.62, 2
  %227 = insertvalue { ptr, i64, ptr, i64 } %226, i64 1, 3
  %228 = alloca ptr, align 8
  store ptr null, ptr %228, align 8
  %229 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %228, 0
  %230 = insertvalue { ptr, i64, ptr, i64 } %229, i64 8, 1
  %231 = insertvalue { ptr, i64, ptr, i64 } %230, ptr @gc.offsets.63, 2
  %232 = insertvalue { ptr, i64, ptr, i64 } %231, i64 1, 3
  %233 = alloca ptr, align 8
  store ptr null, ptr %233, align 8
  %234 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %233, 0
  %235 = insertvalue { ptr, i64, ptr, i64 } %234, i64 8, 1
  %236 = insertvalue { ptr, i64, ptr, i64 } %235, ptr @gc.offsets.64, 2
  %237 = insertvalue { ptr, i64, ptr, i64 } %236, i64 1, 3
  %238 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %238, align 8
  %239 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %238, 0
  %240 = insertvalue { ptr, i64, ptr, i64 } %239, i64 72, 1
  %241 = insertvalue { ptr, i64, ptr, i64 } %240, ptr @gc.offsets.65, 2
  %242 = insertvalue { ptr, i64, ptr, i64 } %241, i64 4, 3
  %243 = alloca [44 x { ptr, i64, ptr, i64 }], align 8
  %244 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %37, ptr %244, align 8
  %245 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %41, ptr %245, align 8
  %246 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %45, ptr %246, align 8
  %247 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %49, ptr %247, align 8
  %248 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %53, ptr %248, align 8
  %249 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %57, ptr %249, align 8
  %250 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %61, ptr %250, align 8
  %251 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %65, ptr %251, align 8
  %252 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %69, ptr %252, align 8
  %253 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %73, ptr %253, align 8
  %254 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %77, ptr %254, align 8
  %255 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %82, ptr %255, align 8
  %256 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %87, ptr %256, align 8
  %257 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %92, ptr %257, align 8
  %258 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %97, ptr %258, align 8
  %259 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %102, ptr %259, align 8
  %260 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %107, ptr %260, align 8
  %261 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %112, ptr %261, align 8
  %262 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %117, ptr %262, align 8
  %263 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %122, ptr %263, align 8
  %264 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %127, ptr %264, align 8
  %265 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %132, ptr %265, align 8
  %266 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %137, ptr %266, align 8
  %267 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %142, ptr %267, align 8
  %268 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 24
  store { ptr, i64, ptr, i64 } %147, ptr %268, align 8
  %269 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 25
  store { ptr, i64, ptr, i64 } %152, ptr %269, align 8
  %270 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 26
  store { ptr, i64, ptr, i64 } %157, ptr %270, align 8
  %271 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 27
  store { ptr, i64, ptr, i64 } %162, ptr %271, align 8
  %272 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 28
  store { ptr, i64, ptr, i64 } %167, ptr %272, align 8
  %273 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 29
  store { ptr, i64, ptr, i64 } %172, ptr %273, align 8
  %274 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 30
  store { ptr, i64, ptr, i64 } %177, ptr %274, align 8
  %275 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 31
  store { ptr, i64, ptr, i64 } %182, ptr %275, align 8
  %276 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 32
  store { ptr, i64, ptr, i64 } %187, ptr %276, align 8
  %277 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 33
  store { ptr, i64, ptr, i64 } %192, ptr %277, align 8
  %278 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 34
  store { ptr, i64, ptr, i64 } %197, ptr %278, align 8
  %279 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 35
  store { ptr, i64, ptr, i64 } %202, ptr %279, align 8
  %280 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 36
  store { ptr, i64, ptr, i64 } %207, ptr %280, align 8
  %281 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 37
  store { ptr, i64, ptr, i64 } %212, ptr %281, align 8
  %282 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 38
  store { ptr, i64, ptr, i64 } %217, ptr %282, align 8
  %283 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 39
  store { ptr, i64, ptr, i64 } %222, ptr %283, align 8
  %284 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 40
  store { ptr, i64, ptr, i64 } %227, ptr %284, align 8
  %285 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 41
  store { ptr, i64, ptr, i64 } %232, ptr %285, align 8
  %286 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 42
  store { ptr, i64, ptr, i64 } %237, ptr %286, align 8
  %287 = getelementptr inbounds [44 x { ptr, i64, ptr, i64 }], ptr %243, i32 0, i32 43
  store { ptr, i64, ptr, i64 } %242, ptr %287, align 8
  %288 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %288, ptr %243, i64 44)
  call void @vd_gc_poll()
  %289 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %289, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !39
  %290 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !39
  br i1 %290, label %worker.cancelled1, label %worker.continue2, !dbg !39

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !40
  %291 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !40
  br i1 %291, label %worker.cancelled3, label %worker.continue4, !dbg !40

block3:                                           ; preds = %worker.continue4, %worker.continue2
  call void @vd_gc_poll(), !dbg !40
  %292 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !40
  br i1 %292, label %worker.cancelled5, label %worker.continue6, !dbg !40

block4:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !41
  %293 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !41
  br i1 %293, label %worker.cancelled7, label %worker.continue8, !dbg !41

block5:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !42
  %294 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !42
  br i1 %294, label %worker.cancelled9, label %worker.continue10, !dbg !42

block6:                                           ; preds = %worker.continue10, %worker.continue8
  call void @vd_gc_poll(), !dbg !42
  %295 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !42
  br i1 %295, label %worker.cancelled11, label %worker.continue12, !dbg !42

block7:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !43
  %296 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !43
  br i1 %296, label %worker.cancelled13, label %worker.continue14, !dbg !43

block8:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !44
  %297 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !44
  br i1 %297, label %worker.cancelled15, label %worker.continue16, !dbg !44

block9:                                           ; preds = %worker.continue16, %worker.continue14
  call void @vd_gc_poll(), !dbg !44
  %298 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !44
  br i1 %298, label %worker.cancelled17, label %worker.continue18, !dbg !44

block10:                                          ; preds = %worker.continue18
  call void @vd_gc_poll(), !dbg !45
  %299 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !45
  br i1 %299, label %worker.cancelled19, label %worker.continue20, !dbg !45

block11:                                          ; preds = %worker.continue18
  call void @vd_gc_poll(), !dbg !46
  %300 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !46
  br i1 %300, label %worker.cancelled21, label %worker.continue22, !dbg !46

block12:                                          ; preds = %worker.continue22, %worker.continue20
  call void @vd_gc_poll(), !dbg !46
  %301 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !46
  br i1 %301, label %worker.cancelled23, label %worker.continue24, !dbg !46

block13:                                          ; preds = %worker.continue24
  call void @vd_gc_poll(), !dbg !47
  %302 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !47
  br i1 %302, label %worker.cancelled25, label %worker.continue26, !dbg !47

block14:                                          ; preds = %worker.continue24
  call void @vd_gc_poll(), !dbg !48
  %303 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !48
  br i1 %303, label %worker.cancelled27, label %worker.continue28, !dbg !48

block15:                                          ; preds = %worker.continue28, %worker.continue26
  call void @vd_gc_poll(), !dbg !48
  %304 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !48
  br i1 %304, label %worker.cancelled29, label %worker.continue30, !dbg !48

block16:                                          ; preds = %worker.continue30
  call void @vd_gc_poll(), !dbg !49
  %305 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !49
  br i1 %305, label %worker.cancelled31, label %worker.continue32, !dbg !49

block17:                                          ; preds = %worker.continue30
  call void @vd_gc_poll(), !dbg !50
  %306 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !50
  br i1 %306, label %worker.cancelled33, label %worker.continue34, !dbg !50

block18:                                          ; preds = %worker.continue34, %worker.continue32
  call void @vd_gc_poll(), !dbg !50
  %307 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !50
  br i1 %307, label %worker.cancelled35, label %worker.continue36, !dbg !50

block19:                                          ; preds = %worker.continue36
  call void @vd_gc_poll(), !dbg !51
  %308 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !51
  br i1 %308, label %worker.cancelled37, label %worker.continue38, !dbg !51

block20:                                          ; preds = %worker.continue36
  call void @vd_gc_poll(), !dbg !52
  %309 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !52
  br i1 %309, label %worker.cancelled39, label %worker.continue40, !dbg !52

block21:                                          ; preds = %worker.continue40, %worker.continue38
  call void @vd_gc_poll(), !dbg !52
  %310 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !52
  br i1 %310, label %worker.cancelled41, label %worker.continue42, !dbg !52

block22:                                          ; preds = %worker.continue42
  call void @vd_gc_poll(), !dbg !53
  %311 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !53
  br i1 %311, label %worker.cancelled43, label %worker.continue44, !dbg !53

block23:                                          ; preds = %worker.continue42
  call void @vd_gc_poll(), !dbg !54
  %312 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !54
  br i1 %312, label %worker.cancelled45, label %worker.continue46, !dbg !54

block24:                                          ; preds = %worker.continue46, %worker.continue44
  call void @vd_gc_poll(), !dbg !54
  %313 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !54
  br i1 %313, label %worker.cancelled47, label %worker.continue48, !dbg !54

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %288)
  ret %"/@stdlib/console.void::io_error" zeroinitializer

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::_reply" %0, ptr %93, align 8, !dbg !55
  store %"/@stdlib/console.void::_reply" %0, ptr %4, align 8, !dbg !55
  store ptr %1, ptr %98, align 8, !dbg !56
  store ptr %1, ptr %5, align 8, !dbg !56
  store ptr %2, ptr %103, align 8, !dbg !57
  store ptr %2, ptr %6, align 8, !dbg !57
  store %"/@stdlib/console.void::io_error_kind" { i32 8 }, ptr %7, align 4, !dbg !58
  %314 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !59
  store %"/@stdlib/console.void::_reply" %314, ptr %108, align 8, !dbg !59
  %315 = extractvalue %"/@stdlib/console.void::_reply" %314, 0, !dbg !60
  store i64 %315, ptr %8, align 8, !dbg !39
  %316 = load i64, ptr %8, align 8, !dbg !39
  %317 = icmp eq i64 %316, 1, !dbg !39
  br i1 %317, label %block1, label %block2, !dbg !39

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %288), !dbg !39
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !39

worker.continue2:                                 ; preds = %block1
  store %"/@stdlib/console.void::io_error_kind" zeroinitializer, ptr %7, align 4, !dbg !40
  br label %block3, !dbg !40

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %288), !dbg !40
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !40

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !40

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %288), !dbg !40
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !40

worker.continue6:                                 ; preds = %block3
  %318 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !61
  store %"/@stdlib/console.void::_reply" %318, ptr %113, align 8, !dbg !61
  %319 = extractvalue %"/@stdlib/console.void::_reply" %318, 0, !dbg !62
  store i64 %319, ptr %9, align 8, !dbg !41
  %320 = load i64, ptr %9, align 8, !dbg !41
  %321 = icmp eq i64 %320, 2, !dbg !41
  br i1 %321, label %block4, label %block5, !dbg !41

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %288), !dbg !41
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !41

worker.continue8:                                 ; preds = %block4
  store %"/@stdlib/console.void::io_error_kind" { i32 1 }, ptr %7, align 4, !dbg !42
  br label %block6, !dbg !42

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr %288), !dbg !42
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !42

worker.continue10:                                ; preds = %block5
  br label %block6, !dbg !42

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %288), !dbg !42
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !42

worker.continue12:                                ; preds = %block6
  %322 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !63
  store %"/@stdlib/console.void::_reply" %322, ptr %118, align 8, !dbg !63
  %323 = extractvalue %"/@stdlib/console.void::_reply" %322, 0, !dbg !64
  store i64 %323, ptr %10, align 8, !dbg !43
  %324 = load i64, ptr %10, align 8, !dbg !43
  %325 = icmp eq i64 %324, 3, !dbg !43
  br i1 %325, label %block7, label %block8, !dbg !43

worker.cancelled13:                               ; preds = %block7
  call void @vd_gc_frame_leave(ptr %288), !dbg !43
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !43

worker.continue14:                                ; preds = %block7
  store %"/@stdlib/console.void::io_error_kind" { i32 2 }, ptr %7, align 4, !dbg !44
  br label %block9, !dbg !44

worker.cancelled15:                               ; preds = %block8
  call void @vd_gc_frame_leave(ptr %288), !dbg !44
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !44

worker.continue16:                                ; preds = %block8
  br label %block9, !dbg !44

worker.cancelled17:                               ; preds = %block9
  call void @vd_gc_frame_leave(ptr %288), !dbg !44
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !44

worker.continue18:                                ; preds = %block9
  %326 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !65
  store %"/@stdlib/console.void::_reply" %326, ptr %123, align 8, !dbg !65
  %327 = extractvalue %"/@stdlib/console.void::_reply" %326, 0, !dbg !66
  store i64 %327, ptr %11, align 8, !dbg !45
  %328 = load i64, ptr %11, align 8, !dbg !45
  %329 = icmp eq i64 %328, 4, !dbg !45
  br i1 %329, label %block10, label %block11, !dbg !45

worker.cancelled19:                               ; preds = %block10
  call void @vd_gc_frame_leave(ptr %288), !dbg !45
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !45

worker.continue20:                                ; preds = %block10
  store %"/@stdlib/console.void::io_error_kind" { i32 3 }, ptr %7, align 4, !dbg !46
  br label %block12, !dbg !46

worker.cancelled21:                               ; preds = %block11
  call void @vd_gc_frame_leave(ptr %288), !dbg !46
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !46

worker.continue22:                                ; preds = %block11
  br label %block12, !dbg !46

worker.cancelled23:                               ; preds = %block12
  call void @vd_gc_frame_leave(ptr %288), !dbg !46
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !46

worker.continue24:                                ; preds = %block12
  %330 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !67
  store %"/@stdlib/console.void::_reply" %330, ptr %128, align 8, !dbg !67
  %331 = extractvalue %"/@stdlib/console.void::_reply" %330, 0, !dbg !68
  store i64 %331, ptr %12, align 8, !dbg !47
  %332 = load i64, ptr %12, align 8, !dbg !47
  %333 = icmp eq i64 %332, 5, !dbg !47
  br i1 %333, label %block13, label %block14, !dbg !47

worker.cancelled25:                               ; preds = %block13
  call void @vd_gc_frame_leave(ptr %288), !dbg !47
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !47

worker.continue26:                                ; preds = %block13
  store %"/@stdlib/console.void::io_error_kind" { i32 4 }, ptr %7, align 4, !dbg !48
  br label %block15, !dbg !48

worker.cancelled27:                               ; preds = %block14
  call void @vd_gc_frame_leave(ptr %288), !dbg !48
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !48

worker.continue28:                                ; preds = %block14
  br label %block15, !dbg !48

worker.cancelled29:                               ; preds = %block15
  call void @vd_gc_frame_leave(ptr %288), !dbg !48
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !48

worker.continue30:                                ; preds = %block15
  %334 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !69
  store %"/@stdlib/console.void::_reply" %334, ptr %133, align 8, !dbg !69
  %335 = extractvalue %"/@stdlib/console.void::_reply" %334, 0, !dbg !70
  store i64 %335, ptr %13, align 8, !dbg !49
  %336 = load i64, ptr %13, align 8, !dbg !49
  %337 = icmp eq i64 %336, 6, !dbg !49
  br i1 %337, label %block16, label %block17, !dbg !49

worker.cancelled31:                               ; preds = %block16
  call void @vd_gc_frame_leave(ptr %288), !dbg !49
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !49

worker.continue32:                                ; preds = %block16
  store %"/@stdlib/console.void::io_error_kind" { i32 5 }, ptr %7, align 4, !dbg !50
  br label %block18, !dbg !50

worker.cancelled33:                               ; preds = %block17
  call void @vd_gc_frame_leave(ptr %288), !dbg !50
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !50

worker.continue34:                                ; preds = %block17
  br label %block18, !dbg !50

worker.cancelled35:                               ; preds = %block18
  call void @vd_gc_frame_leave(ptr %288), !dbg !50
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !50

worker.continue36:                                ; preds = %block18
  %338 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !71
  store %"/@stdlib/console.void::_reply" %338, ptr %138, align 8, !dbg !71
  %339 = extractvalue %"/@stdlib/console.void::_reply" %338, 0, !dbg !72
  store i64 %339, ptr %14, align 8, !dbg !51
  %340 = load i64, ptr %14, align 8, !dbg !51
  %341 = icmp eq i64 %340, 7, !dbg !51
  br i1 %341, label %block19, label %block20, !dbg !51

worker.cancelled37:                               ; preds = %block19
  call void @vd_gc_frame_leave(ptr %288), !dbg !51
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !51

worker.continue38:                                ; preds = %block19
  store %"/@stdlib/console.void::io_error_kind" { i32 6 }, ptr %7, align 4, !dbg !52
  br label %block21, !dbg !52

worker.cancelled39:                               ; preds = %block20
  call void @vd_gc_frame_leave(ptr %288), !dbg !52
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !52

worker.continue40:                                ; preds = %block20
  br label %block21, !dbg !52

worker.cancelled41:                               ; preds = %block21
  call void @vd_gc_frame_leave(ptr %288), !dbg !52
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !52

worker.continue42:                                ; preds = %block21
  %342 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !73
  store %"/@stdlib/console.void::_reply" %342, ptr %143, align 8, !dbg !73
  %343 = extractvalue %"/@stdlib/console.void::_reply" %342, 0, !dbg !74
  store i64 %343, ptr %15, align 8, !dbg !53
  %344 = load i64, ptr %15, align 8, !dbg !53
  %345 = icmp eq i64 %344, 8, !dbg !53
  br i1 %345, label %block22, label %block23, !dbg !53

worker.cancelled43:                               ; preds = %block22
  call void @vd_gc_frame_leave(ptr %288), !dbg !53
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !53

worker.continue44:                                ; preds = %block22
  store %"/@stdlib/console.void::io_error_kind" { i32 7 }, ptr %7, align 4, !dbg !54
  br label %block24, !dbg !54

worker.cancelled45:                               ; preds = %block23
  call void @vd_gc_frame_leave(ptr %288), !dbg !54
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !54

worker.continue46:                                ; preds = %block23
  br label %block24, !dbg !54

worker.cancelled47:                               ; preds = %block24
  call void @vd_gc_frame_leave(ptr %288), !dbg !54
  ret %"/@stdlib/console.void::io_error" zeroinitializer, !dbg !54

worker.continue48:                                ; preds = %block24
  %346 = load ptr, ptr %5, align 8, !dbg !75
  store ptr %346, ptr %148, align 8, !dbg !75
  store ptr %346, ptr %16, align 8, !dbg !75
  %347 = load ptr, ptr %6, align 8, !dbg !76
  store ptr %347, ptr %153, align 8, !dbg !76
  store ptr %347, ptr %17, align 8, !dbg !76
  %348 = load %"/@stdlib/console.void::io_error_kind", ptr %7, align 4, !dbg !77
  store %"/@stdlib/console.void::io_error_kind" %348, ptr %18, align 4, !dbg !77
  %349 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !78
  store %"/@stdlib/console.void::_reply" %349, ptr %158, align 8, !dbg !78
  %350 = extractvalue %"/@stdlib/console.void::_reply" %349, 1, !dbg !79
  store i64 %350, ptr %19, align 8, !dbg !79
  %351 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !80
  store %"/@stdlib/console.void::_reply" %351, ptr %163, align 8, !dbg !80
  %352 = extractvalue %"/@stdlib/console.void::_reply" %351, 6, !dbg !81
  store ptr %352, ptr %168, align 8, !dbg !81
  store ptr %352, ptr %20, align 8, !dbg !81
  %353 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !82
  store %"/@stdlib/console.void::_reply" %353, ptr %173, align 8, !dbg !82
  %354 = extractvalue %"/@stdlib/console.void::_reply" %353, 2, !dbg !83
  store i64 %354, ptr %21, align 8, !dbg !83
  %355 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !84
  store %"/@stdlib/console.void::_reply" %355, ptr %178, align 8, !dbg !84
  %356 = extractvalue %"/@stdlib/console.void::_reply" %355, 7, !dbg !85
  store ptr %356, ptr %183, align 8, !dbg !85
  store ptr %356, ptr %22, align 8, !dbg !85
  %357 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !86
  store %"/@stdlib/console.void::_reply" %357, ptr %188, align 8, !dbg !86
  %358 = extractvalue %"/@stdlib/console.void::_reply" %357, 3, !dbg !87
  store i64 %358, ptr %23, align 8, !dbg !87
  %359 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !88
  store %"/@stdlib/console.void::_reply" %359, ptr %193, align 8, !dbg !88
  %360 = extractvalue %"/@stdlib/console.void::_reply" %359, 4, !dbg !89
  store i64 %360, ptr %24, align 8, !dbg !89
  %361 = load ptr, ptr %16, align 8, !dbg !90
  store ptr %361, ptr %198, align 8, !dbg !90
  store ptr %361, ptr %25, align 8, !dbg !90
  %362 = load ptr, ptr %17, align 8, !dbg !90
  store ptr %362, ptr %203, align 8, !dbg !90
  store ptr %362, ptr %26, align 8, !dbg !90
  %363 = load %"/@stdlib/console.void::io_error_kind", ptr %18, align 4, !dbg !90
  store %"/@stdlib/console.void::io_error_kind" %363, ptr %27, align 4, !dbg !90
  %364 = load i64, ptr %19, align 8, !dbg !90
  store i64 %364, ptr %28, align 8, !dbg !90
  %365 = load ptr, ptr %20, align 8, !dbg !90
  store ptr %365, ptr %208, align 8, !dbg !90
  store ptr %365, ptr %29, align 8, !dbg !90
  %366 = load i64, ptr %21, align 8, !dbg !90
  store i64 %366, ptr %30, align 8, !dbg !90
  %367 = load ptr, ptr %22, align 8, !dbg !90
  store ptr %367, ptr %213, align 8, !dbg !90
  store ptr %367, ptr %31, align 8, !dbg !90
  %368 = load i64, ptr %23, align 8, !dbg !90
  store i64 %368, ptr %32, align 8, !dbg !90
  %369 = load i64, ptr %24, align 8, !dbg !90
  store i64 %369, ptr %33, align 8, !dbg !90
  %370 = load ptr, ptr %25, align 8, !dbg !90
  store ptr %370, ptr %218, align 8, !dbg !90
  %371 = load ptr, ptr %26, align 8, !dbg !90
  store ptr %371, ptr %223, align 8, !dbg !90
  %372 = load %"/@stdlib/console.void::io_error_kind", ptr %27, align 4, !dbg !90
  %373 = load i64, ptr %28, align 8, !dbg !90
  %374 = load ptr, ptr %29, align 8, !dbg !90
  store ptr %374, ptr %228, align 8, !dbg !90
  %375 = load i64, ptr %30, align 8, !dbg !90
  %376 = load ptr, ptr %31, align 8, !dbg !90
  store ptr %376, ptr %233, align 8, !dbg !90
  %377 = load i64, ptr %32, align 8, !dbg !90
  %378 = load i64, ptr %33, align 8, !dbg !90
  %379 = insertvalue %"/@stdlib/console.void::io_error" zeroinitializer, ptr %370, 0, !dbg !90
  %380 = insertvalue %"/@stdlib/console.void::io_error" %379, ptr %371, 1, !dbg !90
  %381 = insertvalue %"/@stdlib/console.void::io_error" %380, %"/@stdlib/console.void::io_error_kind" %372, 2, !dbg !90
  %382 = insertvalue %"/@stdlib/console.void::io_error" %381, i64 %373, 3, !dbg !90
  %383 = insertvalue %"/@stdlib/console.void::io_error" %382, ptr %374, 4, !dbg !90
  %384 = insertvalue %"/@stdlib/console.void::io_error" %383, i64 %375, 5, !dbg !90
  %385 = insertvalue %"/@stdlib/console.void::io_error" %384, ptr %376, 6, !dbg !90
  %386 = insertvalue %"/@stdlib/console.void::io_error" %385, i64 %377, 7, !dbg !90
  %387 = insertvalue %"/@stdlib/console.void::io_error" %386, i64 %378, 8, !dbg !90
  store %"/@stdlib/console.void::io_error" %387, ptr %238, align 8, !dbg !90
  call void @vd_gc_frame_leave(ptr %288), !dbg !90
  ret %"/@stdlib/console.void::io_error" %387, !dbg !90
}

define internal ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %0, ptr %1) !dbg !91 {
block0:
  %2 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %2, align 8
  %3 = alloca i64, align 8
  store i64 0, ptr %3, align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %6 = insertvalue { ptr, i64, ptr, i64 } %5, i64 8, 1
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, ptr @gc.offsets.66, 2
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, i64 1, 3
  %9 = alloca ptr, align 8
  store ptr null, ptr %9, align 8
  %10 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 8, 1
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, ptr @gc.offsets.67, 2
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 1, 3
  %14 = alloca [2 x { ptr, i64, ptr, i64 }], align 8
  %15 = getelementptr inbounds [2 x { ptr, i64, ptr, i64 }], ptr %14, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %8, ptr %15, align 8
  %16 = getelementptr inbounds [2 x { ptr, i64, ptr, i64 }], ptr %14, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %13, ptr %16, align 8
  %17 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %17, ptr %14, i64 2)
  call void @vd_gc_poll()
  %18 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %18, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !97
  %19 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !97
  br i1 %19, label %worker.cancelled1, label %worker.continue2, !dbg !97

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !98
  %20 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !98
  br i1 %20, label %worker.cancelled3, label %worker.continue4, !dbg !98

block3:                                           ; preds = %worker.continue4
  call void @vd_gc_poll(), !dbg !98
  %21 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !98
  br i1 %21, label %worker.cancelled5, label %worker.continue6, !dbg !98

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %17)
  ret ptr null

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::output" %0, ptr %2, align 8, !dbg !99
  %22 = load %"/@stdlib/console.void::output", ptr %2, align 8, !dbg !100
  %23 = extractvalue %"/@stdlib/console.void::output" %22, 0, !dbg !101
  store i64 %23, ptr %3, align 8, !dbg !97
  %24 = load i64, ptr %3, align 8, !dbg !97
  %25 = icmp eq i64 %24, 1, !dbg !97
  br i1 %25, label %block1, label %block2, !dbg !97

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %17), !dbg !97
  ret ptr null, !dbg !97

worker.continue2:                                 ; preds = %block1
  call void @vd_string_literal(ptr %4, ptr @88, i64 6, ptr %1), !dbg !98
  %26 = load ptr, ptr %4, align 8, !dbg !98
  %27 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !98
  %28 = load ptr, ptr %27, align 8, !dbg !98
  %29 = icmp ne ptr %28, null, !dbg !98
  br i1 %29, label %numeric_error, label %numeric_valid, !dbg !98

numeric_error:                                    ; preds = %worker.continue2
  %30 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !98
  store ptr @89, ptr %30, align 8, !dbg !98
  call void @vd_gc_frame_leave(ptr %17), !dbg !98
  ret ptr null, !dbg !98

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %26, ptr %4, align 8, !dbg !98
  call void @vd_gc_frame_leave(ptr %17), !dbg !98
  ret ptr %26, !dbg !98

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %17), !dbg !98
  ret ptr null, !dbg !98

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !98

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %17), !dbg !98
  ret ptr null, !dbg !98

worker.continue6:                                 ; preds = %block3
  call void @vd_string_literal(ptr %9, ptr @90, i64 6, ptr %1), !dbg !102
  %31 = load ptr, ptr %9, align 8, !dbg !102
  %32 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !102
  %33 = load ptr, ptr %32, align 8, !dbg !102
  %34 = icmp ne ptr %33, null, !dbg !102
  br i1 %34, label %numeric_error7, label %numeric_valid8, !dbg !102

numeric_error7:                                   ; preds = %worker.continue6
  %35 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !102
  store ptr @91, ptr %35, align 8, !dbg !102
  call void @vd_gc_frame_leave(ptr %17), !dbg !102
  ret ptr null, !dbg !102

numeric_valid8:                                   ; preds = %worker.continue6
  store ptr %31, ptr %9, align 8, !dbg !102
  call void @vd_gc_frame_leave(ptr %17), !dbg !102
  ret ptr %31, !dbg !102
}

define %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7772697465__v1(ptr %0, ptr %1, ptr %2) !dbg !103 {
block0:
  %3 = alloca [8 x i64], align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca i64, align 8
  store i64 0, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %9, align 8
  %10 = alloca ptr, align 8
  store ptr null, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %12, align 8
  %13 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 8, 1
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, ptr @gc.offsets.68, 2
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 1, 3
  %19 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 80, 1
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, ptr @gc.offsets.69, 2
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 2, 3
  %23 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 8, 1
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, ptr @gc.offsets.70, 2
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 1, 3
  %27 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 80, 1
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, ptr @gc.offsets.71, 2
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 2, 3
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 8, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.72, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 1, 3
  %35 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 8, 1
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, ptr @gc.offsets.73, 2
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 1, 3
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 72, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.74, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 4, 3
  %43 = alloca ptr, align 8
  store ptr %1, ptr %43, align 8
  %44 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %43, 0
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 8, 1
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, ptr @gc.offsets.75, 2
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 1, 3
  %48 = alloca ptr, align 8
  store ptr null, ptr %48, align 8
  %49 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %48, 0
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 8, 1
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, ptr @gc.offsets.76, 2
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 1, 3
  %53 = alloca ptr, align 8
  store ptr null, ptr %53, align 8
  %54 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %53, 0
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 8, 1
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, ptr @gc.offsets.77, 2
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 1, 3
  %58 = alloca ptr, align 8
  store ptr null, ptr %58, align 8
  %59 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %58, 0
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 8, 1
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, ptr @gc.offsets.78, 2
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, i64 1, 3
  %63 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %63, align 8
  %64 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %63, 0
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 80, 1
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, ptr @gc.offsets.79, 2
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, i64 2, 3
  %68 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %68, align 8
  %69 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %68, 0
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 80, 1
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, ptr @gc.offsets.80, 2
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, i64 2, 3
  %73 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %73, align 8
  %74 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %73, 0
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 80, 1
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, ptr @gc.offsets.81, 2
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, i64 2, 3
  %78 = alloca ptr, align 8
  store ptr null, ptr %78, align 8
  %79 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %78, 0
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 8, 1
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, ptr @gc.offsets.82, 2
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, i64 1, 3
  %83 = alloca ptr, align 8
  store ptr null, ptr %83, align 8
  %84 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %83, 0
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 8, 1
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, ptr @gc.offsets.83, 2
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, i64 1, 3
  %88 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %88, align 8
  %89 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %88, 0
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 80, 1
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, ptr @gc.offsets.84, 2
  %92 = insertvalue { ptr, i64, ptr, i64 } %91, i64 2, 3
  %93 = alloca ptr, align 8
  store ptr null, ptr %93, align 8
  %94 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %93, 0
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 8, 1
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, ptr @gc.offsets.85, 2
  %97 = insertvalue { ptr, i64, ptr, i64 } %96, i64 1, 3
  %98 = alloca ptr, align 8
  store ptr null, ptr %98, align 8
  %99 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %98, 0
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 8, 1
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, ptr @gc.offsets.86, 2
  %102 = insertvalue { ptr, i64, ptr, i64 } %101, i64 1, 3
  %103 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %103, align 8
  %104 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %103, 0
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 72, 1
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, ptr @gc.offsets.87, 2
  %107 = insertvalue { ptr, i64, ptr, i64 } %106, i64 4, 3
  %108 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %108, align 8
  %109 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %108, 0
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, i64 72, 1
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, ptr @gc.offsets.88, 2
  %112 = insertvalue { ptr, i64, ptr, i64 } %111, i64 4, 3
  %113 = alloca %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %113, align 8
  %114 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %113, 0
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, i64 88, 1
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, ptr @gc.offsets.89, 2
  %117 = insertvalue { ptr, i64, ptr, i64 } %116, i64 4, 3
  %118 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %118, align 8
  %119 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %118, 0
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, i64 80, 1
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, ptr @gc.offsets.90, 2
  %122 = insertvalue { ptr, i64, ptr, i64 } %121, i64 2, 3
  %123 = alloca %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %123, align 8
  %124 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %123, 0
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, i64 88, 1
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, ptr @gc.offsets.91, 2
  %127 = insertvalue { ptr, i64, ptr, i64 } %126, i64 4, 3
  %128 = alloca [24 x { ptr, i64, ptr, i64 }], align 8
  %129 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %18, ptr %129, align 8
  %130 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %22, ptr %130, align 8
  %131 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %26, ptr %131, align 8
  %132 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %30, ptr %132, align 8
  %133 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %34, ptr %133, align 8
  %134 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %38, ptr %134, align 8
  %135 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %42, ptr %135, align 8
  %136 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %47, ptr %136, align 8
  %137 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %52, ptr %137, align 8
  %138 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %57, ptr %138, align 8
  %139 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %62, ptr %139, align 8
  %140 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %67, ptr %140, align 8
  %141 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %72, ptr %141, align 8
  %142 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %77, ptr %142, align 8
  %143 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %82, ptr %143, align 8
  %144 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %87, ptr %144, align 8
  %145 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %92, ptr %145, align 8
  %146 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %97, ptr %146, align 8
  %147 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %102, ptr %147, align 8
  %148 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %107, ptr %148, align 8
  %149 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %112, ptr %149, align 8
  %150 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %117, ptr %150, align 8
  %151 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %122, ptr %151, align 8
  %152 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %127, ptr %152, align 8
  %153 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %153, ptr %128, i64 24)
  call void @vd_gc_poll()
  %154 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %154, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !111
  %155 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !111
  br i1 %155, label %worker.cancelled1, label %worker.continue2, !dbg !111

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !112
  %156 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !112
  br i1 %156, label %worker.cancelled13, label %worker.continue14, !dbg !112

block3:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !112
  %157 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !112
  br i1 %157, label %worker.cancelled15, label %worker.continue16, !dbg !112

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %153)
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store ptr %1, ptr %48, align 8, !dbg !113
  store ptr %1, ptr %4, align 8, !dbg !113
  %158 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !114
  store %"/@stdlib/console.void::output" %158, ptr %6, align 8, !dbg !114
  %159 = load ptr, ptr %4, align 8, !dbg !115
  store ptr %159, ptr %53, align 8, !dbg !115
  store ptr %159, ptr %7, align 8, !dbg !115
  %160 = load %"/@stdlib/console.void::output", ptr %6, align 8, !dbg !116
  %161 = load ptr, ptr %7, align 8, !dbg !116
  store ptr %161, ptr %58, align 8, !dbg !116
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %63, align 8, !dbg !116
  store [8 x i64] zeroinitializer, ptr %3, align 8, !dbg !116
  %162 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 6, !dbg !116
  %163 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 7, !dbg !116
  %164 = extractvalue %"/@stdlib/console.void::output" %160, 0, !dbg !116
  call void @vd_console_v2(ptr %162, ptr %163, ptr %3, i32 0, i64 %164, ptr %58, i64 0, i64 -1, ptr %2), !dbg !116
  %165 = load ptr, ptr %2, align 8, !dbg !116
  %166 = icmp ne ptr %165, null, !dbg !116
  br i1 %166, label %selected.failure, label %selected.valid, !dbg !116

selected.failure:                                 ; preds = %worker.continue
  %167 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !116
  %168 = load i32, ptr %167, align 4, !dbg !116
  %169 = icmp ult i32 %168, 32, !dbg !116
  br i1 %169, label %trace_caller, label %trace_limit, !dbg !116

selected.valid:                                   ; preds = %worker.continue
  %170 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 0, !dbg !116
  %171 = load i64, ptr %170, align 8, !dbg !116
  %172 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 0, !dbg !116
  store i64 %171, ptr %172, align 8, !dbg !116
  %173 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 1, !dbg !116
  %174 = load i64, ptr %173, align 8, !dbg !116
  %175 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 1, !dbg !116
  store i64 %174, ptr %175, align 8, !dbg !116
  %176 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 2, !dbg !116
  %177 = load i64, ptr %176, align 8, !dbg !116
  %178 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 2, !dbg !116
  store i64 %177, ptr %178, align 8, !dbg !116
  %179 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 3, !dbg !116
  %180 = load i64, ptr %179, align 8, !dbg !116
  %181 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 3, !dbg !116
  store i64 %180, ptr %181, align 8, !dbg !116
  %182 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 4, !dbg !116
  %183 = load i64, ptr %182, align 8, !dbg !116
  %184 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 4, !dbg !116
  store i64 %183, ptr %184, align 8, !dbg !116
  %185 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 5, !dbg !116
  %186 = load i64, ptr %185, align 8, !dbg !116
  %187 = trunc i64 %186 to i1, !dbg !116
  %188 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 5, !dbg !116
  store i1 %187, ptr %188, align 1, !dbg !116
  %189 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 6, !dbg !116
  %190 = load i64, ptr %189, align 8, !dbg !116
  %191 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 8, !dbg !116
  store i64 %190, ptr %191, align 8, !dbg !116
  %192 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 7, !dbg !116
  %193 = load i64, ptr %192, align 8, !dbg !116
  %194 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 9, !dbg !116
  store i64 %193, ptr %194, align 8, !dbg !116
  %195 = load %"/@stdlib/console.void::_reply", ptr %63, align 8, !dbg !116
  store %"/@stdlib/console.void::_reply" %195, ptr %63, align 8, !dbg !116
  store %"/@stdlib/console.void::_reply" %195, ptr %5, align 8, !dbg !117
  %196 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !118
  store %"/@stdlib/console.void::_reply" %196, ptr %68, align 8, !dbg !118
  %197 = extractvalue %"/@stdlib/console.void::_reply" %196, 0, !dbg !119
  store i64 %197, ptr %8, align 8, !dbg !111
  %198 = load i64, ptr %8, align 8, !dbg !111
  %199 = icmp ne i64 %198, 0, !dbg !111
  br i1 %199, label %block1, label %block2, !dbg !111

trace_caller:                                     ; preds = %selected.failure
  %200 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !116
  %201 = getelementptr [32 x ptr], ptr %200, i32 0, i32 %168, !dbg !116
  store ptr @92, ptr %201, align 8, !dbg !116
  %202 = add i32 %168, 1, !dbg !116
  store i32 %202, ptr %167, align 4, !dbg !116
  br label %error_return, !dbg !116

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %153), !dbg !116
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !116

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %167, align 4, !dbg !116
  br label %error_return, !dbg !116

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %153), !dbg !111
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !111

worker.continue2:                                 ; preds = %block1
  %203 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !120
  store %"/@stdlib/console.void::_reply" %203, ptr %73, align 8, !dbg !120
  store %"/@stdlib/console.void::_reply" %203, ptr %9, align 8, !dbg !120
  call void @vd_string_literal(ptr %78, ptr @93, i64 5, ptr %2), !dbg !121
  %204 = load ptr, ptr %78, align 8, !dbg !121
  %205 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !121
  %206 = load ptr, ptr %205, align 8, !dbg !121
  %207 = icmp ne ptr %206, null, !dbg !121
  br i1 %207, label %numeric_error, label %numeric_valid, !dbg !121

numeric_error:                                    ; preds = %worker.continue2
  %208 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !121
  store ptr @94, ptr %208, align 8, !dbg !121
  call void @vd_gc_frame_leave(ptr %153), !dbg !121
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !121

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %204, ptr %78, align 8, !dbg !121
  store ptr %204, ptr %10, align 8, !dbg !121
  %209 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !122
  store %"/@stdlib/console.void::output" %209, ptr %12, align 8, !dbg !122
  %210 = load %"/@stdlib/console.void::output", ptr %12, align 8, !dbg !123
  %211 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %210, ptr %2), !dbg !123
  %212 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !123
  %213 = load ptr, ptr %212, align 8, !dbg !123
  %214 = icmp ne ptr %213, null, !dbg !123
  br i1 %214, label %propagate_error, label %call_success, !dbg !123

propagate_error:                                  ; preds = %numeric_valid
  %215 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !123
  %216 = load i32, ptr %215, align 4, !dbg !123
  %217 = icmp ult i32 %216, 32, !dbg !123
  br i1 %217, label %trace_caller3, label %trace_limit5, !dbg !123

call_success:                                     ; preds = %numeric_valid
  store ptr %211, ptr %83, align 8, !dbg !123
  store ptr %211, ptr %11, align 8, !dbg !123
  %218 = load %"/@stdlib/console.void::_reply", ptr %9, align 8, !dbg !124
  store %"/@stdlib/console.void::_reply" %218, ptr %88, align 8, !dbg !124
  %219 = load ptr, ptr %10, align 8, !dbg !124
  store ptr %219, ptr %93, align 8, !dbg !124
  %220 = load ptr, ptr %11, align 8, !dbg !124
  store ptr %220, ptr %98, align 8, !dbg !124
  %221 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %218, ptr %219, ptr %220, ptr %2), !dbg !124
  %222 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !124
  %223 = load ptr, ptr %222, align 8, !dbg !124
  %224 = icmp ne ptr %223, null, !dbg !124
  br i1 %224, label %propagate_error6, label %call_success7, !dbg !124

trace_caller3:                                    ; preds = %propagate_error
  %225 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !123
  %226 = getelementptr [32 x ptr], ptr %225, i32 0, i32 %216, !dbg !123
  store ptr @95, ptr %226, align 8, !dbg !123
  %227 = add i32 %216, 1, !dbg !123
  store i32 %227, ptr %215, align 4, !dbg !123
  br label %error_return4, !dbg !123

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %153), !dbg !123
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !123

trace_limit5:                                     ; preds = %propagate_error
  store i32 33, ptr %215, align 4, !dbg !123
  br label %error_return4, !dbg !123

propagate_error6:                                 ; preds = %call_success
  %228 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !124
  %229 = load i32, ptr %228, align 4, !dbg !124
  %230 = icmp ult i32 %229, 32, !dbg !124
  br i1 %230, label %trace_caller8, label %trace_limit10, !dbg !124

call_success7:                                    ; preds = %call_success
  store %"/@stdlib/console.void::io_error" %221, ptr %103, align 8, !dbg !124
  store %"/@stdlib/console.void::io_error" %221, ptr %13, align 8, !dbg !124
  %231 = load %"/@stdlib/console.void::io_error", ptr %13, align 8, !dbg !112
  store %"/@stdlib/console.void::io_error" %231, ptr %108, align 8, !dbg !112
  %232 = insertvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, i64 0, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %231, 2, !dbg !112
  %233 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 0, !dbg !112
  %234 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 0, !dbg !112
  %235 = icmp eq i32 %234, 0, !dbg !112
  br i1 %235, label %validate_active_payload, label %validate_payload_done, !dbg !112

trace_caller8:                                    ; preds = %propagate_error6
  %236 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !124
  %237 = getelementptr [32 x ptr], ptr %236, i32 0, i32 %229, !dbg !124
  store ptr @96, ptr %237, align 8, !dbg !124
  %238 = add i32 %229, 1, !dbg !124
  store i32 %238, ptr %228, align 4, !dbg !124
  br label %error_return9, !dbg !124

error_return9:                                    ; preds = %trace_caller8, %trace_limit10
  call void @vd_gc_frame_leave(ptr %153), !dbg !124
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !124

trace_limit10:                                    ; preds = %propagate_error6
  store i32 33, ptr %228, align 4, !dbg !124
  br label %error_return9, !dbg !124

validate_active_payload:                          ; preds = %call_success7
  %239 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 1, !dbg !112
  br label %validate_payload_done, !dbg !112

validate_payload_done:                            ; preds = %validate_active_payload, %call_success7
  %240 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 0, !dbg !112
  %241 = icmp eq i32 %240, 1, !dbg !112
  br i1 %241, label %validate_active_payload11, label %validate_payload_done12, !dbg !112

validate_active_payload11:                        ; preds = %validate_payload_done
  %242 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 2, !dbg !112
  %243 = extractvalue %"/@stdlib/console.void::io_error" %242, 0, !dbg !112
  %244 = extractvalue %"/@stdlib/console.void::io_error" %242, 1, !dbg !112
  %245 = extractvalue %"/@stdlib/console.void::io_error" %242, 2, !dbg !112
  %246 = extractvalue %"/@stdlib/console.void::io_error_kind" %245, 0, !dbg !112
  %247 = extractvalue %"/@stdlib/console.void::io_error" %242, 3, !dbg !112
  %248 = extractvalue %"/@stdlib/console.void::io_error" %242, 4, !dbg !112
  %249 = extractvalue %"/@stdlib/console.void::io_error" %242, 5, !dbg !112
  %250 = extractvalue %"/@stdlib/console.void::io_error" %242, 6, !dbg !112
  %251 = extractvalue %"/@stdlib/console.void::io_error" %242, 7, !dbg !112
  %252 = extractvalue %"/@stdlib/console.void::io_error" %242, 8, !dbg !112
  br label %validate_payload_done12, !dbg !112

validate_payload_done12:                          ; preds = %validate_active_payload11, %validate_payload_done
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, ptr %113, align 8, !dbg !112
  call void @vd_gc_frame_leave(ptr %153), !dbg !112
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, !dbg !112

worker.cancelled13:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %153), !dbg !112
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !112

worker.continue14:                                ; preds = %block2
  br label %block3, !dbg !112

worker.cancelled15:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %153), !dbg !112
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !112

worker.continue16:                                ; preds = %block3
  %253 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !125
  store %"/@stdlib/console.void::_reply" %253, ptr %118, align 8, !dbg !125
  %254 = extractvalue %"/@stdlib/console.void::_reply" %253, 2, !dbg !126
  store i64 %254, ptr %14, align 8, !dbg !126
  %255 = load i64, ptr %14, align 8, !dbg !127
  %256 = insertvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, i64 %255, 1, !dbg !127
  %257 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 0, !dbg !127
  %258 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 0, !dbg !127
  %259 = icmp eq i32 %258, 0, !dbg !127
  br i1 %259, label %validate_active_payload17, label %validate_payload_done18, !dbg !127

validate_active_payload17:                        ; preds = %worker.continue16
  %260 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 1, !dbg !127
  br label %validate_payload_done18, !dbg !127

validate_payload_done18:                          ; preds = %validate_active_payload17, %worker.continue16
  %261 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 0, !dbg !127
  %262 = icmp eq i32 %261, 1, !dbg !127
  br i1 %262, label %validate_active_payload19, label %validate_payload_done20, !dbg !127

validate_active_payload19:                        ; preds = %validate_payload_done18
  %263 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 2, !dbg !127
  %264 = extractvalue %"/@stdlib/console.void::io_error" %263, 0, !dbg !127
  %265 = extractvalue %"/@stdlib/console.void::io_error" %263, 1, !dbg !127
  %266 = extractvalue %"/@stdlib/console.void::io_error" %263, 2, !dbg !127
  %267 = extractvalue %"/@stdlib/console.void::io_error_kind" %266, 0, !dbg !127
  %268 = extractvalue %"/@stdlib/console.void::io_error" %263, 3, !dbg !127
  %269 = extractvalue %"/@stdlib/console.void::io_error" %263, 4, !dbg !127
  %270 = extractvalue %"/@stdlib/console.void::io_error" %263, 5, !dbg !127
  %271 = extractvalue %"/@stdlib/console.void::io_error" %263, 6, !dbg !127
  %272 = extractvalue %"/@stdlib/console.void::io_error" %263, 7, !dbg !127
  %273 = extractvalue %"/@stdlib/console.void::io_error" %263, 8, !dbg !127
  br label %validate_payload_done20, !dbg !127

validate_payload_done20:                          ; preds = %validate_active_payload19, %validate_payload_done18
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, ptr %123, align 8, !dbg !127
  call void @vd_gc_frame_leave(ptr %153), !dbg !127
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, !dbg !127
}

define %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a77726974655f6279746573__v1(ptr %0, ptr %1, ptr %2) !dbg !128 {
block0:
  %3 = alloca [8 x i64], align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca i64, align 8
  store i64 0, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %9, align 8
  %10 = alloca ptr, align 8
  store ptr null, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %12, align 8
  %13 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 8, 1
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, ptr @gc.offsets.92, 2
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 1, 3
  %19 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 80, 1
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, ptr @gc.offsets.93, 2
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 2, 3
  %23 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 8, 1
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, ptr @gc.offsets.94, 2
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 1, 3
  %27 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 80, 1
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, ptr @gc.offsets.95, 2
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 2, 3
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 8, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.96, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 1, 3
  %35 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 8, 1
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, ptr @gc.offsets.97, 2
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 1, 3
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 72, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.98, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 4, 3
  %43 = alloca ptr, align 8
  store ptr %1, ptr %43, align 8
  %44 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %43, 0
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 8, 1
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, ptr @gc.offsets.99, 2
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 1, 3
  %48 = alloca ptr, align 8
  store ptr null, ptr %48, align 8
  %49 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %48, 0
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 8, 1
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, ptr @gc.offsets.100, 2
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 1, 3
  %53 = alloca ptr, align 8
  store ptr null, ptr %53, align 8
  %54 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %53, 0
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 8, 1
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, ptr @gc.offsets.101, 2
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 1, 3
  %58 = alloca ptr, align 8
  store ptr null, ptr %58, align 8
  %59 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %58, 0
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 8, 1
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, ptr @gc.offsets.102, 2
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, i64 1, 3
  %63 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %63, align 8
  %64 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %63, 0
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 80, 1
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, ptr @gc.offsets.103, 2
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, i64 2, 3
  %68 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %68, align 8
  %69 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %68, 0
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 80, 1
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, ptr @gc.offsets.104, 2
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, i64 2, 3
  %73 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %73, align 8
  %74 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %73, 0
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 80, 1
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, ptr @gc.offsets.105, 2
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, i64 2, 3
  %78 = alloca ptr, align 8
  store ptr null, ptr %78, align 8
  %79 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %78, 0
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 8, 1
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, ptr @gc.offsets.106, 2
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, i64 1, 3
  %83 = alloca ptr, align 8
  store ptr null, ptr %83, align 8
  %84 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %83, 0
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 8, 1
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, ptr @gc.offsets.107, 2
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, i64 1, 3
  %88 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %88, align 8
  %89 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %88, 0
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 80, 1
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, ptr @gc.offsets.108, 2
  %92 = insertvalue { ptr, i64, ptr, i64 } %91, i64 2, 3
  %93 = alloca ptr, align 8
  store ptr null, ptr %93, align 8
  %94 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %93, 0
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 8, 1
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, ptr @gc.offsets.109, 2
  %97 = insertvalue { ptr, i64, ptr, i64 } %96, i64 1, 3
  %98 = alloca ptr, align 8
  store ptr null, ptr %98, align 8
  %99 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %98, 0
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 8, 1
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, ptr @gc.offsets.110, 2
  %102 = insertvalue { ptr, i64, ptr, i64 } %101, i64 1, 3
  %103 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %103, align 8
  %104 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %103, 0
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 72, 1
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, ptr @gc.offsets.111, 2
  %107 = insertvalue { ptr, i64, ptr, i64 } %106, i64 4, 3
  %108 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %108, align 8
  %109 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %108, 0
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, i64 72, 1
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, ptr @gc.offsets.112, 2
  %112 = insertvalue { ptr, i64, ptr, i64 } %111, i64 4, 3
  %113 = alloca %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %113, align 8
  %114 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %113, 0
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, i64 88, 1
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, ptr @gc.offsets.113, 2
  %117 = insertvalue { ptr, i64, ptr, i64 } %116, i64 4, 3
  %118 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %118, align 8
  %119 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %118, 0
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, i64 80, 1
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, ptr @gc.offsets.114, 2
  %122 = insertvalue { ptr, i64, ptr, i64 } %121, i64 2, 3
  %123 = alloca %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %123, align 8
  %124 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %123, 0
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, i64 88, 1
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, ptr @gc.offsets.115, 2
  %127 = insertvalue { ptr, i64, ptr, i64 } %126, i64 4, 3
  %128 = alloca [24 x { ptr, i64, ptr, i64 }], align 8
  %129 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %18, ptr %129, align 8
  %130 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %22, ptr %130, align 8
  %131 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %26, ptr %131, align 8
  %132 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %30, ptr %132, align 8
  %133 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %34, ptr %133, align 8
  %134 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %38, ptr %134, align 8
  %135 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %42, ptr %135, align 8
  %136 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %47, ptr %136, align 8
  %137 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %52, ptr %137, align 8
  %138 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %57, ptr %138, align 8
  %139 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %62, ptr %139, align 8
  %140 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %67, ptr %140, align 8
  %141 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %72, ptr %141, align 8
  %142 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %77, ptr %142, align 8
  %143 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %82, ptr %143, align 8
  %144 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %87, ptr %144, align 8
  %145 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %92, ptr %145, align 8
  %146 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %97, ptr %146, align 8
  %147 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %102, ptr %147, align 8
  %148 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %107, ptr %148, align 8
  %149 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %112, ptr %149, align 8
  %150 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %117, ptr %150, align 8
  %151 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %122, ptr %151, align 8
  %152 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %128, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %127, ptr %152, align 8
  %153 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %153, ptr %128, i64 24)
  call void @vd_gc_poll()
  %154 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %154, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !131
  %155 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !131
  br i1 %155, label %worker.cancelled1, label %worker.continue2, !dbg !131

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !132
  %156 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !132
  br i1 %156, label %worker.cancelled13, label %worker.continue14, !dbg !132

block3:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !132
  %157 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !132
  br i1 %157, label %worker.cancelled15, label %worker.continue16, !dbg !132

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %153)
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store ptr %1, ptr %48, align 8, !dbg !133
  store ptr %1, ptr %4, align 8, !dbg !133
  %158 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !134
  store %"/@stdlib/console.void::output" %158, ptr %6, align 8, !dbg !134
  %159 = load ptr, ptr %4, align 8, !dbg !135
  store ptr %159, ptr %53, align 8, !dbg !135
  store ptr %159, ptr %7, align 8, !dbg !135
  %160 = load %"/@stdlib/console.void::output", ptr %6, align 8, !dbg !136
  %161 = load ptr, ptr %7, align 8, !dbg !136
  store ptr %161, ptr %58, align 8, !dbg !136
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %63, align 8, !dbg !136
  store [8 x i64] zeroinitializer, ptr %3, align 8, !dbg !136
  %162 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 6, !dbg !136
  %163 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 7, !dbg !136
  %164 = extractvalue %"/@stdlib/console.void::output" %160, 0, !dbg !136
  call void @vd_console_v2(ptr %162, ptr %163, ptr %3, i32 1, i64 %164, ptr %58, i64 0, i64 -1, ptr %2), !dbg !136
  %165 = load ptr, ptr %2, align 8, !dbg !136
  %166 = icmp ne ptr %165, null, !dbg !136
  br i1 %166, label %selected.failure, label %selected.valid, !dbg !136

selected.failure:                                 ; preds = %worker.continue
  %167 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !136
  %168 = load i32, ptr %167, align 4, !dbg !136
  %169 = icmp ult i32 %168, 32, !dbg !136
  br i1 %169, label %trace_caller, label %trace_limit, !dbg !136

selected.valid:                                   ; preds = %worker.continue
  %170 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 0, !dbg !136
  %171 = load i64, ptr %170, align 8, !dbg !136
  %172 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 0, !dbg !136
  store i64 %171, ptr %172, align 8, !dbg !136
  %173 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 1, !dbg !136
  %174 = load i64, ptr %173, align 8, !dbg !136
  %175 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 1, !dbg !136
  store i64 %174, ptr %175, align 8, !dbg !136
  %176 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 2, !dbg !136
  %177 = load i64, ptr %176, align 8, !dbg !136
  %178 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 2, !dbg !136
  store i64 %177, ptr %178, align 8, !dbg !136
  %179 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 3, !dbg !136
  %180 = load i64, ptr %179, align 8, !dbg !136
  %181 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 3, !dbg !136
  store i64 %180, ptr %181, align 8, !dbg !136
  %182 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 4, !dbg !136
  %183 = load i64, ptr %182, align 8, !dbg !136
  %184 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 4, !dbg !136
  store i64 %183, ptr %184, align 8, !dbg !136
  %185 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 5, !dbg !136
  %186 = load i64, ptr %185, align 8, !dbg !136
  %187 = trunc i64 %186 to i1, !dbg !136
  %188 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 5, !dbg !136
  store i1 %187, ptr %188, align 1, !dbg !136
  %189 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 6, !dbg !136
  %190 = load i64, ptr %189, align 8, !dbg !136
  %191 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 8, !dbg !136
  store i64 %190, ptr %191, align 8, !dbg !136
  %192 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 7, !dbg !136
  %193 = load i64, ptr %192, align 8, !dbg !136
  %194 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %63, i32 0, i32 9, !dbg !136
  store i64 %193, ptr %194, align 8, !dbg !136
  %195 = load %"/@stdlib/console.void::_reply", ptr %63, align 8, !dbg !136
  store %"/@stdlib/console.void::_reply" %195, ptr %63, align 8, !dbg !136
  store %"/@stdlib/console.void::_reply" %195, ptr %5, align 8, !dbg !137
  %196 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !138
  store %"/@stdlib/console.void::_reply" %196, ptr %68, align 8, !dbg !138
  %197 = extractvalue %"/@stdlib/console.void::_reply" %196, 0, !dbg !139
  store i64 %197, ptr %8, align 8, !dbg !131
  %198 = load i64, ptr %8, align 8, !dbg !131
  %199 = icmp ne i64 %198, 0, !dbg !131
  br i1 %199, label %block1, label %block2, !dbg !131

trace_caller:                                     ; preds = %selected.failure
  %200 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !136
  %201 = getelementptr [32 x ptr], ptr %200, i32 0, i32 %168, !dbg !136
  store ptr @97, ptr %201, align 8, !dbg !136
  %202 = add i32 %168, 1, !dbg !136
  store i32 %202, ptr %167, align 4, !dbg !136
  br label %error_return, !dbg !136

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %153), !dbg !136
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !136

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %167, align 4, !dbg !136
  br label %error_return, !dbg !136

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %153), !dbg !131
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !131

worker.continue2:                                 ; preds = %block1
  %203 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !140
  store %"/@stdlib/console.void::_reply" %203, ptr %73, align 8, !dbg !140
  store %"/@stdlib/console.void::_reply" %203, ptr %9, align 8, !dbg !140
  call void @vd_string_literal(ptr %78, ptr @98, i64 11, ptr %2), !dbg !141
  %204 = load ptr, ptr %78, align 8, !dbg !141
  %205 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !141
  %206 = load ptr, ptr %205, align 8, !dbg !141
  %207 = icmp ne ptr %206, null, !dbg !141
  br i1 %207, label %numeric_error, label %numeric_valid, !dbg !141

numeric_error:                                    ; preds = %worker.continue2
  %208 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !141
  store ptr @99, ptr %208, align 8, !dbg !141
  call void @vd_gc_frame_leave(ptr %153), !dbg !141
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !141

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %204, ptr %78, align 8, !dbg !141
  store ptr %204, ptr %10, align 8, !dbg !141
  %209 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !142
  store %"/@stdlib/console.void::output" %209, ptr %12, align 8, !dbg !142
  %210 = load %"/@stdlib/console.void::output", ptr %12, align 8, !dbg !143
  %211 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %210, ptr %2), !dbg !143
  %212 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !143
  %213 = load ptr, ptr %212, align 8, !dbg !143
  %214 = icmp ne ptr %213, null, !dbg !143
  br i1 %214, label %propagate_error, label %call_success, !dbg !143

propagate_error:                                  ; preds = %numeric_valid
  %215 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !143
  %216 = load i32, ptr %215, align 4, !dbg !143
  %217 = icmp ult i32 %216, 32, !dbg !143
  br i1 %217, label %trace_caller3, label %trace_limit5, !dbg !143

call_success:                                     ; preds = %numeric_valid
  store ptr %211, ptr %83, align 8, !dbg !143
  store ptr %211, ptr %11, align 8, !dbg !143
  %218 = load %"/@stdlib/console.void::_reply", ptr %9, align 8, !dbg !144
  store %"/@stdlib/console.void::_reply" %218, ptr %88, align 8, !dbg !144
  %219 = load ptr, ptr %10, align 8, !dbg !144
  store ptr %219, ptr %93, align 8, !dbg !144
  %220 = load ptr, ptr %11, align 8, !dbg !144
  store ptr %220, ptr %98, align 8, !dbg !144
  %221 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %218, ptr %219, ptr %220, ptr %2), !dbg !144
  %222 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !144
  %223 = load ptr, ptr %222, align 8, !dbg !144
  %224 = icmp ne ptr %223, null, !dbg !144
  br i1 %224, label %propagate_error6, label %call_success7, !dbg !144

trace_caller3:                                    ; preds = %propagate_error
  %225 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !143
  %226 = getelementptr [32 x ptr], ptr %225, i32 0, i32 %216, !dbg !143
  store ptr @100, ptr %226, align 8, !dbg !143
  %227 = add i32 %216, 1, !dbg !143
  store i32 %227, ptr %215, align 4, !dbg !143
  br label %error_return4, !dbg !143

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %153), !dbg !143
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !143

trace_limit5:                                     ; preds = %propagate_error
  store i32 33, ptr %215, align 4, !dbg !143
  br label %error_return4, !dbg !143

propagate_error6:                                 ; preds = %call_success
  %228 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !144
  %229 = load i32, ptr %228, align 4, !dbg !144
  %230 = icmp ult i32 %229, 32, !dbg !144
  br i1 %230, label %trace_caller8, label %trace_limit10, !dbg !144

call_success7:                                    ; preds = %call_success
  store %"/@stdlib/console.void::io_error" %221, ptr %103, align 8, !dbg !144
  store %"/@stdlib/console.void::io_error" %221, ptr %13, align 8, !dbg !144
  %231 = load %"/@stdlib/console.void::io_error", ptr %13, align 8, !dbg !132
  store %"/@stdlib/console.void::io_error" %231, ptr %108, align 8, !dbg !132
  %232 = insertvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, i64 0, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %231, 2, !dbg !132
  %233 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 0, !dbg !132
  %234 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 0, !dbg !132
  %235 = icmp eq i32 %234, 0, !dbg !132
  br i1 %235, label %validate_active_payload, label %validate_payload_done, !dbg !132

trace_caller8:                                    ; preds = %propagate_error6
  %236 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !144
  %237 = getelementptr [32 x ptr], ptr %236, i32 0, i32 %229, !dbg !144
  store ptr @101, ptr %237, align 8, !dbg !144
  %238 = add i32 %229, 1, !dbg !144
  store i32 %238, ptr %228, align 4, !dbg !144
  br label %error_return9, !dbg !144

error_return9:                                    ; preds = %trace_caller8, %trace_limit10
  call void @vd_gc_frame_leave(ptr %153), !dbg !144
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !144

trace_limit10:                                    ; preds = %propagate_error6
  store i32 33, ptr %228, align 4, !dbg !144
  br label %error_return9, !dbg !144

validate_active_payload:                          ; preds = %call_success7
  %239 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 1, !dbg !132
  br label %validate_payload_done, !dbg !132

validate_payload_done:                            ; preds = %validate_active_payload, %call_success7
  %240 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 0, !dbg !132
  %241 = icmp eq i32 %240, 1, !dbg !132
  br i1 %241, label %validate_active_payload11, label %validate_payload_done12, !dbg !132

validate_active_payload11:                        ; preds = %validate_payload_done
  %242 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, 2, !dbg !132
  %243 = extractvalue %"/@stdlib/console.void::io_error" %242, 0, !dbg !132
  %244 = extractvalue %"/@stdlib/console.void::io_error" %242, 1, !dbg !132
  %245 = extractvalue %"/@stdlib/console.void::io_error" %242, 2, !dbg !132
  %246 = extractvalue %"/@stdlib/console.void::io_error_kind" %245, 0, !dbg !132
  %247 = extractvalue %"/@stdlib/console.void::io_error" %242, 3, !dbg !132
  %248 = extractvalue %"/@stdlib/console.void::io_error" %242, 4, !dbg !132
  %249 = extractvalue %"/@stdlib/console.void::io_error" %242, 5, !dbg !132
  %250 = extractvalue %"/@stdlib/console.void::io_error" %242, 6, !dbg !132
  %251 = extractvalue %"/@stdlib/console.void::io_error" %242, 7, !dbg !132
  %252 = extractvalue %"/@stdlib/console.void::io_error" %242, 8, !dbg !132
  br label %validate_payload_done12, !dbg !132

validate_payload_done12:                          ; preds = %validate_active_payload11, %validate_payload_done
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, ptr %113, align 8, !dbg !132
  call void @vd_gc_frame_leave(ptr %153), !dbg !132
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %232, !dbg !132

worker.cancelled13:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %153), !dbg !132
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !132

worker.continue14:                                ; preds = %block2
  br label %block3, !dbg !132

worker.cancelled15:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %153), !dbg !132
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !132

worker.continue16:                                ; preds = %block3
  %253 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !145
  store %"/@stdlib/console.void::_reply" %253, ptr %118, align 8, !dbg !145
  %254 = extractvalue %"/@stdlib/console.void::_reply" %253, 2, !dbg !146
  store i64 %254, ptr %14, align 8, !dbg !146
  %255 = load i64, ptr %14, align 8, !dbg !147
  %256 = insertvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, i64 %255, 1, !dbg !147
  %257 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 0, !dbg !147
  %258 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 0, !dbg !147
  %259 = icmp eq i32 %258, 0, !dbg !147
  br i1 %259, label %validate_active_payload17, label %validate_payload_done18, !dbg !147

validate_active_payload17:                        ; preds = %worker.continue16
  %260 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 1, !dbg !147
  br label %validate_payload_done18, !dbg !147

validate_payload_done18:                          ; preds = %validate_active_payload17, %worker.continue16
  %261 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 0, !dbg !147
  %262 = icmp eq i32 %261, 1, !dbg !147
  br i1 %262, label %validate_active_payload19, label %validate_payload_done20, !dbg !147

validate_active_payload19:                        ; preds = %validate_payload_done18
  %263 = extractvalue %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, 2, !dbg !147
  %264 = extractvalue %"/@stdlib/console.void::io_error" %263, 0, !dbg !147
  %265 = extractvalue %"/@stdlib/console.void::io_error" %263, 1, !dbg !147
  %266 = extractvalue %"/@stdlib/console.void::io_error" %263, 2, !dbg !147
  %267 = extractvalue %"/@stdlib/console.void::io_error_kind" %266, 0, !dbg !147
  %268 = extractvalue %"/@stdlib/console.void::io_error" %263, 3, !dbg !147
  %269 = extractvalue %"/@stdlib/console.void::io_error" %263, 4, !dbg !147
  %270 = extractvalue %"/@stdlib/console.void::io_error" %263, 5, !dbg !147
  %271 = extractvalue %"/@stdlib/console.void::io_error" %263, 6, !dbg !147
  %272 = extractvalue %"/@stdlib/console.void::io_error" %263, 7, !dbg !147
  %273 = extractvalue %"/@stdlib/console.void::io_error" %263, 8, !dbg !147
  br label %validate_payload_done20, !dbg !147

validate_payload_done20:                          ; preds = %validate_active_payload19, %validate_payload_done18
  store %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, ptr %123, align 8, !dbg !147
  call void @vd_gc_frame_leave(ptr %153), !dbg !147
  ret %"$result:$array:2:5::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %256, !dbg !147
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a666c757368__v1(ptr %0, ptr %1) !dbg !148 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %9, align 8
  %10 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %10, align 8
  %11 = alloca i1, align 1
  store i1 false, ptr %11, align 1
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 80, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.116, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 2, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 80, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.117, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 2, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 8, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.118, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 1, 3
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.119, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 72, 1
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, ptr @gc.offsets.120, 2
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 4, 3
  %32 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %32, align 8
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %32, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 80, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.121, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 2, 3
  %37 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %37, align 8
  %38 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %37, 0
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 80, 1
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, ptr @gc.offsets.122, 2
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 2, 3
  %42 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %42, align 8
  %43 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %42, 0
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 80, 1
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, ptr @gc.offsets.123, 2
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 2, 3
  %47 = alloca ptr, align 8
  store ptr null, ptr %47, align 8
  %48 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %47, 0
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 8, 1
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, ptr @gc.offsets.124, 2
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 1, 3
  %52 = alloca ptr, align 8
  store ptr null, ptr %52, align 8
  %53 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %52, 0
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 8, 1
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, ptr @gc.offsets.125, 2
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 1, 3
  %57 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %57, align 8
  %58 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %57, 0
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, i64 80, 1
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, ptr @gc.offsets.126, 2
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 2, 3
  %62 = alloca ptr, align 8
  store ptr null, ptr %62, align 8
  %63 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %62, 0
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, i64 8, 1
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, ptr @gc.offsets.127, 2
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, i64 1, 3
  %67 = alloca ptr, align 8
  store ptr null, ptr %67, align 8
  %68 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %67, 0
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, i64 8, 1
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, ptr @gc.offsets.128, 2
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 1, 3
  %72 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %72, align 8
  %73 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %72, 0
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, i64 72, 1
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, ptr @gc.offsets.129, 2
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, i64 4, 3
  %77 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %77, align 8
  %78 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %77, 0
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, i64 72, 1
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, ptr @gc.offsets.130, 2
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, i64 4, 3
  %82 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %82, align 8
  %83 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %82, 0
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, i64 80, 1
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, ptr @gc.offsets.131, 2
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, i64 4, 3
  %87 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %87, align 8
  %88 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %87, 0
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, i64 80, 1
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, ptr @gc.offsets.132, 2
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, i64 4, 3
  %92 = alloca [17 x { ptr, i64, ptr, i64 }], align 8
  %93 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %15, ptr %93, align 8
  %94 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %19, ptr %94, align 8
  %95 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %23, ptr %95, align 8
  %96 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %27, ptr %96, align 8
  %97 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %31, ptr %97, align 8
  %98 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %36, ptr %98, align 8
  %99 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %41, ptr %99, align 8
  %100 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %46, ptr %100, align 8
  %101 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %51, ptr %101, align 8
  %102 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %56, ptr %102, align 8
  %103 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %61, ptr %103, align 8
  %104 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %66, ptr %104, align 8
  %105 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %71, ptr %105, align 8
  %106 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %76, ptr %106, align 8
  %107 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %81, ptr %107, align 8
  %108 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %86, ptr %108, align 8
  %109 = getelementptr inbounds [17 x { ptr, i64, ptr, i64 }], ptr %92, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %91, ptr %109, align 8
  %110 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %110, ptr %92, i64 17)
  call void @vd_gc_poll()
  %111 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %111, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !155
  %112 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !155
  br i1 %112, label %worker.cancelled1, label %worker.continue2, !dbg !155

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !156
  %113 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !156
  br i1 %113, label %worker.cancelled13, label %worker.continue14, !dbg !156

block3:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !156
  %114 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !156
  br i1 %114, label %worker.cancelled15, label %worker.continue16, !dbg !156

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %110)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %115 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !157
  store %"/@stdlib/console.void::output" %115, ptr %4, align 8, !dbg !157
  %116 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !158
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %32, align 8, !dbg !158
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !158
  %117 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 6, !dbg !158
  %118 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 7, !dbg !158
  %119 = extractvalue %"/@stdlib/console.void::output" %116, 0, !dbg !158
  call void @vd_console_v2(ptr %117, ptr %118, ptr %2, i32 7, i64 %119, ptr null, i64 0, i64 -1, ptr %1), !dbg !158
  %120 = load ptr, ptr %1, align 8, !dbg !158
  %121 = icmp ne ptr %120, null, !dbg !158
  br i1 %121, label %selected.failure, label %selected.valid, !dbg !158

selected.failure:                                 ; preds = %worker.continue
  %122 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !158
  %123 = load i32, ptr %122, align 4, !dbg !158
  %124 = icmp ult i32 %123, 32, !dbg !158
  br i1 %124, label %trace_caller, label %trace_limit, !dbg !158

selected.valid:                                   ; preds = %worker.continue
  %125 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !158
  %126 = load i64, ptr %125, align 8, !dbg !158
  %127 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 0, !dbg !158
  store i64 %126, ptr %127, align 8, !dbg !158
  %128 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !158
  %129 = load i64, ptr %128, align 8, !dbg !158
  %130 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 1, !dbg !158
  store i64 %129, ptr %130, align 8, !dbg !158
  %131 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !158
  %132 = load i64, ptr %131, align 8, !dbg !158
  %133 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 2, !dbg !158
  store i64 %132, ptr %133, align 8, !dbg !158
  %134 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !158
  %135 = load i64, ptr %134, align 8, !dbg !158
  %136 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 3, !dbg !158
  store i64 %135, ptr %136, align 8, !dbg !158
  %137 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !158
  %138 = load i64, ptr %137, align 8, !dbg !158
  %139 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 4, !dbg !158
  store i64 %138, ptr %139, align 8, !dbg !158
  %140 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !158
  %141 = load i64, ptr %140, align 8, !dbg !158
  %142 = trunc i64 %141 to i1, !dbg !158
  %143 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 5, !dbg !158
  store i1 %142, ptr %143, align 1, !dbg !158
  %144 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !158
  %145 = load i64, ptr %144, align 8, !dbg !158
  %146 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 8, !dbg !158
  store i64 %145, ptr %146, align 8, !dbg !158
  %147 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !158
  %148 = load i64, ptr %147, align 8, !dbg !158
  %149 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 9, !dbg !158
  store i64 %148, ptr %149, align 8, !dbg !158
  %150 = load %"/@stdlib/console.void::_reply", ptr %32, align 8, !dbg !158
  store %"/@stdlib/console.void::_reply" %150, ptr %32, align 8, !dbg !158
  store %"/@stdlib/console.void::_reply" %150, ptr %3, align 8, !dbg !159
  %151 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !160
  store %"/@stdlib/console.void::_reply" %151, ptr %37, align 8, !dbg !160
  %152 = extractvalue %"/@stdlib/console.void::_reply" %151, 0, !dbg !161
  store i64 %152, ptr %5, align 8, !dbg !155
  %153 = load i64, ptr %5, align 8, !dbg !155
  %154 = icmp ne i64 %153, 0, !dbg !155
  br i1 %154, label %block1, label %block2, !dbg !155

trace_caller:                                     ; preds = %selected.failure
  %155 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !158
  %156 = getelementptr [32 x ptr], ptr %155, i32 0, i32 %123, !dbg !158
  store ptr @102, ptr %156, align 8, !dbg !158
  %157 = add i32 %123, 1, !dbg !158
  store i32 %157, ptr %122, align 4, !dbg !158
  br label %error_return, !dbg !158

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %110), !dbg !158
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !158

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %122, align 4, !dbg !158
  br label %error_return, !dbg !158

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %110), !dbg !155
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !155

worker.continue2:                                 ; preds = %block1
  %158 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !162
  store %"/@stdlib/console.void::_reply" %158, ptr %42, align 8, !dbg !162
  store %"/@stdlib/console.void::_reply" %158, ptr %6, align 8, !dbg !162
  call void @vd_string_literal(ptr %47, ptr @103, i64 5, ptr %1), !dbg !163
  %159 = load ptr, ptr %47, align 8, !dbg !163
  %160 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !163
  %161 = load ptr, ptr %160, align 8, !dbg !163
  %162 = icmp ne ptr %161, null, !dbg !163
  br i1 %162, label %numeric_error, label %numeric_valid, !dbg !163

numeric_error:                                    ; preds = %worker.continue2
  %163 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !163
  store ptr @104, ptr %163, align 8, !dbg !163
  call void @vd_gc_frame_leave(ptr %110), !dbg !163
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !163

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %159, ptr %47, align 8, !dbg !163
  store ptr %159, ptr %7, align 8, !dbg !163
  %164 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !164
  store %"/@stdlib/console.void::output" %164, ptr %9, align 8, !dbg !164
  %165 = load %"/@stdlib/console.void::output", ptr %9, align 8, !dbg !165
  %166 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %165, ptr %1), !dbg !165
  %167 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !165
  %168 = load ptr, ptr %167, align 8, !dbg !165
  %169 = icmp ne ptr %168, null, !dbg !165
  br i1 %169, label %propagate_error, label %call_success, !dbg !165

propagate_error:                                  ; preds = %numeric_valid
  %170 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !165
  %171 = load i32, ptr %170, align 4, !dbg !165
  %172 = icmp ult i32 %171, 32, !dbg !165
  br i1 %172, label %trace_caller3, label %trace_limit5, !dbg !165

call_success:                                     ; preds = %numeric_valid
  store ptr %166, ptr %52, align 8, !dbg !165
  store ptr %166, ptr %8, align 8, !dbg !165
  %173 = load %"/@stdlib/console.void::_reply", ptr %6, align 8, !dbg !166
  store %"/@stdlib/console.void::_reply" %173, ptr %57, align 8, !dbg !166
  %174 = load ptr, ptr %7, align 8, !dbg !166
  store ptr %174, ptr %62, align 8, !dbg !166
  %175 = load ptr, ptr %8, align 8, !dbg !166
  store ptr %175, ptr %67, align 8, !dbg !166
  %176 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %173, ptr %174, ptr %175, ptr %1), !dbg !166
  %177 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !166
  %178 = load ptr, ptr %177, align 8, !dbg !166
  %179 = icmp ne ptr %178, null, !dbg !166
  br i1 %179, label %propagate_error6, label %call_success7, !dbg !166

trace_caller3:                                    ; preds = %propagate_error
  %180 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !165
  %181 = getelementptr [32 x ptr], ptr %180, i32 0, i32 %171, !dbg !165
  store ptr @105, ptr %181, align 8, !dbg !165
  %182 = add i32 %171, 1, !dbg !165
  store i32 %182, ptr %170, align 4, !dbg !165
  br label %error_return4, !dbg !165

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %110), !dbg !165
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !165

trace_limit5:                                     ; preds = %propagate_error
  store i32 33, ptr %170, align 4, !dbg !165
  br label %error_return4, !dbg !165

propagate_error6:                                 ; preds = %call_success
  %183 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !166
  %184 = load i32, ptr %183, align 4, !dbg !166
  %185 = icmp ult i32 %184, 32, !dbg !166
  br i1 %185, label %trace_caller8, label %trace_limit10, !dbg !166

call_success7:                                    ; preds = %call_success
  store %"/@stdlib/console.void::io_error" %176, ptr %72, align 8, !dbg !166
  store %"/@stdlib/console.void::io_error" %176, ptr %10, align 8, !dbg !166
  %186 = load %"/@stdlib/console.void::io_error", ptr %10, align 8, !dbg !156
  store %"/@stdlib/console.void::io_error" %186, ptr %77, align 8, !dbg !156
  %187 = insertvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, i1 false, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %186, 2, !dbg !156
  %188 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, 0, !dbg !156
  %189 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, 0, !dbg !156
  %190 = icmp eq i32 %189, 0, !dbg !156
  br i1 %190, label %validate_active_payload, label %validate_payload_done, !dbg !156

trace_caller8:                                    ; preds = %propagate_error6
  %191 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !166
  %192 = getelementptr [32 x ptr], ptr %191, i32 0, i32 %184, !dbg !166
  store ptr @106, ptr %192, align 8, !dbg !166
  %193 = add i32 %184, 1, !dbg !166
  store i32 %193, ptr %183, align 4, !dbg !166
  br label %error_return9, !dbg !166

error_return9:                                    ; preds = %trace_caller8, %trace_limit10
  call void @vd_gc_frame_leave(ptr %110), !dbg !166
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !166

trace_limit10:                                    ; preds = %propagate_error6
  store i32 33, ptr %183, align 4, !dbg !166
  br label %error_return9, !dbg !166

validate_active_payload:                          ; preds = %call_success7
  %194 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, 1, !dbg !156
  br label %validate_payload_done, !dbg !156

validate_payload_done:                            ; preds = %validate_active_payload, %call_success7
  %195 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, 0, !dbg !156
  %196 = icmp eq i32 %195, 1, !dbg !156
  br i1 %196, label %validate_active_payload11, label %validate_payload_done12, !dbg !156

validate_active_payload11:                        ; preds = %validate_payload_done
  %197 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, 2, !dbg !156
  %198 = extractvalue %"/@stdlib/console.void::io_error" %197, 0, !dbg !156
  %199 = extractvalue %"/@stdlib/console.void::io_error" %197, 1, !dbg !156
  %200 = extractvalue %"/@stdlib/console.void::io_error" %197, 2, !dbg !156
  %201 = extractvalue %"/@stdlib/console.void::io_error_kind" %200, 0, !dbg !156
  %202 = extractvalue %"/@stdlib/console.void::io_error" %197, 3, !dbg !156
  %203 = extractvalue %"/@stdlib/console.void::io_error" %197, 4, !dbg !156
  %204 = extractvalue %"/@stdlib/console.void::io_error" %197, 5, !dbg !156
  %205 = extractvalue %"/@stdlib/console.void::io_error" %197, 6, !dbg !156
  %206 = extractvalue %"/@stdlib/console.void::io_error" %197, 7, !dbg !156
  %207 = extractvalue %"/@stdlib/console.void::io_error" %197, 8, !dbg !156
  br label %validate_payload_done12, !dbg !156

validate_payload_done12:                          ; preds = %validate_active_payload11, %validate_payload_done
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, ptr %82, align 8, !dbg !156
  call void @vd_gc_frame_leave(ptr %110), !dbg !156
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %187, !dbg !156

worker.cancelled13:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %110), !dbg !156
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !156

worker.continue14:                                ; preds = %block2
  br label %block3, !dbg !156

worker.cancelled15:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %110), !dbg !156
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !156

worker.continue16:                                ; preds = %block3
  store i1 true, ptr %11, align 1, !dbg !167
  %208 = load i1, ptr %11, align 1, !dbg !168
  %209 = insertvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, i1 %208, 1, !dbg !168
  %210 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, 0, !dbg !168
  %211 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, 0, !dbg !168
  %212 = icmp eq i32 %211, 0, !dbg !168
  br i1 %212, label %validate_active_payload17, label %validate_payload_done18, !dbg !168

validate_active_payload17:                        ; preds = %worker.continue16
  %213 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, 1, !dbg !168
  br label %validate_payload_done18, !dbg !168

validate_payload_done18:                          ; preds = %validate_active_payload17, %worker.continue16
  %214 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, 0, !dbg !168
  %215 = icmp eq i32 %214, 1, !dbg !168
  br i1 %215, label %validate_active_payload19, label %validate_payload_done20, !dbg !168

validate_active_payload19:                        ; preds = %validate_payload_done18
  %216 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, 2, !dbg !168
  %217 = extractvalue %"/@stdlib/console.void::io_error" %216, 0, !dbg !168
  %218 = extractvalue %"/@stdlib/console.void::io_error" %216, 1, !dbg !168
  %219 = extractvalue %"/@stdlib/console.void::io_error" %216, 2, !dbg !168
  %220 = extractvalue %"/@stdlib/console.void::io_error_kind" %219, 0, !dbg !168
  %221 = extractvalue %"/@stdlib/console.void::io_error" %216, 3, !dbg !168
  %222 = extractvalue %"/@stdlib/console.void::io_error" %216, 4, !dbg !168
  %223 = extractvalue %"/@stdlib/console.void::io_error" %216, 5, !dbg !168
  %224 = extractvalue %"/@stdlib/console.void::io_error" %216, 6, !dbg !168
  %225 = extractvalue %"/@stdlib/console.void::io_error" %216, 7, !dbg !168
  %226 = extractvalue %"/@stdlib/console.void::io_error" %216, 8, !dbg !168
  br label %validate_payload_done20, !dbg !168

validate_payload_done20:                          ; preds = %validate_active_payload19, %validate_payload_done18
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, ptr %87, align 8, !dbg !168
  call void @vd_gc_frame_leave(ptr %110), !dbg !168
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %209, !dbg !168
}

define i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a69735f72656469726563746564__v1(ptr %0, ptr %1) !dbg !169 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %3, align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, i64 80, 1
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, ptr @gc.offsets.133, 2
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 2, 3
  %10 = alloca [1 x { ptr, i64, ptr, i64 }], align 8
  %11 = getelementptr inbounds [1 x { ptr, i64, ptr, i64 }], ptr %10, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %9, ptr %11, align 8
  %12 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %12, ptr %10, i64 1)
  call void @vd_gc_poll()
  %13 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %13, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %12)
  ret i1 false

worker.continue:                                  ; preds = %block0
  %14 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !172
  store %"/@stdlib/console.void::output" %14, ptr %3, align 8, !dbg !172
  %15 = load %"/@stdlib/console.void::output", ptr %3, align 8, !dbg !173
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8, !dbg !173
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !173
  %16 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 6, !dbg !173
  %17 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 7, !dbg !173
  %18 = extractvalue %"/@stdlib/console.void::output" %15, 0, !dbg !173
  call void @vd_console_v2(ptr %16, ptr %17, ptr %2, i32 6, i64 %18, ptr null, i64 0, i64 -1, ptr %1), !dbg !173
  %19 = load ptr, ptr %1, align 8, !dbg !173
  %20 = icmp ne ptr %19, null, !dbg !173
  br i1 %20, label %selected.failure, label %selected.valid, !dbg !173

selected.failure:                                 ; preds = %worker.continue
  %21 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !173
  %22 = load i32, ptr %21, align 4, !dbg !173
  %23 = icmp ult i32 %22, 32, !dbg !173
  br i1 %23, label %trace_caller, label %trace_limit, !dbg !173

selected.valid:                                   ; preds = %worker.continue
  %24 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !173
  %25 = load i64, ptr %24, align 8, !dbg !173
  %26 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 0, !dbg !173
  store i64 %25, ptr %26, align 8, !dbg !173
  %27 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !173
  %28 = load i64, ptr %27, align 8, !dbg !173
  %29 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 1, !dbg !173
  store i64 %28, ptr %29, align 8, !dbg !173
  %30 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !173
  %31 = load i64, ptr %30, align 8, !dbg !173
  %32 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 2, !dbg !173
  store i64 %31, ptr %32, align 8, !dbg !173
  %33 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !173
  %34 = load i64, ptr %33, align 8, !dbg !173
  %35 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 3, !dbg !173
  store i64 %34, ptr %35, align 8, !dbg !173
  %36 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !173
  %37 = load i64, ptr %36, align 8, !dbg !173
  %38 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 4, !dbg !173
  store i64 %37, ptr %38, align 8, !dbg !173
  %39 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !173
  %40 = load i64, ptr %39, align 8, !dbg !173
  %41 = trunc i64 %40 to i1, !dbg !173
  %42 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 5, !dbg !173
  store i1 %41, ptr %42, align 1, !dbg !173
  %43 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !173
  %44 = load i64, ptr %43, align 8, !dbg !173
  %45 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 8, !dbg !173
  store i64 %44, ptr %45, align 8, !dbg !173
  %46 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !173
  %47 = load i64, ptr %46, align 8, !dbg !173
  %48 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 9, !dbg !173
  store i64 %47, ptr %48, align 8, !dbg !173
  %49 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !173
  store %"/@stdlib/console.void::_reply" %49, ptr %5, align 8, !dbg !173
  %50 = extractvalue %"/@stdlib/console.void::_reply" %49, 2, !dbg !174
  store i64 %50, ptr %4, align 8, !dbg !175
  %51 = load i64, ptr %4, align 8, !dbg !175
  %52 = icmp ne i64 %51, 0, !dbg !175
  call void @vd_gc_frame_leave(ptr %12), !dbg !175
  ret i1 %52, !dbg !175

trace_caller:                                     ; preds = %selected.failure
  %53 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !173
  %54 = getelementptr [32 x ptr], ptr %53, i32 0, i32 %22, !dbg !173
  store ptr @107, ptr %54, align 8, !dbg !173
  %55 = add i32 %22, 1, !dbg !173
  store i32 %55, ptr %21, align 4, !dbg !173
  br label %error_return, !dbg !173

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %12), !dbg !173
  ret i1 false, !dbg !173

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %21, align 4, !dbg !173
  br label %error_return, !dbg !173
}

define i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a69735f72656469726563746564__v1(ptr %0, ptr %1) !dbg !176 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %3, align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, i64 80, 1
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, ptr @gc.offsets.134, 2
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 2, 3
  %10 = alloca [1 x { ptr, i64, ptr, i64 }], align 8
  %11 = getelementptr inbounds [1 x { ptr, i64, ptr, i64 }], ptr %10, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %9, ptr %11, align 8
  %12 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %12, ptr %10, i64 1)
  call void @vd_gc_poll()
  %13 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %13, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %12)
  ret i1 false

worker.continue:                                  ; preds = %block0
  %14 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !181
  store %"/@stdlib/console.void::input" %14, ptr %3, align 8, !dbg !181
  %15 = load %"/@stdlib/console.void::input", ptr %3, align 8, !dbg !182
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8, !dbg !182
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !182
  %16 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 6, !dbg !182
  %17 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 7, !dbg !182
  %18 = extractvalue %"/@stdlib/console.void::input" %15, 0, !dbg !182
  call void @vd_console_v2(ptr %16, ptr %17, ptr %2, i32 6, i64 %18, ptr null, i64 0, i64 -1, ptr %1), !dbg !182
  %19 = load ptr, ptr %1, align 8, !dbg !182
  %20 = icmp ne ptr %19, null, !dbg !182
  br i1 %20, label %selected.failure, label %selected.valid, !dbg !182

selected.failure:                                 ; preds = %worker.continue
  %21 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !182
  %22 = load i32, ptr %21, align 4, !dbg !182
  %23 = icmp ult i32 %22, 32, !dbg !182
  br i1 %23, label %trace_caller, label %trace_limit, !dbg !182

selected.valid:                                   ; preds = %worker.continue
  %24 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !182
  %25 = load i64, ptr %24, align 8, !dbg !182
  %26 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 0, !dbg !182
  store i64 %25, ptr %26, align 8, !dbg !182
  %27 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !182
  %28 = load i64, ptr %27, align 8, !dbg !182
  %29 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 1, !dbg !182
  store i64 %28, ptr %29, align 8, !dbg !182
  %30 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !182
  %31 = load i64, ptr %30, align 8, !dbg !182
  %32 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 2, !dbg !182
  store i64 %31, ptr %32, align 8, !dbg !182
  %33 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !182
  %34 = load i64, ptr %33, align 8, !dbg !182
  %35 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 3, !dbg !182
  store i64 %34, ptr %35, align 8, !dbg !182
  %36 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !182
  %37 = load i64, ptr %36, align 8, !dbg !182
  %38 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 4, !dbg !182
  store i64 %37, ptr %38, align 8, !dbg !182
  %39 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !182
  %40 = load i64, ptr %39, align 8, !dbg !182
  %41 = trunc i64 %40 to i1, !dbg !182
  %42 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 5, !dbg !182
  store i1 %41, ptr %42, align 1, !dbg !182
  %43 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !182
  %44 = load i64, ptr %43, align 8, !dbg !182
  %45 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 8, !dbg !182
  store i64 %44, ptr %45, align 8, !dbg !182
  %46 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !182
  %47 = load i64, ptr %46, align 8, !dbg !182
  %48 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %5, i32 0, i32 9, !dbg !182
  store i64 %47, ptr %48, align 8, !dbg !182
  %49 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !182
  store %"/@stdlib/console.void::_reply" %49, ptr %5, align 8, !dbg !182
  %50 = extractvalue %"/@stdlib/console.void::_reply" %49, 2, !dbg !183
  store i64 %50, ptr %4, align 8, !dbg !184
  %51 = load i64, ptr %4, align 8, !dbg !184
  %52 = icmp ne i64 %51, 0, !dbg !184
  call void @vd_gc_frame_leave(ptr %12), !dbg !184
  ret i1 %52, !dbg !184

trace_caller:                                     ; preds = %selected.failure
  %53 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !182
  %54 = getelementptr [32 x ptr], ptr %53, i32 0, i32 %22, !dbg !182
  store ptr @108, ptr %54, align 8, !dbg !182
  %55 = add i32 %22, 1, !dbg !182
  store i32 %55, ptr %21, align 4, !dbg !182
  br label %error_return, !dbg !182

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %12), !dbg !182
  ret i1 false, !dbg !182

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %21, align 4, !dbg !182
  br label %error_return, !dbg !182
}

define internal %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f74657874__v1(%"/@stdlib/console.void::_reply" %0, ptr %1, ptr %2) !dbg !185 {
block0:
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %9, align 8
  %10 = alloca %"/@stdlib/console.void::text_read", align 8
  store %"/@stdlib/console.void::text_read" zeroinitializer, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca %"/@stdlib/console.void::text_read", align 8
  store %"/@stdlib/console.void::text_read" zeroinitializer, ptr %12, align 8
  %13 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, i64 80, 1
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, ptr @gc.offsets.135, 2
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 2, 3
  %17 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 8, 1
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, ptr @gc.offsets.136, 2
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 1, 3
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 80, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.137, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 2, 3
  %25 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 8, 1
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, ptr @gc.offsets.138, 2
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 1, 3
  %29 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 8, 1
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, ptr @gc.offsets.139, 2
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 1, 3
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 72, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.140, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 4, 3
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 16, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.141, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 1, 3
  %41 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 8, 1
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, ptr @gc.offsets.142, 2
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 1, 3
  %45 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %12, 0
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 16, 1
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, ptr @gc.offsets.143, 2
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 1, 3
  %49 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" %0, ptr %49, align 8
  %50 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %49, 0
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 80, 1
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, ptr @gc.offsets.144, 2
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 2, 3
  %54 = alloca ptr, align 8
  store ptr %1, ptr %54, align 8
  %55 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %54, 0
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 8, 1
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, ptr @gc.offsets.145, 2
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 1, 3
  %59 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %59, align 8
  %60 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %59, 0
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 80, 1
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, ptr @gc.offsets.146, 2
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 2, 3
  %64 = alloca ptr, align 8
  store ptr null, ptr %64, align 8
  %65 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %64, 0
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, i64 8, 1
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, ptr @gc.offsets.147, 2
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 1, 3
  %69 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %69, align 8
  %70 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %69, 0
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 80, 1
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, ptr @gc.offsets.148, 2
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 2, 3
  %74 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %74, align 8
  %75 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %74, 0
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, i64 80, 1
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, ptr @gc.offsets.149, 2
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 2, 3
  %79 = alloca ptr, align 8
  store ptr null, ptr %79, align 8
  %80 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %79, 0
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, i64 8, 1
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, ptr @gc.offsets.150, 2
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 1, 3
  %84 = alloca ptr, align 8
  store ptr null, ptr %84, align 8
  %85 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %84, 0
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, i64 8, 1
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, ptr @gc.offsets.151, 2
  %88 = insertvalue { ptr, i64, ptr, i64 } %87, i64 1, 3
  %89 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %89, align 8
  %90 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %89, 0
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, i64 80, 1
  %92 = insertvalue { ptr, i64, ptr, i64 } %91, ptr @gc.offsets.152, 2
  %93 = insertvalue { ptr, i64, ptr, i64 } %92, i64 2, 3
  %94 = alloca ptr, align 8
  store ptr null, ptr %94, align 8
  %95 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %94, 0
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, i64 8, 1
  %97 = insertvalue { ptr, i64, ptr, i64 } %96, ptr @gc.offsets.153, 2
  %98 = insertvalue { ptr, i64, ptr, i64 } %97, i64 1, 3
  %99 = alloca ptr, align 8
  store ptr null, ptr %99, align 8
  %100 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %99, 0
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, i64 8, 1
  %102 = insertvalue { ptr, i64, ptr, i64 } %101, ptr @gc.offsets.154, 2
  %103 = insertvalue { ptr, i64, ptr, i64 } %102, i64 1, 3
  %104 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %104, align 8
  %105 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %104, 0
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, i64 72, 1
  %107 = insertvalue { ptr, i64, ptr, i64 } %106, ptr @gc.offsets.155, 2
  %108 = insertvalue { ptr, i64, ptr, i64 } %107, i64 4, 3
  %109 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %109, align 8
  %110 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %109, 0
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, i64 72, 1
  %112 = insertvalue { ptr, i64, ptr, i64 } %111, ptr @gc.offsets.156, 2
  %113 = insertvalue { ptr, i64, ptr, i64 } %112, i64 4, 3
  %114 = alloca %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %114, align 8
  %115 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %114, 0
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, i64 96, 1
  %117 = insertvalue { ptr, i64, ptr, i64 } %116, ptr @gc.offsets.157, 2
  %118 = insertvalue { ptr, i64, ptr, i64 } %117, i64 5, 3
  %119 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %119, align 8
  %120 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %119, 0
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, i64 80, 1
  %122 = insertvalue { ptr, i64, ptr, i64 } %121, ptr @gc.offsets.158, 2
  %123 = insertvalue { ptr, i64, ptr, i64 } %122, i64 2, 3
  %124 = alloca %"/@stdlib/console.void::text_read", align 8
  store %"/@stdlib/console.void::text_read" zeroinitializer, ptr %124, align 8
  %125 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %124, 0
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, i64 16, 1
  %127 = insertvalue { ptr, i64, ptr, i64 } %126, ptr @gc.offsets.159, 2
  %128 = insertvalue { ptr, i64, ptr, i64 } %127, i64 1, 3
  %129 = alloca %"/@stdlib/console.void::text_read", align 8
  store %"/@stdlib/console.void::text_read" zeroinitializer, ptr %129, align 8
  %130 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %129, 0
  %131 = insertvalue { ptr, i64, ptr, i64 } %130, i64 16, 1
  %132 = insertvalue { ptr, i64, ptr, i64 } %131, ptr @gc.offsets.160, 2
  %133 = insertvalue { ptr, i64, ptr, i64 } %132, i64 1, 3
  %134 = alloca %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %134, align 8
  %135 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %134, 0
  %136 = insertvalue { ptr, i64, ptr, i64 } %135, i64 96, 1
  %137 = insertvalue { ptr, i64, ptr, i64 } %136, ptr @gc.offsets.161, 2
  %138 = insertvalue { ptr, i64, ptr, i64 } %137, i64 5, 3
  %139 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %139, align 8
  %140 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %139, 0
  %141 = insertvalue { ptr, i64, ptr, i64 } %140, i64 80, 1
  %142 = insertvalue { ptr, i64, ptr, i64 } %141, ptr @gc.offsets.162, 2
  %143 = insertvalue { ptr, i64, ptr, i64 } %142, i64 2, 3
  %144 = alloca ptr, align 8
  store ptr null, ptr %144, align 8
  %145 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %144, 0
  %146 = insertvalue { ptr, i64, ptr, i64 } %145, i64 8, 1
  %147 = insertvalue { ptr, i64, ptr, i64 } %146, ptr @gc.offsets.163, 2
  %148 = insertvalue { ptr, i64, ptr, i64 } %147, i64 1, 3
  %149 = alloca ptr, align 8
  store ptr null, ptr %149, align 8
  %150 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %149, 0
  %151 = insertvalue { ptr, i64, ptr, i64 } %150, i64 8, 1
  %152 = insertvalue { ptr, i64, ptr, i64 } %151, ptr @gc.offsets.164, 2
  %153 = insertvalue { ptr, i64, ptr, i64 } %152, i64 1, 3
  %154 = alloca %"/@stdlib/console.void::text_read", align 8
  store %"/@stdlib/console.void::text_read" zeroinitializer, ptr %154, align 8
  %155 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %154, 0
  %156 = insertvalue { ptr, i64, ptr, i64 } %155, i64 16, 1
  %157 = insertvalue { ptr, i64, ptr, i64 } %156, ptr @gc.offsets.165, 2
  %158 = insertvalue { ptr, i64, ptr, i64 } %157, i64 1, 3
  %159 = alloca %"/@stdlib/console.void::text_read", align 8
  store %"/@stdlib/console.void::text_read" zeroinitializer, ptr %159, align 8
  %160 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %159, 0
  %161 = insertvalue { ptr, i64, ptr, i64 } %160, i64 16, 1
  %162 = insertvalue { ptr, i64, ptr, i64 } %161, ptr @gc.offsets.166, 2
  %163 = insertvalue { ptr, i64, ptr, i64 } %162, i64 1, 3
  %164 = alloca %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %164, align 8
  %165 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %164, 0
  %166 = insertvalue { ptr, i64, ptr, i64 } %165, i64 96, 1
  %167 = insertvalue { ptr, i64, ptr, i64 } %166, ptr @gc.offsets.167, 2
  %168 = insertvalue { ptr, i64, ptr, i64 } %167, i64 5, 3
  %169 = alloca [33 x { ptr, i64, ptr, i64 }], align 8
  %170 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %16, ptr %170, align 8
  %171 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %20, ptr %171, align 8
  %172 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %24, ptr %172, align 8
  %173 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %28, ptr %173, align 8
  %174 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %32, ptr %174, align 8
  %175 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %36, ptr %175, align 8
  %176 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %40, ptr %176, align 8
  %177 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %44, ptr %177, align 8
  %178 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %48, ptr %178, align 8
  %179 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %53, ptr %179, align 8
  %180 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %58, ptr %180, align 8
  %181 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %63, ptr %181, align 8
  %182 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %68, ptr %182, align 8
  %183 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %73, ptr %183, align 8
  %184 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %78, ptr %184, align 8
  %185 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %83, ptr %185, align 8
  %186 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %88, ptr %186, align 8
  %187 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %93, ptr %187, align 8
  %188 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %98, ptr %188, align 8
  %189 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %103, ptr %189, align 8
  %190 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %108, ptr %190, align 8
  %191 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %113, ptr %191, align 8
  %192 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %118, ptr %192, align 8
  %193 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %123, ptr %193, align 8
  %194 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 24
  store { ptr, i64, ptr, i64 } %128, ptr %194, align 8
  %195 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 25
  store { ptr, i64, ptr, i64 } %133, ptr %195, align 8
  %196 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 26
  store { ptr, i64, ptr, i64 } %138, ptr %196, align 8
  %197 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 27
  store { ptr, i64, ptr, i64 } %143, ptr %197, align 8
  %198 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 28
  store { ptr, i64, ptr, i64 } %148, ptr %198, align 8
  %199 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 29
  store { ptr, i64, ptr, i64 } %153, ptr %199, align 8
  %200 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 30
  store { ptr, i64, ptr, i64 } %158, ptr %200, align 8
  %201 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 31
  store { ptr, i64, ptr, i64 } %163, ptr %201, align 8
  %202 = getelementptr inbounds [33 x { ptr, i64, ptr, i64 }], ptr %169, i32 0, i32 32
  store { ptr, i64, ptr, i64 } %168, ptr %202, align 8
  %203 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %203, ptr %169, i64 33)
  call void @vd_gc_poll()
  %204 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %204, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !195
  %205 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !195
  br i1 %205, label %worker.cancelled1, label %worker.continue2, !dbg !195

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !196
  %206 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !196
  br i1 %206, label %worker.cancelled7, label %worker.continue8, !dbg !196

block3:                                           ; preds = %worker.continue8
  call void @vd_gc_poll(), !dbg !196
  %207 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !196
  br i1 %207, label %worker.cancelled9, label %worker.continue10, !dbg !196

block4:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !197
  %208 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !197
  br i1 %208, label %worker.cancelled11, label %worker.continue12, !dbg !197

block5:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !198
  %209 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !198
  br i1 %209, label %worker.cancelled21, label %worker.continue22, !dbg !198

block6:                                           ; preds = %worker.continue22
  call void @vd_gc_poll(), !dbg !198
  %210 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !198
  br i1 %210, label %worker.cancelled23, label %worker.continue24, !dbg !198

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %203)
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::_reply" %0, ptr %59, align 8, !dbg !199
  store %"/@stdlib/console.void::_reply" %0, ptr %3, align 8, !dbg !199
  store ptr %1, ptr %64, align 8, !dbg !200
  store ptr %1, ptr %4, align 8, !dbg !200
  %211 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !201
  store %"/@stdlib/console.void::_reply" %211, ptr %69, align 8, !dbg !201
  %212 = extractvalue %"/@stdlib/console.void::_reply" %211, 0, !dbg !202
  store i64 %212, ptr %5, align 8, !dbg !195
  %213 = load i64, ptr %5, align 8, !dbg !195
  %214 = icmp ne i64 %213, 0, !dbg !195
  br i1 %214, label %block1, label %block2, !dbg !195

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %203), !dbg !195
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !195

worker.continue2:                                 ; preds = %block1
  %215 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !203
  store %"/@stdlib/console.void::_reply" %215, ptr %74, align 8, !dbg !203
  store %"/@stdlib/console.void::_reply" %215, ptr %6, align 8, !dbg !203
  %216 = load ptr, ptr %4, align 8, !dbg !204
  store ptr %216, ptr %79, align 8, !dbg !204
  store ptr %216, ptr %7, align 8, !dbg !204
  call void @vd_string_literal(ptr %84, ptr @109, i64 5, ptr %2), !dbg !205
  %217 = load ptr, ptr %84, align 8, !dbg !205
  %218 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !205
  %219 = load ptr, ptr %218, align 8, !dbg !205
  %220 = icmp ne ptr %219, null, !dbg !205
  br i1 %220, label %numeric_error, label %numeric_valid, !dbg !205

numeric_error:                                    ; preds = %worker.continue2
  %221 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !205
  store ptr @110, ptr %221, align 8, !dbg !205
  call void @vd_gc_frame_leave(ptr %203), !dbg !205
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !205

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %217, ptr %84, align 8, !dbg !205
  store ptr %217, ptr %8, align 8, !dbg !205
  %222 = load %"/@stdlib/console.void::_reply", ptr %6, align 8, !dbg !206
  store %"/@stdlib/console.void::_reply" %222, ptr %89, align 8, !dbg !206
  %223 = load ptr, ptr %7, align 8, !dbg !206
  store ptr %223, ptr %94, align 8, !dbg !206
  %224 = load ptr, ptr %8, align 8, !dbg !206
  store ptr %224, ptr %99, align 8, !dbg !206
  %225 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %222, ptr %223, ptr %224, ptr %2), !dbg !206
  %226 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !206
  %227 = load ptr, ptr %226, align 8, !dbg !206
  %228 = icmp ne ptr %227, null, !dbg !206
  br i1 %228, label %propagate_error, label %call_success, !dbg !206

propagate_error:                                  ; preds = %numeric_valid
  %229 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !206
  %230 = load i32, ptr %229, align 4, !dbg !206
  %231 = icmp ult i32 %230, 32, !dbg !206
  br i1 %231, label %trace_caller, label %trace_limit, !dbg !206

call_success:                                     ; preds = %numeric_valid
  store %"/@stdlib/console.void::io_error" %225, ptr %104, align 8, !dbg !206
  store %"/@stdlib/console.void::io_error" %225, ptr %9, align 8, !dbg !206
  %232 = load %"/@stdlib/console.void::io_error", ptr %9, align 8, !dbg !196
  store %"/@stdlib/console.void::io_error" %232, ptr %109, align 8, !dbg !196
  %233 = insertvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, %"/@stdlib/console.void::text_read" zeroinitializer, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %232, 2, !dbg !196
  %234 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, 0, !dbg !196
  %235 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, 0, !dbg !196
  %236 = icmp eq i32 %235, 0, !dbg !196
  br i1 %236, label %validate_active_payload, label %validate_payload_done, !dbg !196

trace_caller:                                     ; preds = %propagate_error
  %237 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !206
  %238 = getelementptr [32 x ptr], ptr %237, i32 0, i32 %230, !dbg !206
  store ptr @111, ptr %238, align 8, !dbg !206
  %239 = add i32 %230, 1, !dbg !206
  store i32 %239, ptr %229, align 4, !dbg !206
  br label %error_return, !dbg !206

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %203), !dbg !206
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !206

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %229, align 4, !dbg !206
  br label %error_return, !dbg !206

validate_active_payload:                          ; preds = %call_success
  %240 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, 1, !dbg !196
  %241 = extractvalue %"/@stdlib/console.void::text_read" %240, 0, !dbg !196
  %242 = extractvalue %"/@stdlib/console.void::text_read" %240, 0, !dbg !196
  %243 = icmp eq i32 %242, 0, !dbg !196
  br i1 %243, label %validate_active_payload3, label %validate_payload_done4, !dbg !196

validate_payload_done:                            ; preds = %validate_payload_done4, %call_success
  %244 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, 0, !dbg !196
  %245 = icmp eq i32 %244, 1, !dbg !196
  br i1 %245, label %validate_active_payload5, label %validate_payload_done6, !dbg !196

validate_active_payload3:                         ; preds = %validate_active_payload
  %246 = extractvalue %"/@stdlib/console.void::text_read" %240, 1, !dbg !196
  br label %validate_payload_done4, !dbg !196

validate_payload_done4:                           ; preds = %validate_active_payload3, %validate_active_payload
  br label %validate_payload_done, !dbg !196

validate_active_payload5:                         ; preds = %validate_payload_done
  %247 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, 2, !dbg !196
  %248 = extractvalue %"/@stdlib/console.void::io_error" %247, 0, !dbg !196
  %249 = extractvalue %"/@stdlib/console.void::io_error" %247, 1, !dbg !196
  %250 = extractvalue %"/@stdlib/console.void::io_error" %247, 2, !dbg !196
  %251 = extractvalue %"/@stdlib/console.void::io_error_kind" %250, 0, !dbg !196
  %252 = extractvalue %"/@stdlib/console.void::io_error" %247, 3, !dbg !196
  %253 = extractvalue %"/@stdlib/console.void::io_error" %247, 4, !dbg !196
  %254 = extractvalue %"/@stdlib/console.void::io_error" %247, 5, !dbg !196
  %255 = extractvalue %"/@stdlib/console.void::io_error" %247, 6, !dbg !196
  %256 = extractvalue %"/@stdlib/console.void::io_error" %247, 7, !dbg !196
  %257 = extractvalue %"/@stdlib/console.void::io_error" %247, 8, !dbg !196
  br label %validate_payload_done6, !dbg !196

validate_payload_done6:                           ; preds = %validate_active_payload5, %validate_payload_done
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, ptr %114, align 8, !dbg !196
  call void @vd_gc_frame_leave(ptr %203), !dbg !196
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %233, !dbg !196

worker.cancelled7:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %203), !dbg !196
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !196

worker.continue8:                                 ; preds = %block2
  br label %block3, !dbg !196

worker.cancelled9:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %203), !dbg !196
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !196

worker.continue10:                                ; preds = %block3
  %258 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !207
  store %"/@stdlib/console.void::_reply" %258, ptr %119, align 8, !dbg !207
  %259 = extractvalue %"/@stdlib/console.void::_reply" %258, 5, !dbg !197
  br i1 %259, label %block4, label %block5, !dbg !197

worker.cancelled11:                               ; preds = %block4
  call void @vd_gc_frame_leave(ptr %203), !dbg !197
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !197

worker.continue12:                                ; preds = %block4
  br i1 false, label %validate_active_payload13, label %validate_payload_done14, !dbg !208

validate_active_payload13:                        ; preds = %worker.continue12
  br label %validate_payload_done14, !dbg !208

validate_payload_done14:                          ; preds = %validate_active_payload13, %worker.continue12
  store %"/@stdlib/console.void::text_read" { i32 1, ptr null }, ptr %124, align 8, !dbg !208
  store %"/@stdlib/console.void::text_read" { i32 1, ptr null }, ptr %10, align 8, !dbg !208
  %260 = load %"/@stdlib/console.void::text_read", ptr %10, align 8, !dbg !198
  store %"/@stdlib/console.void::text_read" %260, ptr %129, align 8, !dbg !198
  %261 = insertvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::text_read" %260, 1, !dbg !198
  %262 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, 0, !dbg !198
  %263 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, 0, !dbg !198
  %264 = icmp eq i32 %263, 0, !dbg !198
  br i1 %264, label %validate_active_payload15, label %validate_payload_done16, !dbg !198

validate_active_payload15:                        ; preds = %validate_payload_done14
  %265 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, 1, !dbg !198
  %266 = extractvalue %"/@stdlib/console.void::text_read" %265, 0, !dbg !198
  %267 = extractvalue %"/@stdlib/console.void::text_read" %265, 0, !dbg !198
  %268 = icmp eq i32 %267, 0, !dbg !198
  br i1 %268, label %validate_active_payload17, label %validate_payload_done18, !dbg !198

validate_payload_done16:                          ; preds = %validate_payload_done18, %validate_payload_done14
  %269 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, 0, !dbg !198
  %270 = icmp eq i32 %269, 1, !dbg !198
  br i1 %270, label %validate_active_payload19, label %validate_payload_done20, !dbg !198

validate_active_payload17:                        ; preds = %validate_active_payload15
  %271 = extractvalue %"/@stdlib/console.void::text_read" %265, 1, !dbg !198
  br label %validate_payload_done18, !dbg !198

validate_payload_done18:                          ; preds = %validate_active_payload17, %validate_active_payload15
  br label %validate_payload_done16, !dbg !198

validate_active_payload19:                        ; preds = %validate_payload_done16
  %272 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, 2, !dbg !198
  %273 = extractvalue %"/@stdlib/console.void::io_error" %272, 0, !dbg !198
  %274 = extractvalue %"/@stdlib/console.void::io_error" %272, 1, !dbg !198
  %275 = extractvalue %"/@stdlib/console.void::io_error" %272, 2, !dbg !198
  %276 = extractvalue %"/@stdlib/console.void::io_error_kind" %275, 0, !dbg !198
  %277 = extractvalue %"/@stdlib/console.void::io_error" %272, 3, !dbg !198
  %278 = extractvalue %"/@stdlib/console.void::io_error" %272, 4, !dbg !198
  %279 = extractvalue %"/@stdlib/console.void::io_error" %272, 5, !dbg !198
  %280 = extractvalue %"/@stdlib/console.void::io_error" %272, 6, !dbg !198
  %281 = extractvalue %"/@stdlib/console.void::io_error" %272, 7, !dbg !198
  %282 = extractvalue %"/@stdlib/console.void::io_error" %272, 8, !dbg !198
  br label %validate_payload_done20, !dbg !198

validate_payload_done20:                          ; preds = %validate_active_payload19, %validate_payload_done16
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, ptr %134, align 8, !dbg !198
  call void @vd_gc_frame_leave(ptr %203), !dbg !198
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %261, !dbg !198

worker.cancelled21:                               ; preds = %block5
  call void @vd_gc_frame_leave(ptr %203), !dbg !198
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !198

worker.continue22:                                ; preds = %block5
  br label %block6, !dbg !198

worker.cancelled23:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %203), !dbg !198
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !198

worker.continue24:                                ; preds = %block6
  %283 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !209
  store %"/@stdlib/console.void::_reply" %283, ptr %139, align 8, !dbg !209
  %284 = extractvalue %"/@stdlib/console.void::_reply" %283, 6, !dbg !210
  store ptr %284, ptr %144, align 8, !dbg !210
  store ptr %284, ptr %11, align 8, !dbg !210
  %285 = load ptr, ptr %11, align 8, !dbg !211
  store ptr %285, ptr %149, align 8, !dbg !211
  %286 = insertvalue %"/@stdlib/console.void::text_read" zeroinitializer, ptr %285, 1, !dbg !211
  %287 = extractvalue %"/@stdlib/console.void::text_read" %286, 0, !dbg !211
  %288 = extractvalue %"/@stdlib/console.void::text_read" %286, 0, !dbg !211
  %289 = icmp eq i32 %288, 0, !dbg !211
  br i1 %289, label %validate_active_payload25, label %validate_payload_done26, !dbg !211

validate_active_payload25:                        ; preds = %worker.continue24
  %290 = extractvalue %"/@stdlib/console.void::text_read" %286, 1, !dbg !211
  br label %validate_payload_done26, !dbg !211

validate_payload_done26:                          ; preds = %validate_active_payload25, %worker.continue24
  store %"/@stdlib/console.void::text_read" %286, ptr %154, align 8, !dbg !211
  store %"/@stdlib/console.void::text_read" %286, ptr %12, align 8, !dbg !211
  %291 = load %"/@stdlib/console.void::text_read", ptr %12, align 8, !dbg !212
  store %"/@stdlib/console.void::text_read" %291, ptr %159, align 8, !dbg !212
  %292 = insertvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::text_read" %291, 1, !dbg !212
  %293 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, 0, !dbg !212
  %294 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, 0, !dbg !212
  %295 = icmp eq i32 %294, 0, !dbg !212
  br i1 %295, label %validate_active_payload27, label %validate_payload_done28, !dbg !212

validate_active_payload27:                        ; preds = %validate_payload_done26
  %296 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, 1, !dbg !212
  %297 = extractvalue %"/@stdlib/console.void::text_read" %296, 0, !dbg !212
  %298 = extractvalue %"/@stdlib/console.void::text_read" %296, 0, !dbg !212
  %299 = icmp eq i32 %298, 0, !dbg !212
  br i1 %299, label %validate_active_payload29, label %validate_payload_done30, !dbg !212

validate_payload_done28:                          ; preds = %validate_payload_done30, %validate_payload_done26
  %300 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, 0, !dbg !212
  %301 = icmp eq i32 %300, 1, !dbg !212
  br i1 %301, label %validate_active_payload31, label %validate_payload_done32, !dbg !212

validate_active_payload29:                        ; preds = %validate_active_payload27
  %302 = extractvalue %"/@stdlib/console.void::text_read" %296, 1, !dbg !212
  br label %validate_payload_done30, !dbg !212

validate_payload_done30:                          ; preds = %validate_active_payload29, %validate_active_payload27
  br label %validate_payload_done28, !dbg !212

validate_active_payload31:                        ; preds = %validate_payload_done28
  %303 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, 2, !dbg !212
  %304 = extractvalue %"/@stdlib/console.void::io_error" %303, 0, !dbg !212
  %305 = extractvalue %"/@stdlib/console.void::io_error" %303, 1, !dbg !212
  %306 = extractvalue %"/@stdlib/console.void::io_error" %303, 2, !dbg !212
  %307 = extractvalue %"/@stdlib/console.void::io_error_kind" %306, 0, !dbg !212
  %308 = extractvalue %"/@stdlib/console.void::io_error" %303, 3, !dbg !212
  %309 = extractvalue %"/@stdlib/console.void::io_error" %303, 4, !dbg !212
  %310 = extractvalue %"/@stdlib/console.void::io_error" %303, 5, !dbg !212
  %311 = extractvalue %"/@stdlib/console.void::io_error" %303, 6, !dbg !212
  %312 = extractvalue %"/@stdlib/console.void::io_error" %303, 7, !dbg !212
  %313 = extractvalue %"/@stdlib/console.void::io_error" %303, 8, !dbg !212
  br label %validate_payload_done32, !dbg !212

validate_payload_done32:                          ; preds = %validate_active_payload31, %validate_payload_done28
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, ptr %164, align 8, !dbg !212
  call void @vd_gc_frame_leave(ptr %203), !dbg !212
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %292, !dbg !212
}

define %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f63686172__v1(ptr %0, i64 %1, ptr %2) !dbg !213 {
block0:
  %3 = alloca [8 x i64], align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %6, align 8
  %7 = alloca i64, align 8
  store i64 0, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, i64 80, 1
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, ptr @gc.offsets.168, 2
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, i64 2, 3
  %13 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, i64 8, 1
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, ptr @gc.offsets.169, 2
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 1, 3
  %17 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %17, align 8
  %18 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %17, 0
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 80, 1
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, ptr @gc.offsets.170, 2
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 2, 3
  %22 = alloca ptr, align 8
  store ptr null, ptr %22, align 8
  %23 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %22, 0
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 8, 1
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, ptr @gc.offsets.171, 2
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 1, 3
  %27 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %27, align 8
  %28 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %27, 0
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 80, 1
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, ptr @gc.offsets.172, 2
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 2, 3
  %32 = alloca ptr, align 8
  store ptr null, ptr %32, align 8
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %32, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 8, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.173, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 1, 3
  %37 = alloca %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %37, align 8
  %38 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %37, 0
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 96, 1
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, ptr @gc.offsets.174, 2
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 5, 3
  %42 = alloca [7 x { ptr, i64, ptr, i64 }], align 8
  %43 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %12, ptr %43, align 8
  %44 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %16, ptr %44, align 8
  %45 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %21, ptr %45, align 8
  %46 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %26, ptr %46, align 8
  %47 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %31, ptr %47, align 8
  %48 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %36, ptr %48, align 8
  %49 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %41, ptr %49, align 8
  %50 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %50, ptr %42, i64 7)
  call void @vd_gc_poll()
  %51 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %51, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %50)
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i64 %1, ptr %4, align 8, !dbg !216
  %52 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !217
  store %"/@stdlib/console.void::input" %52, ptr %6, align 8, !dbg !217
  %53 = load i64, ptr %4, align 8, !dbg !218
  store i64 %53, ptr %7, align 8, !dbg !218
  %54 = load %"/@stdlib/console.void::input", ptr %6, align 8, !dbg !219
  %55 = load i64, ptr %7, align 8, !dbg !219
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %17, align 8, !dbg !219
  store [8 x i64] zeroinitializer, ptr %3, align 8, !dbg !219
  %56 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 6, !dbg !219
  %57 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 7, !dbg !219
  %58 = extractvalue %"/@stdlib/console.void::input" %54, 0, !dbg !219
  call void @vd_console_v2(ptr %56, ptr %57, ptr %3, i32 2, i64 %58, ptr null, i64 0, i64 %55, ptr %2), !dbg !219
  %59 = load ptr, ptr %2, align 8, !dbg !219
  %60 = icmp ne ptr %59, null, !dbg !219
  br i1 %60, label %selected.failure, label %selected.valid, !dbg !219

selected.failure:                                 ; preds = %worker.continue
  %61 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !219
  %62 = load i32, ptr %61, align 4, !dbg !219
  %63 = icmp ult i32 %62, 32, !dbg !219
  br i1 %63, label %trace_caller, label %trace_limit, !dbg !219

selected.valid:                                   ; preds = %worker.continue
  %64 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 0, !dbg !219
  %65 = load i64, ptr %64, align 8, !dbg !219
  %66 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 0, !dbg !219
  store i64 %65, ptr %66, align 8, !dbg !219
  %67 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 1, !dbg !219
  %68 = load i64, ptr %67, align 8, !dbg !219
  %69 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 1, !dbg !219
  store i64 %68, ptr %69, align 8, !dbg !219
  %70 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 2, !dbg !219
  %71 = load i64, ptr %70, align 8, !dbg !219
  %72 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 2, !dbg !219
  store i64 %71, ptr %72, align 8, !dbg !219
  %73 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 3, !dbg !219
  %74 = load i64, ptr %73, align 8, !dbg !219
  %75 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 3, !dbg !219
  store i64 %74, ptr %75, align 8, !dbg !219
  %76 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 4, !dbg !219
  %77 = load i64, ptr %76, align 8, !dbg !219
  %78 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 4, !dbg !219
  store i64 %77, ptr %78, align 8, !dbg !219
  %79 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 5, !dbg !219
  %80 = load i64, ptr %79, align 8, !dbg !219
  %81 = trunc i64 %80 to i1, !dbg !219
  %82 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 5, !dbg !219
  store i1 %81, ptr %82, align 1, !dbg !219
  %83 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 6, !dbg !219
  %84 = load i64, ptr %83, align 8, !dbg !219
  %85 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 8, !dbg !219
  store i64 %84, ptr %85, align 8, !dbg !219
  %86 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 7, !dbg !219
  %87 = load i64, ptr %86, align 8, !dbg !219
  %88 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 9, !dbg !219
  store i64 %87, ptr %88, align 8, !dbg !219
  %89 = load %"/@stdlib/console.void::_reply", ptr %17, align 8, !dbg !219
  store %"/@stdlib/console.void::_reply" %89, ptr %17, align 8, !dbg !219
  store %"/@stdlib/console.void::_reply" %89, ptr %5, align 8, !dbg !219
  call void @vd_string_literal(ptr %22, ptr @113, i64 9, ptr %2), !dbg !220
  %90 = load ptr, ptr %22, align 8, !dbg !220
  %91 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !220
  %92 = load ptr, ptr %91, align 8, !dbg !220
  %93 = icmp ne ptr %92, null, !dbg !220
  br i1 %93, label %numeric_error, label %numeric_valid, !dbg !220

trace_caller:                                     ; preds = %selected.failure
  %94 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !219
  %95 = getelementptr [32 x ptr], ptr %94, i32 0, i32 %62, !dbg !219
  store ptr @112, ptr %95, align 8, !dbg !219
  %96 = add i32 %62, 1, !dbg !219
  store i32 %96, ptr %61, align 4, !dbg !219
  br label %error_return, !dbg !219

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %50), !dbg !219
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !219

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %61, align 4, !dbg !219
  br label %error_return, !dbg !219

numeric_error:                                    ; preds = %selected.valid
  %97 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !220
  store ptr @114, ptr %97, align 8, !dbg !220
  call void @vd_gc_frame_leave(ptr %50), !dbg !220
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !220

numeric_valid:                                    ; preds = %selected.valid
  store ptr %90, ptr %22, align 8, !dbg !220
  store ptr %90, ptr %8, align 8, !dbg !220
  %98 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !221
  store %"/@stdlib/console.void::_reply" %98, ptr %27, align 8, !dbg !221
  %99 = load ptr, ptr %8, align 8, !dbg !221
  store ptr %99, ptr %32, align 8, !dbg !221
  %100 = call %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f74657874__v1(%"/@stdlib/console.void::_reply" %98, ptr %99, ptr %2), !dbg !221
  %101 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !221
  %102 = load ptr, ptr %101, align 8, !dbg !221
  %103 = icmp ne ptr %102, null, !dbg !221
  br i1 %103, label %propagate_error, label %call_success, !dbg !221

propagate_error:                                  ; preds = %numeric_valid
  %104 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !221
  %105 = load i32, ptr %104, align 4, !dbg !221
  %106 = icmp ult i32 %105, 32, !dbg !221
  br i1 %106, label %trace_caller1, label %trace_limit3, !dbg !221

call_success:                                     ; preds = %numeric_valid
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %100, ptr %37, align 8, !dbg !221
  call void @vd_gc_frame_leave(ptr %50), !dbg !221
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %100, !dbg !221

trace_caller1:                                    ; preds = %propagate_error
  %107 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !221
  %108 = getelementptr [32 x ptr], ptr %107, i32 0, i32 %105, !dbg !221
  store ptr @115, ptr %108, align 8, !dbg !221
  %109 = add i32 %105, 1, !dbg !221
  store i32 %109, ptr %104, align 4, !dbg !221
  br label %error_return2, !dbg !221

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %50), !dbg !221
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !221

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %104, align 4, !dbg !221
  br label %error_return2, !dbg !221
}

define %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f74657874__v1(ptr %0, i64 %1, i64 %2, ptr %3) !dbg !222 {
block0:
  %4 = alloca [8 x i64], align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %7, align 8
  %8 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %8, align 8
  %9 = alloca i64, align 8
  store i64 0, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 80, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.175, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 2, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 8, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.176, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 1, 3
  %20 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %20, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 80, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.177, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 2, 3
  %25 = alloca ptr, align 8
  store ptr null, ptr %25, align 8
  %26 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %25, 0
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 8, 1
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, ptr @gc.offsets.178, 2
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 1, 3
  %30 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %30, align 8
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %30, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 80, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.179, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 2, 3
  %35 = alloca ptr, align 8
  store ptr null, ptr %35, align 8
  %36 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %35, 0
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 8, 1
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, ptr @gc.offsets.180, 2
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 1, 3
  %40 = alloca %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %40, align 8
  %41 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %40, 0
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 96, 1
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, ptr @gc.offsets.181, 2
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 5, 3
  %45 = alloca [7 x { ptr, i64, ptr, i64 }], align 8
  %46 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %15, ptr %46, align 8
  %47 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %19, ptr %47, align 8
  %48 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %24, ptr %48, align 8
  %49 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %29, ptr %49, align 8
  %50 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %34, ptr %50, align 8
  %51 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %39, ptr %51, align 8
  %52 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %45, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %44, ptr %52, align 8
  %53 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %53, ptr %45, i64 7)
  call void @vd_gc_poll()
  %54 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %54, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %53)
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i64 %1, ptr %5, align 8, !dbg !225
  store i64 %2, ptr %6, align 8, !dbg !226
  %55 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !227
  store %"/@stdlib/console.void::input" %55, ptr %8, align 8, !dbg !227
  %56 = load i64, ptr %5, align 8, !dbg !228
  store i64 %56, ptr %9, align 8, !dbg !228
  %57 = load i64, ptr %6, align 8, !dbg !229
  store i64 %57, ptr %10, align 8, !dbg !229
  %58 = load %"/@stdlib/console.void::input", ptr %8, align 8, !dbg !230
  %59 = load i64, ptr %9, align 8, !dbg !230
  %60 = load i64, ptr %10, align 8, !dbg !230
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8, !dbg !230
  store [8 x i64] zeroinitializer, ptr %4, align 8, !dbg !230
  %61 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 6, !dbg !230
  %62 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 7, !dbg !230
  %63 = extractvalue %"/@stdlib/console.void::input" %58, 0, !dbg !230
  call void @vd_console_v2(ptr %61, ptr %62, ptr %4, i32 3, i64 %63, ptr null, i64 %59, i64 %60, ptr %3), !dbg !230
  %64 = load ptr, ptr %3, align 8, !dbg !230
  %65 = icmp ne ptr %64, null, !dbg !230
  br i1 %65, label %selected.failure, label %selected.valid, !dbg !230

selected.failure:                                 ; preds = %worker.continue
  %66 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !230
  %67 = load i32, ptr %66, align 4, !dbg !230
  %68 = icmp ult i32 %67, 32, !dbg !230
  br i1 %68, label %trace_caller, label %trace_limit, !dbg !230

selected.valid:                                   ; preds = %worker.continue
  %69 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 0, !dbg !230
  %70 = load i64, ptr %69, align 8, !dbg !230
  %71 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 0, !dbg !230
  store i64 %70, ptr %71, align 8, !dbg !230
  %72 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 1, !dbg !230
  %73 = load i64, ptr %72, align 8, !dbg !230
  %74 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 1, !dbg !230
  store i64 %73, ptr %74, align 8, !dbg !230
  %75 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 2, !dbg !230
  %76 = load i64, ptr %75, align 8, !dbg !230
  %77 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 2, !dbg !230
  store i64 %76, ptr %77, align 8, !dbg !230
  %78 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 3, !dbg !230
  %79 = load i64, ptr %78, align 8, !dbg !230
  %80 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 3, !dbg !230
  store i64 %79, ptr %80, align 8, !dbg !230
  %81 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 4, !dbg !230
  %82 = load i64, ptr %81, align 8, !dbg !230
  %83 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 4, !dbg !230
  store i64 %82, ptr %83, align 8, !dbg !230
  %84 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 5, !dbg !230
  %85 = load i64, ptr %84, align 8, !dbg !230
  %86 = trunc i64 %85 to i1, !dbg !230
  %87 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 5, !dbg !230
  store i1 %86, ptr %87, align 1, !dbg !230
  %88 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 6, !dbg !230
  %89 = load i64, ptr %88, align 8, !dbg !230
  %90 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 8, !dbg !230
  store i64 %89, ptr %90, align 8, !dbg !230
  %91 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 7, !dbg !230
  %92 = load i64, ptr %91, align 8, !dbg !230
  %93 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 9, !dbg !230
  store i64 %92, ptr %93, align 8, !dbg !230
  %94 = load %"/@stdlib/console.void::_reply", ptr %20, align 8, !dbg !230
  store %"/@stdlib/console.void::_reply" %94, ptr %20, align 8, !dbg !230
  store %"/@stdlib/console.void::_reply" %94, ptr %7, align 8, !dbg !230
  call void @vd_string_literal(ptr %25, ptr @117, i64 9, ptr %3), !dbg !231
  %95 = load ptr, ptr %25, align 8, !dbg !231
  %96 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !231
  %97 = load ptr, ptr %96, align 8, !dbg !231
  %98 = icmp ne ptr %97, null, !dbg !231
  br i1 %98, label %numeric_error, label %numeric_valid, !dbg !231

trace_caller:                                     ; preds = %selected.failure
  %99 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !230
  %100 = getelementptr [32 x ptr], ptr %99, i32 0, i32 %67, !dbg !230
  store ptr @116, ptr %100, align 8, !dbg !230
  %101 = add i32 %67, 1, !dbg !230
  store i32 %101, ptr %66, align 4, !dbg !230
  br label %error_return, !dbg !230

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %53), !dbg !230
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !230

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %66, align 4, !dbg !230
  br label %error_return, !dbg !230

numeric_error:                                    ; preds = %selected.valid
  %102 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !231
  store ptr @118, ptr %102, align 8, !dbg !231
  call void @vd_gc_frame_leave(ptr %53), !dbg !231
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !231

numeric_valid:                                    ; preds = %selected.valid
  store ptr %95, ptr %25, align 8, !dbg !231
  store ptr %95, ptr %11, align 8, !dbg !231
  %103 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !232
  store %"/@stdlib/console.void::_reply" %103, ptr %30, align 8, !dbg !232
  %104 = load ptr, ptr %11, align 8, !dbg !232
  store ptr %104, ptr %35, align 8, !dbg !232
  %105 = call %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f74657874__v1(%"/@stdlib/console.void::_reply" %103, ptr %104, ptr %3), !dbg !232
  %106 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !232
  %107 = load ptr, ptr %106, align 8, !dbg !232
  %108 = icmp ne ptr %107, null, !dbg !232
  br i1 %108, label %propagate_error, label %call_success, !dbg !232

propagate_error:                                  ; preds = %numeric_valid
  %109 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !232
  %110 = load i32, ptr %109, align 4, !dbg !232
  %111 = icmp ult i32 %110, 32, !dbg !232
  br i1 %111, label %trace_caller1, label %trace_limit3, !dbg !232

call_success:                                     ; preds = %numeric_valid
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %105, ptr %40, align 8, !dbg !232
  call void @vd_gc_frame_leave(ptr %53), !dbg !232
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %105, !dbg !232

trace_caller1:                                    ; preds = %propagate_error
  %112 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !232
  %113 = getelementptr [32 x ptr], ptr %112, i32 0, i32 %110, !dbg !232
  store ptr @119, ptr %113, align 8, !dbg !232
  %114 = add i32 %110, 1, !dbg !232
  store i32 %114, ptr %109, align 4, !dbg !232
  br label %error_return2, !dbg !232

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %53), !dbg !232
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !232

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %109, align 4, !dbg !232
  br label %error_return2, !dbg !232
}

define %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f6c696e65__v1(ptr %0, i64 %1, ptr %2) !dbg !233 {
block0:
  %3 = alloca [8 x i64], align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %6, align 8
  %7 = alloca i64, align 8
  store i64 0, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, i64 80, 1
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, ptr @gc.offsets.182, 2
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, i64 2, 3
  %13 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, i64 8, 1
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, ptr @gc.offsets.183, 2
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 1, 3
  %17 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %17, align 8
  %18 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %17, 0
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 80, 1
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, ptr @gc.offsets.184, 2
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 2, 3
  %22 = alloca ptr, align 8
  store ptr null, ptr %22, align 8
  %23 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %22, 0
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 8, 1
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, ptr @gc.offsets.185, 2
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 1, 3
  %27 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %27, align 8
  %28 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %27, 0
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 80, 1
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, ptr @gc.offsets.186, 2
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 2, 3
  %32 = alloca ptr, align 8
  store ptr null, ptr %32, align 8
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %32, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 8, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.187, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 1, 3
  %37 = alloca %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %37, align 8
  %38 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %37, 0
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 96, 1
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, ptr @gc.offsets.188, 2
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 5, 3
  %42 = alloca [7 x { ptr, i64, ptr, i64 }], align 8
  %43 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %12, ptr %43, align 8
  %44 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %16, ptr %44, align 8
  %45 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %21, ptr %45, align 8
  %46 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %26, ptr %46, align 8
  %47 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %31, ptr %47, align 8
  %48 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %36, ptr %48, align 8
  %49 = getelementptr inbounds [7 x { ptr, i64, ptr, i64 }], ptr %42, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %41, ptr %49, align 8
  %50 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %50, ptr %42, i64 7)
  call void @vd_gc_poll()
  %51 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %51, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %50)
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i64 %1, ptr %4, align 8, !dbg !234
  %52 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !235
  store %"/@stdlib/console.void::input" %52, ptr %6, align 8, !dbg !235
  %53 = load i64, ptr %4, align 8, !dbg !236
  store i64 %53, ptr %7, align 8, !dbg !236
  %54 = load %"/@stdlib/console.void::input", ptr %6, align 8, !dbg !237
  %55 = load i64, ptr %7, align 8, !dbg !237
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %17, align 8, !dbg !237
  store [8 x i64] zeroinitializer, ptr %3, align 8, !dbg !237
  %56 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 6, !dbg !237
  %57 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 7, !dbg !237
  %58 = extractvalue %"/@stdlib/console.void::input" %54, 0, !dbg !237
  call void @vd_console_v2(ptr %56, ptr %57, ptr %3, i32 4, i64 %58, ptr null, i64 0, i64 %55, ptr %2), !dbg !237
  %59 = load ptr, ptr %2, align 8, !dbg !237
  %60 = icmp ne ptr %59, null, !dbg !237
  br i1 %60, label %selected.failure, label %selected.valid, !dbg !237

selected.failure:                                 ; preds = %worker.continue
  %61 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !237
  %62 = load i32, ptr %61, align 4, !dbg !237
  %63 = icmp ult i32 %62, 32, !dbg !237
  br i1 %63, label %trace_caller, label %trace_limit, !dbg !237

selected.valid:                                   ; preds = %worker.continue
  %64 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 0, !dbg !237
  %65 = load i64, ptr %64, align 8, !dbg !237
  %66 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 0, !dbg !237
  store i64 %65, ptr %66, align 8, !dbg !237
  %67 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 1, !dbg !237
  %68 = load i64, ptr %67, align 8, !dbg !237
  %69 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 1, !dbg !237
  store i64 %68, ptr %69, align 8, !dbg !237
  %70 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 2, !dbg !237
  %71 = load i64, ptr %70, align 8, !dbg !237
  %72 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 2, !dbg !237
  store i64 %71, ptr %72, align 8, !dbg !237
  %73 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 3, !dbg !237
  %74 = load i64, ptr %73, align 8, !dbg !237
  %75 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 3, !dbg !237
  store i64 %74, ptr %75, align 8, !dbg !237
  %76 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 4, !dbg !237
  %77 = load i64, ptr %76, align 8, !dbg !237
  %78 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 4, !dbg !237
  store i64 %77, ptr %78, align 8, !dbg !237
  %79 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 5, !dbg !237
  %80 = load i64, ptr %79, align 8, !dbg !237
  %81 = trunc i64 %80 to i1, !dbg !237
  %82 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 5, !dbg !237
  store i1 %81, ptr %82, align 1, !dbg !237
  %83 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 6, !dbg !237
  %84 = load i64, ptr %83, align 8, !dbg !237
  %85 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 8, !dbg !237
  store i64 %84, ptr %85, align 8, !dbg !237
  %86 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 7, !dbg !237
  %87 = load i64, ptr %86, align 8, !dbg !237
  %88 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %17, i32 0, i32 9, !dbg !237
  store i64 %87, ptr %88, align 8, !dbg !237
  %89 = load %"/@stdlib/console.void::_reply", ptr %17, align 8, !dbg !237
  store %"/@stdlib/console.void::_reply" %89, ptr %17, align 8, !dbg !237
  store %"/@stdlib/console.void::_reply" %89, ptr %5, align 8, !dbg !237
  call void @vd_string_literal(ptr %22, ptr @121, i64 9, ptr %2), !dbg !238
  %90 = load ptr, ptr %22, align 8, !dbg !238
  %91 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !238
  %92 = load ptr, ptr %91, align 8, !dbg !238
  %93 = icmp ne ptr %92, null, !dbg !238
  br i1 %93, label %numeric_error, label %numeric_valid, !dbg !238

trace_caller:                                     ; preds = %selected.failure
  %94 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !237
  %95 = getelementptr [32 x ptr], ptr %94, i32 0, i32 %62, !dbg !237
  store ptr @120, ptr %95, align 8, !dbg !237
  %96 = add i32 %62, 1, !dbg !237
  store i32 %96, ptr %61, align 4, !dbg !237
  br label %error_return, !dbg !237

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %50), !dbg !237
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !237

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %61, align 4, !dbg !237
  br label %error_return, !dbg !237

numeric_error:                                    ; preds = %selected.valid
  %97 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !238
  store ptr @122, ptr %97, align 8, !dbg !238
  call void @vd_gc_frame_leave(ptr %50), !dbg !238
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !238

numeric_valid:                                    ; preds = %selected.valid
  store ptr %90, ptr %22, align 8, !dbg !238
  store ptr %90, ptr %8, align 8, !dbg !238
  %98 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !239
  store %"/@stdlib/console.void::_reply" %98, ptr %27, align 8, !dbg !239
  %99 = load ptr, ptr %8, align 8, !dbg !239
  store ptr %99, ptr %32, align 8, !dbg !239
  %100 = call %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f74657874__v1(%"/@stdlib/console.void::_reply" %98, ptr %99, ptr %2), !dbg !239
  %101 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !239
  %102 = load ptr, ptr %101, align 8, !dbg !239
  %103 = icmp ne ptr %102, null, !dbg !239
  br i1 %103, label %propagate_error, label %call_success, !dbg !239

propagate_error:                                  ; preds = %numeric_valid
  %104 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !239
  %105 = load i32, ptr %104, align 4, !dbg !239
  %106 = icmp ult i32 %105, 32, !dbg !239
  br i1 %106, label %trace_caller1, label %trace_limit3, !dbg !239

call_success:                                     ; preds = %numeric_valid
  store %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %100, ptr %37, align 8, !dbg !239
  call void @vd_gc_frame_leave(ptr %50), !dbg !239
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %100, !dbg !239

trace_caller1:                                    ; preds = %propagate_error
  %107 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !239
  %108 = getelementptr [32 x ptr], ptr %107, i32 0, i32 %105, !dbg !239
  store ptr @123, ptr %108, align 8, !dbg !239
  %109 = add i32 %105, 1, !dbg !239
  store i32 %109, ptr %104, align 4, !dbg !239
  br label %error_return2, !dbg !239

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %50), !dbg !239
  ret %"$result:$array:35:12:/@stdlib/console.void::text_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !239

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %104, align 4, !dbg !239
  br label %error_return2, !dbg !239
}

define %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f6279746573__v1(ptr %0, i64 %1, i64 %2, ptr %3) !dbg !240 {
block0:
  %4 = alloca [8 x i64], align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %7, align 8
  %8 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %8, align 8
  %9 = alloca i64, align 8
  store i64 0, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %12, align 8
  %13 = alloca ptr, align 8
  store ptr null, ptr %13, align 8
  %14 = alloca ptr, align 8
  store ptr null, ptr %14, align 8
  %15 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %15, align 8
  %16 = alloca %"/@stdlib/console.void::bytes_read", align 8
  store %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %16, align 8
  %17 = alloca ptr, align 8
  store ptr null, ptr %17, align 8
  %18 = alloca %"/@stdlib/console.void::bytes_read", align 8
  store %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %18, align 8
  %19 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 80, 1
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, ptr @gc.offsets.189, 2
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 2, 3
  %23 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %12, 0
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 80, 1
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, ptr @gc.offsets.190, 2
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 2, 3
  %27 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 8, 1
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, ptr @gc.offsets.191, 2
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 1, 3
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %14, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 8, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.192, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 1, 3
  %35 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %15, 0
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 72, 1
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, ptr @gc.offsets.193, 2
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 4, 3
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %16, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 16, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.194, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 1, 3
  %43 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %17, 0
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 8, 1
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, ptr @gc.offsets.195, 2
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 1, 3
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %18, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 16, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.196, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 1, 3
  %51 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 80, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.197, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 2, 3
  %56 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %56, align 8
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %56, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 80, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.198, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 2, 3
  %61 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %61, align 8
  %62 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %61, 0
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 80, 1
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, ptr @gc.offsets.199, 2
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 2, 3
  %66 = alloca ptr, align 8
  store ptr null, ptr %66, align 8
  %67 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %66, 0
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 8, 1
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, ptr @gc.offsets.200, 2
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 1, 3
  %71 = alloca ptr, align 8
  store ptr null, ptr %71, align 8
  %72 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %71, 0
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 8, 1
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, ptr @gc.offsets.201, 2
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 1, 3
  %76 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %76, align 8
  %77 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %76, 0
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 80, 1
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, ptr @gc.offsets.202, 2
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 2, 3
  %81 = alloca ptr, align 8
  store ptr null, ptr %81, align 8
  %82 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %81, 0
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 8, 1
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, ptr @gc.offsets.203, 2
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 1, 3
  %86 = alloca ptr, align 8
  store ptr null, ptr %86, align 8
  %87 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %86, 0
  %88 = insertvalue { ptr, i64, ptr, i64 } %87, i64 8, 1
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, ptr @gc.offsets.204, 2
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 1, 3
  %91 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %91, align 8
  %92 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %91, 0
  %93 = insertvalue { ptr, i64, ptr, i64 } %92, i64 72, 1
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, ptr @gc.offsets.205, 2
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 4, 3
  %96 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %96, align 8
  %97 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %96, 0
  %98 = insertvalue { ptr, i64, ptr, i64 } %97, i64 72, 1
  %99 = insertvalue { ptr, i64, ptr, i64 } %98, ptr @gc.offsets.206, 2
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 4, 3
  %101 = alloca %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %101, align 8
  %102 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %101, 0
  %103 = insertvalue { ptr, i64, ptr, i64 } %102, i64 96, 1
  %104 = insertvalue { ptr, i64, ptr, i64 } %103, ptr @gc.offsets.207, 2
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 5, 3
  %106 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %106, align 8
  %107 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %106, 0
  %108 = insertvalue { ptr, i64, ptr, i64 } %107, i64 80, 1
  %109 = insertvalue { ptr, i64, ptr, i64 } %108, ptr @gc.offsets.208, 2
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, i64 2, 3
  %111 = alloca %"/@stdlib/console.void::bytes_read", align 8
  store %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %111, align 8
  %112 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %111, 0
  %113 = insertvalue { ptr, i64, ptr, i64 } %112, i64 16, 1
  %114 = insertvalue { ptr, i64, ptr, i64 } %113, ptr @gc.offsets.209, 2
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, i64 1, 3
  %116 = alloca %"/@stdlib/console.void::bytes_read", align 8
  store %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %116, align 8
  %117 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %116, 0
  %118 = insertvalue { ptr, i64, ptr, i64 } %117, i64 16, 1
  %119 = insertvalue { ptr, i64, ptr, i64 } %118, ptr @gc.offsets.210, 2
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, i64 1, 3
  %121 = alloca %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %121, align 8
  %122 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %121, 0
  %123 = insertvalue { ptr, i64, ptr, i64 } %122, i64 96, 1
  %124 = insertvalue { ptr, i64, ptr, i64 } %123, ptr @gc.offsets.211, 2
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, i64 5, 3
  %126 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %126, align 8
  %127 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %126, 0
  %128 = insertvalue { ptr, i64, ptr, i64 } %127, i64 80, 1
  %129 = insertvalue { ptr, i64, ptr, i64 } %128, ptr @gc.offsets.212, 2
  %130 = insertvalue { ptr, i64, ptr, i64 } %129, i64 2, 3
  %131 = alloca ptr, align 8
  store ptr null, ptr %131, align 8
  %132 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %131, 0
  %133 = insertvalue { ptr, i64, ptr, i64 } %132, i64 8, 1
  %134 = insertvalue { ptr, i64, ptr, i64 } %133, ptr @gc.offsets.213, 2
  %135 = insertvalue { ptr, i64, ptr, i64 } %134, i64 1, 3
  %136 = alloca ptr, align 8
  store ptr null, ptr %136, align 8
  %137 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %136, 0
  %138 = insertvalue { ptr, i64, ptr, i64 } %137, i64 8, 1
  %139 = insertvalue { ptr, i64, ptr, i64 } %138, ptr @gc.offsets.214, 2
  %140 = insertvalue { ptr, i64, ptr, i64 } %139, i64 1, 3
  %141 = alloca %"/@stdlib/console.void::bytes_read", align 8
  store %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %141, align 8
  %142 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %141, 0
  %143 = insertvalue { ptr, i64, ptr, i64 } %142, i64 16, 1
  %144 = insertvalue { ptr, i64, ptr, i64 } %143, ptr @gc.offsets.215, 2
  %145 = insertvalue { ptr, i64, ptr, i64 } %144, i64 1, 3
  %146 = alloca %"/@stdlib/console.void::bytes_read", align 8
  store %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %146, align 8
  %147 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %146, 0
  %148 = insertvalue { ptr, i64, ptr, i64 } %147, i64 16, 1
  %149 = insertvalue { ptr, i64, ptr, i64 } %148, ptr @gc.offsets.216, 2
  %150 = insertvalue { ptr, i64, ptr, i64 } %149, i64 1, 3
  %151 = alloca %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %151, align 8
  %152 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %151, 0
  %153 = insertvalue { ptr, i64, ptr, i64 } %152, i64 96, 1
  %154 = insertvalue { ptr, i64, ptr, i64 } %153, ptr @gc.offsets.217, 2
  %155 = insertvalue { ptr, i64, ptr, i64 } %154, i64 5, 3
  %156 = alloca [29 x { ptr, i64, ptr, i64 }], align 8
  %157 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %22, ptr %157, align 8
  %158 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %26, ptr %158, align 8
  %159 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %30, ptr %159, align 8
  %160 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %34, ptr %160, align 8
  %161 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %38, ptr %161, align 8
  %162 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %42, ptr %162, align 8
  %163 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %46, ptr %163, align 8
  %164 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %50, ptr %164, align 8
  %165 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %55, ptr %165, align 8
  %166 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %60, ptr %166, align 8
  %167 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %65, ptr %167, align 8
  %168 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %70, ptr %168, align 8
  %169 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %75, ptr %169, align 8
  %170 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %80, ptr %170, align 8
  %171 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %85, ptr %171, align 8
  %172 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %90, ptr %172, align 8
  %173 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %95, ptr %173, align 8
  %174 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %100, ptr %174, align 8
  %175 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %105, ptr %175, align 8
  %176 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %110, ptr %176, align 8
  %177 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %115, ptr %177, align 8
  %178 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %120, ptr %178, align 8
  %179 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %125, ptr %179, align 8
  %180 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %130, ptr %180, align 8
  %181 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 24
  store { ptr, i64, ptr, i64 } %135, ptr %181, align 8
  %182 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 25
  store { ptr, i64, ptr, i64 } %140, ptr %182, align 8
  %183 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 26
  store { ptr, i64, ptr, i64 } %145, ptr %183, align 8
  %184 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 27
  store { ptr, i64, ptr, i64 } %150, ptr %184, align 8
  %185 = getelementptr inbounds [29 x { ptr, i64, ptr, i64 }], ptr %156, i32 0, i32 28
  store { ptr, i64, ptr, i64 } %155, ptr %185, align 8
  %186 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %186, ptr %156, i64 29)
  call void @vd_gc_poll()
  %187 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %187, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !249
  %188 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !249
  br i1 %188, label %worker.cancelled1, label %worker.continue2, !dbg !249

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !250
  %189 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !250
  br i1 %189, label %worker.cancelled12, label %worker.continue13, !dbg !250

block3:                                           ; preds = %worker.continue13
  call void @vd_gc_poll(), !dbg !250
  %190 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !250
  br i1 %190, label %worker.cancelled14, label %worker.continue15, !dbg !250

block4:                                           ; preds = %worker.continue15
  call void @vd_gc_poll(), !dbg !251
  %191 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !251
  br i1 %191, label %worker.cancelled16, label %worker.continue17, !dbg !251

block5:                                           ; preds = %worker.continue15
  call void @vd_gc_poll(), !dbg !252
  %192 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !252
  br i1 %192, label %worker.cancelled26, label %worker.continue27, !dbg !252

block6:                                           ; preds = %worker.continue27
  call void @vd_gc_poll(), !dbg !252
  %193 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !252
  br i1 %193, label %worker.cancelled28, label %worker.continue29, !dbg !252

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %186)
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i64 %1, ptr %5, align 8, !dbg !253
  store i64 %2, ptr %6, align 8, !dbg !254
  %194 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !255
  store %"/@stdlib/console.void::input" %194, ptr %8, align 8, !dbg !255
  %195 = load i64, ptr %5, align 8, !dbg !256
  store i64 %195, ptr %9, align 8, !dbg !256
  %196 = load i64, ptr %6, align 8, !dbg !257
  store i64 %196, ptr %10, align 8, !dbg !257
  %197 = load %"/@stdlib/console.void::input", ptr %8, align 8, !dbg !258
  %198 = load i64, ptr %9, align 8, !dbg !258
  %199 = load i64, ptr %10, align 8, !dbg !258
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %51, align 8, !dbg !258
  store [8 x i64] zeroinitializer, ptr %4, align 8, !dbg !258
  %200 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 6, !dbg !258
  %201 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 7, !dbg !258
  %202 = extractvalue %"/@stdlib/console.void::input" %197, 0, !dbg !258
  call void @vd_console_v2(ptr %200, ptr %201, ptr %4, i32 5, i64 %202, ptr null, i64 %198, i64 %199, ptr %3), !dbg !258
  %203 = load ptr, ptr %3, align 8, !dbg !258
  %204 = icmp ne ptr %203, null, !dbg !258
  br i1 %204, label %selected.failure, label %selected.valid, !dbg !258

selected.failure:                                 ; preds = %worker.continue
  %205 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !258
  %206 = load i32, ptr %205, align 4, !dbg !258
  %207 = icmp ult i32 %206, 32, !dbg !258
  br i1 %207, label %trace_caller, label %trace_limit, !dbg !258

selected.valid:                                   ; preds = %worker.continue
  %208 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 0, !dbg !258
  %209 = load i64, ptr %208, align 8, !dbg !258
  %210 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 0, !dbg !258
  store i64 %209, ptr %210, align 8, !dbg !258
  %211 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 1, !dbg !258
  %212 = load i64, ptr %211, align 8, !dbg !258
  %213 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 1, !dbg !258
  store i64 %212, ptr %213, align 8, !dbg !258
  %214 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 2, !dbg !258
  %215 = load i64, ptr %214, align 8, !dbg !258
  %216 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 2, !dbg !258
  store i64 %215, ptr %216, align 8, !dbg !258
  %217 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 3, !dbg !258
  %218 = load i64, ptr %217, align 8, !dbg !258
  %219 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 3, !dbg !258
  store i64 %218, ptr %219, align 8, !dbg !258
  %220 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 4, !dbg !258
  %221 = load i64, ptr %220, align 8, !dbg !258
  %222 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 4, !dbg !258
  store i64 %221, ptr %222, align 8, !dbg !258
  %223 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 5, !dbg !258
  %224 = load i64, ptr %223, align 8, !dbg !258
  %225 = trunc i64 %224 to i1, !dbg !258
  %226 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 5, !dbg !258
  store i1 %225, ptr %226, align 1, !dbg !258
  %227 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 6, !dbg !258
  %228 = load i64, ptr %227, align 8, !dbg !258
  %229 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 8, !dbg !258
  store i64 %228, ptr %229, align 8, !dbg !258
  %230 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 7, !dbg !258
  %231 = load i64, ptr %230, align 8, !dbg !258
  %232 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 9, !dbg !258
  store i64 %231, ptr %232, align 8, !dbg !258
  %233 = load %"/@stdlib/console.void::_reply", ptr %51, align 8, !dbg !258
  store %"/@stdlib/console.void::_reply" %233, ptr %51, align 8, !dbg !258
  store %"/@stdlib/console.void::_reply" %233, ptr %7, align 8, !dbg !259
  %234 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !260
  store %"/@stdlib/console.void::_reply" %234, ptr %56, align 8, !dbg !260
  %235 = extractvalue %"/@stdlib/console.void::_reply" %234, 0, !dbg !261
  store i64 %235, ptr %11, align 8, !dbg !249
  %236 = load i64, ptr %11, align 8, !dbg !249
  %237 = icmp ne i64 %236, 0, !dbg !249
  br i1 %237, label %block1, label %block2, !dbg !249

trace_caller:                                     ; preds = %selected.failure
  %238 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !258
  %239 = getelementptr [32 x ptr], ptr %238, i32 0, i32 %206, !dbg !258
  store ptr @124, ptr %239, align 8, !dbg !258
  %240 = add i32 %206, 1, !dbg !258
  store i32 %240, ptr %205, align 4, !dbg !258
  br label %error_return, !dbg !258

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %186), !dbg !258
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !258

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %205, align 4, !dbg !258
  br label %error_return, !dbg !258

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %186), !dbg !249
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !249

worker.continue2:                                 ; preds = %block1
  %241 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !262
  store %"/@stdlib/console.void::_reply" %241, ptr %61, align 8, !dbg !262
  store %"/@stdlib/console.void::_reply" %241, ptr %12, align 8, !dbg !262
  call void @vd_string_literal(ptr %66, ptr @125, i64 10, ptr %3), !dbg !263
  %242 = load ptr, ptr %66, align 8, !dbg !263
  %243 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !263
  %244 = load ptr, ptr %243, align 8, !dbg !263
  %245 = icmp ne ptr %244, null, !dbg !263
  br i1 %245, label %numeric_error, label %numeric_valid, !dbg !263

numeric_error:                                    ; preds = %worker.continue2
  %246 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !263
  store ptr @126, ptr %246, align 8, !dbg !263
  call void @vd_gc_frame_leave(ptr %186), !dbg !263
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !263

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %242, ptr %66, align 8, !dbg !263
  store ptr %242, ptr %13, align 8, !dbg !263
  call void @vd_string_literal(ptr %71, ptr @127, i64 5, ptr %3), !dbg !264
  %247 = load ptr, ptr %71, align 8, !dbg !264
  %248 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !264
  %249 = load ptr, ptr %248, align 8, !dbg !264
  %250 = icmp ne ptr %249, null, !dbg !264
  br i1 %250, label %numeric_error3, label %numeric_valid4, !dbg !264

numeric_error3:                                   ; preds = %numeric_valid
  %251 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !264
  store ptr @128, ptr %251, align 8, !dbg !264
  call void @vd_gc_frame_leave(ptr %186), !dbg !264
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !264

numeric_valid4:                                   ; preds = %numeric_valid
  store ptr %247, ptr %71, align 8, !dbg !264
  store ptr %247, ptr %14, align 8, !dbg !264
  %252 = load %"/@stdlib/console.void::_reply", ptr %12, align 8, !dbg !265
  store %"/@stdlib/console.void::_reply" %252, ptr %76, align 8, !dbg !265
  %253 = load ptr, ptr %13, align 8, !dbg !265
  store ptr %253, ptr %81, align 8, !dbg !265
  %254 = load ptr, ptr %14, align 8, !dbg !265
  store ptr %254, ptr %86, align 8, !dbg !265
  %255 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %252, ptr %253, ptr %254, ptr %3), !dbg !265
  %256 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !265
  %257 = load ptr, ptr %256, align 8, !dbg !265
  %258 = icmp ne ptr %257, null, !dbg !265
  br i1 %258, label %propagate_error, label %call_success, !dbg !265

propagate_error:                                  ; preds = %numeric_valid4
  %259 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !265
  %260 = load i32, ptr %259, align 4, !dbg !265
  %261 = icmp ult i32 %260, 32, !dbg !265
  br i1 %261, label %trace_caller5, label %trace_limit7, !dbg !265

call_success:                                     ; preds = %numeric_valid4
  store %"/@stdlib/console.void::io_error" %255, ptr %91, align 8, !dbg !265
  store %"/@stdlib/console.void::io_error" %255, ptr %15, align 8, !dbg !265
  %262 = load %"/@stdlib/console.void::io_error", ptr %15, align 8, !dbg !250
  store %"/@stdlib/console.void::io_error" %262, ptr %96, align 8, !dbg !250
  %263 = insertvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, %"/@stdlib/console.void::bytes_read" zeroinitializer, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %262, 2, !dbg !250
  %264 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, 0, !dbg !250
  %265 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, 0, !dbg !250
  %266 = icmp eq i32 %265, 0, !dbg !250
  br i1 %266, label %validate_active_payload, label %validate_payload_done, !dbg !250

trace_caller5:                                    ; preds = %propagate_error
  %267 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !265
  %268 = getelementptr [32 x ptr], ptr %267, i32 0, i32 %260, !dbg !265
  store ptr @129, ptr %268, align 8, !dbg !265
  %269 = add i32 %260, 1, !dbg !265
  store i32 %269, ptr %259, align 4, !dbg !265
  br label %error_return6, !dbg !265

error_return6:                                    ; preds = %trace_caller5, %trace_limit7
  call void @vd_gc_frame_leave(ptr %186), !dbg !265
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !265

trace_limit7:                                     ; preds = %propagate_error
  store i32 33, ptr %259, align 4, !dbg !265
  br label %error_return6, !dbg !265

validate_active_payload:                          ; preds = %call_success
  %270 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, 1, !dbg !250
  %271 = extractvalue %"/@stdlib/console.void::bytes_read" %270, 0, !dbg !250
  %272 = extractvalue %"/@stdlib/console.void::bytes_read" %270, 0, !dbg !250
  %273 = icmp eq i32 %272, 0, !dbg !250
  br i1 %273, label %validate_active_payload8, label %validate_payload_done9, !dbg !250

validate_payload_done:                            ; preds = %validate_payload_done9, %call_success
  %274 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, 0, !dbg !250
  %275 = icmp eq i32 %274, 1, !dbg !250
  br i1 %275, label %validate_active_payload10, label %validate_payload_done11, !dbg !250

validate_active_payload8:                         ; preds = %validate_active_payload
  %276 = extractvalue %"/@stdlib/console.void::bytes_read" %270, 1, !dbg !250
  br label %validate_payload_done9, !dbg !250

validate_payload_done9:                           ; preds = %validate_active_payload8, %validate_active_payload
  br label %validate_payload_done, !dbg !250

validate_active_payload10:                        ; preds = %validate_payload_done
  %277 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, 2, !dbg !250
  %278 = extractvalue %"/@stdlib/console.void::io_error" %277, 0, !dbg !250
  %279 = extractvalue %"/@stdlib/console.void::io_error" %277, 1, !dbg !250
  %280 = extractvalue %"/@stdlib/console.void::io_error" %277, 2, !dbg !250
  %281 = extractvalue %"/@stdlib/console.void::io_error_kind" %280, 0, !dbg !250
  %282 = extractvalue %"/@stdlib/console.void::io_error" %277, 3, !dbg !250
  %283 = extractvalue %"/@stdlib/console.void::io_error" %277, 4, !dbg !250
  %284 = extractvalue %"/@stdlib/console.void::io_error" %277, 5, !dbg !250
  %285 = extractvalue %"/@stdlib/console.void::io_error" %277, 6, !dbg !250
  %286 = extractvalue %"/@stdlib/console.void::io_error" %277, 7, !dbg !250
  %287 = extractvalue %"/@stdlib/console.void::io_error" %277, 8, !dbg !250
  br label %validate_payload_done11, !dbg !250

validate_payload_done11:                          ; preds = %validate_active_payload10, %validate_payload_done
  store %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, ptr %101, align 8, !dbg !250
  call void @vd_gc_frame_leave(ptr %186), !dbg !250
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %263, !dbg !250

worker.cancelled12:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %186), !dbg !250
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !250

worker.continue13:                                ; preds = %block2
  br label %block3, !dbg !250

worker.cancelled14:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %186), !dbg !250
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !250

worker.continue15:                                ; preds = %block3
  %288 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !266
  store %"/@stdlib/console.void::_reply" %288, ptr %106, align 8, !dbg !266
  %289 = extractvalue %"/@stdlib/console.void::_reply" %288, 5, !dbg !251
  br i1 %289, label %block4, label %block5, !dbg !251

worker.cancelled16:                               ; preds = %block4
  call void @vd_gc_frame_leave(ptr %186), !dbg !251
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !251

worker.continue17:                                ; preds = %block4
  br i1 false, label %validate_active_payload18, label %validate_payload_done19, !dbg !267

validate_active_payload18:                        ; preds = %worker.continue17
  br label %validate_payload_done19, !dbg !267

validate_payload_done19:                          ; preds = %validate_active_payload18, %worker.continue17
  store %"/@stdlib/console.void::bytes_read" { i32 1, ptr null }, ptr %111, align 8, !dbg !267
  store %"/@stdlib/console.void::bytes_read" { i32 1, ptr null }, ptr %16, align 8, !dbg !267
  %290 = load %"/@stdlib/console.void::bytes_read", ptr %16, align 8, !dbg !252
  store %"/@stdlib/console.void::bytes_read" %290, ptr %116, align 8, !dbg !252
  %291 = insertvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::bytes_read" %290, 1, !dbg !252
  %292 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, 0, !dbg !252
  %293 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, 0, !dbg !252
  %294 = icmp eq i32 %293, 0, !dbg !252
  br i1 %294, label %validate_active_payload20, label %validate_payload_done21, !dbg !252

validate_active_payload20:                        ; preds = %validate_payload_done19
  %295 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, 1, !dbg !252
  %296 = extractvalue %"/@stdlib/console.void::bytes_read" %295, 0, !dbg !252
  %297 = extractvalue %"/@stdlib/console.void::bytes_read" %295, 0, !dbg !252
  %298 = icmp eq i32 %297, 0, !dbg !252
  br i1 %298, label %validate_active_payload22, label %validate_payload_done23, !dbg !252

validate_payload_done21:                          ; preds = %validate_payload_done23, %validate_payload_done19
  %299 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, 0, !dbg !252
  %300 = icmp eq i32 %299, 1, !dbg !252
  br i1 %300, label %validate_active_payload24, label %validate_payload_done25, !dbg !252

validate_active_payload22:                        ; preds = %validate_active_payload20
  %301 = extractvalue %"/@stdlib/console.void::bytes_read" %295, 1, !dbg !252
  br label %validate_payload_done23, !dbg !252

validate_payload_done23:                          ; preds = %validate_active_payload22, %validate_active_payload20
  br label %validate_payload_done21, !dbg !252

validate_active_payload24:                        ; preds = %validate_payload_done21
  %302 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, 2, !dbg !252
  %303 = extractvalue %"/@stdlib/console.void::io_error" %302, 0, !dbg !252
  %304 = extractvalue %"/@stdlib/console.void::io_error" %302, 1, !dbg !252
  %305 = extractvalue %"/@stdlib/console.void::io_error" %302, 2, !dbg !252
  %306 = extractvalue %"/@stdlib/console.void::io_error_kind" %305, 0, !dbg !252
  %307 = extractvalue %"/@stdlib/console.void::io_error" %302, 3, !dbg !252
  %308 = extractvalue %"/@stdlib/console.void::io_error" %302, 4, !dbg !252
  %309 = extractvalue %"/@stdlib/console.void::io_error" %302, 5, !dbg !252
  %310 = extractvalue %"/@stdlib/console.void::io_error" %302, 6, !dbg !252
  %311 = extractvalue %"/@stdlib/console.void::io_error" %302, 7, !dbg !252
  %312 = extractvalue %"/@stdlib/console.void::io_error" %302, 8, !dbg !252
  br label %validate_payload_done25, !dbg !252

validate_payload_done25:                          ; preds = %validate_active_payload24, %validate_payload_done21
  store %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, ptr %121, align 8, !dbg !252
  call void @vd_gc_frame_leave(ptr %186), !dbg !252
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %291, !dbg !252

worker.cancelled26:                               ; preds = %block5
  call void @vd_gc_frame_leave(ptr %186), !dbg !252
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !252

worker.continue27:                                ; preds = %block5
  br label %block6, !dbg !252

worker.cancelled28:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %186), !dbg !252
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !252

worker.continue29:                                ; preds = %block6
  %313 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !268
  store %"/@stdlib/console.void::_reply" %313, ptr %126, align 8, !dbg !268
  %314 = extractvalue %"/@stdlib/console.void::_reply" %313, 7, !dbg !269
  store ptr %314, ptr %131, align 8, !dbg !269
  store ptr %314, ptr %17, align 8, !dbg !269
  %315 = load ptr, ptr %17, align 8, !dbg !270
  store ptr %315, ptr %136, align 8, !dbg !270
  %316 = insertvalue %"/@stdlib/console.void::bytes_read" zeroinitializer, ptr %315, 1, !dbg !270
  %317 = extractvalue %"/@stdlib/console.void::bytes_read" %316, 0, !dbg !270
  %318 = extractvalue %"/@stdlib/console.void::bytes_read" %316, 0, !dbg !270
  %319 = icmp eq i32 %318, 0, !dbg !270
  br i1 %319, label %validate_active_payload30, label %validate_payload_done31, !dbg !270

validate_active_payload30:                        ; preds = %worker.continue29
  %320 = extractvalue %"/@stdlib/console.void::bytes_read" %316, 1, !dbg !270
  br label %validate_payload_done31, !dbg !270

validate_payload_done31:                          ; preds = %validate_active_payload30, %worker.continue29
  store %"/@stdlib/console.void::bytes_read" %316, ptr %141, align 8, !dbg !270
  store %"/@stdlib/console.void::bytes_read" %316, ptr %18, align 8, !dbg !270
  %321 = load %"/@stdlib/console.void::bytes_read", ptr %18, align 8, !dbg !271
  store %"/@stdlib/console.void::bytes_read" %321, ptr %146, align 8, !dbg !271
  %322 = insertvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::bytes_read" %321, 1, !dbg !271
  %323 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, 0, !dbg !271
  %324 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, 0, !dbg !271
  %325 = icmp eq i32 %324, 0, !dbg !271
  br i1 %325, label %validate_active_payload32, label %validate_payload_done33, !dbg !271

validate_active_payload32:                        ; preds = %validate_payload_done31
  %326 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, 1, !dbg !271
  %327 = extractvalue %"/@stdlib/console.void::bytes_read" %326, 0, !dbg !271
  %328 = extractvalue %"/@stdlib/console.void::bytes_read" %326, 0, !dbg !271
  %329 = icmp eq i32 %328, 0, !dbg !271
  br i1 %329, label %validate_active_payload34, label %validate_payload_done35, !dbg !271

validate_payload_done33:                          ; preds = %validate_payload_done35, %validate_payload_done31
  %330 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, 0, !dbg !271
  %331 = icmp eq i32 %330, 1, !dbg !271
  br i1 %331, label %validate_active_payload36, label %validate_payload_done37, !dbg !271

validate_active_payload34:                        ; preds = %validate_active_payload32
  %332 = extractvalue %"/@stdlib/console.void::bytes_read" %326, 1, !dbg !271
  br label %validate_payload_done35, !dbg !271

validate_payload_done35:                          ; preds = %validate_active_payload34, %validate_active_payload32
  br label %validate_payload_done33, !dbg !271

validate_active_payload36:                        ; preds = %validate_payload_done33
  %333 = extractvalue %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, 2, !dbg !271
  %334 = extractvalue %"/@stdlib/console.void::io_error" %333, 0, !dbg !271
  %335 = extractvalue %"/@stdlib/console.void::io_error" %333, 1, !dbg !271
  %336 = extractvalue %"/@stdlib/console.void::io_error" %333, 2, !dbg !271
  %337 = extractvalue %"/@stdlib/console.void::io_error_kind" %336, 0, !dbg !271
  %338 = extractvalue %"/@stdlib/console.void::io_error" %333, 3, !dbg !271
  %339 = extractvalue %"/@stdlib/console.void::io_error" %333, 4, !dbg !271
  %340 = extractvalue %"/@stdlib/console.void::io_error" %333, 5, !dbg !271
  %341 = extractvalue %"/@stdlib/console.void::io_error" %333, 6, !dbg !271
  %342 = extractvalue %"/@stdlib/console.void::io_error" %333, 7, !dbg !271
  %343 = extractvalue %"/@stdlib/console.void::io_error" %333, 8, !dbg !271
  br label %validate_payload_done37, !dbg !271

validate_payload_done37:                          ; preds = %validate_active_payload36, %validate_payload_done33
  store %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, ptr %151, align 8, !dbg !271
  call void @vd_gc_frame_leave(ptr %186), !dbg !271
  ret %"$result:$array:36:12:/@stdlib/console.void::bytes_read:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %322, !dbg !271
}

define internal i64 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f636f6c6f725f636f6465__v1(%"/@stdlib/console.void::color" %0, ptr %1) !dbg !272 {
block0:
  %2 = alloca %"/@stdlib/console.void::color", align 8
  store %"/@stdlib/console.void::color" zeroinitializer, ptr %2, align 4
  %3 = alloca %"/@stdlib/console.void::color", align 8
  store %"/@stdlib/console.void::color" zeroinitializer, ptr %3, align 4
  %4 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %5 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %5, ptr %4, i64 0)
  call void @vd_gc_poll()
  %6 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %6, label %worker.cancelled, label %worker.continue

block1:                                           ; No predecessors!
  call void @vd_gc_poll(), !dbg !276
  %7 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !276
  br i1 %7, label %worker.cancelled1, label %worker.continue2, !dbg !276

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !276
  %8 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !276
  br i1 %8, label %worker.cancelled3, label %worker.continue4, !dbg !276

block3:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !277
  %9 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !277
  br i1 %9, label %worker.cancelled5, label %worker.continue6, !dbg !277

block4:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !278
  %10 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !278
  br i1 %10, label %worker.cancelled7, label %worker.continue8, !dbg !278

block5:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !279
  %11 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !279
  br i1 %11, label %worker.cancelled9, label %worker.continue10, !dbg !279

block6:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !280
  %12 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !280
  br i1 %12, label %worker.cancelled11, label %worker.continue12, !dbg !280

block7:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !281
  %13 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !281
  br i1 %13, label %worker.cancelled13, label %worker.continue14, !dbg !281

block8:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !282
  %14 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !282
  br i1 %14, label %worker.cancelled15, label %worker.continue16, !dbg !282

block9:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !283
  %15 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !283
  br i1 %15, label %worker.cancelled17, label %worker.continue18, !dbg !283

block10:                                          ; preds = %worker.continue18
  call void @vd_gc_poll(), !dbg !284
  %16 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !284
  br i1 %16, label %worker.cancelled19, label %worker.continue20, !dbg !284

block11:                                          ; preds = %worker.continue18
  call void @vd_gc_poll(), !dbg !285
  %17 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !285
  br i1 %17, label %worker.cancelled21, label %worker.continue22, !dbg !285

block12:                                          ; preds = %worker.continue22
  call void @vd_gc_poll(), !dbg !286
  %18 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !286
  br i1 %18, label %worker.cancelled23, label %worker.continue24, !dbg !286

block13:                                          ; preds = %worker.continue22
  call void @vd_gc_poll(), !dbg !287
  %19 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !287
  br i1 %19, label %worker.cancelled25, label %worker.continue26, !dbg !287

block14:                                          ; preds = %worker.continue26
  call void @vd_gc_poll(), !dbg !288
  %20 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !288
  br i1 %20, label %worker.cancelled27, label %worker.continue28, !dbg !288

block15:                                          ; preds = %worker.continue26
  call void @vd_gc_poll(), !dbg !289
  %21 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !289
  br i1 %21, label %worker.cancelled29, label %worker.continue30, !dbg !289

block16:                                          ; preds = %worker.continue30
  call void @vd_gc_poll(), !dbg !290
  %22 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !290
  br i1 %22, label %worker.cancelled31, label %worker.continue32, !dbg !290

block17:                                          ; preds = %worker.continue30
  call void @vd_gc_poll(), !dbg !291
  %23 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !291
  br i1 %23, label %worker.cancelled33, label %worker.continue34, !dbg !291

block18:                                          ; preds = %worker.continue34
  call void @vd_gc_poll(), !dbg !292
  %24 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !292
  br i1 %24, label %worker.cancelled35, label %worker.continue36, !dbg !292

block19:                                          ; preds = %worker.continue34
  call void @vd_gc_poll(), !dbg !293
  %25 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !293
  br i1 %25, label %worker.cancelled37, label %worker.continue38, !dbg !293

block20:                                          ; preds = %worker.continue38
  call void @vd_gc_poll(), !dbg !294
  %26 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !294
  br i1 %26, label %worker.cancelled39, label %worker.continue40, !dbg !294

block21:                                          ; preds = %worker.continue38
  call void @vd_gc_poll(), !dbg !295
  %27 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !295
  br i1 %27, label %worker.cancelled41, label %worker.continue42, !dbg !295

block22:                                          ; preds = %worker.continue42
  call void @vd_gc_poll(), !dbg !296
  %28 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !296
  br i1 %28, label %worker.cancelled43, label %worker.continue44, !dbg !296

block23:                                          ; preds = %worker.continue42
  call void @vd_gc_poll(), !dbg !297
  %29 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !297
  br i1 %29, label %worker.cancelled45, label %worker.continue46, !dbg !297

block24:                                          ; preds = %worker.continue46
  call void @vd_gc_poll(), !dbg !298
  %30 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !298
  br i1 %30, label %worker.cancelled47, label %worker.continue48, !dbg !298

block25:                                          ; preds = %worker.continue46
  call void @vd_gc_poll(), !dbg !299
  %31 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !299
  br i1 %31, label %worker.cancelled49, label %worker.continue50, !dbg !299

block26:                                          ; preds = %worker.continue50
  call void @vd_gc_poll(), !dbg !300
  %32 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !300
  br i1 %32, label %worker.cancelled51, label %worker.continue52, !dbg !300

block27:                                          ; preds = %worker.continue50
  call void @vd_gc_poll(), !dbg !301
  %33 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !301
  br i1 %33, label %worker.cancelled53, label %worker.continue54, !dbg !301

block28:                                          ; preds = %worker.continue54
  call void @vd_gc_poll(), !dbg !302
  %34 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !302
  br i1 %34, label %worker.cancelled55, label %worker.continue56, !dbg !302

block29:                                          ; preds = %worker.continue54
  call void @vd_gc_poll(), !dbg !303
  %35 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !303
  br i1 %35, label %worker.cancelled57, label %worker.continue58, !dbg !303

block30:                                          ; preds = %worker.continue58
  call void @vd_gc_poll(), !dbg !304
  %36 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !304
  br i1 %36, label %worker.cancelled59, label %worker.continue60, !dbg !304

block31:                                          ; preds = %worker.continue58
  call void @vd_gc_poll(), !dbg !305
  %37 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !305
  br i1 %37, label %worker.cancelled61, label %worker.continue62, !dbg !305

block32:                                          ; preds = %worker.continue62
  call void @vd_gc_poll(), !dbg !306
  %38 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !306
  br i1 %38, label %worker.cancelled63, label %worker.continue64, !dbg !306

block33:                                          ; preds = %worker.continue62
  call void @vd_gc_poll(), !dbg !307
  %39 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !307
  br i1 %39, label %worker.cancelled65, label %worker.continue66, !dbg !307

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %5)
  ret i64 0

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::color" %0, ptr %2, align 4, !dbg !308
  %40 = load %"/@stdlib/console.void::color", ptr %2, align 4, !dbg !309
  store %"/@stdlib/console.void::color" %40, ptr %3, align 4, !dbg !310
  %41 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !276
  %42 = extractvalue %"/@stdlib/console.void::color" %41, 0, !dbg !276
  %43 = icmp eq i32 %42, 0, !dbg !276
  br i1 %43, label %block2, label %block3, !dbg !276

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %5), !dbg !276
  ret i64 0, !dbg !276

worker.continue2:                                 ; preds = %block1
  unreachable, !dbg !276

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %5), !dbg !276
  ret i64 0, !dbg !276

worker.continue4:                                 ; preds = %block2
  call void @vd_gc_frame_leave(ptr %5), !dbg !277
  ret i64 0, !dbg !277

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %5), !dbg !277
  ret i64 0, !dbg !277

worker.continue6:                                 ; preds = %block3
  %44 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !278
  %45 = extractvalue %"/@stdlib/console.void::color" %44, 0, !dbg !278
  %46 = icmp eq i32 %45, 1, !dbg !278
  br i1 %46, label %block4, label %block5, !dbg !278

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %5), !dbg !278
  ret i64 0, !dbg !278

worker.continue8:                                 ; preds = %block4
  call void @vd_gc_frame_leave(ptr %5), !dbg !279
  ret i64 1, !dbg !279

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr %5), !dbg !279
  ret i64 0, !dbg !279

worker.continue10:                                ; preds = %block5
  %47 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !280
  %48 = extractvalue %"/@stdlib/console.void::color" %47, 0, !dbg !280
  %49 = icmp eq i32 %48, 2, !dbg !280
  br i1 %49, label %block6, label %block7, !dbg !280

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %5), !dbg !280
  ret i64 0, !dbg !280

worker.continue12:                                ; preds = %block6
  call void @vd_gc_frame_leave(ptr %5), !dbg !281
  ret i64 2, !dbg !281

worker.cancelled13:                               ; preds = %block7
  call void @vd_gc_frame_leave(ptr %5), !dbg !281
  ret i64 0, !dbg !281

worker.continue14:                                ; preds = %block7
  %50 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !282
  %51 = extractvalue %"/@stdlib/console.void::color" %50, 0, !dbg !282
  %52 = icmp eq i32 %51, 3, !dbg !282
  br i1 %52, label %block8, label %block9, !dbg !282

worker.cancelled15:                               ; preds = %block8
  call void @vd_gc_frame_leave(ptr %5), !dbg !282
  ret i64 0, !dbg !282

worker.continue16:                                ; preds = %block8
  call void @vd_gc_frame_leave(ptr %5), !dbg !283
  ret i64 3, !dbg !283

worker.cancelled17:                               ; preds = %block9
  call void @vd_gc_frame_leave(ptr %5), !dbg !283
  ret i64 0, !dbg !283

worker.continue18:                                ; preds = %block9
  %53 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !284
  %54 = extractvalue %"/@stdlib/console.void::color" %53, 0, !dbg !284
  %55 = icmp eq i32 %54, 4, !dbg !284
  br i1 %55, label %block10, label %block11, !dbg !284

worker.cancelled19:                               ; preds = %block10
  call void @vd_gc_frame_leave(ptr %5), !dbg !284
  ret i64 0, !dbg !284

worker.continue20:                                ; preds = %block10
  call void @vd_gc_frame_leave(ptr %5), !dbg !285
  ret i64 4, !dbg !285

worker.cancelled21:                               ; preds = %block11
  call void @vd_gc_frame_leave(ptr %5), !dbg !285
  ret i64 0, !dbg !285

worker.continue22:                                ; preds = %block11
  %56 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !286
  %57 = extractvalue %"/@stdlib/console.void::color" %56, 0, !dbg !286
  %58 = icmp eq i32 %57, 5, !dbg !286
  br i1 %58, label %block12, label %block13, !dbg !286

worker.cancelled23:                               ; preds = %block12
  call void @vd_gc_frame_leave(ptr %5), !dbg !286
  ret i64 0, !dbg !286

worker.continue24:                                ; preds = %block12
  call void @vd_gc_frame_leave(ptr %5), !dbg !287
  ret i64 5, !dbg !287

worker.cancelled25:                               ; preds = %block13
  call void @vd_gc_frame_leave(ptr %5), !dbg !287
  ret i64 0, !dbg !287

worker.continue26:                                ; preds = %block13
  %59 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !288
  %60 = extractvalue %"/@stdlib/console.void::color" %59, 0, !dbg !288
  %61 = icmp eq i32 %60, 6, !dbg !288
  br i1 %61, label %block14, label %block15, !dbg !288

worker.cancelled27:                               ; preds = %block14
  call void @vd_gc_frame_leave(ptr %5), !dbg !288
  ret i64 0, !dbg !288

worker.continue28:                                ; preds = %block14
  call void @vd_gc_frame_leave(ptr %5), !dbg !289
  ret i64 6, !dbg !289

worker.cancelled29:                               ; preds = %block15
  call void @vd_gc_frame_leave(ptr %5), !dbg !289
  ret i64 0, !dbg !289

worker.continue30:                                ; preds = %block15
  %62 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !290
  %63 = extractvalue %"/@stdlib/console.void::color" %62, 0, !dbg !290
  %64 = icmp eq i32 %63, 7, !dbg !290
  br i1 %64, label %block16, label %block17, !dbg !290

worker.cancelled31:                               ; preds = %block16
  call void @vd_gc_frame_leave(ptr %5), !dbg !290
  ret i64 0, !dbg !290

worker.continue32:                                ; preds = %block16
  call void @vd_gc_frame_leave(ptr %5), !dbg !291
  ret i64 7, !dbg !291

worker.cancelled33:                               ; preds = %block17
  call void @vd_gc_frame_leave(ptr %5), !dbg !291
  ret i64 0, !dbg !291

worker.continue34:                                ; preds = %block17
  %65 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !292
  %66 = extractvalue %"/@stdlib/console.void::color" %65, 0, !dbg !292
  %67 = icmp eq i32 %66, 8, !dbg !292
  br i1 %67, label %block18, label %block19, !dbg !292

worker.cancelled35:                               ; preds = %block18
  call void @vd_gc_frame_leave(ptr %5), !dbg !292
  ret i64 0, !dbg !292

worker.continue36:                                ; preds = %block18
  call void @vd_gc_frame_leave(ptr %5), !dbg !293
  ret i64 8, !dbg !293

worker.cancelled37:                               ; preds = %block19
  call void @vd_gc_frame_leave(ptr %5), !dbg !293
  ret i64 0, !dbg !293

worker.continue38:                                ; preds = %block19
  %68 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !294
  %69 = extractvalue %"/@stdlib/console.void::color" %68, 0, !dbg !294
  %70 = icmp eq i32 %69, 9, !dbg !294
  br i1 %70, label %block20, label %block21, !dbg !294

worker.cancelled39:                               ; preds = %block20
  call void @vd_gc_frame_leave(ptr %5), !dbg !294
  ret i64 0, !dbg !294

worker.continue40:                                ; preds = %block20
  call void @vd_gc_frame_leave(ptr %5), !dbg !295
  ret i64 9, !dbg !295

worker.cancelled41:                               ; preds = %block21
  call void @vd_gc_frame_leave(ptr %5), !dbg !295
  ret i64 0, !dbg !295

worker.continue42:                                ; preds = %block21
  %71 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !296
  %72 = extractvalue %"/@stdlib/console.void::color" %71, 0, !dbg !296
  %73 = icmp eq i32 %72, 10, !dbg !296
  br i1 %73, label %block22, label %block23, !dbg !296

worker.cancelled43:                               ; preds = %block22
  call void @vd_gc_frame_leave(ptr %5), !dbg !296
  ret i64 0, !dbg !296

worker.continue44:                                ; preds = %block22
  call void @vd_gc_frame_leave(ptr %5), !dbg !297
  ret i64 10, !dbg !297

worker.cancelled45:                               ; preds = %block23
  call void @vd_gc_frame_leave(ptr %5), !dbg !297
  ret i64 0, !dbg !297

worker.continue46:                                ; preds = %block23
  %74 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !298
  %75 = extractvalue %"/@stdlib/console.void::color" %74, 0, !dbg !298
  %76 = icmp eq i32 %75, 11, !dbg !298
  br i1 %76, label %block24, label %block25, !dbg !298

worker.cancelled47:                               ; preds = %block24
  call void @vd_gc_frame_leave(ptr %5), !dbg !298
  ret i64 0, !dbg !298

worker.continue48:                                ; preds = %block24
  call void @vd_gc_frame_leave(ptr %5), !dbg !299
  ret i64 11, !dbg !299

worker.cancelled49:                               ; preds = %block25
  call void @vd_gc_frame_leave(ptr %5), !dbg !299
  ret i64 0, !dbg !299

worker.continue50:                                ; preds = %block25
  %77 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !300
  %78 = extractvalue %"/@stdlib/console.void::color" %77, 0, !dbg !300
  %79 = icmp eq i32 %78, 12, !dbg !300
  br i1 %79, label %block26, label %block27, !dbg !300

worker.cancelled51:                               ; preds = %block26
  call void @vd_gc_frame_leave(ptr %5), !dbg !300
  ret i64 0, !dbg !300

worker.continue52:                                ; preds = %block26
  call void @vd_gc_frame_leave(ptr %5), !dbg !301
  ret i64 12, !dbg !301

worker.cancelled53:                               ; preds = %block27
  call void @vd_gc_frame_leave(ptr %5), !dbg !301
  ret i64 0, !dbg !301

worker.continue54:                                ; preds = %block27
  %80 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !302
  %81 = extractvalue %"/@stdlib/console.void::color" %80, 0, !dbg !302
  %82 = icmp eq i32 %81, 13, !dbg !302
  br i1 %82, label %block28, label %block29, !dbg !302

worker.cancelled55:                               ; preds = %block28
  call void @vd_gc_frame_leave(ptr %5), !dbg !302
  ret i64 0, !dbg !302

worker.continue56:                                ; preds = %block28
  call void @vd_gc_frame_leave(ptr %5), !dbg !303
  ret i64 13, !dbg !303

worker.cancelled57:                               ; preds = %block29
  call void @vd_gc_frame_leave(ptr %5), !dbg !303
  ret i64 0, !dbg !303

worker.continue58:                                ; preds = %block29
  %83 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !304
  %84 = extractvalue %"/@stdlib/console.void::color" %83, 0, !dbg !304
  %85 = icmp eq i32 %84, 14, !dbg !304
  br i1 %85, label %block30, label %block31, !dbg !304

worker.cancelled59:                               ; preds = %block30
  call void @vd_gc_frame_leave(ptr %5), !dbg !304
  ret i64 0, !dbg !304

worker.continue60:                                ; preds = %block30
  call void @vd_gc_frame_leave(ptr %5), !dbg !305
  ret i64 14, !dbg !305

worker.cancelled61:                               ; preds = %block31
  call void @vd_gc_frame_leave(ptr %5), !dbg !305
  ret i64 0, !dbg !305

worker.continue62:                                ; preds = %block31
  %86 = load %"/@stdlib/console.void::color", ptr %3, align 4, !dbg !306
  %87 = extractvalue %"/@stdlib/console.void::color" %86, 0, !dbg !306
  %88 = icmp eq i32 %87, 15, !dbg !306
  br i1 %88, label %block32, label %block33, !dbg !306

worker.cancelled63:                               ; preds = %block32
  call void @vd_gc_frame_leave(ptr %5), !dbg !306
  ret i64 0, !dbg !306

worker.continue64:                                ; preds = %block32
  call void @vd_gc_frame_leave(ptr %5), !dbg !307
  ret i64 15, !dbg !307

worker.cancelled65:                               ; preds = %block33
  call void @vd_gc_frame_leave(ptr %5), !dbg !307
  ret i64 0, !dbg !307

worker.continue66:                                ; preds = %block33
  unreachable, !dbg !307
}

define internal i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %0, i64 %1, ptr %2) !dbg !311 {
block0:
  %3 = alloca i64, align 8
  store i64 0, ptr %3, align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca i64, align 8
  store i64 0, ptr %7, align 8
  %8 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %9 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %9, ptr %8, i64 0)
  call void @vd_gc_poll()
  %10 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %10, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %9)
  ret i1 false

worker.continue:                                  ; preds = %block0
  store i64 %0, ptr %3, align 8, !dbg !314
  store i64 %1, ptr %4, align 8, !dbg !315
  %11 = load i64, ptr %3, align 8, !dbg !316
  store i64 %11, ptr %5, align 8, !dbg !317
  %12 = load i64, ptr %4, align 8, !dbg !318
  %13 = load i64, ptr %5, align 8, !dbg !317
  %14 = icmp eq i64 %12, 0, !dbg !317
  br i1 %14, label %numeric_error, label %numeric_valid, !dbg !317

numeric_error:                                    ; preds = %worker.continue
  %15 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !317
  store ptr @130, ptr %15, align 8, !dbg !317
  call void @vd_gc_frame_leave(ptr %9), !dbg !317
  ret i1 false, !dbg !317

numeric_valid:                                    ; preds = %worker.continue
  %16 = icmp eq i64 %13, -9223372036854775808, !dbg !317
  %17 = icmp eq i64 %12, -1, !dbg !317
  %18 = and i1 %16, %17, !dbg !317
  %19 = select i1 %18, i64 1, i64 %12, !dbg !317
  %20 = sdiv i64 %13, %19, !dbg !317
  %21 = select i1 %18, i64 -9223372036854775808, i64 %20, !dbg !317
  store i64 %21, ptr %6, align 8, !dbg !319
  %22 = load i64, ptr %6, align 8, !dbg !319
  br i1 false, label %numeric_error1, label %numeric_valid2, !dbg !319

numeric_error1:                                   ; preds = %numeric_valid
  %23 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !319
  store ptr @131, ptr %23, align 8, !dbg !319
  call void @vd_gc_frame_leave(ptr %9), !dbg !319
  ret i1 false, !dbg !319

numeric_valid2:                                   ; preds = %numeric_valid
  %24 = icmp eq i64 %22, -9223372036854775808, !dbg !319
  %25 = and i1 %24, false, !dbg !319
  %26 = select i1 %25, i64 1, i64 2, !dbg !319
  %27 = srem i64 %22, %26, !dbg !319
  %28 = select i1 %25, i64 0, i64 %27, !dbg !319
  store i64 %28, ptr %7, align 8, !dbg !320
  %29 = load i64, ptr %7, align 8, !dbg !320
  %30 = icmp ne i64 %29, 0, !dbg !320
  call void @vd_gc_frame_leave(ptr %9), !dbg !320
  ret i1 %30, !dbg !320
}

define internal %"/@stdlib/console.void::terminal_capabilities" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6361706162696c6974696573__v1(%"/@stdlib/console.void::_reply" %0, ptr %1) !dbg !321 {
block0:
  %2 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %2, align 8
  %3 = alloca i64, align 8
  store i64 0, ptr %3, align 8
  %4 = alloca i1, align 1
  store i1 false, ptr %4, align 1
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca i1, align 1
  store i1 false, ptr %7, align 1
  %8 = alloca i64, align 8
  store i64 0, ptr %8, align 8
  %9 = alloca i64, align 8
  store i64 0, ptr %9, align 8
  %10 = alloca i1, align 1
  store i1 false, ptr %10, align 1
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca i1, align 1
  store i1 false, ptr %13, align 1
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = alloca i64, align 8
  store i64 0, ptr %15, align 8
  %16 = alloca i1, align 1
  store i1 false, ptr %16, align 1
  %17 = alloca i64, align 8
  store i64 0, ptr %17, align 8
  %18 = alloca i64, align 8
  store i64 0, ptr %18, align 8
  %19 = alloca i1, align 1
  store i1 false, ptr %19, align 1
  %20 = alloca i64, align 8
  store i64 0, ptr %20, align 8
  %21 = alloca i64, align 8
  store i64 0, ptr %21, align 8
  %22 = alloca i1, align 1
  store i1 false, ptr %22, align 1
  %23 = alloca i64, align 8
  store i64 0, ptr %23, align 8
  %24 = alloca i64, align 8
  store i64 0, ptr %24, align 8
  %25 = alloca i1, align 1
  store i1 false, ptr %25, align 1
  %26 = alloca i64, align 8
  store i64 0, ptr %26, align 8
  %27 = alloca i64, align 8
  store i64 0, ptr %27, align 8
  %28 = alloca i1, align 1
  store i1 false, ptr %28, align 1
  %29 = alloca i64, align 8
  store i64 0, ptr %29, align 8
  %30 = alloca i64, align 8
  store i64 0, ptr %30, align 8
  %31 = alloca i1, align 1
  store i1 false, ptr %31, align 1
  %32 = alloca i64, align 8
  store i64 0, ptr %32, align 8
  %33 = alloca i64, align 8
  store i64 0, ptr %33, align 8
  %34 = alloca i1, align 1
  store i1 false, ptr %34, align 1
  %35 = alloca i64, align 8
  store i64 0, ptr %35, align 8
  %36 = alloca i64, align 8
  store i64 0, ptr %36, align 8
  %37 = alloca i1, align 1
  store i1 false, ptr %37, align 1
  %38 = alloca i1, align 1
  store i1 false, ptr %38, align 1
  %39 = alloca i1, align 1
  store i1 false, ptr %39, align 1
  %40 = alloca i1, align 1
  store i1 false, ptr %40, align 1
  %41 = alloca i1, align 1
  store i1 false, ptr %41, align 1
  %42 = alloca i1, align 1
  store i1 false, ptr %42, align 1
  %43 = alloca i1, align 1
  store i1 false, ptr %43, align 1
  %44 = alloca i1, align 1
  store i1 false, ptr %44, align 1
  %45 = alloca i1, align 1
  store i1 false, ptr %45, align 1
  %46 = alloca i1, align 1
  store i1 false, ptr %46, align 1
  %47 = alloca i1, align 1
  store i1 false, ptr %47, align 1
  %48 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %2, 0
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 80, 1
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, ptr @gc.offsets.218, 2
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 2, 3
  %52 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" %0, ptr %52, align 8
  %53 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %52, 0
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 80, 1
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, ptr @gc.offsets.219, 2
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 2, 3
  %57 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %57, align 8
  %58 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %57, 0
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, i64 80, 1
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, ptr @gc.offsets.220, 2
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 2, 3
  %62 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %62, align 8
  %63 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %62, 0
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, i64 80, 1
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, ptr @gc.offsets.221, 2
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, i64 2, 3
  %67 = alloca [4 x { ptr, i64, ptr, i64 }], align 8
  %68 = getelementptr inbounds [4 x { ptr, i64, ptr, i64 }], ptr %67, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %51, ptr %68, align 8
  %69 = getelementptr inbounds [4 x { ptr, i64, ptr, i64 }], ptr %67, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %56, ptr %69, align 8
  %70 = getelementptr inbounds [4 x { ptr, i64, ptr, i64 }], ptr %67, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %61, ptr %70, align 8
  %71 = getelementptr inbounds [4 x { ptr, i64, ptr, i64 }], ptr %67, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %66, ptr %71, align 8
  %72 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %72, ptr %67, i64 4)
  call void @vd_gc_poll()
  %73 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %73, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %72)
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::_reply" %0, ptr %57, align 8, !dbg !337
  store %"/@stdlib/console.void::_reply" %0, ptr %2, align 8, !dbg !337
  %74 = load %"/@stdlib/console.void::_reply", ptr %2, align 8, !dbg !338
  store %"/@stdlib/console.void::_reply" %74, ptr %62, align 8, !dbg !338
  %75 = extractvalue %"/@stdlib/console.void::_reply" %74, 2, !dbg !339
  store i64 %75, ptr %3, align 8, !dbg !340
  %76 = load i64, ptr %3, align 8, !dbg !341
  store i64 %76, ptr %5, align 8, !dbg !341
  store i64 1, ptr %6, align 8, !dbg !342
  %77 = load i64, ptr %5, align 8, !dbg !343
  %78 = load i64, ptr %6, align 8, !dbg !343
  %79 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %77, i64 %78, ptr %1), !dbg !343
  %80 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !343
  %81 = load ptr, ptr %80, align 8, !dbg !343
  %82 = icmp ne ptr %81, null, !dbg !343
  br i1 %82, label %propagate_error, label %call_success, !dbg !343

propagate_error:                                  ; preds = %worker.continue
  %83 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !343
  %84 = load i32, ptr %83, align 4, !dbg !343
  %85 = icmp ult i32 %84, 32, !dbg !343
  br i1 %85, label %trace_caller, label %trace_limit, !dbg !343

call_success:                                     ; preds = %worker.continue
  store i1 %79, ptr %4, align 1, !dbg !343
  %86 = load i64, ptr %3, align 8, !dbg !344
  store i64 %86, ptr %8, align 8, !dbg !344
  store i64 2, ptr %9, align 8, !dbg !345
  %87 = load i64, ptr %8, align 8, !dbg !346
  %88 = load i64, ptr %9, align 8, !dbg !346
  %89 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %87, i64 %88, ptr %1), !dbg !346
  %90 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !346
  %91 = load ptr, ptr %90, align 8, !dbg !346
  %92 = icmp ne ptr %91, null, !dbg !346
  br i1 %92, label %propagate_error1, label %call_success2, !dbg !346

trace_caller:                                     ; preds = %propagate_error
  %93 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !343
  %94 = getelementptr [32 x ptr], ptr %93, i32 0, i32 %84, !dbg !343
  store ptr @132, ptr %94, align 8, !dbg !343
  %95 = add i32 %84, 1, !dbg !343
  store i32 %95, ptr %83, align 4, !dbg !343
  br label %error_return, !dbg !343

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %72), !dbg !343
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !343

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %83, align 4, !dbg !343
  br label %error_return, !dbg !343

propagate_error1:                                 ; preds = %call_success
  %96 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !346
  %97 = load i32, ptr %96, align 4, !dbg !346
  %98 = icmp ult i32 %97, 32, !dbg !346
  br i1 %98, label %trace_caller3, label %trace_limit5, !dbg !346

call_success2:                                    ; preds = %call_success
  store i1 %89, ptr %7, align 1, !dbg !346
  %99 = load i64, ptr %3, align 8, !dbg !347
  store i64 %99, ptr %11, align 8, !dbg !347
  store i64 4, ptr %12, align 8, !dbg !348
  %100 = load i64, ptr %11, align 8, !dbg !349
  %101 = load i64, ptr %12, align 8, !dbg !349
  %102 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %100, i64 %101, ptr %1), !dbg !349
  %103 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !349
  %104 = load ptr, ptr %103, align 8, !dbg !349
  %105 = icmp ne ptr %104, null, !dbg !349
  br i1 %105, label %propagate_error6, label %call_success7, !dbg !349

trace_caller3:                                    ; preds = %propagate_error1
  %106 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !346
  %107 = getelementptr [32 x ptr], ptr %106, i32 0, i32 %97, !dbg !346
  store ptr @133, ptr %107, align 8, !dbg !346
  %108 = add i32 %97, 1, !dbg !346
  store i32 %108, ptr %96, align 4, !dbg !346
  br label %error_return4, !dbg !346

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %72), !dbg !346
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !346

trace_limit5:                                     ; preds = %propagate_error1
  store i32 33, ptr %96, align 4, !dbg !346
  br label %error_return4, !dbg !346

propagate_error6:                                 ; preds = %call_success2
  %109 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !349
  %110 = load i32, ptr %109, align 4, !dbg !349
  %111 = icmp ult i32 %110, 32, !dbg !349
  br i1 %111, label %trace_caller8, label %trace_limit10, !dbg !349

call_success7:                                    ; preds = %call_success2
  store i1 %102, ptr %10, align 1, !dbg !349
  %112 = load i64, ptr %3, align 8, !dbg !350
  store i64 %112, ptr %14, align 8, !dbg !350
  store i64 8, ptr %15, align 8, !dbg !351
  %113 = load i64, ptr %14, align 8, !dbg !352
  %114 = load i64, ptr %15, align 8, !dbg !352
  %115 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %113, i64 %114, ptr %1), !dbg !352
  %116 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !352
  %117 = load ptr, ptr %116, align 8, !dbg !352
  %118 = icmp ne ptr %117, null, !dbg !352
  br i1 %118, label %propagate_error11, label %call_success12, !dbg !352

trace_caller8:                                    ; preds = %propagate_error6
  %119 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !349
  %120 = getelementptr [32 x ptr], ptr %119, i32 0, i32 %110, !dbg !349
  store ptr @134, ptr %120, align 8, !dbg !349
  %121 = add i32 %110, 1, !dbg !349
  store i32 %121, ptr %109, align 4, !dbg !349
  br label %error_return9, !dbg !349

error_return9:                                    ; preds = %trace_caller8, %trace_limit10
  call void @vd_gc_frame_leave(ptr %72), !dbg !349
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !349

trace_limit10:                                    ; preds = %propagate_error6
  store i32 33, ptr %109, align 4, !dbg !349
  br label %error_return9, !dbg !349

propagate_error11:                                ; preds = %call_success7
  %122 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !352
  %123 = load i32, ptr %122, align 4, !dbg !352
  %124 = icmp ult i32 %123, 32, !dbg !352
  br i1 %124, label %trace_caller13, label %trace_limit15, !dbg !352

call_success12:                                   ; preds = %call_success7
  store i1 %115, ptr %13, align 1, !dbg !352
  %125 = load i64, ptr %3, align 8, !dbg !353
  store i64 %125, ptr %17, align 8, !dbg !353
  store i64 16, ptr %18, align 8, !dbg !354
  %126 = load i64, ptr %17, align 8, !dbg !355
  %127 = load i64, ptr %18, align 8, !dbg !355
  %128 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %126, i64 %127, ptr %1), !dbg !355
  %129 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !355
  %130 = load ptr, ptr %129, align 8, !dbg !355
  %131 = icmp ne ptr %130, null, !dbg !355
  br i1 %131, label %propagate_error16, label %call_success17, !dbg !355

trace_caller13:                                   ; preds = %propagate_error11
  %132 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !352
  %133 = getelementptr [32 x ptr], ptr %132, i32 0, i32 %123, !dbg !352
  store ptr @135, ptr %133, align 8, !dbg !352
  %134 = add i32 %123, 1, !dbg !352
  store i32 %134, ptr %122, align 4, !dbg !352
  br label %error_return14, !dbg !352

error_return14:                                   ; preds = %trace_caller13, %trace_limit15
  call void @vd_gc_frame_leave(ptr %72), !dbg !352
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !352

trace_limit15:                                    ; preds = %propagate_error11
  store i32 33, ptr %122, align 4, !dbg !352
  br label %error_return14, !dbg !352

propagate_error16:                                ; preds = %call_success12
  %135 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !355
  %136 = load i32, ptr %135, align 4, !dbg !355
  %137 = icmp ult i32 %136, 32, !dbg !355
  br i1 %137, label %trace_caller18, label %trace_limit20, !dbg !355

call_success17:                                   ; preds = %call_success12
  store i1 %128, ptr %16, align 1, !dbg !355
  %138 = load i64, ptr %3, align 8, !dbg !356
  store i64 %138, ptr %20, align 8, !dbg !356
  store i64 32, ptr %21, align 8, !dbg !357
  %139 = load i64, ptr %20, align 8, !dbg !358
  %140 = load i64, ptr %21, align 8, !dbg !358
  %141 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %139, i64 %140, ptr %1), !dbg !358
  %142 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !358
  %143 = load ptr, ptr %142, align 8, !dbg !358
  %144 = icmp ne ptr %143, null, !dbg !358
  br i1 %144, label %propagate_error21, label %call_success22, !dbg !358

trace_caller18:                                   ; preds = %propagate_error16
  %145 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !355
  %146 = getelementptr [32 x ptr], ptr %145, i32 0, i32 %136, !dbg !355
  store ptr @136, ptr %146, align 8, !dbg !355
  %147 = add i32 %136, 1, !dbg !355
  store i32 %147, ptr %135, align 4, !dbg !355
  br label %error_return19, !dbg !355

error_return19:                                   ; preds = %trace_caller18, %trace_limit20
  call void @vd_gc_frame_leave(ptr %72), !dbg !355
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !355

trace_limit20:                                    ; preds = %propagate_error16
  store i32 33, ptr %135, align 4, !dbg !355
  br label %error_return19, !dbg !355

propagate_error21:                                ; preds = %call_success17
  %148 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !358
  %149 = load i32, ptr %148, align 4, !dbg !358
  %150 = icmp ult i32 %149, 32, !dbg !358
  br i1 %150, label %trace_caller23, label %trace_limit25, !dbg !358

call_success22:                                   ; preds = %call_success17
  store i1 %141, ptr %19, align 1, !dbg !358
  %151 = load i64, ptr %3, align 8, !dbg !359
  store i64 %151, ptr %23, align 8, !dbg !359
  store i64 64, ptr %24, align 8, !dbg !360
  %152 = load i64, ptr %23, align 8, !dbg !361
  %153 = load i64, ptr %24, align 8, !dbg !361
  %154 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %152, i64 %153, ptr %1), !dbg !361
  %155 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !361
  %156 = load ptr, ptr %155, align 8, !dbg !361
  %157 = icmp ne ptr %156, null, !dbg !361
  br i1 %157, label %propagate_error26, label %call_success27, !dbg !361

trace_caller23:                                   ; preds = %propagate_error21
  %158 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !358
  %159 = getelementptr [32 x ptr], ptr %158, i32 0, i32 %149, !dbg !358
  store ptr @137, ptr %159, align 8, !dbg !358
  %160 = add i32 %149, 1, !dbg !358
  store i32 %160, ptr %148, align 4, !dbg !358
  br label %error_return24, !dbg !358

error_return24:                                   ; preds = %trace_caller23, %trace_limit25
  call void @vd_gc_frame_leave(ptr %72), !dbg !358
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !358

trace_limit25:                                    ; preds = %propagate_error21
  store i32 33, ptr %148, align 4, !dbg !358
  br label %error_return24, !dbg !358

propagate_error26:                                ; preds = %call_success22
  %161 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !361
  %162 = load i32, ptr %161, align 4, !dbg !361
  %163 = icmp ult i32 %162, 32, !dbg !361
  br i1 %163, label %trace_caller28, label %trace_limit30, !dbg !361

call_success27:                                   ; preds = %call_success22
  store i1 %154, ptr %22, align 1, !dbg !361
  %164 = load i64, ptr %3, align 8, !dbg !362
  store i64 %164, ptr %26, align 8, !dbg !362
  store i64 128, ptr %27, align 8, !dbg !363
  %165 = load i64, ptr %26, align 8, !dbg !364
  %166 = load i64, ptr %27, align 8, !dbg !364
  %167 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %165, i64 %166, ptr %1), !dbg !364
  %168 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !364
  %169 = load ptr, ptr %168, align 8, !dbg !364
  %170 = icmp ne ptr %169, null, !dbg !364
  br i1 %170, label %propagate_error31, label %call_success32, !dbg !364

trace_caller28:                                   ; preds = %propagate_error26
  %171 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !361
  %172 = getelementptr [32 x ptr], ptr %171, i32 0, i32 %162, !dbg !361
  store ptr @138, ptr %172, align 8, !dbg !361
  %173 = add i32 %162, 1, !dbg !361
  store i32 %173, ptr %161, align 4, !dbg !361
  br label %error_return29, !dbg !361

error_return29:                                   ; preds = %trace_caller28, %trace_limit30
  call void @vd_gc_frame_leave(ptr %72), !dbg !361
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !361

trace_limit30:                                    ; preds = %propagate_error26
  store i32 33, ptr %161, align 4, !dbg !361
  br label %error_return29, !dbg !361

propagate_error31:                                ; preds = %call_success27
  %174 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !364
  %175 = load i32, ptr %174, align 4, !dbg !364
  %176 = icmp ult i32 %175, 32, !dbg !364
  br i1 %176, label %trace_caller33, label %trace_limit35, !dbg !364

call_success32:                                   ; preds = %call_success27
  store i1 %167, ptr %25, align 1, !dbg !364
  %177 = load i64, ptr %3, align 8, !dbg !365
  store i64 %177, ptr %29, align 8, !dbg !365
  store i64 256, ptr %30, align 8, !dbg !366
  %178 = load i64, ptr %29, align 8, !dbg !367
  %179 = load i64, ptr %30, align 8, !dbg !367
  %180 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %178, i64 %179, ptr %1), !dbg !367
  %181 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !367
  %182 = load ptr, ptr %181, align 8, !dbg !367
  %183 = icmp ne ptr %182, null, !dbg !367
  br i1 %183, label %propagate_error36, label %call_success37, !dbg !367

trace_caller33:                                   ; preds = %propagate_error31
  %184 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !364
  %185 = getelementptr [32 x ptr], ptr %184, i32 0, i32 %175, !dbg !364
  store ptr @139, ptr %185, align 8, !dbg !364
  %186 = add i32 %175, 1, !dbg !364
  store i32 %186, ptr %174, align 4, !dbg !364
  br label %error_return34, !dbg !364

error_return34:                                   ; preds = %trace_caller33, %trace_limit35
  call void @vd_gc_frame_leave(ptr %72), !dbg !364
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !364

trace_limit35:                                    ; preds = %propagate_error31
  store i32 33, ptr %174, align 4, !dbg !364
  br label %error_return34, !dbg !364

propagate_error36:                                ; preds = %call_success32
  %187 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !367
  %188 = load i32, ptr %187, align 4, !dbg !367
  %189 = icmp ult i32 %188, 32, !dbg !367
  br i1 %189, label %trace_caller38, label %trace_limit40, !dbg !367

call_success37:                                   ; preds = %call_success32
  store i1 %180, ptr %28, align 1, !dbg !367
  %190 = load i64, ptr %3, align 8, !dbg !368
  store i64 %190, ptr %32, align 8, !dbg !368
  store i64 512, ptr %33, align 8, !dbg !369
  %191 = load i64, ptr %32, align 8, !dbg !370
  %192 = load i64, ptr %33, align 8, !dbg !370
  %193 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %191, i64 %192, ptr %1), !dbg !370
  %194 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !370
  %195 = load ptr, ptr %194, align 8, !dbg !370
  %196 = icmp ne ptr %195, null, !dbg !370
  br i1 %196, label %propagate_error41, label %call_success42, !dbg !370

trace_caller38:                                   ; preds = %propagate_error36
  %197 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !367
  %198 = getelementptr [32 x ptr], ptr %197, i32 0, i32 %188, !dbg !367
  store ptr @140, ptr %198, align 8, !dbg !367
  %199 = add i32 %188, 1, !dbg !367
  store i32 %199, ptr %187, align 4, !dbg !367
  br label %error_return39, !dbg !367

error_return39:                                   ; preds = %trace_caller38, %trace_limit40
  call void @vd_gc_frame_leave(ptr %72), !dbg !367
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !367

trace_limit40:                                    ; preds = %propagate_error36
  store i32 33, ptr %187, align 4, !dbg !367
  br label %error_return39, !dbg !367

propagate_error41:                                ; preds = %call_success37
  %200 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !370
  %201 = load i32, ptr %200, align 4, !dbg !370
  %202 = icmp ult i32 %201, 32, !dbg !370
  br i1 %202, label %trace_caller43, label %trace_limit45, !dbg !370

call_success42:                                   ; preds = %call_success37
  store i1 %193, ptr %31, align 1, !dbg !370
  %203 = load i64, ptr %3, align 8, !dbg !371
  store i64 %203, ptr %35, align 8, !dbg !371
  store i64 1024, ptr %36, align 8, !dbg !372
  %204 = load i64, ptr %35, align 8, !dbg !373
  %205 = load i64, ptr %36, align 8, !dbg !373
  %206 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %204, i64 %205, ptr %1), !dbg !373
  %207 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !373
  %208 = load ptr, ptr %207, align 8, !dbg !373
  %209 = icmp ne ptr %208, null, !dbg !373
  br i1 %209, label %propagate_error46, label %call_success47, !dbg !373

trace_caller43:                                   ; preds = %propagate_error41
  %210 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !370
  %211 = getelementptr [32 x ptr], ptr %210, i32 0, i32 %201, !dbg !370
  store ptr @141, ptr %211, align 8, !dbg !370
  %212 = add i32 %201, 1, !dbg !370
  store i32 %212, ptr %200, align 4, !dbg !370
  br label %error_return44, !dbg !370

error_return44:                                   ; preds = %trace_caller43, %trace_limit45
  call void @vd_gc_frame_leave(ptr %72), !dbg !370
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !370

trace_limit45:                                    ; preds = %propagate_error41
  store i32 33, ptr %200, align 4, !dbg !370
  br label %error_return44, !dbg !370

propagate_error46:                                ; preds = %call_success42
  %213 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !373
  %214 = load i32, ptr %213, align 4, !dbg !373
  %215 = icmp ult i32 %214, 32, !dbg !373
  br i1 %215, label %trace_caller48, label %trace_limit50, !dbg !373

call_success47:                                   ; preds = %call_success42
  store i1 %206, ptr %34, align 1, !dbg !373
  %216 = load i1, ptr %4, align 1, !dbg !374
  store i1 %216, ptr %37, align 1, !dbg !374
  %217 = load i1, ptr %7, align 1, !dbg !374
  store i1 %217, ptr %38, align 1, !dbg !374
  %218 = load i1, ptr %10, align 1, !dbg !374
  store i1 %218, ptr %39, align 1, !dbg !374
  %219 = load i1, ptr %13, align 1, !dbg !374
  store i1 %219, ptr %40, align 1, !dbg !374
  %220 = load i1, ptr %16, align 1, !dbg !374
  store i1 %220, ptr %41, align 1, !dbg !374
  %221 = load i1, ptr %19, align 1, !dbg !374
  store i1 %221, ptr %42, align 1, !dbg !374
  %222 = load i1, ptr %22, align 1, !dbg !374
  store i1 %222, ptr %43, align 1, !dbg !374
  %223 = load i1, ptr %25, align 1, !dbg !374
  store i1 %223, ptr %44, align 1, !dbg !374
  %224 = load i1, ptr %28, align 1, !dbg !374
  store i1 %224, ptr %45, align 1, !dbg !374
  %225 = load i1, ptr %31, align 1, !dbg !374
  store i1 %225, ptr %46, align 1, !dbg !374
  %226 = load i1, ptr %34, align 1, !dbg !374
  store i1 %226, ptr %47, align 1, !dbg !374
  %227 = load i1, ptr %37, align 1, !dbg !374
  %228 = load i1, ptr %38, align 1, !dbg !374
  %229 = load i1, ptr %39, align 1, !dbg !374
  %230 = load i1, ptr %40, align 1, !dbg !374
  %231 = load i1, ptr %41, align 1, !dbg !374
  %232 = load i1, ptr %42, align 1, !dbg !374
  %233 = load i1, ptr %43, align 1, !dbg !374
  %234 = load i1, ptr %44, align 1, !dbg !374
  %235 = load i1, ptr %45, align 1, !dbg !374
  %236 = load i1, ptr %46, align 1, !dbg !374
  %237 = load i1, ptr %47, align 1, !dbg !374
  %238 = insertvalue %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, i1 %227, 0, !dbg !374
  %239 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %238, i1 %228, 1, !dbg !374
  %240 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %239, i1 %229, 2, !dbg !374
  %241 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %240, i1 %230, 3, !dbg !374
  %242 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %241, i1 %231, 4, !dbg !374
  %243 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %242, i1 %232, 5, !dbg !374
  %244 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %243, i1 %233, 6, !dbg !374
  %245 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %244, i1 %234, 7, !dbg !374
  %246 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %245, i1 %235, 8, !dbg !374
  %247 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %246, i1 %236, 9, !dbg !374
  %248 = insertvalue %"/@stdlib/console.void::terminal_capabilities" %247, i1 %237, 10, !dbg !374
  call void @vd_gc_frame_leave(ptr %72), !dbg !374
  ret %"/@stdlib/console.void::terminal_capabilities" %248, !dbg !374

trace_caller48:                                   ; preds = %propagate_error46
  %249 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !373
  %250 = getelementptr [32 x ptr], ptr %249, i32 0, i32 %214, !dbg !373
  store ptr @142, ptr %250, align 8, !dbg !373
  %251 = add i32 %214, 1, !dbg !373
  store i32 %251, ptr %213, align 4, !dbg !373
  br label %error_return49, !dbg !373

error_return49:                                   ; preds = %trace_caller48, %trace_limit50
  call void @vd_gc_frame_leave(ptr %72), !dbg !373
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !373

trace_limit50:                                    ; preds = %propagate_error46
  store i32 33, ptr %213, align 4, !dbg !373
  br label %error_return49, !dbg !373
}

define %"/@stdlib/console.void::terminal_capabilities" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a6361706162696c6974696573__v1(ptr %0, ptr %1) !dbg !375 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %4, align 8
  %5 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %6 = insertvalue { ptr, i64, ptr, i64 } %5, i64 80, 1
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, ptr @gc.offsets.222, 2
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, i64 2, 3
  %9 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %9, align 8
  %10 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 80, 1
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, ptr @gc.offsets.223, 2
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 2, 3
  %14 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %14, align 8
  %15 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %14, 0
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 80, 1
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, ptr @gc.offsets.224, 2
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 2, 3
  %19 = alloca [3 x { ptr, i64, ptr, i64 }], align 8
  %20 = getelementptr inbounds [3 x { ptr, i64, ptr, i64 }], ptr %19, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %8, ptr %20, align 8
  %21 = getelementptr inbounds [3 x { ptr, i64, ptr, i64 }], ptr %19, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %13, ptr %21, align 8
  %22 = getelementptr inbounds [3 x { ptr, i64, ptr, i64 }], ptr %19, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %18, ptr %22, align 8
  %23 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %23, ptr %19, i64 3)
  call void @vd_gc_poll()
  %24 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %24, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %23)
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer

worker.continue:                                  ; preds = %block0
  %25 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !378
  store %"/@stdlib/console.void::input" %25, ptr %4, align 8, !dbg !378
  %26 = load %"/@stdlib/console.void::input", ptr %4, align 8, !dbg !379
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %9, align 8, !dbg !379
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !379
  %27 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 6, !dbg !379
  %28 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 7, !dbg !379
  %29 = extractvalue %"/@stdlib/console.void::input" %26, 0, !dbg !379
  call void @vd_console_v2(ptr %27, ptr %28, ptr %2, i32 8, i64 %29, ptr null, i64 0, i64 -1, ptr %1), !dbg !379
  %30 = load ptr, ptr %1, align 8, !dbg !379
  %31 = icmp ne ptr %30, null, !dbg !379
  br i1 %31, label %selected.failure, label %selected.valid, !dbg !379

selected.failure:                                 ; preds = %worker.continue
  %32 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !379
  %33 = load i32, ptr %32, align 4, !dbg !379
  %34 = icmp ult i32 %33, 32, !dbg !379
  br i1 %34, label %trace_caller, label %trace_limit, !dbg !379

selected.valid:                                   ; preds = %worker.continue
  %35 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !379
  %36 = load i64, ptr %35, align 8, !dbg !379
  %37 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 0, !dbg !379
  store i64 %36, ptr %37, align 8, !dbg !379
  %38 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !379
  %39 = load i64, ptr %38, align 8, !dbg !379
  %40 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 1, !dbg !379
  store i64 %39, ptr %40, align 8, !dbg !379
  %41 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !379
  %42 = load i64, ptr %41, align 8, !dbg !379
  %43 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 2, !dbg !379
  store i64 %42, ptr %43, align 8, !dbg !379
  %44 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !379
  %45 = load i64, ptr %44, align 8, !dbg !379
  %46 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 3, !dbg !379
  store i64 %45, ptr %46, align 8, !dbg !379
  %47 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !379
  %48 = load i64, ptr %47, align 8, !dbg !379
  %49 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 4, !dbg !379
  store i64 %48, ptr %49, align 8, !dbg !379
  %50 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !379
  %51 = load i64, ptr %50, align 8, !dbg !379
  %52 = trunc i64 %51 to i1, !dbg !379
  %53 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 5, !dbg !379
  store i1 %52, ptr %53, align 1, !dbg !379
  %54 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !379
  %55 = load i64, ptr %54, align 8, !dbg !379
  %56 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 8, !dbg !379
  store i64 %55, ptr %56, align 8, !dbg !379
  %57 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !379
  %58 = load i64, ptr %57, align 8, !dbg !379
  %59 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 9, !dbg !379
  store i64 %58, ptr %59, align 8, !dbg !379
  %60 = load %"/@stdlib/console.void::_reply", ptr %9, align 8, !dbg !379
  store %"/@stdlib/console.void::_reply" %60, ptr %9, align 8, !dbg !379
  store %"/@stdlib/console.void::_reply" %60, ptr %3, align 8, !dbg !379
  %61 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !380
  store %"/@stdlib/console.void::_reply" %61, ptr %14, align 8, !dbg !380
  %62 = call %"/@stdlib/console.void::terminal_capabilities" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6361706162696c6974696573__v1(%"/@stdlib/console.void::_reply" %61, ptr %1), !dbg !380
  %63 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !380
  %64 = load ptr, ptr %63, align 8, !dbg !380
  %65 = icmp ne ptr %64, null, !dbg !380
  br i1 %65, label %propagate_error, label %call_success, !dbg !380

trace_caller:                                     ; preds = %selected.failure
  %66 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !379
  %67 = getelementptr [32 x ptr], ptr %66, i32 0, i32 %33, !dbg !379
  store ptr @143, ptr %67, align 8, !dbg !379
  %68 = add i32 %33, 1, !dbg !379
  store i32 %68, ptr %32, align 4, !dbg !379
  br label %error_return, !dbg !379

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %23), !dbg !379
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !379

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %32, align 4, !dbg !379
  br label %error_return, !dbg !379

propagate_error:                                  ; preds = %selected.valid
  %69 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !380
  %70 = load i32, ptr %69, align 4, !dbg !380
  %71 = icmp ult i32 %70, 32, !dbg !380
  br i1 %71, label %trace_caller1, label %trace_limit3, !dbg !380

call_success:                                     ; preds = %selected.valid
  call void @vd_gc_frame_leave(ptr %23), !dbg !380
  ret %"/@stdlib/console.void::terminal_capabilities" %62, !dbg !380

trace_caller1:                                    ; preds = %propagate_error
  %72 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !380
  %73 = getelementptr [32 x ptr], ptr %72, i32 0, i32 %70, !dbg !380
  store ptr @144, ptr %73, align 8, !dbg !380
  %74 = add i32 %70, 1, !dbg !380
  store i32 %74, ptr %69, align 4, !dbg !380
  br label %error_return2, !dbg !380

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %23), !dbg !380
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !380

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %69, align 4, !dbg !380
  br label %error_return2, !dbg !380
}

define %"/@stdlib/console.void::terminal_capabilities" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a6361706162696c6974696573__v1(ptr %0, ptr %1) !dbg !381 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %6 = insertvalue { ptr, i64, ptr, i64 } %5, i64 80, 1
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, ptr @gc.offsets.225, 2
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, i64 2, 3
  %9 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %9, align 8
  %10 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 80, 1
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, ptr @gc.offsets.226, 2
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 2, 3
  %14 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %14, align 8
  %15 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %14, 0
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 80, 1
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, ptr @gc.offsets.227, 2
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 2, 3
  %19 = alloca [3 x { ptr, i64, ptr, i64 }], align 8
  %20 = getelementptr inbounds [3 x { ptr, i64, ptr, i64 }], ptr %19, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %8, ptr %20, align 8
  %21 = getelementptr inbounds [3 x { ptr, i64, ptr, i64 }], ptr %19, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %13, ptr %21, align 8
  %22 = getelementptr inbounds [3 x { ptr, i64, ptr, i64 }], ptr %19, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %18, ptr %22, align 8
  %23 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %23, ptr %19, i64 3)
  call void @vd_gc_poll()
  %24 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %24, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %23)
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer

worker.continue:                                  ; preds = %block0
  %25 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !384
  store %"/@stdlib/console.void::output" %25, ptr %4, align 8, !dbg !384
  %26 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !385
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %9, align 8, !dbg !385
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !385
  %27 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 6, !dbg !385
  %28 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 7, !dbg !385
  %29 = extractvalue %"/@stdlib/console.void::output" %26, 0, !dbg !385
  call void @vd_console_v2(ptr %27, ptr %28, ptr %2, i32 8, i64 %29, ptr null, i64 0, i64 -1, ptr %1), !dbg !385
  %30 = load ptr, ptr %1, align 8, !dbg !385
  %31 = icmp ne ptr %30, null, !dbg !385
  br i1 %31, label %selected.failure, label %selected.valid, !dbg !385

selected.failure:                                 ; preds = %worker.continue
  %32 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !385
  %33 = load i32, ptr %32, align 4, !dbg !385
  %34 = icmp ult i32 %33, 32, !dbg !385
  br i1 %34, label %trace_caller, label %trace_limit, !dbg !385

selected.valid:                                   ; preds = %worker.continue
  %35 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !385
  %36 = load i64, ptr %35, align 8, !dbg !385
  %37 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 0, !dbg !385
  store i64 %36, ptr %37, align 8, !dbg !385
  %38 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !385
  %39 = load i64, ptr %38, align 8, !dbg !385
  %40 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 1, !dbg !385
  store i64 %39, ptr %40, align 8, !dbg !385
  %41 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !385
  %42 = load i64, ptr %41, align 8, !dbg !385
  %43 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 2, !dbg !385
  store i64 %42, ptr %43, align 8, !dbg !385
  %44 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !385
  %45 = load i64, ptr %44, align 8, !dbg !385
  %46 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 3, !dbg !385
  store i64 %45, ptr %46, align 8, !dbg !385
  %47 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !385
  %48 = load i64, ptr %47, align 8, !dbg !385
  %49 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 4, !dbg !385
  store i64 %48, ptr %49, align 8, !dbg !385
  %50 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !385
  %51 = load i64, ptr %50, align 8, !dbg !385
  %52 = trunc i64 %51 to i1, !dbg !385
  %53 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 5, !dbg !385
  store i1 %52, ptr %53, align 1, !dbg !385
  %54 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !385
  %55 = load i64, ptr %54, align 8, !dbg !385
  %56 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 8, !dbg !385
  store i64 %55, ptr %56, align 8, !dbg !385
  %57 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !385
  %58 = load i64, ptr %57, align 8, !dbg !385
  %59 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %9, i32 0, i32 9, !dbg !385
  store i64 %58, ptr %59, align 8, !dbg !385
  %60 = load %"/@stdlib/console.void::_reply", ptr %9, align 8, !dbg !385
  store %"/@stdlib/console.void::_reply" %60, ptr %9, align 8, !dbg !385
  store %"/@stdlib/console.void::_reply" %60, ptr %3, align 8, !dbg !385
  %61 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !386
  store %"/@stdlib/console.void::_reply" %61, ptr %14, align 8, !dbg !386
  %62 = call %"/@stdlib/console.void::terminal_capabilities" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6361706162696c6974696573__v1(%"/@stdlib/console.void::_reply" %61, ptr %1), !dbg !386
  %63 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !386
  %64 = load ptr, ptr %63, align 8, !dbg !386
  %65 = icmp ne ptr %64, null, !dbg !386
  br i1 %65, label %propagate_error, label %call_success, !dbg !386

trace_caller:                                     ; preds = %selected.failure
  %66 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !385
  %67 = getelementptr [32 x ptr], ptr %66, i32 0, i32 %33, !dbg !385
  store ptr @145, ptr %67, align 8, !dbg !385
  %68 = add i32 %33, 1, !dbg !385
  store i32 %68, ptr %32, align 4, !dbg !385
  br label %error_return, !dbg !385

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %23), !dbg !385
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !385

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %32, align 4, !dbg !385
  br label %error_return, !dbg !385

propagate_error:                                  ; preds = %selected.valid
  %69 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !386
  %70 = load i32, ptr %69, align 4, !dbg !386
  %71 = icmp ult i32 %70, 32, !dbg !386
  br i1 %71, label %trace_caller1, label %trace_limit3, !dbg !386

call_success:                                     ; preds = %selected.valid
  call void @vd_gc_frame_leave(ptr %23), !dbg !386
  ret %"/@stdlib/console.void::terminal_capabilities" %62, !dbg !386

trace_caller1:                                    ; preds = %propagate_error
  %72 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !386
  %73 = getelementptr [32 x ptr], ptr %72, i32 0, i32 %70, !dbg !386
  store ptr @146, ptr %73, align 8, !dbg !386
  %74 = add i32 %70, 1, !dbg !386
  store i32 %74, ptr %69, align 4, !dbg !386
  br label %error_return2, !dbg !386

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %23), !dbg !386
  ret %"/@stdlib/console.void::terminal_capabilities" zeroinitializer, !dbg !386

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %69, align 4, !dbg !386
  br label %error_return2, !dbg !386
}

define internal %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %0, ptr %1, ptr %2, ptr %3) !dbg !387 {
block0:
  %4 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca i64, align 8
  store i64 0, ptr %7, align 8
  %8 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %8, align 8
  %9 = alloca ptr, align 8
  store ptr null, ptr %9, align 8
  %10 = alloca ptr, align 8
  store ptr null, ptr %10, align 8
  %11 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %11, align 8
  %12 = alloca i1, align 1
  store i1 false, ptr %12, align 1
  %13 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, i64 80, 1
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, ptr @gc.offsets.228, 2
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 2, 3
  %17 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 8, 1
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, ptr @gc.offsets.229, 2
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 1, 3
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 8, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.230, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 1, 3
  %25 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 80, 1
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, ptr @gc.offsets.231, 2
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 2, 3
  %29 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 8, 1
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, ptr @gc.offsets.232, 2
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 1, 3
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 8, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.233, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 1, 3
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 72, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.234, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 4, 3
  %41 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" %0, ptr %41, align 8
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %41, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 80, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.235, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 2, 3
  %46 = alloca ptr, align 8
  store ptr %1, ptr %46, align 8
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %46, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 8, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.236, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 1, 3
  %51 = alloca ptr, align 8
  store ptr %2, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 8, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.237, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 1, 3
  %56 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %56, align 8
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %56, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 80, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.238, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 2, 3
  %61 = alloca ptr, align 8
  store ptr null, ptr %61, align 8
  %62 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %61, 0
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 8, 1
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, ptr @gc.offsets.239, 2
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 1, 3
  %66 = alloca ptr, align 8
  store ptr null, ptr %66, align 8
  %67 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %66, 0
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 8, 1
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, ptr @gc.offsets.240, 2
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 1, 3
  %71 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %71, align 8
  %72 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %71, 0
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 80, 1
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, ptr @gc.offsets.241, 2
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 2, 3
  %76 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %76, align 8
  %77 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %76, 0
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 80, 1
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, ptr @gc.offsets.242, 2
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 2, 3
  %81 = alloca ptr, align 8
  store ptr null, ptr %81, align 8
  %82 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %81, 0
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 8, 1
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, ptr @gc.offsets.243, 2
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 1, 3
  %86 = alloca ptr, align 8
  store ptr null, ptr %86, align 8
  %87 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %86, 0
  %88 = insertvalue { ptr, i64, ptr, i64 } %87, i64 8, 1
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, ptr @gc.offsets.244, 2
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 1, 3
  %91 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %91, align 8
  %92 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %91, 0
  %93 = insertvalue { ptr, i64, ptr, i64 } %92, i64 80, 1
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, ptr @gc.offsets.245, 2
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 2, 3
  %96 = alloca ptr, align 8
  store ptr null, ptr %96, align 8
  %97 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %96, 0
  %98 = insertvalue { ptr, i64, ptr, i64 } %97, i64 8, 1
  %99 = insertvalue { ptr, i64, ptr, i64 } %98, ptr @gc.offsets.246, 2
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 1, 3
  %101 = alloca ptr, align 8
  store ptr null, ptr %101, align 8
  %102 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %101, 0
  %103 = insertvalue { ptr, i64, ptr, i64 } %102, i64 8, 1
  %104 = insertvalue { ptr, i64, ptr, i64 } %103, ptr @gc.offsets.247, 2
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 1, 3
  %106 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %106, align 8
  %107 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %106, 0
  %108 = insertvalue { ptr, i64, ptr, i64 } %107, i64 72, 1
  %109 = insertvalue { ptr, i64, ptr, i64 } %108, ptr @gc.offsets.248, 2
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, i64 4, 3
  %111 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %111, align 8
  %112 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %111, 0
  %113 = insertvalue { ptr, i64, ptr, i64 } %112, i64 72, 1
  %114 = insertvalue { ptr, i64, ptr, i64 } %113, ptr @gc.offsets.249, 2
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, i64 4, 3
  %116 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %116, align 8
  %117 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %116, 0
  %118 = insertvalue { ptr, i64, ptr, i64 } %117, i64 80, 1
  %119 = insertvalue { ptr, i64, ptr, i64 } %118, ptr @gc.offsets.250, 2
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, i64 4, 3
  %121 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %121, align 8
  %122 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %121, 0
  %123 = insertvalue { ptr, i64, ptr, i64 } %122, i64 80, 1
  %124 = insertvalue { ptr, i64, ptr, i64 } %123, ptr @gc.offsets.251, 2
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, i64 4, 3
  %126 = alloca [24 x { ptr, i64, ptr, i64 }], align 8
  %127 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %16, ptr %127, align 8
  %128 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %20, ptr %128, align 8
  %129 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %24, ptr %129, align 8
  %130 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %28, ptr %130, align 8
  %131 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %32, ptr %131, align 8
  %132 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %36, ptr %132, align 8
  %133 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %40, ptr %133, align 8
  %134 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %45, ptr %134, align 8
  %135 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %50, ptr %135, align 8
  %136 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %55, ptr %136, align 8
  %137 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %60, ptr %137, align 8
  %138 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %65, ptr %138, align 8
  %139 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %70, ptr %139, align 8
  %140 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %75, ptr %140, align 8
  %141 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %80, ptr %141, align 8
  %142 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %85, ptr %142, align 8
  %143 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %90, ptr %143, align 8
  %144 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %95, ptr %144, align 8
  %145 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %100, ptr %145, align 8
  %146 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %105, ptr %146, align 8
  %147 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %110, ptr %147, align 8
  %148 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %115, ptr %148, align 8
  %149 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %120, ptr %149, align 8
  %150 = getelementptr inbounds [24 x { ptr, i64, ptr, i64 }], ptr %126, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %125, ptr %150, align 8
  %151 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %151, ptr %126, i64 24)
  call void @vd_gc_poll()
  %152 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %152, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !390
  %153 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !390
  br i1 %153, label %worker.cancelled1, label %worker.continue2, !dbg !390

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !391
  %154 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !391
  br i1 %154, label %worker.cancelled5, label %worker.continue6, !dbg !391

block3:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !391
  %155 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !391
  br i1 %155, label %worker.cancelled7, label %worker.continue8, !dbg !391

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %151)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::_reply" %0, ptr %56, align 8, !dbg !392
  store %"/@stdlib/console.void::_reply" %0, ptr %4, align 8, !dbg !392
  store ptr %1, ptr %61, align 8, !dbg !393
  store ptr %1, ptr %5, align 8, !dbg !393
  store ptr %2, ptr %66, align 8, !dbg !394
  store ptr %2, ptr %6, align 8, !dbg !394
  %156 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !395
  store %"/@stdlib/console.void::_reply" %156, ptr %71, align 8, !dbg !395
  %157 = extractvalue %"/@stdlib/console.void::_reply" %156, 0, !dbg !396
  store i64 %157, ptr %7, align 8, !dbg !390
  %158 = load i64, ptr %7, align 8, !dbg !390
  %159 = icmp ne i64 %158, 0, !dbg !390
  br i1 %159, label %block1, label %block2, !dbg !390

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %151), !dbg !390
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !390

worker.continue2:                                 ; preds = %block1
  %160 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !397
  store %"/@stdlib/console.void::_reply" %160, ptr %76, align 8, !dbg !397
  store %"/@stdlib/console.void::_reply" %160, ptr %8, align 8, !dbg !397
  %161 = load ptr, ptr %5, align 8, !dbg !398
  store ptr %161, ptr %81, align 8, !dbg !398
  store ptr %161, ptr %9, align 8, !dbg !398
  %162 = load ptr, ptr %6, align 8, !dbg !399
  store ptr %162, ptr %86, align 8, !dbg !399
  store ptr %162, ptr %10, align 8, !dbg !399
  %163 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !400
  store %"/@stdlib/console.void::_reply" %163, ptr %91, align 8, !dbg !400
  %164 = load ptr, ptr %9, align 8, !dbg !400
  store ptr %164, ptr %96, align 8, !dbg !400
  %165 = load ptr, ptr %10, align 8, !dbg !400
  store ptr %165, ptr %101, align 8, !dbg !400
  %166 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %163, ptr %164, ptr %165, ptr %3), !dbg !400
  %167 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !400
  %168 = load ptr, ptr %167, align 8, !dbg !400
  %169 = icmp ne ptr %168, null, !dbg !400
  br i1 %169, label %propagate_error, label %call_success, !dbg !400

propagate_error:                                  ; preds = %worker.continue2
  %170 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !400
  %171 = load i32, ptr %170, align 4, !dbg !400
  %172 = icmp ult i32 %171, 32, !dbg !400
  br i1 %172, label %trace_caller, label %trace_limit, !dbg !400

call_success:                                     ; preds = %worker.continue2
  store %"/@stdlib/console.void::io_error" %166, ptr %106, align 8, !dbg !400
  store %"/@stdlib/console.void::io_error" %166, ptr %11, align 8, !dbg !400
  %173 = load %"/@stdlib/console.void::io_error", ptr %11, align 8, !dbg !391
  store %"/@stdlib/console.void::io_error" %173, ptr %111, align 8, !dbg !391
  %174 = insertvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, i1 false, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %173, 2, !dbg !391
  %175 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, 0, !dbg !391
  %176 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, 0, !dbg !391
  %177 = icmp eq i32 %176, 0, !dbg !391
  br i1 %177, label %validate_active_payload, label %validate_payload_done, !dbg !391

trace_caller:                                     ; preds = %propagate_error
  %178 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !400
  %179 = getelementptr [32 x ptr], ptr %178, i32 0, i32 %171, !dbg !400
  store ptr @147, ptr %179, align 8, !dbg !400
  %180 = add i32 %171, 1, !dbg !400
  store i32 %180, ptr %170, align 4, !dbg !400
  br label %error_return, !dbg !400

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %151), !dbg !400
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !400

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %170, align 4, !dbg !400
  br label %error_return, !dbg !400

validate_active_payload:                          ; preds = %call_success
  %181 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, 1, !dbg !391
  br label %validate_payload_done, !dbg !391

validate_payload_done:                            ; preds = %validate_active_payload, %call_success
  %182 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, 0, !dbg !391
  %183 = icmp eq i32 %182, 1, !dbg !391
  br i1 %183, label %validate_active_payload3, label %validate_payload_done4, !dbg !391

validate_active_payload3:                         ; preds = %validate_payload_done
  %184 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, 2, !dbg !391
  %185 = extractvalue %"/@stdlib/console.void::io_error" %184, 0, !dbg !391
  %186 = extractvalue %"/@stdlib/console.void::io_error" %184, 1, !dbg !391
  %187 = extractvalue %"/@stdlib/console.void::io_error" %184, 2, !dbg !391
  %188 = extractvalue %"/@stdlib/console.void::io_error_kind" %187, 0, !dbg !391
  %189 = extractvalue %"/@stdlib/console.void::io_error" %184, 3, !dbg !391
  %190 = extractvalue %"/@stdlib/console.void::io_error" %184, 4, !dbg !391
  %191 = extractvalue %"/@stdlib/console.void::io_error" %184, 5, !dbg !391
  %192 = extractvalue %"/@stdlib/console.void::io_error" %184, 6, !dbg !391
  %193 = extractvalue %"/@stdlib/console.void::io_error" %184, 7, !dbg !391
  %194 = extractvalue %"/@stdlib/console.void::io_error" %184, 8, !dbg !391
  br label %validate_payload_done4, !dbg !391

validate_payload_done4:                           ; preds = %validate_active_payload3, %validate_payload_done
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, ptr %116, align 8, !dbg !391
  call void @vd_gc_frame_leave(ptr %151), !dbg !391
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %174, !dbg !391

worker.cancelled5:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %151), !dbg !391
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !391

worker.continue6:                                 ; preds = %block2
  br label %block3, !dbg !391

worker.cancelled7:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %151), !dbg !391
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !391

worker.continue8:                                 ; preds = %block3
  store i1 true, ptr %12, align 1, !dbg !401
  %195 = load i1, ptr %12, align 1, !dbg !402
  %196 = insertvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, i1 %195, 1, !dbg !402
  %197 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, 0, !dbg !402
  %198 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, 0, !dbg !402
  %199 = icmp eq i32 %198, 0, !dbg !402
  br i1 %199, label %validate_active_payload9, label %validate_payload_done10, !dbg !402

validate_active_payload9:                         ; preds = %worker.continue8
  %200 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, 1, !dbg !402
  br label %validate_payload_done10, !dbg !402

validate_payload_done10:                          ; preds = %validate_active_payload9, %worker.continue8
  %201 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, 0, !dbg !402
  %202 = icmp eq i32 %201, 1, !dbg !402
  br i1 %202, label %validate_active_payload11, label %validate_payload_done12, !dbg !402

validate_active_payload11:                        ; preds = %validate_payload_done10
  %203 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, 2, !dbg !402
  %204 = extractvalue %"/@stdlib/console.void::io_error" %203, 0, !dbg !402
  %205 = extractvalue %"/@stdlib/console.void::io_error" %203, 1, !dbg !402
  %206 = extractvalue %"/@stdlib/console.void::io_error" %203, 2, !dbg !402
  %207 = extractvalue %"/@stdlib/console.void::io_error_kind" %206, 0, !dbg !402
  %208 = extractvalue %"/@stdlib/console.void::io_error" %203, 3, !dbg !402
  %209 = extractvalue %"/@stdlib/console.void::io_error" %203, 4, !dbg !402
  %210 = extractvalue %"/@stdlib/console.void::io_error" %203, 5, !dbg !402
  %211 = extractvalue %"/@stdlib/console.void::io_error" %203, 6, !dbg !402
  %212 = extractvalue %"/@stdlib/console.void::io_error" %203, 7, !dbg !402
  %213 = extractvalue %"/@stdlib/console.void::io_error" %203, 8, !dbg !402
  br label %validate_payload_done12, !dbg !402

validate_payload_done12:                          ; preds = %validate_active_payload11, %validate_payload_done10
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, ptr %121, align 8, !dbg !402
  call void @vd_gc_frame_leave(ptr %151), !dbg !402
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %196, !dbg !402
}

define %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a73697a65__v1(ptr %0, ptr %1) !dbg !403 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %9, align 8
  %10 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %10, align 8
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca i64, align 8
  store i64 0, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = alloca %"/@stdlib/console.void::terminal_size", align 8
  store %"/@stdlib/console.void::terminal_size" zeroinitializer, ptr %15, align 8
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 80, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.252, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 2, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 80, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.253, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 2, 3
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.254, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 8, 1
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, ptr @gc.offsets.255, 2
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 1, 3
  %32 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, i64 72, 1
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, ptr @gc.offsets.256, 2
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 4, 3
  %36 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %36, align 8
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %36, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 80, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.257, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 2, 3
  %41 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %41, align 8
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %41, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 80, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.258, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 2, 3
  %46 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %46, align 8
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %46, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 80, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.259, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 2, 3
  %51 = alloca ptr, align 8
  store ptr null, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 8, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.260, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 1, 3
  %56 = alloca ptr, align 8
  store ptr null, ptr %56, align 8
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %56, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 8, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.261, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 1, 3
  %61 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %61, align 8
  %62 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %61, 0
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 80, 1
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, ptr @gc.offsets.262, 2
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 2, 3
  %66 = alloca ptr, align 8
  store ptr null, ptr %66, align 8
  %67 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %66, 0
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 8, 1
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, ptr @gc.offsets.263, 2
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 1, 3
  %71 = alloca ptr, align 8
  store ptr null, ptr %71, align 8
  %72 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %71, 0
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 8, 1
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, ptr @gc.offsets.264, 2
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 1, 3
  %76 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %76, align 8
  %77 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %76, 0
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 72, 1
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, ptr @gc.offsets.265, 2
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 4, 3
  %81 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %81, align 8
  %82 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %81, 0
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 72, 1
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, ptr @gc.offsets.266, 2
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 4, 3
  %86 = alloca %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %86, align 8
  %87 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %86, 0
  %88 = insertvalue { ptr, i64, ptr, i64 } %87, i64 96, 1
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, ptr @gc.offsets.267, 2
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 4, 3
  %91 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %91, align 8
  %92 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %91, 0
  %93 = insertvalue { ptr, i64, ptr, i64 } %92, i64 80, 1
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, ptr @gc.offsets.268, 2
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 2, 3
  %96 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %96, align 8
  %97 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %96, 0
  %98 = insertvalue { ptr, i64, ptr, i64 } %97, i64 80, 1
  %99 = insertvalue { ptr, i64, ptr, i64 } %98, ptr @gc.offsets.269, 2
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 2, 3
  %101 = alloca %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %101, align 8
  %102 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %101, 0
  %103 = insertvalue { ptr, i64, ptr, i64 } %102, i64 96, 1
  %104 = insertvalue { ptr, i64, ptr, i64 } %103, ptr @gc.offsets.270, 2
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 4, 3
  %106 = alloca [19 x { ptr, i64, ptr, i64 }], align 8
  %107 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %19, ptr %107, align 8
  %108 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %23, ptr %108, align 8
  %109 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %27, ptr %109, align 8
  %110 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %31, ptr %110, align 8
  %111 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %35, ptr %111, align 8
  %112 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %40, ptr %112, align 8
  %113 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %45, ptr %113, align 8
  %114 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %50, ptr %114, align 8
  %115 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %55, ptr %115, align 8
  %116 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %60, ptr %116, align 8
  %117 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %65, ptr %117, align 8
  %118 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %70, ptr %118, align 8
  %119 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %75, ptr %119, align 8
  %120 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %80, ptr %120, align 8
  %121 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %85, ptr %121, align 8
  %122 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %90, ptr %122, align 8
  %123 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %95, ptr %123, align 8
  %124 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %100, ptr %124, align 8
  %125 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %105, ptr %125, align 8
  %126 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %126, ptr %106, i64 19)
  call void @vd_gc_poll()
  %127 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %127, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !413
  %128 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !413
  br i1 %128, label %worker.cancelled1, label %worker.continue2, !dbg !413

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !414
  %129 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !414
  br i1 %129, label %worker.cancelled13, label %worker.continue14, !dbg !414

block3:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !414
  %130 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !414
  br i1 %130, label %worker.cancelled15, label %worker.continue16, !dbg !414

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %126)
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %131 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !415
  store %"/@stdlib/console.void::output" %131, ptr %4, align 8, !dbg !415
  %132 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !416
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %36, align 8, !dbg !416
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !416
  %133 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 6, !dbg !416
  %134 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 7, !dbg !416
  %135 = extractvalue %"/@stdlib/console.void::output" %132, 0, !dbg !416
  call void @vd_console_v2(ptr %133, ptr %134, ptr %2, i32 9, i64 %135, ptr null, i64 0, i64 -1, ptr %1), !dbg !416
  %136 = load ptr, ptr %1, align 8, !dbg !416
  %137 = icmp ne ptr %136, null, !dbg !416
  br i1 %137, label %selected.failure, label %selected.valid, !dbg !416

selected.failure:                                 ; preds = %worker.continue
  %138 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !416
  %139 = load i32, ptr %138, align 4, !dbg !416
  %140 = icmp ult i32 %139, 32, !dbg !416
  br i1 %140, label %trace_caller, label %trace_limit, !dbg !416

selected.valid:                                   ; preds = %worker.continue
  %141 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !416
  %142 = load i64, ptr %141, align 8, !dbg !416
  %143 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 0, !dbg !416
  store i64 %142, ptr %143, align 8, !dbg !416
  %144 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !416
  %145 = load i64, ptr %144, align 8, !dbg !416
  %146 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 1, !dbg !416
  store i64 %145, ptr %146, align 8, !dbg !416
  %147 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !416
  %148 = load i64, ptr %147, align 8, !dbg !416
  %149 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 2, !dbg !416
  store i64 %148, ptr %149, align 8, !dbg !416
  %150 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !416
  %151 = load i64, ptr %150, align 8, !dbg !416
  %152 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 3, !dbg !416
  store i64 %151, ptr %152, align 8, !dbg !416
  %153 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !416
  %154 = load i64, ptr %153, align 8, !dbg !416
  %155 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 4, !dbg !416
  store i64 %154, ptr %155, align 8, !dbg !416
  %156 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !416
  %157 = load i64, ptr %156, align 8, !dbg !416
  %158 = trunc i64 %157 to i1, !dbg !416
  %159 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 5, !dbg !416
  store i1 %158, ptr %159, align 1, !dbg !416
  %160 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !416
  %161 = load i64, ptr %160, align 8, !dbg !416
  %162 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 8, !dbg !416
  store i64 %161, ptr %162, align 8, !dbg !416
  %163 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !416
  %164 = load i64, ptr %163, align 8, !dbg !416
  %165 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 9, !dbg !416
  store i64 %164, ptr %165, align 8, !dbg !416
  %166 = load %"/@stdlib/console.void::_reply", ptr %36, align 8, !dbg !416
  store %"/@stdlib/console.void::_reply" %166, ptr %36, align 8, !dbg !416
  store %"/@stdlib/console.void::_reply" %166, ptr %3, align 8, !dbg !417
  %167 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !418
  store %"/@stdlib/console.void::_reply" %167, ptr %41, align 8, !dbg !418
  %168 = extractvalue %"/@stdlib/console.void::_reply" %167, 0, !dbg !419
  store i64 %168, ptr %5, align 8, !dbg !413
  %169 = load i64, ptr %5, align 8, !dbg !413
  %170 = icmp ne i64 %169, 0, !dbg !413
  br i1 %170, label %block1, label %block2, !dbg !413

trace_caller:                                     ; preds = %selected.failure
  %171 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !416
  %172 = getelementptr [32 x ptr], ptr %171, i32 0, i32 %139, !dbg !416
  store ptr @148, ptr %172, align 8, !dbg !416
  %173 = add i32 %139, 1, !dbg !416
  store i32 %173, ptr %138, align 4, !dbg !416
  br label %error_return, !dbg !416

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %126), !dbg !416
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !416

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %138, align 4, !dbg !416
  br label %error_return, !dbg !416

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %126), !dbg !413
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !413

worker.continue2:                                 ; preds = %block1
  %174 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !420
  store %"/@stdlib/console.void::_reply" %174, ptr %46, align 8, !dbg !420
  store %"/@stdlib/console.void::_reply" %174, ptr %6, align 8, !dbg !420
  call void @vd_string_literal(ptr %51, ptr @149, i64 4, ptr %1), !dbg !421
  %175 = load ptr, ptr %51, align 8, !dbg !421
  %176 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !421
  %177 = load ptr, ptr %176, align 8, !dbg !421
  %178 = icmp ne ptr %177, null, !dbg !421
  br i1 %178, label %numeric_error, label %numeric_valid, !dbg !421

numeric_error:                                    ; preds = %worker.continue2
  %179 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !421
  store ptr @150, ptr %179, align 8, !dbg !421
  call void @vd_gc_frame_leave(ptr %126), !dbg !421
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !421

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %175, ptr %51, align 8, !dbg !421
  store ptr %175, ptr %7, align 8, !dbg !421
  %180 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !422
  store %"/@stdlib/console.void::output" %180, ptr %9, align 8, !dbg !422
  %181 = load %"/@stdlib/console.void::output", ptr %9, align 8, !dbg !423
  %182 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %181, ptr %1), !dbg !423
  %183 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !423
  %184 = load ptr, ptr %183, align 8, !dbg !423
  %185 = icmp ne ptr %184, null, !dbg !423
  br i1 %185, label %propagate_error, label %call_success, !dbg !423

propagate_error:                                  ; preds = %numeric_valid
  %186 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !423
  %187 = load i32, ptr %186, align 4, !dbg !423
  %188 = icmp ult i32 %187, 32, !dbg !423
  br i1 %188, label %trace_caller3, label %trace_limit5, !dbg !423

call_success:                                     ; preds = %numeric_valid
  store ptr %182, ptr %56, align 8, !dbg !423
  store ptr %182, ptr %8, align 8, !dbg !423
  %189 = load %"/@stdlib/console.void::_reply", ptr %6, align 8, !dbg !424
  store %"/@stdlib/console.void::_reply" %189, ptr %61, align 8, !dbg !424
  %190 = load ptr, ptr %7, align 8, !dbg !424
  store ptr %190, ptr %66, align 8, !dbg !424
  %191 = load ptr, ptr %8, align 8, !dbg !424
  store ptr %191, ptr %71, align 8, !dbg !424
  %192 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %189, ptr %190, ptr %191, ptr %1), !dbg !424
  %193 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !424
  %194 = load ptr, ptr %193, align 8, !dbg !424
  %195 = icmp ne ptr %194, null, !dbg !424
  br i1 %195, label %propagate_error6, label %call_success7, !dbg !424

trace_caller3:                                    ; preds = %propagate_error
  %196 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !423
  %197 = getelementptr [32 x ptr], ptr %196, i32 0, i32 %187, !dbg !423
  store ptr @151, ptr %197, align 8, !dbg !423
  %198 = add i32 %187, 1, !dbg !423
  store i32 %198, ptr %186, align 4, !dbg !423
  br label %error_return4, !dbg !423

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %126), !dbg !423
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !423

trace_limit5:                                     ; preds = %propagate_error
  store i32 33, ptr %186, align 4, !dbg !423
  br label %error_return4, !dbg !423

propagate_error6:                                 ; preds = %call_success
  %199 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !424
  %200 = load i32, ptr %199, align 4, !dbg !424
  %201 = icmp ult i32 %200, 32, !dbg !424
  br i1 %201, label %trace_caller8, label %trace_limit10, !dbg !424

call_success7:                                    ; preds = %call_success
  store %"/@stdlib/console.void::io_error" %192, ptr %76, align 8, !dbg !424
  store %"/@stdlib/console.void::io_error" %192, ptr %10, align 8, !dbg !424
  %202 = load %"/@stdlib/console.void::io_error", ptr %10, align 8, !dbg !414
  store %"/@stdlib/console.void::io_error" %202, ptr %81, align 8, !dbg !414
  %203 = insertvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, %"/@stdlib/console.void::terminal_size" zeroinitializer, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %202, 2, !dbg !414
  %204 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 0, !dbg !414
  %205 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 0, !dbg !414
  %206 = icmp eq i32 %205, 0, !dbg !414
  br i1 %206, label %validate_active_payload, label %validate_payload_done, !dbg !414

trace_caller8:                                    ; preds = %propagate_error6
  %207 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !424
  %208 = getelementptr [32 x ptr], ptr %207, i32 0, i32 %200, !dbg !424
  store ptr @152, ptr %208, align 8, !dbg !424
  %209 = add i32 %200, 1, !dbg !424
  store i32 %209, ptr %199, align 4, !dbg !424
  br label %error_return9, !dbg !424

error_return9:                                    ; preds = %trace_caller8, %trace_limit10
  call void @vd_gc_frame_leave(ptr %126), !dbg !424
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !424

trace_limit10:                                    ; preds = %propagate_error6
  store i32 33, ptr %199, align 4, !dbg !424
  br label %error_return9, !dbg !424

validate_active_payload:                          ; preds = %call_success7
  %210 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 1, !dbg !414
  %211 = extractvalue %"/@stdlib/console.void::terminal_size" %210, 0, !dbg !414
  %212 = extractvalue %"/@stdlib/console.void::terminal_size" %210, 1, !dbg !414
  br label %validate_payload_done, !dbg !414

validate_payload_done:                            ; preds = %validate_active_payload, %call_success7
  %213 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 0, !dbg !414
  %214 = icmp eq i32 %213, 1, !dbg !414
  br i1 %214, label %validate_active_payload11, label %validate_payload_done12, !dbg !414

validate_active_payload11:                        ; preds = %validate_payload_done
  %215 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 2, !dbg !414
  %216 = extractvalue %"/@stdlib/console.void::io_error" %215, 0, !dbg !414
  %217 = extractvalue %"/@stdlib/console.void::io_error" %215, 1, !dbg !414
  %218 = extractvalue %"/@stdlib/console.void::io_error" %215, 2, !dbg !414
  %219 = extractvalue %"/@stdlib/console.void::io_error_kind" %218, 0, !dbg !414
  %220 = extractvalue %"/@stdlib/console.void::io_error" %215, 3, !dbg !414
  %221 = extractvalue %"/@stdlib/console.void::io_error" %215, 4, !dbg !414
  %222 = extractvalue %"/@stdlib/console.void::io_error" %215, 5, !dbg !414
  %223 = extractvalue %"/@stdlib/console.void::io_error" %215, 6, !dbg !414
  %224 = extractvalue %"/@stdlib/console.void::io_error" %215, 7, !dbg !414
  %225 = extractvalue %"/@stdlib/console.void::io_error" %215, 8, !dbg !414
  br label %validate_payload_done12, !dbg !414

validate_payload_done12:                          ; preds = %validate_active_payload11, %validate_payload_done
  store %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, ptr %86, align 8, !dbg !414
  call void @vd_gc_frame_leave(ptr %126), !dbg !414
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, !dbg !414

worker.cancelled13:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %126), !dbg !414
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !414

worker.continue14:                                ; preds = %block2
  br label %block3, !dbg !414

worker.cancelled15:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %126), !dbg !414
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !414

worker.continue16:                                ; preds = %block3
  %226 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !425
  store %"/@stdlib/console.void::_reply" %226, ptr %91, align 8, !dbg !425
  %227 = extractvalue %"/@stdlib/console.void::_reply" %226, 8, !dbg !426
  store i64 %227, ptr %11, align 8, !dbg !426
  %228 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !427
  store %"/@stdlib/console.void::_reply" %228, ptr %96, align 8, !dbg !427
  %229 = extractvalue %"/@stdlib/console.void::_reply" %228, 9, !dbg !428
  store i64 %229, ptr %12, align 8, !dbg !428
  %230 = load i64, ptr %11, align 8, !dbg !429
  store i64 %230, ptr %13, align 8, !dbg !429
  %231 = load i64, ptr %12, align 8, !dbg !429
  store i64 %231, ptr %14, align 8, !dbg !429
  %232 = load i64, ptr %13, align 8, !dbg !429
  %233 = load i64, ptr %14, align 8, !dbg !429
  %234 = insertvalue %"/@stdlib/console.void::terminal_size" zeroinitializer, i64 %232, 0, !dbg !429
  %235 = insertvalue %"/@stdlib/console.void::terminal_size" %234, i64 %233, 1, !dbg !429
  store %"/@stdlib/console.void::terminal_size" %235, ptr %15, align 8, !dbg !429
  %236 = load %"/@stdlib/console.void::terminal_size", ptr %15, align 8, !dbg !430
  %237 = insertvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::terminal_size" %236, 1, !dbg !430
  %238 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 0, !dbg !430
  %239 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 0, !dbg !430
  %240 = icmp eq i32 %239, 0, !dbg !430
  br i1 %240, label %validate_active_payload17, label %validate_payload_done18, !dbg !430

validate_active_payload17:                        ; preds = %worker.continue16
  %241 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 1, !dbg !430
  %242 = extractvalue %"/@stdlib/console.void::terminal_size" %241, 0, !dbg !430
  %243 = extractvalue %"/@stdlib/console.void::terminal_size" %241, 1, !dbg !430
  br label %validate_payload_done18, !dbg !430

validate_payload_done18:                          ; preds = %validate_active_payload17, %worker.continue16
  %244 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 0, !dbg !430
  %245 = icmp eq i32 %244, 1, !dbg !430
  br i1 %245, label %validate_active_payload19, label %validate_payload_done20, !dbg !430

validate_active_payload19:                        ; preds = %validate_payload_done18
  %246 = extractvalue %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 2, !dbg !430
  %247 = extractvalue %"/@stdlib/console.void::io_error" %246, 0, !dbg !430
  %248 = extractvalue %"/@stdlib/console.void::io_error" %246, 1, !dbg !430
  %249 = extractvalue %"/@stdlib/console.void::io_error" %246, 2, !dbg !430
  %250 = extractvalue %"/@stdlib/console.void::io_error_kind" %249, 0, !dbg !430
  %251 = extractvalue %"/@stdlib/console.void::io_error" %246, 3, !dbg !430
  %252 = extractvalue %"/@stdlib/console.void::io_error" %246, 4, !dbg !430
  %253 = extractvalue %"/@stdlib/console.void::io_error" %246, 5, !dbg !430
  %254 = extractvalue %"/@stdlib/console.void::io_error" %246, 6, !dbg !430
  %255 = extractvalue %"/@stdlib/console.void::io_error" %246, 7, !dbg !430
  %256 = extractvalue %"/@stdlib/console.void::io_error" %246, 8, !dbg !430
  br label %validate_payload_done20, !dbg !430

validate_payload_done20:                          ; preds = %validate_active_payload19, %validate_payload_done18
  store %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, ptr %101, align 8, !dbg !430
  call void @vd_gc_frame_leave(ptr %126), !dbg !430
  ret %"$result:$array:39:12:/@stdlib/console.void::terminal_size:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, !dbg !430
}

define %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a637572736f725f706f736974696f6e__v1(ptr %0, ptr %1) !dbg !431 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %9, align 8
  %10 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %10, align 8
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca i64, align 8
  store i64 0, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = alloca %"/@stdlib/console.void::terminal_position", align 8
  store %"/@stdlib/console.void::terminal_position" zeroinitializer, ptr %15, align 8
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 80, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.271, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 2, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 80, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.272, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 2, 3
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.273, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 8, 1
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, ptr @gc.offsets.274, 2
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 1, 3
  %32 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, i64 72, 1
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, ptr @gc.offsets.275, 2
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 4, 3
  %36 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %36, align 8
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %36, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 80, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.276, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 2, 3
  %41 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %41, align 8
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %41, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 80, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.277, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 2, 3
  %46 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %46, align 8
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %46, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 80, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.278, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 2, 3
  %51 = alloca ptr, align 8
  store ptr null, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 8, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.279, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 1, 3
  %56 = alloca ptr, align 8
  store ptr null, ptr %56, align 8
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %56, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 8, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.280, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 1, 3
  %61 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %61, align 8
  %62 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %61, 0
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 80, 1
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, ptr @gc.offsets.281, 2
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 2, 3
  %66 = alloca ptr, align 8
  store ptr null, ptr %66, align 8
  %67 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %66, 0
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 8, 1
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, ptr @gc.offsets.282, 2
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 1, 3
  %71 = alloca ptr, align 8
  store ptr null, ptr %71, align 8
  %72 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %71, 0
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 8, 1
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, ptr @gc.offsets.283, 2
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 1, 3
  %76 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %76, align 8
  %77 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %76, 0
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 72, 1
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, ptr @gc.offsets.284, 2
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 4, 3
  %81 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %81, align 8
  %82 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %81, 0
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 72, 1
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, ptr @gc.offsets.285, 2
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 4, 3
  %86 = alloca %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %86, align 8
  %87 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %86, 0
  %88 = insertvalue { ptr, i64, ptr, i64 } %87, i64 96, 1
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, ptr @gc.offsets.286, 2
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 4, 3
  %91 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %91, align 8
  %92 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %91, 0
  %93 = insertvalue { ptr, i64, ptr, i64 } %92, i64 80, 1
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, ptr @gc.offsets.287, 2
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 2, 3
  %96 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %96, align 8
  %97 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %96, 0
  %98 = insertvalue { ptr, i64, ptr, i64 } %97, i64 80, 1
  %99 = insertvalue { ptr, i64, ptr, i64 } %98, ptr @gc.offsets.288, 2
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 2, 3
  %101 = alloca %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %101, align 8
  %102 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %101, 0
  %103 = insertvalue { ptr, i64, ptr, i64 } %102, i64 96, 1
  %104 = insertvalue { ptr, i64, ptr, i64 } %103, ptr @gc.offsets.289, 2
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 4, 3
  %106 = alloca [19 x { ptr, i64, ptr, i64 }], align 8
  %107 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %19, ptr %107, align 8
  %108 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %23, ptr %108, align 8
  %109 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %27, ptr %109, align 8
  %110 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %31, ptr %110, align 8
  %111 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %35, ptr %111, align 8
  %112 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %40, ptr %112, align 8
  %113 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %45, ptr %113, align 8
  %114 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %50, ptr %114, align 8
  %115 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %55, ptr %115, align 8
  %116 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %60, ptr %116, align 8
  %117 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %65, ptr %117, align 8
  %118 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %70, ptr %118, align 8
  %119 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %75, ptr %119, align 8
  %120 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %80, ptr %120, align 8
  %121 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %85, ptr %121, align 8
  %122 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %90, ptr %122, align 8
  %123 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %95, ptr %123, align 8
  %124 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %100, ptr %124, align 8
  %125 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %106, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %105, ptr %125, align 8
  %126 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %126, ptr %106, i64 19)
  call void @vd_gc_poll()
  %127 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %127, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !441
  %128 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !441
  br i1 %128, label %worker.cancelled1, label %worker.continue2, !dbg !441

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !442
  %129 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !442
  br i1 %129, label %worker.cancelled13, label %worker.continue14, !dbg !442

block3:                                           ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !442
  %130 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !442
  br i1 %130, label %worker.cancelled15, label %worker.continue16, !dbg !442

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %126)
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %131 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !443
  store %"/@stdlib/console.void::output" %131, ptr %4, align 8, !dbg !443
  %132 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !444
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %36, align 8, !dbg !444
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !444
  %133 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 6, !dbg !444
  %134 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 7, !dbg !444
  %135 = extractvalue %"/@stdlib/console.void::output" %132, 0, !dbg !444
  call void @vd_console_v2(ptr %133, ptr %134, ptr %2, i32 10, i64 %135, ptr null, i64 0, i64 -1, ptr %1), !dbg !444
  %136 = load ptr, ptr %1, align 8, !dbg !444
  %137 = icmp ne ptr %136, null, !dbg !444
  br i1 %137, label %selected.failure, label %selected.valid, !dbg !444

selected.failure:                                 ; preds = %worker.continue
  %138 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !444
  %139 = load i32, ptr %138, align 4, !dbg !444
  %140 = icmp ult i32 %139, 32, !dbg !444
  br i1 %140, label %trace_caller, label %trace_limit, !dbg !444

selected.valid:                                   ; preds = %worker.continue
  %141 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !444
  %142 = load i64, ptr %141, align 8, !dbg !444
  %143 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 0, !dbg !444
  store i64 %142, ptr %143, align 8, !dbg !444
  %144 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !444
  %145 = load i64, ptr %144, align 8, !dbg !444
  %146 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 1, !dbg !444
  store i64 %145, ptr %146, align 8, !dbg !444
  %147 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !444
  %148 = load i64, ptr %147, align 8, !dbg !444
  %149 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 2, !dbg !444
  store i64 %148, ptr %149, align 8, !dbg !444
  %150 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !444
  %151 = load i64, ptr %150, align 8, !dbg !444
  %152 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 3, !dbg !444
  store i64 %151, ptr %152, align 8, !dbg !444
  %153 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !444
  %154 = load i64, ptr %153, align 8, !dbg !444
  %155 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 4, !dbg !444
  store i64 %154, ptr %155, align 8, !dbg !444
  %156 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !444
  %157 = load i64, ptr %156, align 8, !dbg !444
  %158 = trunc i64 %157 to i1, !dbg !444
  %159 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 5, !dbg !444
  store i1 %158, ptr %159, align 1, !dbg !444
  %160 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !444
  %161 = load i64, ptr %160, align 8, !dbg !444
  %162 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 8, !dbg !444
  store i64 %161, ptr %162, align 8, !dbg !444
  %163 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !444
  %164 = load i64, ptr %163, align 8, !dbg !444
  %165 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %36, i32 0, i32 9, !dbg !444
  store i64 %164, ptr %165, align 8, !dbg !444
  %166 = load %"/@stdlib/console.void::_reply", ptr %36, align 8, !dbg !444
  store %"/@stdlib/console.void::_reply" %166, ptr %36, align 8, !dbg !444
  store %"/@stdlib/console.void::_reply" %166, ptr %3, align 8, !dbg !445
  %167 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !446
  store %"/@stdlib/console.void::_reply" %167, ptr %41, align 8, !dbg !446
  %168 = extractvalue %"/@stdlib/console.void::_reply" %167, 0, !dbg !447
  store i64 %168, ptr %5, align 8, !dbg !441
  %169 = load i64, ptr %5, align 8, !dbg !441
  %170 = icmp ne i64 %169, 0, !dbg !441
  br i1 %170, label %block1, label %block2, !dbg !441

trace_caller:                                     ; preds = %selected.failure
  %171 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !444
  %172 = getelementptr [32 x ptr], ptr %171, i32 0, i32 %139, !dbg !444
  store ptr @153, ptr %172, align 8, !dbg !444
  %173 = add i32 %139, 1, !dbg !444
  store i32 %173, ptr %138, align 4, !dbg !444
  br label %error_return, !dbg !444

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %126), !dbg !444
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !444

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %138, align 4, !dbg !444
  br label %error_return, !dbg !444

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %126), !dbg !441
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !441

worker.continue2:                                 ; preds = %block1
  %174 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !448
  store %"/@stdlib/console.void::_reply" %174, ptr %46, align 8, !dbg !448
  store %"/@stdlib/console.void::_reply" %174, ptr %6, align 8, !dbg !448
  call void @vd_string_literal(ptr %51, ptr @154, i64 15, ptr %1), !dbg !449
  %175 = load ptr, ptr %51, align 8, !dbg !449
  %176 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !449
  %177 = load ptr, ptr %176, align 8, !dbg !449
  %178 = icmp ne ptr %177, null, !dbg !449
  br i1 %178, label %numeric_error, label %numeric_valid, !dbg !449

numeric_error:                                    ; preds = %worker.continue2
  %179 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !449
  store ptr @155, ptr %179, align 8, !dbg !449
  call void @vd_gc_frame_leave(ptr %126), !dbg !449
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !449

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %175, ptr %51, align 8, !dbg !449
  store ptr %175, ptr %7, align 8, !dbg !449
  %180 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !450
  store %"/@stdlib/console.void::output" %180, ptr %9, align 8, !dbg !450
  %181 = load %"/@stdlib/console.void::output", ptr %9, align 8, !dbg !451
  %182 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %181, ptr %1), !dbg !451
  %183 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !451
  %184 = load ptr, ptr %183, align 8, !dbg !451
  %185 = icmp ne ptr %184, null, !dbg !451
  br i1 %185, label %propagate_error, label %call_success, !dbg !451

propagate_error:                                  ; preds = %numeric_valid
  %186 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !451
  %187 = load i32, ptr %186, align 4, !dbg !451
  %188 = icmp ult i32 %187, 32, !dbg !451
  br i1 %188, label %trace_caller3, label %trace_limit5, !dbg !451

call_success:                                     ; preds = %numeric_valid
  store ptr %182, ptr %56, align 8, !dbg !451
  store ptr %182, ptr %8, align 8, !dbg !451
  %189 = load %"/@stdlib/console.void::_reply", ptr %6, align 8, !dbg !452
  store %"/@stdlib/console.void::_reply" %189, ptr %61, align 8, !dbg !452
  %190 = load ptr, ptr %7, align 8, !dbg !452
  store ptr %190, ptr %66, align 8, !dbg !452
  %191 = load ptr, ptr %8, align 8, !dbg !452
  store ptr %191, ptr %71, align 8, !dbg !452
  %192 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %189, ptr %190, ptr %191, ptr %1), !dbg !452
  %193 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !452
  %194 = load ptr, ptr %193, align 8, !dbg !452
  %195 = icmp ne ptr %194, null, !dbg !452
  br i1 %195, label %propagate_error6, label %call_success7, !dbg !452

trace_caller3:                                    ; preds = %propagate_error
  %196 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !451
  %197 = getelementptr [32 x ptr], ptr %196, i32 0, i32 %187, !dbg !451
  store ptr @156, ptr %197, align 8, !dbg !451
  %198 = add i32 %187, 1, !dbg !451
  store i32 %198, ptr %186, align 4, !dbg !451
  br label %error_return4, !dbg !451

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %126), !dbg !451
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !451

trace_limit5:                                     ; preds = %propagate_error
  store i32 33, ptr %186, align 4, !dbg !451
  br label %error_return4, !dbg !451

propagate_error6:                                 ; preds = %call_success
  %199 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !452
  %200 = load i32, ptr %199, align 4, !dbg !452
  %201 = icmp ult i32 %200, 32, !dbg !452
  br i1 %201, label %trace_caller8, label %trace_limit10, !dbg !452

call_success7:                                    ; preds = %call_success
  store %"/@stdlib/console.void::io_error" %192, ptr %76, align 8, !dbg !452
  store %"/@stdlib/console.void::io_error" %192, ptr %10, align 8, !dbg !452
  %202 = load %"/@stdlib/console.void::io_error", ptr %10, align 8, !dbg !442
  store %"/@stdlib/console.void::io_error" %202, ptr %81, align 8, !dbg !442
  %203 = insertvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, %"/@stdlib/console.void::terminal_position" zeroinitializer, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %202, 2, !dbg !442
  %204 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 0, !dbg !442
  %205 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 0, !dbg !442
  %206 = icmp eq i32 %205, 0, !dbg !442
  br i1 %206, label %validate_active_payload, label %validate_payload_done, !dbg !442

trace_caller8:                                    ; preds = %propagate_error6
  %207 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !452
  %208 = getelementptr [32 x ptr], ptr %207, i32 0, i32 %200, !dbg !452
  store ptr @157, ptr %208, align 8, !dbg !452
  %209 = add i32 %200, 1, !dbg !452
  store i32 %209, ptr %199, align 4, !dbg !452
  br label %error_return9, !dbg !452

error_return9:                                    ; preds = %trace_caller8, %trace_limit10
  call void @vd_gc_frame_leave(ptr %126), !dbg !452
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !452

trace_limit10:                                    ; preds = %propagate_error6
  store i32 33, ptr %199, align 4, !dbg !452
  br label %error_return9, !dbg !452

validate_active_payload:                          ; preds = %call_success7
  %210 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 1, !dbg !442
  %211 = extractvalue %"/@stdlib/console.void::terminal_position" %210, 0, !dbg !442
  %212 = extractvalue %"/@stdlib/console.void::terminal_position" %210, 1, !dbg !442
  br label %validate_payload_done, !dbg !442

validate_payload_done:                            ; preds = %validate_active_payload, %call_success7
  %213 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 0, !dbg !442
  %214 = icmp eq i32 %213, 1, !dbg !442
  br i1 %214, label %validate_active_payload11, label %validate_payload_done12, !dbg !442

validate_active_payload11:                        ; preds = %validate_payload_done
  %215 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, 2, !dbg !442
  %216 = extractvalue %"/@stdlib/console.void::io_error" %215, 0, !dbg !442
  %217 = extractvalue %"/@stdlib/console.void::io_error" %215, 1, !dbg !442
  %218 = extractvalue %"/@stdlib/console.void::io_error" %215, 2, !dbg !442
  %219 = extractvalue %"/@stdlib/console.void::io_error_kind" %218, 0, !dbg !442
  %220 = extractvalue %"/@stdlib/console.void::io_error" %215, 3, !dbg !442
  %221 = extractvalue %"/@stdlib/console.void::io_error" %215, 4, !dbg !442
  %222 = extractvalue %"/@stdlib/console.void::io_error" %215, 5, !dbg !442
  %223 = extractvalue %"/@stdlib/console.void::io_error" %215, 6, !dbg !442
  %224 = extractvalue %"/@stdlib/console.void::io_error" %215, 7, !dbg !442
  %225 = extractvalue %"/@stdlib/console.void::io_error" %215, 8, !dbg !442
  br label %validate_payload_done12, !dbg !442

validate_payload_done12:                          ; preds = %validate_active_payload11, %validate_payload_done
  store %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, ptr %86, align 8, !dbg !442
  call void @vd_gc_frame_leave(ptr %126), !dbg !442
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %203, !dbg !442

worker.cancelled13:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %126), !dbg !442
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !442

worker.continue14:                                ; preds = %block2
  br label %block3, !dbg !442

worker.cancelled15:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %126), !dbg !442
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !442

worker.continue16:                                ; preds = %block3
  %226 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !453
  store %"/@stdlib/console.void::_reply" %226, ptr %91, align 8, !dbg !453
  %227 = extractvalue %"/@stdlib/console.void::_reply" %226, 8, !dbg !454
  store i64 %227, ptr %11, align 8, !dbg !454
  %228 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !455
  store %"/@stdlib/console.void::_reply" %228, ptr %96, align 8, !dbg !455
  %229 = extractvalue %"/@stdlib/console.void::_reply" %228, 9, !dbg !456
  store i64 %229, ptr %12, align 8, !dbg !456
  %230 = load i64, ptr %11, align 8, !dbg !457
  store i64 %230, ptr %13, align 8, !dbg !457
  %231 = load i64, ptr %12, align 8, !dbg !457
  store i64 %231, ptr %14, align 8, !dbg !457
  %232 = load i64, ptr %13, align 8, !dbg !457
  %233 = load i64, ptr %14, align 8, !dbg !457
  %234 = insertvalue %"/@stdlib/console.void::terminal_position" zeroinitializer, i64 %232, 0, !dbg !457
  %235 = insertvalue %"/@stdlib/console.void::terminal_position" %234, i64 %233, 1, !dbg !457
  store %"/@stdlib/console.void::terminal_position" %235, ptr %15, align 8, !dbg !457
  %236 = load %"/@stdlib/console.void::terminal_position", ptr %15, align 8, !dbg !458
  %237 = insertvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::terminal_position" %236, 1, !dbg !458
  %238 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 0, !dbg !458
  %239 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 0, !dbg !458
  %240 = icmp eq i32 %239, 0, !dbg !458
  br i1 %240, label %validate_active_payload17, label %validate_payload_done18, !dbg !458

validate_active_payload17:                        ; preds = %worker.continue16
  %241 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 1, !dbg !458
  %242 = extractvalue %"/@stdlib/console.void::terminal_position" %241, 0, !dbg !458
  %243 = extractvalue %"/@stdlib/console.void::terminal_position" %241, 1, !dbg !458
  br label %validate_payload_done18, !dbg !458

validate_payload_done18:                          ; preds = %validate_active_payload17, %worker.continue16
  %244 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 0, !dbg !458
  %245 = icmp eq i32 %244, 1, !dbg !458
  br i1 %245, label %validate_active_payload19, label %validate_payload_done20, !dbg !458

validate_active_payload19:                        ; preds = %validate_payload_done18
  %246 = extractvalue %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, 2, !dbg !458
  %247 = extractvalue %"/@stdlib/console.void::io_error" %246, 0, !dbg !458
  %248 = extractvalue %"/@stdlib/console.void::io_error" %246, 1, !dbg !458
  %249 = extractvalue %"/@stdlib/console.void::io_error" %246, 2, !dbg !458
  %250 = extractvalue %"/@stdlib/console.void::io_error_kind" %249, 0, !dbg !458
  %251 = extractvalue %"/@stdlib/console.void::io_error" %246, 3, !dbg !458
  %252 = extractvalue %"/@stdlib/console.void::io_error" %246, 4, !dbg !458
  %253 = extractvalue %"/@stdlib/console.void::io_error" %246, 5, !dbg !458
  %254 = extractvalue %"/@stdlib/console.void::io_error" %246, 6, !dbg !458
  %255 = extractvalue %"/@stdlib/console.void::io_error" %246, 7, !dbg !458
  %256 = extractvalue %"/@stdlib/console.void::io_error" %246, 8, !dbg !458
  br label %validate_payload_done20, !dbg !458

validate_payload_done20:                          ; preds = %validate_active_payload19, %validate_payload_done18
  store %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, ptr %101, align 8, !dbg !458
  call void @vd_gc_frame_leave(ptr %126), !dbg !458
  ret %"$result:$array:43:12:/@stdlib/console.void::terminal_position:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %237, !dbg !458
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f637572736f72__v1(ptr %0, i64 %1, i64 %2, ptr %3) !dbg !459 {
block0:
  %4 = alloca [8 x i64], align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %7, align 8
  %8 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %8, align 8
  %9 = alloca i64, align 8
  store i64 0, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca ptr, align 8
  store ptr null, ptr %12, align 8
  %13 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %13, align 8
  %14 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 80, 1
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, ptr @gc.offsets.290, 2
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 2, 3
  %18 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 8, 1
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, ptr @gc.offsets.291, 2
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 1, 3
  %22 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %12, 0
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 8, 1
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, ptr @gc.offsets.292, 2
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 1, 3
  %26 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %26, align 8
  %27 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %26, 0
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 80, 1
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, ptr @gc.offsets.293, 2
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 2, 3
  %31 = alloca ptr, align 8
  store ptr null, ptr %31, align 8
  %32 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %31, 0
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, i64 8, 1
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, ptr @gc.offsets.294, 2
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 1, 3
  %36 = alloca ptr, align 8
  store ptr null, ptr %36, align 8
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %36, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 8, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.295, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 1, 3
  %41 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %41, align 8
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %41, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 80, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.296, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 2, 3
  %46 = alloca ptr, align 8
  store ptr null, ptr %46, align 8
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %46, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 8, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.297, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 1, 3
  %51 = alloca ptr, align 8
  store ptr null, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 8, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.298, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 1, 3
  %56 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %56, align 8
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %56, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 80, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.299, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 4, 3
  %61 = alloca [10 x { ptr, i64, ptr, i64 }], align 8
  %62 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %17, ptr %62, align 8
  %63 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %21, ptr %63, align 8
  %64 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %25, ptr %64, align 8
  %65 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %30, ptr %65, align 8
  %66 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %35, ptr %66, align 8
  %67 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %40, ptr %67, align 8
  %68 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %45, ptr %68, align 8
  %69 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %50, ptr %69, align 8
  %70 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %55, ptr %70, align 8
  %71 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %61, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %60, ptr %71, align 8
  %72 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %72, ptr %61, i64 10)
  call void @vd_gc_poll()
  %73 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %73, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %72)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i64 %1, ptr %5, align 8, !dbg !462
  store i64 %2, ptr %6, align 8, !dbg !463
  %74 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !464
  store %"/@stdlib/console.void::output" %74, ptr %8, align 8, !dbg !464
  %75 = load i64, ptr %5, align 8, !dbg !465
  store i64 %75, ptr %9, align 8, !dbg !465
  %76 = load i64, ptr %6, align 8, !dbg !466
  store i64 %76, ptr %10, align 8, !dbg !466
  %77 = load %"/@stdlib/console.void::output", ptr %8, align 8, !dbg !467
  %78 = load i64, ptr %9, align 8, !dbg !467
  %79 = load i64, ptr %10, align 8, !dbg !467
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %26, align 8, !dbg !467
  store [8 x i64] zeroinitializer, ptr %4, align 8, !dbg !467
  %80 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 6, !dbg !467
  %81 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 7, !dbg !467
  %82 = extractvalue %"/@stdlib/console.void::output" %77, 0, !dbg !467
  call void @vd_console_v2(ptr %80, ptr %81, ptr %4, i32 11, i64 %82, ptr null, i64 %78, i64 %79, ptr %3), !dbg !467
  %83 = load ptr, ptr %3, align 8, !dbg !467
  %84 = icmp ne ptr %83, null, !dbg !467
  br i1 %84, label %selected.failure, label %selected.valid, !dbg !467

selected.failure:                                 ; preds = %worker.continue
  %85 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !467
  %86 = load i32, ptr %85, align 4, !dbg !467
  %87 = icmp ult i32 %86, 32, !dbg !467
  br i1 %87, label %trace_caller, label %trace_limit, !dbg !467

selected.valid:                                   ; preds = %worker.continue
  %88 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 0, !dbg !467
  %89 = load i64, ptr %88, align 8, !dbg !467
  %90 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 0, !dbg !467
  store i64 %89, ptr %90, align 8, !dbg !467
  %91 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 1, !dbg !467
  %92 = load i64, ptr %91, align 8, !dbg !467
  %93 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 1, !dbg !467
  store i64 %92, ptr %93, align 8, !dbg !467
  %94 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 2, !dbg !467
  %95 = load i64, ptr %94, align 8, !dbg !467
  %96 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 2, !dbg !467
  store i64 %95, ptr %96, align 8, !dbg !467
  %97 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 3, !dbg !467
  %98 = load i64, ptr %97, align 8, !dbg !467
  %99 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 3, !dbg !467
  store i64 %98, ptr %99, align 8, !dbg !467
  %100 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 4, !dbg !467
  %101 = load i64, ptr %100, align 8, !dbg !467
  %102 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 4, !dbg !467
  store i64 %101, ptr %102, align 8, !dbg !467
  %103 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 5, !dbg !467
  %104 = load i64, ptr %103, align 8, !dbg !467
  %105 = trunc i64 %104 to i1, !dbg !467
  %106 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 5, !dbg !467
  store i1 %105, ptr %106, align 1, !dbg !467
  %107 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 6, !dbg !467
  %108 = load i64, ptr %107, align 8, !dbg !467
  %109 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 8, !dbg !467
  store i64 %108, ptr %109, align 8, !dbg !467
  %110 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 7, !dbg !467
  %111 = load i64, ptr %110, align 8, !dbg !467
  %112 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %26, i32 0, i32 9, !dbg !467
  store i64 %111, ptr %112, align 8, !dbg !467
  %113 = load %"/@stdlib/console.void::_reply", ptr %26, align 8, !dbg !467
  store %"/@stdlib/console.void::_reply" %113, ptr %26, align 8, !dbg !467
  store %"/@stdlib/console.void::_reply" %113, ptr %7, align 8, !dbg !467
  call void @vd_string_literal(ptr %31, ptr @159, i64 10, ptr %3), !dbg !468
  %114 = load ptr, ptr %31, align 8, !dbg !468
  %115 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !468
  %116 = load ptr, ptr %115, align 8, !dbg !468
  %117 = icmp ne ptr %116, null, !dbg !468
  br i1 %117, label %numeric_error, label %numeric_valid, !dbg !468

trace_caller:                                     ; preds = %selected.failure
  %118 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !467
  %119 = getelementptr [32 x ptr], ptr %118, i32 0, i32 %86, !dbg !467
  store ptr @158, ptr %119, align 8, !dbg !467
  %120 = add i32 %86, 1, !dbg !467
  store i32 %120, ptr %85, align 4, !dbg !467
  br label %error_return, !dbg !467

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %72), !dbg !467
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !467

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %85, align 4, !dbg !467
  br label %error_return, !dbg !467

numeric_error:                                    ; preds = %selected.valid
  %121 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !468
  store ptr @160, ptr %121, align 8, !dbg !468
  call void @vd_gc_frame_leave(ptr %72), !dbg !468
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !468

numeric_valid:                                    ; preds = %selected.valid
  store ptr %114, ptr %31, align 8, !dbg !468
  store ptr %114, ptr %11, align 8, !dbg !468
  %122 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !469
  store %"/@stdlib/console.void::output" %122, ptr %13, align 8, !dbg !469
  %123 = load %"/@stdlib/console.void::output", ptr %13, align 8, !dbg !470
  %124 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %123, ptr %3), !dbg !470
  %125 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !470
  %126 = load ptr, ptr %125, align 8, !dbg !470
  %127 = icmp ne ptr %126, null, !dbg !470
  br i1 %127, label %propagate_error, label %call_success, !dbg !470

propagate_error:                                  ; preds = %numeric_valid
  %128 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !470
  %129 = load i32, ptr %128, align 4, !dbg !470
  %130 = icmp ult i32 %129, 32, !dbg !470
  br i1 %130, label %trace_caller1, label %trace_limit3, !dbg !470

call_success:                                     ; preds = %numeric_valid
  store ptr %124, ptr %36, align 8, !dbg !470
  store ptr %124, ptr %12, align 8, !dbg !470
  %131 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !471
  store %"/@stdlib/console.void::_reply" %131, ptr %41, align 8, !dbg !471
  %132 = load ptr, ptr %11, align 8, !dbg !471
  store ptr %132, ptr %46, align 8, !dbg !471
  %133 = load ptr, ptr %12, align 8, !dbg !471
  store ptr %133, ptr %51, align 8, !dbg !471
  %134 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %131, ptr %132, ptr %133, ptr %3), !dbg !471
  %135 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !471
  %136 = load ptr, ptr %135, align 8, !dbg !471
  %137 = icmp ne ptr %136, null, !dbg !471
  br i1 %137, label %propagate_error4, label %call_success5, !dbg !471

trace_caller1:                                    ; preds = %propagate_error
  %138 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !470
  %139 = getelementptr [32 x ptr], ptr %138, i32 0, i32 %129, !dbg !470
  store ptr @161, ptr %139, align 8, !dbg !470
  %140 = add i32 %129, 1, !dbg !470
  store i32 %140, ptr %128, align 4, !dbg !470
  br label %error_return2, !dbg !470

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %72), !dbg !470
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !470

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %128, align 4, !dbg !470
  br label %error_return2, !dbg !470

propagate_error4:                                 ; preds = %call_success
  %141 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !471
  %142 = load i32, ptr %141, align 4, !dbg !471
  %143 = icmp ult i32 %142, 32, !dbg !471
  br i1 %143, label %trace_caller6, label %trace_limit8, !dbg !471

call_success5:                                    ; preds = %call_success
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %134, ptr %56, align 8, !dbg !471
  call void @vd_gc_frame_leave(ptr %72), !dbg !471
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %134, !dbg !471

trace_caller6:                                    ; preds = %propagate_error4
  %144 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !471
  %145 = getelementptr [32 x ptr], ptr %144, i32 0, i32 %142, !dbg !471
  store ptr @162, ptr %145, align 8, !dbg !471
  %146 = add i32 %142, 1, !dbg !471
  store i32 %146, ptr %141, align 4, !dbg !471
  br label %error_return7, !dbg !471

error_return7:                                    ; preds = %trace_caller6, %trace_limit8
  call void @vd_gc_frame_leave(ptr %72), !dbg !471
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !471

trace_limit8:                                     ; preds = %propagate_error4
  store i32 33, ptr %141, align 4, !dbg !471
  br label %error_return7, !dbg !471
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f637572736f725f76697369626c65__v1(ptr %0, i1 %1, ptr %2) !dbg !472 {
block0:
  %3 = alloca [8 x i64], align 8
  %4 = alloca i1, align 1
  store i1 false, ptr %4, align 1
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %7, align 8
  %8 = alloca i64, align 8
  store i64 0, ptr %8, align 8
  %9 = alloca ptr, align 8
  store ptr null, ptr %9, align 8
  %10 = alloca ptr, align 8
  store ptr null, ptr %10, align 8
  %11 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %11, align 8
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 80, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.300, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 2, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 8, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.301, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 1, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %10, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 8, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.302, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 1, 3
  %24 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %24, align 8
  %25 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %24, 0
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 80, 1
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, ptr @gc.offsets.303, 2
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 2, 3
  %29 = alloca ptr, align 8
  store ptr null, ptr %29, align 8
  %30 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %29, 0
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 8, 1
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, ptr @gc.offsets.304, 2
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, i64 1, 3
  %34 = alloca ptr, align 8
  store ptr null, ptr %34, align 8
  %35 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %34, 0
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 8, 1
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, ptr @gc.offsets.305, 2
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 1, 3
  %39 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %39, align 8
  %40 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %39, 0
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 80, 1
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, ptr @gc.offsets.306, 2
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 2, 3
  %44 = alloca ptr, align 8
  store ptr null, ptr %44, align 8
  %45 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %44, 0
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 8, 1
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, ptr @gc.offsets.307, 2
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 1, 3
  %49 = alloca ptr, align 8
  store ptr null, ptr %49, align 8
  %50 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %49, 0
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 8, 1
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, ptr @gc.offsets.308, 2
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 1, 3
  %54 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %54, align 8
  %55 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %54, 0
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 80, 1
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, ptr @gc.offsets.309, 2
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 4, 3
  %59 = alloca [10 x { ptr, i64, ptr, i64 }], align 8
  %60 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %15, ptr %60, align 8
  %61 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %19, ptr %61, align 8
  %62 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %23, ptr %62, align 8
  %63 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %28, ptr %63, align 8
  %64 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %33, ptr %64, align 8
  %65 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %38, ptr %65, align 8
  %66 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %43, ptr %66, align 8
  %67 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %48, ptr %67, align 8
  %68 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %53, ptr %68, align 8
  %69 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %59, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %58, ptr %69, align 8
  %70 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %70, ptr %59, i64 10)
  call void @vd_gc_poll()
  %71 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %71, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !475
  %72 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !475
  br i1 %72, label %worker.cancelled1, label %worker.continue2, !dbg !475

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !476
  %73 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !476
  br i1 %73, label %worker.cancelled3, label %worker.continue4, !dbg !476

block3:                                           ; preds = %worker.continue4, %worker.continue2
  call void @vd_gc_poll(), !dbg !476
  %74 = call i1 @vd_worker_checkpoint(ptr %2), !dbg !476
  br i1 %74, label %worker.cancelled5, label %worker.continue6, !dbg !476

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %70)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i1 %1, ptr %4, align 1, !dbg !477
  store i64 0, ptr %5, align 8, !dbg !478
  %75 = load i1, ptr %4, align 1, !dbg !475
  br i1 %75, label %block1, label %block2, !dbg !475

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %70), !dbg !475
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !475

worker.continue2:                                 ; preds = %block1
  store i64 1, ptr %5, align 8, !dbg !476
  br label %block3, !dbg !476

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %70), !dbg !476
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !476

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !476

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %70), !dbg !476
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !476

worker.continue6:                                 ; preds = %block3
  %76 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !479
  store %"/@stdlib/console.void::output" %76, ptr %7, align 8, !dbg !479
  %77 = load i64, ptr %5, align 8, !dbg !480
  store i64 %77, ptr %8, align 8, !dbg !480
  %78 = load %"/@stdlib/console.void::output", ptr %7, align 8, !dbg !481
  %79 = load i64, ptr %8, align 8, !dbg !481
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %24, align 8, !dbg !481
  store [8 x i64] zeroinitializer, ptr %3, align 8, !dbg !481
  %80 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 6, !dbg !481
  %81 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 7, !dbg !481
  %82 = extractvalue %"/@stdlib/console.void::output" %78, 0, !dbg !481
  call void @vd_console_v2(ptr %80, ptr %81, ptr %3, i32 12, i64 %82, ptr null, i64 %79, i64 -1, ptr %2), !dbg !481
  %83 = load ptr, ptr %2, align 8, !dbg !481
  %84 = icmp ne ptr %83, null, !dbg !481
  br i1 %84, label %selected.failure, label %selected.valid, !dbg !481

selected.failure:                                 ; preds = %worker.continue6
  %85 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !481
  %86 = load i32, ptr %85, align 4, !dbg !481
  %87 = icmp ult i32 %86, 32, !dbg !481
  br i1 %87, label %trace_caller, label %trace_limit, !dbg !481

selected.valid:                                   ; preds = %worker.continue6
  %88 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 0, !dbg !481
  %89 = load i64, ptr %88, align 8, !dbg !481
  %90 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 0, !dbg !481
  store i64 %89, ptr %90, align 8, !dbg !481
  %91 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 1, !dbg !481
  %92 = load i64, ptr %91, align 8, !dbg !481
  %93 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 1, !dbg !481
  store i64 %92, ptr %93, align 8, !dbg !481
  %94 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 2, !dbg !481
  %95 = load i64, ptr %94, align 8, !dbg !481
  %96 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 2, !dbg !481
  store i64 %95, ptr %96, align 8, !dbg !481
  %97 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 3, !dbg !481
  %98 = load i64, ptr %97, align 8, !dbg !481
  %99 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 3, !dbg !481
  store i64 %98, ptr %99, align 8, !dbg !481
  %100 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 4, !dbg !481
  %101 = load i64, ptr %100, align 8, !dbg !481
  %102 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 4, !dbg !481
  store i64 %101, ptr %102, align 8, !dbg !481
  %103 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 5, !dbg !481
  %104 = load i64, ptr %103, align 8, !dbg !481
  %105 = trunc i64 %104 to i1, !dbg !481
  %106 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 5, !dbg !481
  store i1 %105, ptr %106, align 1, !dbg !481
  %107 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 6, !dbg !481
  %108 = load i64, ptr %107, align 8, !dbg !481
  %109 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 8, !dbg !481
  store i64 %108, ptr %109, align 8, !dbg !481
  %110 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 7, !dbg !481
  %111 = load i64, ptr %110, align 8, !dbg !481
  %112 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %24, i32 0, i32 9, !dbg !481
  store i64 %111, ptr %112, align 8, !dbg !481
  %113 = load %"/@stdlib/console.void::_reply", ptr %24, align 8, !dbg !481
  store %"/@stdlib/console.void::_reply" %113, ptr %24, align 8, !dbg !481
  store %"/@stdlib/console.void::_reply" %113, ptr %6, align 8, !dbg !481
  call void @vd_string_literal(ptr %29, ptr @164, i64 18, ptr %2), !dbg !482
  %114 = load ptr, ptr %29, align 8, !dbg !482
  %115 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !482
  %116 = load ptr, ptr %115, align 8, !dbg !482
  %117 = icmp ne ptr %116, null, !dbg !482
  br i1 %117, label %numeric_error, label %numeric_valid, !dbg !482

trace_caller:                                     ; preds = %selected.failure
  %118 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !481
  %119 = getelementptr [32 x ptr], ptr %118, i32 0, i32 %86, !dbg !481
  store ptr @163, ptr %119, align 8, !dbg !481
  %120 = add i32 %86, 1, !dbg !481
  store i32 %120, ptr %85, align 4, !dbg !481
  br label %error_return, !dbg !481

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %70), !dbg !481
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !481

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %85, align 4, !dbg !481
  br label %error_return, !dbg !481

numeric_error:                                    ; preds = %selected.valid
  %121 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !482
  store ptr @165, ptr %121, align 8, !dbg !482
  call void @vd_gc_frame_leave(ptr %70), !dbg !482
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !482

numeric_valid:                                    ; preds = %selected.valid
  store ptr %114, ptr %29, align 8, !dbg !482
  store ptr %114, ptr %9, align 8, !dbg !482
  %122 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !483
  store %"/@stdlib/console.void::output" %122, ptr %11, align 8, !dbg !483
  %123 = load %"/@stdlib/console.void::output", ptr %11, align 8, !dbg !484
  %124 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %123, ptr %2), !dbg !484
  %125 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !484
  %126 = load ptr, ptr %125, align 8, !dbg !484
  %127 = icmp ne ptr %126, null, !dbg !484
  br i1 %127, label %propagate_error, label %call_success, !dbg !484

propagate_error:                                  ; preds = %numeric_valid
  %128 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !484
  %129 = load i32, ptr %128, align 4, !dbg !484
  %130 = icmp ult i32 %129, 32, !dbg !484
  br i1 %130, label %trace_caller7, label %trace_limit9, !dbg !484

call_success:                                     ; preds = %numeric_valid
  store ptr %124, ptr %34, align 8, !dbg !484
  store ptr %124, ptr %10, align 8, !dbg !484
  %131 = load %"/@stdlib/console.void::_reply", ptr %6, align 8, !dbg !485
  store %"/@stdlib/console.void::_reply" %131, ptr %39, align 8, !dbg !485
  %132 = load ptr, ptr %9, align 8, !dbg !485
  store ptr %132, ptr %44, align 8, !dbg !485
  %133 = load ptr, ptr %10, align 8, !dbg !485
  store ptr %133, ptr %49, align 8, !dbg !485
  %134 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %131, ptr %132, ptr %133, ptr %2), !dbg !485
  %135 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !485
  %136 = load ptr, ptr %135, align 8, !dbg !485
  %137 = icmp ne ptr %136, null, !dbg !485
  br i1 %137, label %propagate_error10, label %call_success11, !dbg !485

trace_caller7:                                    ; preds = %propagate_error
  %138 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !484
  %139 = getelementptr [32 x ptr], ptr %138, i32 0, i32 %129, !dbg !484
  store ptr @166, ptr %139, align 8, !dbg !484
  %140 = add i32 %129, 1, !dbg !484
  store i32 %140, ptr %128, align 4, !dbg !484
  br label %error_return8, !dbg !484

error_return8:                                    ; preds = %trace_caller7, %trace_limit9
  call void @vd_gc_frame_leave(ptr %70), !dbg !484
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !484

trace_limit9:                                     ; preds = %propagate_error
  store i32 33, ptr %128, align 4, !dbg !484
  br label %error_return8, !dbg !484

propagate_error10:                                ; preds = %call_success
  %141 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !485
  %142 = load i32, ptr %141, align 4, !dbg !485
  %143 = icmp ult i32 %142, 32, !dbg !485
  br i1 %143, label %trace_caller12, label %trace_limit14, !dbg !485

call_success11:                                   ; preds = %call_success
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %134, ptr %54, align 8, !dbg !485
  call void @vd_gc_frame_leave(ptr %70), !dbg !485
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %134, !dbg !485

trace_caller12:                                   ; preds = %propagate_error10
  %144 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !485
  %145 = getelementptr [32 x ptr], ptr %144, i32 0, i32 %142, !dbg !485
  store ptr @167, ptr %145, align 8, !dbg !485
  %146 = add i32 %142, 1, !dbg !485
  store i32 %146, ptr %141, align 4, !dbg !485
  br label %error_return13, !dbg !485

error_return13:                                   ; preds = %trace_caller12, %trace_limit14
  call void @vd_gc_frame_leave(ptr %70), !dbg !485
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !485

trace_limit14:                                    ; preds = %propagate_error10
  store i32 33, ptr %141, align 4, !dbg !485
  br label %error_return13, !dbg !485
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f636f6c6f72__v1(ptr %0, %"/@stdlib/console.void::color" %1, %"/@stdlib/console.void::color" %2, ptr %3) !dbg !486 {
block0:
  %4 = alloca [8 x i64], align 8
  %5 = alloca %"/@stdlib/console.void::color", align 8
  store %"/@stdlib/console.void::color" zeroinitializer, ptr %5, align 4
  %6 = alloca %"/@stdlib/console.void::color", align 8
  store %"/@stdlib/console.void::color" zeroinitializer, ptr %6, align 4
  %7 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %7, align 8
  %8 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::color", align 8
  store %"/@stdlib/console.void::color" zeroinitializer, ptr %9, align 4
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca %"/@stdlib/console.void::color", align 8
  store %"/@stdlib/console.void::color" zeroinitializer, ptr %11, align 4
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca ptr, align 8
  store ptr null, ptr %13, align 8
  %14 = alloca ptr, align 8
  store ptr null, ptr %14, align 8
  %15 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %15, align 8
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 80, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.310, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 2, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 8, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.311, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 1, 3
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %14, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.312, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %28, align 8
  %29 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %28, 0
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 80, 1
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, ptr @gc.offsets.313, 2
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 2, 3
  %33 = alloca ptr, align 8
  store ptr null, ptr %33, align 8
  %34 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %33, 0
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 8, 1
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, ptr @gc.offsets.314, 2
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 1, 3
  %38 = alloca ptr, align 8
  store ptr null, ptr %38, align 8
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %38, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 8, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.315, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 1, 3
  %43 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %43, align 8
  %44 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %43, 0
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 80, 1
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, ptr @gc.offsets.316, 2
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 2, 3
  %48 = alloca ptr, align 8
  store ptr null, ptr %48, align 8
  %49 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %48, 0
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 8, 1
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, ptr @gc.offsets.317, 2
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 1, 3
  %53 = alloca ptr, align 8
  store ptr null, ptr %53, align 8
  %54 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %53, 0
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 8, 1
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, ptr @gc.offsets.318, 2
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 1, 3
  %58 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %58, align 8
  %59 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %58, 0
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 80, 1
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, ptr @gc.offsets.319, 2
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, i64 4, 3
  %63 = alloca [10 x { ptr, i64, ptr, i64 }], align 8
  %64 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %19, ptr %64, align 8
  %65 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %23, ptr %65, align 8
  %66 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %27, ptr %66, align 8
  %67 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %32, ptr %67, align 8
  %68 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %37, ptr %68, align 8
  %69 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %42, ptr %69, align 8
  %70 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %47, ptr %70, align 8
  %71 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %52, ptr %71, align 8
  %72 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %57, ptr %72, align 8
  %73 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %63, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %62, ptr %73, align 8
  %74 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %74, ptr %63, i64 10)
  call void @vd_gc_poll()
  %75 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %75, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %74)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store %"/@stdlib/console.void::color" %1, ptr %5, align 4, !dbg !489
  store %"/@stdlib/console.void::color" %2, ptr %6, align 4, !dbg !490
  %76 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !491
  store %"/@stdlib/console.void::output" %76, ptr %8, align 8, !dbg !491
  %77 = load %"/@stdlib/console.void::color", ptr %5, align 4, !dbg !492
  store %"/@stdlib/console.void::color" %77, ptr %9, align 4, !dbg !492
  %78 = load %"/@stdlib/console.void::color", ptr %9, align 4, !dbg !493
  %79 = call i64 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f636f6c6f725f636f6465__v1(%"/@stdlib/console.void::color" %78, ptr %3), !dbg !493
  %80 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !493
  %81 = load ptr, ptr %80, align 8, !dbg !493
  %82 = icmp ne ptr %81, null, !dbg !493
  br i1 %82, label %propagate_error, label %call_success, !dbg !493

propagate_error:                                  ; preds = %worker.continue
  %83 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !493
  %84 = load i32, ptr %83, align 4, !dbg !493
  %85 = icmp ult i32 %84, 32, !dbg !493
  br i1 %85, label %trace_caller, label %trace_limit, !dbg !493

call_success:                                     ; preds = %worker.continue
  store i64 %79, ptr %10, align 8, !dbg !493
  %86 = load %"/@stdlib/console.void::color", ptr %6, align 4, !dbg !494
  store %"/@stdlib/console.void::color" %86, ptr %11, align 4, !dbg !494
  %87 = load %"/@stdlib/console.void::color", ptr %11, align 4, !dbg !495
  %88 = call i64 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f636f6c6f725f636f6465__v1(%"/@stdlib/console.void::color" %87, ptr %3), !dbg !495
  %89 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !495
  %90 = load ptr, ptr %89, align 8, !dbg !495
  %91 = icmp ne ptr %90, null, !dbg !495
  br i1 %91, label %propagate_error1, label %call_success2, !dbg !495

trace_caller:                                     ; preds = %propagate_error
  %92 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !493
  %93 = getelementptr [32 x ptr], ptr %92, i32 0, i32 %84, !dbg !493
  store ptr @168, ptr %93, align 8, !dbg !493
  %94 = add i32 %84, 1, !dbg !493
  store i32 %94, ptr %83, align 4, !dbg !493
  br label %error_return, !dbg !493

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %74), !dbg !493
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !493

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %83, align 4, !dbg !493
  br label %error_return, !dbg !493

propagate_error1:                                 ; preds = %call_success
  %95 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !495
  %96 = load i32, ptr %95, align 4, !dbg !495
  %97 = icmp ult i32 %96, 32, !dbg !495
  br i1 %97, label %trace_caller3, label %trace_limit5, !dbg !495

call_success2:                                    ; preds = %call_success
  store i64 %88, ptr %12, align 8, !dbg !495
  %98 = load %"/@stdlib/console.void::output", ptr %8, align 8, !dbg !496
  %99 = load i64, ptr %10, align 8, !dbg !496
  %100 = load i64, ptr %12, align 8, !dbg !496
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %28, align 8, !dbg !496
  store [8 x i64] zeroinitializer, ptr %4, align 8, !dbg !496
  %101 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 6, !dbg !496
  %102 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 7, !dbg !496
  %103 = extractvalue %"/@stdlib/console.void::output" %98, 0, !dbg !496
  call void @vd_console_v2(ptr %101, ptr %102, ptr %4, i32 13, i64 %103, ptr null, i64 %99, i64 %100, ptr %3), !dbg !496
  %104 = load ptr, ptr %3, align 8, !dbg !496
  %105 = icmp ne ptr %104, null, !dbg !496
  br i1 %105, label %selected.failure, label %selected.valid, !dbg !496

trace_caller3:                                    ; preds = %propagate_error1
  %106 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !495
  %107 = getelementptr [32 x ptr], ptr %106, i32 0, i32 %96, !dbg !495
  store ptr @169, ptr %107, align 8, !dbg !495
  %108 = add i32 %96, 1, !dbg !495
  store i32 %108, ptr %95, align 4, !dbg !495
  br label %error_return4, !dbg !495

error_return4:                                    ; preds = %trace_caller3, %trace_limit5
  call void @vd_gc_frame_leave(ptr %74), !dbg !495
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !495

trace_limit5:                                     ; preds = %propagate_error1
  store i32 33, ptr %95, align 4, !dbg !495
  br label %error_return4, !dbg !495

selected.failure:                                 ; preds = %call_success2
  %109 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !496
  %110 = load i32, ptr %109, align 4, !dbg !496
  %111 = icmp ult i32 %110, 32, !dbg !496
  br i1 %111, label %trace_caller6, label %trace_limit8, !dbg !496

selected.valid:                                   ; preds = %call_success2
  %112 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 0, !dbg !496
  %113 = load i64, ptr %112, align 8, !dbg !496
  %114 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 0, !dbg !496
  store i64 %113, ptr %114, align 8, !dbg !496
  %115 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 1, !dbg !496
  %116 = load i64, ptr %115, align 8, !dbg !496
  %117 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 1, !dbg !496
  store i64 %116, ptr %117, align 8, !dbg !496
  %118 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 2, !dbg !496
  %119 = load i64, ptr %118, align 8, !dbg !496
  %120 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 2, !dbg !496
  store i64 %119, ptr %120, align 8, !dbg !496
  %121 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 3, !dbg !496
  %122 = load i64, ptr %121, align 8, !dbg !496
  %123 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 3, !dbg !496
  store i64 %122, ptr %123, align 8, !dbg !496
  %124 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 4, !dbg !496
  %125 = load i64, ptr %124, align 8, !dbg !496
  %126 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 4, !dbg !496
  store i64 %125, ptr %126, align 8, !dbg !496
  %127 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 5, !dbg !496
  %128 = load i64, ptr %127, align 8, !dbg !496
  %129 = trunc i64 %128 to i1, !dbg !496
  %130 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 5, !dbg !496
  store i1 %129, ptr %130, align 1, !dbg !496
  %131 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 6, !dbg !496
  %132 = load i64, ptr %131, align 8, !dbg !496
  %133 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 8, !dbg !496
  store i64 %132, ptr %133, align 8, !dbg !496
  %134 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 7, !dbg !496
  %135 = load i64, ptr %134, align 8, !dbg !496
  %136 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %28, i32 0, i32 9, !dbg !496
  store i64 %135, ptr %136, align 8, !dbg !496
  %137 = load %"/@stdlib/console.void::_reply", ptr %28, align 8, !dbg !496
  store %"/@stdlib/console.void::_reply" %137, ptr %28, align 8, !dbg !496
  store %"/@stdlib/console.void::_reply" %137, ptr %7, align 8, !dbg !496
  call void @vd_string_literal(ptr %33, ptr @171, i64 9, ptr %3), !dbg !497
  %138 = load ptr, ptr %33, align 8, !dbg !497
  %139 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !497
  %140 = load ptr, ptr %139, align 8, !dbg !497
  %141 = icmp ne ptr %140, null, !dbg !497
  br i1 %141, label %numeric_error, label %numeric_valid, !dbg !497

trace_caller6:                                    ; preds = %selected.failure
  %142 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !496
  %143 = getelementptr [32 x ptr], ptr %142, i32 0, i32 %110, !dbg !496
  store ptr @170, ptr %143, align 8, !dbg !496
  %144 = add i32 %110, 1, !dbg !496
  store i32 %144, ptr %109, align 4, !dbg !496
  br label %error_return7, !dbg !496

error_return7:                                    ; preds = %trace_caller6, %trace_limit8
  call void @vd_gc_frame_leave(ptr %74), !dbg !496
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !496

trace_limit8:                                     ; preds = %selected.failure
  store i32 33, ptr %109, align 4, !dbg !496
  br label %error_return7, !dbg !496

numeric_error:                                    ; preds = %selected.valid
  %145 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !497
  store ptr @172, ptr %145, align 8, !dbg !497
  call void @vd_gc_frame_leave(ptr %74), !dbg !497
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !497

numeric_valid:                                    ; preds = %selected.valid
  store ptr %138, ptr %33, align 8, !dbg !497
  store ptr %138, ptr %13, align 8, !dbg !497
  %146 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !498
  store %"/@stdlib/console.void::output" %146, ptr %15, align 8, !dbg !498
  %147 = load %"/@stdlib/console.void::output", ptr %15, align 8, !dbg !499
  %148 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %147, ptr %3), !dbg !499
  %149 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !499
  %150 = load ptr, ptr %149, align 8, !dbg !499
  %151 = icmp ne ptr %150, null, !dbg !499
  br i1 %151, label %propagate_error9, label %call_success10, !dbg !499

propagate_error9:                                 ; preds = %numeric_valid
  %152 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !499
  %153 = load i32, ptr %152, align 4, !dbg !499
  %154 = icmp ult i32 %153, 32, !dbg !499
  br i1 %154, label %trace_caller11, label %trace_limit13, !dbg !499

call_success10:                                   ; preds = %numeric_valid
  store ptr %148, ptr %38, align 8, !dbg !499
  store ptr %148, ptr %14, align 8, !dbg !499
  %155 = load %"/@stdlib/console.void::_reply", ptr %7, align 8, !dbg !500
  store %"/@stdlib/console.void::_reply" %155, ptr %43, align 8, !dbg !500
  %156 = load ptr, ptr %13, align 8, !dbg !500
  store ptr %156, ptr %48, align 8, !dbg !500
  %157 = load ptr, ptr %14, align 8, !dbg !500
  store ptr %157, ptr %53, align 8, !dbg !500
  %158 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %155, ptr %156, ptr %157, ptr %3), !dbg !500
  %159 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !500
  %160 = load ptr, ptr %159, align 8, !dbg !500
  %161 = icmp ne ptr %160, null, !dbg !500
  br i1 %161, label %propagate_error14, label %call_success15, !dbg !500

trace_caller11:                                   ; preds = %propagate_error9
  %162 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !499
  %163 = getelementptr [32 x ptr], ptr %162, i32 0, i32 %153, !dbg !499
  store ptr @173, ptr %163, align 8, !dbg !499
  %164 = add i32 %153, 1, !dbg !499
  store i32 %164, ptr %152, align 4, !dbg !499
  br label %error_return12, !dbg !499

error_return12:                                   ; preds = %trace_caller11, %trace_limit13
  call void @vd_gc_frame_leave(ptr %74), !dbg !499
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !499

trace_limit13:                                    ; preds = %propagate_error9
  store i32 33, ptr %152, align 4, !dbg !499
  br label %error_return12, !dbg !499

propagate_error14:                                ; preds = %call_success10
  %165 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !500
  %166 = load i32, ptr %165, align 4, !dbg !500
  %167 = icmp ult i32 %166, 32, !dbg !500
  br i1 %167, label %trace_caller16, label %trace_limit18, !dbg !500

call_success15:                                   ; preds = %call_success10
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %158, ptr %58, align 8, !dbg !500
  call void @vd_gc_frame_leave(ptr %74), !dbg !500
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %158, !dbg !500

trace_caller16:                                   ; preds = %propagate_error14
  %168 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !500
  %169 = getelementptr [32 x ptr], ptr %168, i32 0, i32 %166, !dbg !500
  store ptr @174, ptr %169, align 8, !dbg !500
  %170 = add i32 %166, 1, !dbg !500
  store i32 %170, ptr %165, align 4, !dbg !500
  br label %error_return17, !dbg !500

error_return17:                                   ; preds = %trace_caller16, %trace_limit18
  call void @vd_gc_frame_leave(ptr %74), !dbg !500
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !500

trace_limit18:                                    ; preds = %propagate_error14
  store i32 33, ptr %165, align 4, !dbg !500
  br label %error_return17, !dbg !500
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a72657365745f636f6c6f72__v1(ptr %0, ptr %1) !dbg !501 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %7, align 8
  %8 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 80, 1
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, ptr @gc.offsets.320, 2
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 2, 3
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 8, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.321, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 1, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 8, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.322, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 1, 3
  %20 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %20, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 80, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.323, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 2, 3
  %25 = alloca ptr, align 8
  store ptr null, ptr %25, align 8
  %26 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %25, 0
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 8, 1
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, ptr @gc.offsets.324, 2
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 1, 3
  %30 = alloca ptr, align 8
  store ptr null, ptr %30, align 8
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %30, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 8, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.325, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 1, 3
  %35 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %35, align 8
  %36 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %35, 0
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 80, 1
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, ptr @gc.offsets.326, 2
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 2, 3
  %40 = alloca ptr, align 8
  store ptr null, ptr %40, align 8
  %41 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %40, 0
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 8, 1
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, ptr @gc.offsets.327, 2
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 1, 3
  %45 = alloca ptr, align 8
  store ptr null, ptr %45, align 8
  %46 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %45, 0
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 8, 1
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, ptr @gc.offsets.328, 2
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 1, 3
  %50 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %50, align 8
  %51 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %50, 0
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 80, 1
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, ptr @gc.offsets.329, 2
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 4, 3
  %55 = alloca [10 x { ptr, i64, ptr, i64 }], align 8
  %56 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %11, ptr %56, align 8
  %57 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %15, ptr %57, align 8
  %58 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %19, ptr %58, align 8
  %59 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %24, ptr %59, align 8
  %60 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %29, ptr %60, align 8
  %61 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %34, ptr %61, align 8
  %62 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %39, ptr %62, align 8
  %63 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %44, ptr %63, align 8
  %64 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %49, ptr %64, align 8
  %65 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %54, ptr %65, align 8
  %66 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %66, ptr %55, i64 10)
  call void @vd_gc_poll()
  %67 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %67, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %66)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %68 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !502
  store %"/@stdlib/console.void::output" %68, ptr %4, align 8, !dbg !502
  %69 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !503
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8, !dbg !503
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !503
  %70 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 6, !dbg !503
  %71 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 7, !dbg !503
  %72 = extractvalue %"/@stdlib/console.void::output" %69, 0, !dbg !503
  call void @vd_console_v2(ptr %70, ptr %71, ptr %2, i32 14, i64 %72, ptr null, i64 0, i64 -1, ptr %1), !dbg !503
  %73 = load ptr, ptr %1, align 8, !dbg !503
  %74 = icmp ne ptr %73, null, !dbg !503
  br i1 %74, label %selected.failure, label %selected.valid, !dbg !503

selected.failure:                                 ; preds = %worker.continue
  %75 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !503
  %76 = load i32, ptr %75, align 4, !dbg !503
  %77 = icmp ult i32 %76, 32, !dbg !503
  br i1 %77, label %trace_caller, label %trace_limit, !dbg !503

selected.valid:                                   ; preds = %worker.continue
  %78 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !503
  %79 = load i64, ptr %78, align 8, !dbg !503
  %80 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 0, !dbg !503
  store i64 %79, ptr %80, align 8, !dbg !503
  %81 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !503
  %82 = load i64, ptr %81, align 8, !dbg !503
  %83 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 1, !dbg !503
  store i64 %82, ptr %83, align 8, !dbg !503
  %84 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !503
  %85 = load i64, ptr %84, align 8, !dbg !503
  %86 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 2, !dbg !503
  store i64 %85, ptr %86, align 8, !dbg !503
  %87 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !503
  %88 = load i64, ptr %87, align 8, !dbg !503
  %89 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 3, !dbg !503
  store i64 %88, ptr %89, align 8, !dbg !503
  %90 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !503
  %91 = load i64, ptr %90, align 8, !dbg !503
  %92 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 4, !dbg !503
  store i64 %91, ptr %92, align 8, !dbg !503
  %93 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !503
  %94 = load i64, ptr %93, align 8, !dbg !503
  %95 = trunc i64 %94 to i1, !dbg !503
  %96 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 5, !dbg !503
  store i1 %95, ptr %96, align 1, !dbg !503
  %97 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !503
  %98 = load i64, ptr %97, align 8, !dbg !503
  %99 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 8, !dbg !503
  store i64 %98, ptr %99, align 8, !dbg !503
  %100 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !503
  %101 = load i64, ptr %100, align 8, !dbg !503
  %102 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 9, !dbg !503
  store i64 %101, ptr %102, align 8, !dbg !503
  %103 = load %"/@stdlib/console.void::_reply", ptr %20, align 8, !dbg !503
  store %"/@stdlib/console.void::_reply" %103, ptr %20, align 8, !dbg !503
  store %"/@stdlib/console.void::_reply" %103, ptr %3, align 8, !dbg !503
  call void @vd_string_literal(ptr %25, ptr @176, i64 11, ptr %1), !dbg !504
  %104 = load ptr, ptr %25, align 8, !dbg !504
  %105 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !504
  %106 = load ptr, ptr %105, align 8, !dbg !504
  %107 = icmp ne ptr %106, null, !dbg !504
  br i1 %107, label %numeric_error, label %numeric_valid, !dbg !504

trace_caller:                                     ; preds = %selected.failure
  %108 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !503
  %109 = getelementptr [32 x ptr], ptr %108, i32 0, i32 %76, !dbg !503
  store ptr @175, ptr %109, align 8, !dbg !503
  %110 = add i32 %76, 1, !dbg !503
  store i32 %110, ptr %75, align 4, !dbg !503
  br label %error_return, !dbg !503

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %66), !dbg !503
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !503

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %75, align 4, !dbg !503
  br label %error_return, !dbg !503

numeric_error:                                    ; preds = %selected.valid
  %111 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !504
  store ptr @177, ptr %111, align 8, !dbg !504
  call void @vd_gc_frame_leave(ptr %66), !dbg !504
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !504

numeric_valid:                                    ; preds = %selected.valid
  store ptr %104, ptr %25, align 8, !dbg !504
  store ptr %104, ptr %5, align 8, !dbg !504
  %112 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !505
  store %"/@stdlib/console.void::output" %112, ptr %7, align 8, !dbg !505
  %113 = load %"/@stdlib/console.void::output", ptr %7, align 8, !dbg !506
  %114 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %113, ptr %1), !dbg !506
  %115 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !506
  %116 = load ptr, ptr %115, align 8, !dbg !506
  %117 = icmp ne ptr %116, null, !dbg !506
  br i1 %117, label %propagate_error, label %call_success, !dbg !506

propagate_error:                                  ; preds = %numeric_valid
  %118 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !506
  %119 = load i32, ptr %118, align 4, !dbg !506
  %120 = icmp ult i32 %119, 32, !dbg !506
  br i1 %120, label %trace_caller1, label %trace_limit3, !dbg !506

call_success:                                     ; preds = %numeric_valid
  store ptr %114, ptr %30, align 8, !dbg !506
  store ptr %114, ptr %6, align 8, !dbg !506
  %121 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !507
  store %"/@stdlib/console.void::_reply" %121, ptr %35, align 8, !dbg !507
  %122 = load ptr, ptr %5, align 8, !dbg !507
  store ptr %122, ptr %40, align 8, !dbg !507
  %123 = load ptr, ptr %6, align 8, !dbg !507
  store ptr %123, ptr %45, align 8, !dbg !507
  %124 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %121, ptr %122, ptr %123, ptr %1), !dbg !507
  %125 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !507
  %126 = load ptr, ptr %125, align 8, !dbg !507
  %127 = icmp ne ptr %126, null, !dbg !507
  br i1 %127, label %propagate_error4, label %call_success5, !dbg !507

trace_caller1:                                    ; preds = %propagate_error
  %128 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !506
  %129 = getelementptr [32 x ptr], ptr %128, i32 0, i32 %119, !dbg !506
  store ptr @178, ptr %129, align 8, !dbg !506
  %130 = add i32 %119, 1, !dbg !506
  store i32 %130, ptr %118, align 4, !dbg !506
  br label %error_return2, !dbg !506

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %66), !dbg !506
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !506

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %118, align 4, !dbg !506
  br label %error_return2, !dbg !506

propagate_error4:                                 ; preds = %call_success
  %131 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !507
  %132 = load i32, ptr %131, align 4, !dbg !507
  %133 = icmp ult i32 %132, 32, !dbg !507
  br i1 %133, label %trace_caller6, label %trace_limit8, !dbg !507

call_success5:                                    ; preds = %call_success
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %124, ptr %50, align 8, !dbg !507
  call void @vd_gc_frame_leave(ptr %66), !dbg !507
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %124, !dbg !507

trace_caller6:                                    ; preds = %propagate_error4
  %134 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !507
  %135 = getelementptr [32 x ptr], ptr %134, i32 0, i32 %132, !dbg !507
  store ptr @179, ptr %135, align 8, !dbg !507
  %136 = add i32 %132, 1, !dbg !507
  store i32 %136, ptr %131, align 4, !dbg !507
  br label %error_return7, !dbg !507

error_return7:                                    ; preds = %trace_caller6, %trace_limit8
  call void @vd_gc_frame_leave(ptr %66), !dbg !507
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !507

trace_limit8:                                     ; preds = %propagate_error4
  store i32 33, ptr %131, align 4, !dbg !507
  br label %error_return7, !dbg !507
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a636c656172__v1(ptr %0, ptr %1) !dbg !508 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %7, align 8
  %8 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 80, 1
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, ptr @gc.offsets.330, 2
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 2, 3
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 8, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.331, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 1, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 8, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.332, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 1, 3
  %20 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %20, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 80, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.333, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 2, 3
  %25 = alloca ptr, align 8
  store ptr null, ptr %25, align 8
  %26 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %25, 0
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 8, 1
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, ptr @gc.offsets.334, 2
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 1, 3
  %30 = alloca ptr, align 8
  store ptr null, ptr %30, align 8
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %30, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 8, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.335, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 1, 3
  %35 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %35, align 8
  %36 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %35, 0
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 80, 1
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, ptr @gc.offsets.336, 2
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 2, 3
  %40 = alloca ptr, align 8
  store ptr null, ptr %40, align 8
  %41 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %40, 0
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 8, 1
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, ptr @gc.offsets.337, 2
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 1, 3
  %45 = alloca ptr, align 8
  store ptr null, ptr %45, align 8
  %46 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %45, 0
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 8, 1
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, ptr @gc.offsets.338, 2
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 1, 3
  %50 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %50, align 8
  %51 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %50, 0
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 80, 1
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, ptr @gc.offsets.339, 2
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 4, 3
  %55 = alloca [10 x { ptr, i64, ptr, i64 }], align 8
  %56 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %11, ptr %56, align 8
  %57 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %15, ptr %57, align 8
  %58 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %19, ptr %58, align 8
  %59 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %24, ptr %59, align 8
  %60 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %29, ptr %60, align 8
  %61 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %34, ptr %61, align 8
  %62 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %39, ptr %62, align 8
  %63 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %44, ptr %63, align 8
  %64 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %49, ptr %64, align 8
  %65 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %54, ptr %65, align 8
  %66 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %66, ptr %55, i64 10)
  call void @vd_gc_poll()
  %67 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %67, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %66)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %68 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !509
  store %"/@stdlib/console.void::output" %68, ptr %4, align 8, !dbg !509
  %69 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !510
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8, !dbg !510
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !510
  %70 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 6, !dbg !510
  %71 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 7, !dbg !510
  %72 = extractvalue %"/@stdlib/console.void::output" %69, 0, !dbg !510
  call void @vd_console_v2(ptr %70, ptr %71, ptr %2, i32 15, i64 %72, ptr null, i64 0, i64 -1, ptr %1), !dbg !510
  %73 = load ptr, ptr %1, align 8, !dbg !510
  %74 = icmp ne ptr %73, null, !dbg !510
  br i1 %74, label %selected.failure, label %selected.valid, !dbg !510

selected.failure:                                 ; preds = %worker.continue
  %75 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !510
  %76 = load i32, ptr %75, align 4, !dbg !510
  %77 = icmp ult i32 %76, 32, !dbg !510
  br i1 %77, label %trace_caller, label %trace_limit, !dbg !510

selected.valid:                                   ; preds = %worker.continue
  %78 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !510
  %79 = load i64, ptr %78, align 8, !dbg !510
  %80 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 0, !dbg !510
  store i64 %79, ptr %80, align 8, !dbg !510
  %81 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !510
  %82 = load i64, ptr %81, align 8, !dbg !510
  %83 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 1, !dbg !510
  store i64 %82, ptr %83, align 8, !dbg !510
  %84 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !510
  %85 = load i64, ptr %84, align 8, !dbg !510
  %86 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 2, !dbg !510
  store i64 %85, ptr %86, align 8, !dbg !510
  %87 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !510
  %88 = load i64, ptr %87, align 8, !dbg !510
  %89 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 3, !dbg !510
  store i64 %88, ptr %89, align 8, !dbg !510
  %90 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !510
  %91 = load i64, ptr %90, align 8, !dbg !510
  %92 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 4, !dbg !510
  store i64 %91, ptr %92, align 8, !dbg !510
  %93 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !510
  %94 = load i64, ptr %93, align 8, !dbg !510
  %95 = trunc i64 %94 to i1, !dbg !510
  %96 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 5, !dbg !510
  store i1 %95, ptr %96, align 1, !dbg !510
  %97 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !510
  %98 = load i64, ptr %97, align 8, !dbg !510
  %99 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 8, !dbg !510
  store i64 %98, ptr %99, align 8, !dbg !510
  %100 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !510
  %101 = load i64, ptr %100, align 8, !dbg !510
  %102 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 9, !dbg !510
  store i64 %101, ptr %102, align 8, !dbg !510
  %103 = load %"/@stdlib/console.void::_reply", ptr %20, align 8, !dbg !510
  store %"/@stdlib/console.void::_reply" %103, ptr %20, align 8, !dbg !510
  store %"/@stdlib/console.void::_reply" %103, ptr %3, align 8, !dbg !510
  call void @vd_string_literal(ptr %25, ptr @181, i64 5, ptr %1), !dbg !511
  %104 = load ptr, ptr %25, align 8, !dbg !511
  %105 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !511
  %106 = load ptr, ptr %105, align 8, !dbg !511
  %107 = icmp ne ptr %106, null, !dbg !511
  br i1 %107, label %numeric_error, label %numeric_valid, !dbg !511

trace_caller:                                     ; preds = %selected.failure
  %108 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !510
  %109 = getelementptr [32 x ptr], ptr %108, i32 0, i32 %76, !dbg !510
  store ptr @180, ptr %109, align 8, !dbg !510
  %110 = add i32 %76, 1, !dbg !510
  store i32 %110, ptr %75, align 4, !dbg !510
  br label %error_return, !dbg !510

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %66), !dbg !510
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !510

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %75, align 4, !dbg !510
  br label %error_return, !dbg !510

numeric_error:                                    ; preds = %selected.valid
  %111 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !511
  store ptr @182, ptr %111, align 8, !dbg !511
  call void @vd_gc_frame_leave(ptr %66), !dbg !511
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !511

numeric_valid:                                    ; preds = %selected.valid
  store ptr %104, ptr %25, align 8, !dbg !511
  store ptr %104, ptr %5, align 8, !dbg !511
  %112 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !512
  store %"/@stdlib/console.void::output" %112, ptr %7, align 8, !dbg !512
  %113 = load %"/@stdlib/console.void::output", ptr %7, align 8, !dbg !513
  %114 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %113, ptr %1), !dbg !513
  %115 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !513
  %116 = load ptr, ptr %115, align 8, !dbg !513
  %117 = icmp ne ptr %116, null, !dbg !513
  br i1 %117, label %propagate_error, label %call_success, !dbg !513

propagate_error:                                  ; preds = %numeric_valid
  %118 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !513
  %119 = load i32, ptr %118, align 4, !dbg !513
  %120 = icmp ult i32 %119, 32, !dbg !513
  br i1 %120, label %trace_caller1, label %trace_limit3, !dbg !513

call_success:                                     ; preds = %numeric_valid
  store ptr %114, ptr %30, align 8, !dbg !513
  store ptr %114, ptr %6, align 8, !dbg !513
  %121 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !514
  store %"/@stdlib/console.void::_reply" %121, ptr %35, align 8, !dbg !514
  %122 = load ptr, ptr %5, align 8, !dbg !514
  store ptr %122, ptr %40, align 8, !dbg !514
  %123 = load ptr, ptr %6, align 8, !dbg !514
  store ptr %123, ptr %45, align 8, !dbg !514
  %124 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %121, ptr %122, ptr %123, ptr %1), !dbg !514
  %125 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !514
  %126 = load ptr, ptr %125, align 8, !dbg !514
  %127 = icmp ne ptr %126, null, !dbg !514
  br i1 %127, label %propagate_error4, label %call_success5, !dbg !514

trace_caller1:                                    ; preds = %propagate_error
  %128 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !513
  %129 = getelementptr [32 x ptr], ptr %128, i32 0, i32 %119, !dbg !513
  store ptr @183, ptr %129, align 8, !dbg !513
  %130 = add i32 %119, 1, !dbg !513
  store i32 %130, ptr %118, align 4, !dbg !513
  br label %error_return2, !dbg !513

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %66), !dbg !513
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !513

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %118, align 4, !dbg !513
  br label %error_return2, !dbg !513

propagate_error4:                                 ; preds = %call_success
  %131 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !514
  %132 = load i32, ptr %131, align 4, !dbg !514
  %133 = icmp ult i32 %132, 32, !dbg !514
  br i1 %133, label %trace_caller6, label %trace_limit8, !dbg !514

call_success5:                                    ; preds = %call_success
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %124, ptr %50, align 8, !dbg !514
  call void @vd_gc_frame_leave(ptr %66), !dbg !514
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %124, !dbg !514

trace_caller6:                                    ; preds = %propagate_error4
  %134 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !514
  %135 = getelementptr [32 x ptr], ptr %134, i32 0, i32 %132, !dbg !514
  store ptr @184, ptr %135, align 8, !dbg !514
  %136 = add i32 %132, 1, !dbg !514
  store i32 %136, ptr %131, align 4, !dbg !514
  br label %error_return7, !dbg !514

error_return7:                                    ; preds = %trace_caller6, %trace_limit8
  call void @vd_gc_frame_leave(ptr %66), !dbg !514
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !514

trace_limit8:                                     ; preds = %propagate_error4
  store i32 33, ptr %131, align 4, !dbg !514
  br label %error_return7, !dbg !514
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f7469746c65__v1(ptr %0, ptr %1, ptr %2) !dbg !515 {
block0:
  %3 = alloca [8 x i64], align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca ptr, align 8
  store ptr null, ptr %9, align 8
  %10 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %10, align 8
  %11 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, i64 8, 1
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, ptr @gc.offsets.340, 2
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, i64 1, 3
  %15 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, i64 80, 1
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, ptr @gc.offsets.341, 2
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, i64 2, 3
  %19 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 8, 1
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, ptr @gc.offsets.342, 2
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 1, 3
  %23 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 8, 1
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, ptr @gc.offsets.343, 2
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 1, 3
  %27 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 8, 1
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, ptr @gc.offsets.344, 2
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 1, 3
  %31 = alloca ptr, align 8
  store ptr %1, ptr %31, align 8
  %32 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %31, 0
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, i64 8, 1
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, ptr @gc.offsets.345, 2
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 1, 3
  %36 = alloca ptr, align 8
  store ptr null, ptr %36, align 8
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %36, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 8, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.346, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 1, 3
  %41 = alloca ptr, align 8
  store ptr null, ptr %41, align 8
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %41, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 8, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.347, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 1, 3
  %46 = alloca ptr, align 8
  store ptr null, ptr %46, align 8
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %46, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 8, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.348, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 1, 3
  %51 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 80, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.349, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 2, 3
  %56 = alloca ptr, align 8
  store ptr null, ptr %56, align 8
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %56, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 8, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.350, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 1, 3
  %61 = alloca ptr, align 8
  store ptr null, ptr %61, align 8
  %62 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %61, 0
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 8, 1
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, ptr @gc.offsets.351, 2
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 1, 3
  %66 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %66, align 8
  %67 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %66, 0
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 80, 1
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, ptr @gc.offsets.352, 2
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 2, 3
  %71 = alloca ptr, align 8
  store ptr null, ptr %71, align 8
  %72 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %71, 0
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 8, 1
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, ptr @gc.offsets.353, 2
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 1, 3
  %76 = alloca ptr, align 8
  store ptr null, ptr %76, align 8
  %77 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %76, 0
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 8, 1
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, ptr @gc.offsets.354, 2
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 1, 3
  %81 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %81, align 8
  %82 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %81, 0
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 80, 1
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, ptr @gc.offsets.355, 2
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 4, 3
  %86 = alloca [16 x { ptr, i64, ptr, i64 }], align 8
  %87 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %14, ptr %87, align 8
  %88 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %18, ptr %88, align 8
  %89 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %22, ptr %89, align 8
  %90 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %26, ptr %90, align 8
  %91 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %30, ptr %91, align 8
  %92 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %35, ptr %92, align 8
  %93 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %40, ptr %93, align 8
  %94 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %45, ptr %94, align 8
  %95 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %50, ptr %95, align 8
  %96 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %55, ptr %96, align 8
  %97 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %60, ptr %97, align 8
  %98 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %65, ptr %98, align 8
  %99 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %70, ptr %99, align 8
  %100 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %75, ptr %100, align 8
  %101 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %80, ptr %101, align 8
  %102 = getelementptr inbounds [16 x { ptr, i64, ptr, i64 }], ptr %86, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %85, ptr %102, align 8
  %103 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %103, ptr %86, i64 16)
  call void @vd_gc_poll()
  %104 = call i1 @vd_worker_checkpoint(ptr %2)
  br i1 %104, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %103)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store ptr %1, ptr %36, align 8, !dbg !518
  store ptr %1, ptr %4, align 8, !dbg !518
  %105 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !519
  store %"/@stdlib/console.void::output" %105, ptr %6, align 8, !dbg !519
  %106 = load ptr, ptr %4, align 8, !dbg !520
  store ptr %106, ptr %41, align 8, !dbg !520
  store ptr %106, ptr %7, align 8, !dbg !520
  %107 = load %"/@stdlib/console.void::output", ptr %6, align 8, !dbg !521
  %108 = load ptr, ptr %7, align 8, !dbg !521
  store ptr %108, ptr %46, align 8, !dbg !521
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %51, align 8, !dbg !521
  store [8 x i64] zeroinitializer, ptr %3, align 8, !dbg !521
  %109 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 6, !dbg !521
  %110 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 7, !dbg !521
  %111 = extractvalue %"/@stdlib/console.void::output" %107, 0, !dbg !521
  call void @vd_console_v2(ptr %109, ptr %110, ptr %3, i32 16, i64 %111, ptr %46, i64 0, i64 -1, ptr %2), !dbg !521
  %112 = load ptr, ptr %2, align 8, !dbg !521
  %113 = icmp ne ptr %112, null, !dbg !521
  br i1 %113, label %selected.failure, label %selected.valid, !dbg !521

selected.failure:                                 ; preds = %worker.continue
  %114 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !521
  %115 = load i32, ptr %114, align 4, !dbg !521
  %116 = icmp ult i32 %115, 32, !dbg !521
  br i1 %116, label %trace_caller, label %trace_limit, !dbg !521

selected.valid:                                   ; preds = %worker.continue
  %117 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 0, !dbg !521
  %118 = load i64, ptr %117, align 8, !dbg !521
  %119 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 0, !dbg !521
  store i64 %118, ptr %119, align 8, !dbg !521
  %120 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 1, !dbg !521
  %121 = load i64, ptr %120, align 8, !dbg !521
  %122 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 1, !dbg !521
  store i64 %121, ptr %122, align 8, !dbg !521
  %123 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 2, !dbg !521
  %124 = load i64, ptr %123, align 8, !dbg !521
  %125 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 2, !dbg !521
  store i64 %124, ptr %125, align 8, !dbg !521
  %126 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 3, !dbg !521
  %127 = load i64, ptr %126, align 8, !dbg !521
  %128 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 3, !dbg !521
  store i64 %127, ptr %128, align 8, !dbg !521
  %129 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 4, !dbg !521
  %130 = load i64, ptr %129, align 8, !dbg !521
  %131 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 4, !dbg !521
  store i64 %130, ptr %131, align 8, !dbg !521
  %132 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 5, !dbg !521
  %133 = load i64, ptr %132, align 8, !dbg !521
  %134 = trunc i64 %133 to i1, !dbg !521
  %135 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 5, !dbg !521
  store i1 %134, ptr %135, align 1, !dbg !521
  %136 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 6, !dbg !521
  %137 = load i64, ptr %136, align 8, !dbg !521
  %138 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 8, !dbg !521
  store i64 %137, ptr %138, align 8, !dbg !521
  %139 = getelementptr inbounds [8 x i64], ptr %3, i32 0, i32 7, !dbg !521
  %140 = load i64, ptr %139, align 8, !dbg !521
  %141 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %51, i32 0, i32 9, !dbg !521
  store i64 %140, ptr %141, align 8, !dbg !521
  %142 = load %"/@stdlib/console.void::_reply", ptr %51, align 8, !dbg !521
  store %"/@stdlib/console.void::_reply" %142, ptr %51, align 8, !dbg !521
  store %"/@stdlib/console.void::_reply" %142, ptr %5, align 8, !dbg !521
  call void @vd_string_literal(ptr %56, ptr @186, i64 9, ptr %2), !dbg !522
  %143 = load ptr, ptr %56, align 8, !dbg !522
  %144 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !522
  %145 = load ptr, ptr %144, align 8, !dbg !522
  %146 = icmp ne ptr %145, null, !dbg !522
  br i1 %146, label %numeric_error, label %numeric_valid, !dbg !522

trace_caller:                                     ; preds = %selected.failure
  %147 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !521
  %148 = getelementptr [32 x ptr], ptr %147, i32 0, i32 %115, !dbg !521
  store ptr @185, ptr %148, align 8, !dbg !521
  %149 = add i32 %115, 1, !dbg !521
  store i32 %149, ptr %114, align 4, !dbg !521
  br label %error_return, !dbg !521

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %103), !dbg !521
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !521

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %114, align 4, !dbg !521
  br label %error_return, !dbg !521

numeric_error:                                    ; preds = %selected.valid
  %150 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !522
  store ptr @187, ptr %150, align 8, !dbg !522
  call void @vd_gc_frame_leave(ptr %103), !dbg !522
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !522

numeric_valid:                                    ; preds = %selected.valid
  store ptr %143, ptr %56, align 8, !dbg !522
  store ptr %143, ptr %8, align 8, !dbg !522
  %151 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !523
  store %"/@stdlib/console.void::output" %151, ptr %10, align 8, !dbg !523
  %152 = load %"/@stdlib/console.void::output", ptr %10, align 8, !dbg !524
  %153 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %152, ptr %2), !dbg !524
  %154 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !524
  %155 = load ptr, ptr %154, align 8, !dbg !524
  %156 = icmp ne ptr %155, null, !dbg !524
  br i1 %156, label %propagate_error, label %call_success, !dbg !524

propagate_error:                                  ; preds = %numeric_valid
  %157 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !524
  %158 = load i32, ptr %157, align 4, !dbg !524
  %159 = icmp ult i32 %158, 32, !dbg !524
  br i1 %159, label %trace_caller1, label %trace_limit3, !dbg !524

call_success:                                     ; preds = %numeric_valid
  store ptr %153, ptr %61, align 8, !dbg !524
  store ptr %153, ptr %9, align 8, !dbg !524
  %160 = load %"/@stdlib/console.void::_reply", ptr %5, align 8, !dbg !525
  store %"/@stdlib/console.void::_reply" %160, ptr %66, align 8, !dbg !525
  %161 = load ptr, ptr %8, align 8, !dbg !525
  store ptr %161, ptr %71, align 8, !dbg !525
  %162 = load ptr, ptr %9, align 8, !dbg !525
  store ptr %162, ptr %76, align 8, !dbg !525
  %163 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %160, ptr %161, ptr %162, ptr %2), !dbg !525
  %164 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 0, !dbg !525
  %165 = load ptr, ptr %164, align 8, !dbg !525
  %166 = icmp ne ptr %165, null, !dbg !525
  br i1 %166, label %propagate_error4, label %call_success5, !dbg !525

trace_caller1:                                    ; preds = %propagate_error
  %167 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !524
  %168 = getelementptr [32 x ptr], ptr %167, i32 0, i32 %158, !dbg !524
  store ptr @188, ptr %168, align 8, !dbg !524
  %169 = add i32 %158, 1, !dbg !524
  store i32 %169, ptr %157, align 4, !dbg !524
  br label %error_return2, !dbg !524

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %103), !dbg !524
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !524

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %157, align 4, !dbg !524
  br label %error_return2, !dbg !524

propagate_error4:                                 ; preds = %call_success
  %170 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 1, !dbg !525
  %171 = load i32, ptr %170, align 4, !dbg !525
  %172 = icmp ult i32 %171, 32, !dbg !525
  br i1 %172, label %trace_caller6, label %trace_limit8, !dbg !525

call_success5:                                    ; preds = %call_success
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %163, ptr %81, align 8, !dbg !525
  call void @vd_gc_frame_leave(ptr %103), !dbg !525
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %163, !dbg !525

trace_caller6:                                    ; preds = %propagate_error4
  %173 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %2, i32 0, i32 2, !dbg !525
  %174 = getelementptr [32 x ptr], ptr %173, i32 0, i32 %171, !dbg !525
  store ptr @189, ptr %174, align 8, !dbg !525
  %175 = add i32 %171, 1, !dbg !525
  store i32 %175, ptr %170, align 4, !dbg !525
  br label %error_return7, !dbg !525

error_return7:                                    ; preds = %trace_caller6, %trace_limit8
  call void @vd_gc_frame_leave(ptr %103), !dbg !525
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !525

trace_limit8:                                     ; preds = %propagate_error4
  store i32 33, ptr %170, align 4, !dbg !525
  br label %error_return7, !dbg !525
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a62656c6c__v1(ptr %0, ptr %1) !dbg !526 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %7, align 8
  %8 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 80, 1
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, ptr @gc.offsets.356, 2
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 2, 3
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 8, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.357, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 1, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 8, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.358, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 1, 3
  %20 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %20, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 80, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.359, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 2, 3
  %25 = alloca ptr, align 8
  store ptr null, ptr %25, align 8
  %26 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %25, 0
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 8, 1
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, ptr @gc.offsets.360, 2
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 1, 3
  %30 = alloca ptr, align 8
  store ptr null, ptr %30, align 8
  %31 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %30, 0
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 8, 1
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, ptr @gc.offsets.361, 2
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 1, 3
  %35 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %35, align 8
  %36 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %35, 0
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 80, 1
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, ptr @gc.offsets.362, 2
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 2, 3
  %40 = alloca ptr, align 8
  store ptr null, ptr %40, align 8
  %41 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %40, 0
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 8, 1
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, ptr @gc.offsets.363, 2
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 1, 3
  %45 = alloca ptr, align 8
  store ptr null, ptr %45, align 8
  %46 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %45, 0
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 8, 1
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, ptr @gc.offsets.364, 2
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 1, 3
  %50 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %50, align 8
  %51 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %50, 0
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 80, 1
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, ptr @gc.offsets.365, 2
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 4, 3
  %55 = alloca [10 x { ptr, i64, ptr, i64 }], align 8
  %56 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %11, ptr %56, align 8
  %57 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %15, ptr %57, align 8
  %58 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %19, ptr %58, align 8
  %59 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %24, ptr %59, align 8
  %60 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %29, ptr %60, align 8
  %61 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %34, ptr %61, align 8
  %62 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %39, ptr %62, align 8
  %63 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %44, ptr %63, align 8
  %64 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %49, ptr %64, align 8
  %65 = getelementptr inbounds [10 x { ptr, i64, ptr, i64 }], ptr %55, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %54, ptr %65, align 8
  %66 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %66, ptr %55, i64 10)
  call void @vd_gc_poll()
  %67 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %67, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %66)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %68 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !527
  store %"/@stdlib/console.void::output" %68, ptr %4, align 8, !dbg !527
  %69 = load %"/@stdlib/console.void::output", ptr %4, align 8, !dbg !528
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %20, align 8, !dbg !528
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !528
  %70 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 6, !dbg !528
  %71 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 7, !dbg !528
  %72 = extractvalue %"/@stdlib/console.void::output" %69, 0, !dbg !528
  call void @vd_console_v2(ptr %70, ptr %71, ptr %2, i32 17, i64 %72, ptr null, i64 0, i64 -1, ptr %1), !dbg !528
  %73 = load ptr, ptr %1, align 8, !dbg !528
  %74 = icmp ne ptr %73, null, !dbg !528
  br i1 %74, label %selected.failure, label %selected.valid, !dbg !528

selected.failure:                                 ; preds = %worker.continue
  %75 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !528
  %76 = load i32, ptr %75, align 4, !dbg !528
  %77 = icmp ult i32 %76, 32, !dbg !528
  br i1 %77, label %trace_caller, label %trace_limit, !dbg !528

selected.valid:                                   ; preds = %worker.continue
  %78 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !528
  %79 = load i64, ptr %78, align 8, !dbg !528
  %80 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 0, !dbg !528
  store i64 %79, ptr %80, align 8, !dbg !528
  %81 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !528
  %82 = load i64, ptr %81, align 8, !dbg !528
  %83 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 1, !dbg !528
  store i64 %82, ptr %83, align 8, !dbg !528
  %84 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !528
  %85 = load i64, ptr %84, align 8, !dbg !528
  %86 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 2, !dbg !528
  store i64 %85, ptr %86, align 8, !dbg !528
  %87 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !528
  %88 = load i64, ptr %87, align 8, !dbg !528
  %89 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 3, !dbg !528
  store i64 %88, ptr %89, align 8, !dbg !528
  %90 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !528
  %91 = load i64, ptr %90, align 8, !dbg !528
  %92 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 4, !dbg !528
  store i64 %91, ptr %92, align 8, !dbg !528
  %93 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !528
  %94 = load i64, ptr %93, align 8, !dbg !528
  %95 = trunc i64 %94 to i1, !dbg !528
  %96 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 5, !dbg !528
  store i1 %95, ptr %96, align 1, !dbg !528
  %97 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !528
  %98 = load i64, ptr %97, align 8, !dbg !528
  %99 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 8, !dbg !528
  store i64 %98, ptr %99, align 8, !dbg !528
  %100 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !528
  %101 = load i64, ptr %100, align 8, !dbg !528
  %102 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %20, i32 0, i32 9, !dbg !528
  store i64 %101, ptr %102, align 8, !dbg !528
  %103 = load %"/@stdlib/console.void::_reply", ptr %20, align 8, !dbg !528
  store %"/@stdlib/console.void::_reply" %103, ptr %20, align 8, !dbg !528
  store %"/@stdlib/console.void::_reply" %103, ptr %3, align 8, !dbg !528
  call void @vd_string_literal(ptr %25, ptr @191, i64 4, ptr %1), !dbg !529
  %104 = load ptr, ptr %25, align 8, !dbg !529
  %105 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !529
  %106 = load ptr, ptr %105, align 8, !dbg !529
  %107 = icmp ne ptr %106, null, !dbg !529
  br i1 %107, label %numeric_error, label %numeric_valid, !dbg !529

trace_caller:                                     ; preds = %selected.failure
  %108 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !528
  %109 = getelementptr [32 x ptr], ptr %108, i32 0, i32 %76, !dbg !528
  store ptr @190, ptr %109, align 8, !dbg !528
  %110 = add i32 %76, 1, !dbg !528
  store i32 %110, ptr %75, align 4, !dbg !528
  br label %error_return, !dbg !528

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %66), !dbg !528
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !528

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %75, align 4, !dbg !528
  br label %error_return, !dbg !528

numeric_error:                                    ; preds = %selected.valid
  %111 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !529
  store ptr @192, ptr %111, align 8, !dbg !529
  call void @vd_gc_frame_leave(ptr %66), !dbg !529
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !529

numeric_valid:                                    ; preds = %selected.valid
  store ptr %104, ptr %25, align 8, !dbg !529
  store ptr %104, ptr %5, align 8, !dbg !529
  %112 = load %"/@stdlib/console.void::output", ptr %0, align 8, !dbg !530
  store %"/@stdlib/console.void::output" %112, ptr %7, align 8, !dbg !530
  %113 = load %"/@stdlib/console.void::output", ptr %7, align 8, !dbg !531
  %114 = call ptr @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1(%"/@stdlib/console.void::output" %113, ptr %1), !dbg !531
  %115 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !531
  %116 = load ptr, ptr %115, align 8, !dbg !531
  %117 = icmp ne ptr %116, null, !dbg !531
  br i1 %117, label %propagate_error, label %call_success, !dbg !531

propagate_error:                                  ; preds = %numeric_valid
  %118 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !531
  %119 = load i32, ptr %118, align 4, !dbg !531
  %120 = icmp ult i32 %119, 32, !dbg !531
  br i1 %120, label %trace_caller1, label %trace_limit3, !dbg !531

call_success:                                     ; preds = %numeric_valid
  store ptr %114, ptr %30, align 8, !dbg !531
  store ptr %114, ptr %6, align 8, !dbg !531
  %121 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !532
  store %"/@stdlib/console.void::_reply" %121, ptr %35, align 8, !dbg !532
  %122 = load ptr, ptr %5, align 8, !dbg !532
  store ptr %122, ptr %40, align 8, !dbg !532
  %123 = load ptr, ptr %6, align 8, !dbg !532
  store ptr %123, ptr %45, align 8, !dbg !532
  %124 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %121, ptr %122, ptr %123, ptr %1), !dbg !532
  %125 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !532
  %126 = load ptr, ptr %125, align 8, !dbg !532
  %127 = icmp ne ptr %126, null, !dbg !532
  br i1 %127, label %propagate_error4, label %call_success5, !dbg !532

trace_caller1:                                    ; preds = %propagate_error
  %128 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !531
  %129 = getelementptr [32 x ptr], ptr %128, i32 0, i32 %119, !dbg !531
  store ptr @193, ptr %129, align 8, !dbg !531
  %130 = add i32 %119, 1, !dbg !531
  store i32 %130, ptr %118, align 4, !dbg !531
  br label %error_return2, !dbg !531

error_return2:                                    ; preds = %trace_caller1, %trace_limit3
  call void @vd_gc_frame_leave(ptr %66), !dbg !531
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !531

trace_limit3:                                     ; preds = %propagate_error
  store i32 33, ptr %118, align 4, !dbg !531
  br label %error_return2, !dbg !531

propagate_error4:                                 ; preds = %call_success
  %131 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !532
  %132 = load i32, ptr %131, align 4, !dbg !532
  %133 = icmp ult i32 %132, 32, !dbg !532
  br i1 %133, label %trace_caller6, label %trace_limit8, !dbg !532

call_success5:                                    ; preds = %call_success
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %124, ptr %50, align 8, !dbg !532
  call void @vd_gc_frame_leave(ptr %66), !dbg !532
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %124, !dbg !532

trace_caller6:                                    ; preds = %propagate_error4
  %134 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !532
  %135 = getelementptr [32 x ptr], ptr %134, i32 0, i32 %132, !dbg !532
  store ptr @194, ptr %135, align 8, !dbg !532
  %136 = add i32 %132, 1, !dbg !532
  store i32 %136, ptr %131, align 4, !dbg !532
  br label %error_return7, !dbg !532

error_return7:                                    ; preds = %trace_caller6, %trace_limit8
  call void @vd_gc_frame_leave(ptr %66), !dbg !532
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !532

trace_limit8:                                     ; preds = %propagate_error4
  store i32 33, ptr %131, align 4, !dbg !532
  br label %error_return7, !dbg !532
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a636c6f7365__v1(ptr %0, ptr %1) !dbg !533 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 8, 1
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, ptr @gc.offsets.366, 2
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 1, 3
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 80, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.367, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 2, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 8, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.368, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 1, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 8, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.369, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 1, 3
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.370, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = alloca ptr, align 8
  store ptr null, ptr %28, align 8
  %29 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %28, 0
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 8, 1
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, ptr @gc.offsets.371, 2
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 1, 3
  %33 = alloca ptr, align 8
  store ptr null, ptr %33, align 8
  %34 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %33, 0
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 8, 1
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, ptr @gc.offsets.372, 2
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 1, 3
  %38 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %38, align 8
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %38, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 80, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.373, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 2, 3
  %43 = alloca ptr, align 8
  store ptr null, ptr %43, align 8
  %44 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %43, 0
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 8, 1
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, ptr @gc.offsets.374, 2
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 1, 3
  %48 = alloca ptr, align 8
  store ptr null, ptr %48, align 8
  %49 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %48, 0
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 8, 1
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, ptr @gc.offsets.375, 2
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 1, 3
  %53 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %53, align 8
  %54 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %53, 0
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 80, 1
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, ptr @gc.offsets.376, 2
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 2, 3
  %58 = alloca ptr, align 8
  store ptr null, ptr %58, align 8
  %59 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %58, 0
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 8, 1
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, ptr @gc.offsets.377, 2
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, i64 1, 3
  %63 = alloca ptr, align 8
  store ptr null, ptr %63, align 8
  %64 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %63, 0
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 8, 1
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, ptr @gc.offsets.378, 2
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, i64 1, 3
  %68 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %68, align 8
  %69 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %68, 0
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 80, 1
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, ptr @gc.offsets.379, 2
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, i64 4, 3
  %73 = alloca [14 x { ptr, i64, ptr, i64 }], align 8
  %74 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %11, ptr %74, align 8
  %75 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %15, ptr %75, align 8
  %76 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %19, ptr %76, align 8
  %77 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %23, ptr %77, align 8
  %78 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %27, ptr %78, align 8
  %79 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %32, ptr %79, align 8
  %80 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %37, ptr %80, align 8
  %81 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %42, ptr %81, align 8
  %82 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %47, ptr %82, align 8
  %83 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %52, ptr %83, align 8
  %84 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %57, ptr %84, align 8
  %85 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %62, ptr %85, align 8
  %86 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %67, ptr %86, align 8
  %87 = getelementptr inbounds [14 x { ptr, i64, ptr, i64 }], ptr %73, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %72, ptr %87, align 8
  %88 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %88, ptr %73, i64 14)
  call void @vd_gc_poll()
  %89 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %89, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %88)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %90 = load ptr, ptr %3, align 8, !dbg !537
  store ptr %90, ptr %28, align 8, !dbg !537
  store ptr %90, ptr %5, align 8, !dbg !537
  %91 = load ptr, ptr %5, align 8, !dbg !538
  store ptr %91, ptr %33, align 8, !dbg !538
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %38, align 8, !dbg !538
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !538
  %92 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 6, !dbg !538
  %93 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 7, !dbg !538
  %94 = icmp eq ptr %91, null, !dbg !538
  br i1 %94, label %numeric_error, label %numeric_valid, !dbg !538

numeric_error:                                    ; preds = %worker.continue
  %95 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !538
  store ptr @195, ptr %95, align 8, !dbg !538
  call void @vd_gc_frame_leave(ptr %88), !dbg !538
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !538

numeric_valid:                                    ; preds = %worker.continue
  %96 = getelementptr %"/@stdlib/console.void::terminal_session", ptr %91, i32 0, i32 0, !dbg !538
  %97 = load i64, ptr %96, align 8, !dbg !538
  call void @vd_console_v2(ptr %92, ptr %93, ptr %2, i32 21, i64 0, ptr null, i64 %97, i64 -1, ptr %1), !dbg !538
  %98 = load ptr, ptr %1, align 8, !dbg !538
  %99 = icmp ne ptr %98, null, !dbg !538
  br i1 %99, label %selected.failure, label %selected.valid, !dbg !538

selected.failure:                                 ; preds = %numeric_valid
  %100 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !538
  %101 = load i32, ptr %100, align 4, !dbg !538
  %102 = icmp ult i32 %101, 32, !dbg !538
  br i1 %102, label %trace_caller, label %trace_limit, !dbg !538

selected.valid:                                   ; preds = %numeric_valid
  %103 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !538
  %104 = load i64, ptr %103, align 8, !dbg !538
  %105 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 0, !dbg !538
  store i64 %104, ptr %105, align 8, !dbg !538
  %106 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !538
  %107 = load i64, ptr %106, align 8, !dbg !538
  %108 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 1, !dbg !538
  store i64 %107, ptr %108, align 8, !dbg !538
  %109 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !538
  %110 = load i64, ptr %109, align 8, !dbg !538
  %111 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 2, !dbg !538
  store i64 %110, ptr %111, align 8, !dbg !538
  %112 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !538
  %113 = load i64, ptr %112, align 8, !dbg !538
  %114 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 3, !dbg !538
  store i64 %113, ptr %114, align 8, !dbg !538
  %115 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !538
  %116 = load i64, ptr %115, align 8, !dbg !538
  %117 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 4, !dbg !538
  store i64 %116, ptr %117, align 8, !dbg !538
  %118 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !538
  %119 = load i64, ptr %118, align 8, !dbg !538
  %120 = trunc i64 %119 to i1, !dbg !538
  %121 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 5, !dbg !538
  store i1 %120, ptr %121, align 1, !dbg !538
  %122 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !538
  %123 = load i64, ptr %122, align 8, !dbg !538
  %124 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 8, !dbg !538
  store i64 %123, ptr %124, align 8, !dbg !538
  %125 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !538
  %126 = load i64, ptr %125, align 8, !dbg !538
  %127 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %38, i32 0, i32 9, !dbg !538
  store i64 %126, ptr %127, align 8, !dbg !538
  %128 = load %"/@stdlib/console.void::_reply", ptr %38, align 8, !dbg !538
  store %"/@stdlib/console.void::_reply" %128, ptr %38, align 8, !dbg !538
  store %"/@stdlib/console.void::_reply" %128, ptr %4, align 8, !dbg !538
  call void @vd_string_literal(ptr %43, ptr @197, i64 10, ptr %1), !dbg !539
  %129 = load ptr, ptr %43, align 8, !dbg !539
  %130 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !539
  %131 = load ptr, ptr %130, align 8, !dbg !539
  %132 = icmp ne ptr %131, null, !dbg !539
  br i1 %132, label %numeric_error1, label %numeric_valid2, !dbg !539

trace_caller:                                     ; preds = %selected.failure
  %133 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !538
  %134 = getelementptr [32 x ptr], ptr %133, i32 0, i32 %101, !dbg !538
  store ptr @196, ptr %134, align 8, !dbg !538
  %135 = add i32 %101, 1, !dbg !538
  store i32 %135, ptr %100, align 4, !dbg !538
  br label %error_return, !dbg !538

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %88), !dbg !538
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !538

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %100, align 4, !dbg !538
  br label %error_return, !dbg !538

numeric_error1:                                   ; preds = %selected.valid
  %136 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !539
  store ptr @198, ptr %136, align 8, !dbg !539
  call void @vd_gc_frame_leave(ptr %88), !dbg !539
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !539

numeric_valid2:                                   ; preds = %selected.valid
  store ptr %129, ptr %43, align 8, !dbg !539
  store ptr %129, ptr %6, align 8, !dbg !539
  call void @vd_string_literal(ptr %48, ptr @199, i64 5, ptr %1), !dbg !540
  %137 = load ptr, ptr %48, align 8, !dbg !540
  %138 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !540
  %139 = load ptr, ptr %138, align 8, !dbg !540
  %140 = icmp ne ptr %139, null, !dbg !540
  br i1 %140, label %numeric_error3, label %numeric_valid4, !dbg !540

numeric_error3:                                   ; preds = %numeric_valid2
  %141 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !540
  store ptr @200, ptr %141, align 8, !dbg !540
  call void @vd_gc_frame_leave(ptr %88), !dbg !540
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !540

numeric_valid4:                                   ; preds = %numeric_valid2
  store ptr %137, ptr %48, align 8, !dbg !540
  store ptr %137, ptr %7, align 8, !dbg !540
  %142 = load %"/@stdlib/console.void::_reply", ptr %4, align 8, !dbg !541
  store %"/@stdlib/console.void::_reply" %142, ptr %53, align 8, !dbg !541
  %143 = load ptr, ptr %6, align 8, !dbg !541
  store ptr %143, ptr %58, align 8, !dbg !541
  %144 = load ptr, ptr %7, align 8, !dbg !541
  store ptr %144, ptr %63, align 8, !dbg !541
  %145 = call %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1(%"/@stdlib/console.void::_reply" %142, ptr %143, ptr %144, ptr %1), !dbg !541
  %146 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !541
  %147 = load ptr, ptr %146, align 8, !dbg !541
  %148 = icmp ne ptr %147, null, !dbg !541
  br i1 %148, label %propagate_error, label %call_success, !dbg !541

propagate_error:                                  ; preds = %numeric_valid4
  %149 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !541
  %150 = load i32, ptr %149, align 4, !dbg !541
  %151 = icmp ult i32 %150, 32, !dbg !541
  br i1 %151, label %trace_caller5, label %trace_limit7, !dbg !541

call_success:                                     ; preds = %numeric_valid4
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %145, ptr %68, align 8, !dbg !541
  call void @vd_gc_frame_leave(ptr %88), !dbg !541
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %145, !dbg !541

trace_caller5:                                    ; preds = %propagate_error
  %152 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !541
  %153 = getelementptr [32 x ptr], ptr %152, i32 0, i32 %150, !dbg !541
  store ptr @201, ptr %153, align 8, !dbg !541
  %154 = add i32 %150, 1, !dbg !541
  store i32 %154, ptr %149, align 4, !dbg !541
  br label %error_return6, !dbg !541

error_return6:                                    ; preds = %trace_caller5, %trace_limit7
  call void @vd_gc_frame_leave(ptr %88), !dbg !541
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !541

trace_limit7:                                     ; preds = %propagate_error
  store i32 33, ptr %149, align 4, !dbg !541
  br label %error_return6, !dbg !541
}

define void @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a6465696e6974__v1(ptr %0, ptr %1) !dbg !542 {
block0:
  %2 = alloca ptr, align 8
  store ptr %0, ptr %2, align 8
  %3 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %2, 0
  %4 = insertvalue { ptr, i64, ptr, i64 } %3, i64 8, 1
  %5 = insertvalue { ptr, i64, ptr, i64 } %4, ptr @gc.offsets.380, 2
  %6 = insertvalue { ptr, i64, ptr, i64 } %5, i64 1, 3
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 8, 1
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, ptr @gc.offsets.381, 2
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 1, 3
  %12 = alloca [2 x { ptr, i64, ptr, i64 }], align 8
  %13 = getelementptr inbounds [2 x { ptr, i64, ptr, i64 }], ptr %12, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %6, ptr %13, align 8
  %14 = getelementptr inbounds [2 x { ptr, i64, ptr, i64 }], ptr %12, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %11, ptr %14, align 8
  %15 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %15, ptr %12, i64 2)
  call void @vd_async_cleanup_enter()
  call void @vd_gc_poll()
  %16 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %16, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !545
  %17 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !545
  br i1 %17, label %worker.cancelled1, label %worker.continue2, !dbg !545

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !545
  %18 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !545
  br i1 %18, label %worker.cancelled3, label %worker.continue4, !dbg !545

worker.cancelled:                                 ; preds = %block0
  call void @vd_async_cleanup_leave()
  call void @vd_gc_frame_leave(ptr %15)
  ret void

worker.continue:                                  ; preds = %block0
  %19 = load ptr, ptr %2, align 8, !dbg !545
  store ptr %19, ptr %7, align 8, !dbg !545
  %20 = call i1 @vd_gc_release(ptr %19), !dbg !545
  br i1 %20, label %block1, label %block2, !dbg !545

worker.cancelled1:                                ; preds = %block1
  call void @vd_async_cleanup_leave(), !dbg !545
  call void @vd_gc_frame_leave(ptr %15), !dbg !545
  ret void, !dbg !545

worker.continue2:                                 ; preds = %block1
  %21 = load ptr, ptr %2, align 8, !dbg !545
  call void @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a6465696e69743a3a24626f6479242f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e__v1(ptr %21, ptr %1), !dbg !545
  %22 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !545
  %23 = load ptr, ptr %22, align 8, !dbg !545
  %24 = icmp ne ptr %23, null, !dbg !545
  br i1 %24, label %propagate_error, label %call_success, !dbg !545

propagate_error:                                  ; preds = %worker.continue2
  %25 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !545
  %26 = load i32, ptr %25, align 4, !dbg !545
  %27 = icmp ult i32 %26, 32, !dbg !545
  br i1 %27, label %trace_caller, label %trace_limit, !dbg !545

call_success:                                     ; preds = %worker.continue2
  call void @vd_async_cleanup_leave(), !dbg !545
  call void @vd_gc_frame_leave(ptr %15), !dbg !545
  ret void, !dbg !545

trace_caller:                                     ; preds = %propagate_error
  %28 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !545
  %29 = getelementptr [32 x ptr], ptr %28, i32 0, i32 %26, !dbg !545
  store ptr @202, ptr %29, align 8, !dbg !545
  %30 = add i32 %26, 1, !dbg !545
  store i32 %30, ptr %25, align 4, !dbg !545
  br label %error_return, !dbg !545

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_async_cleanup_leave(), !dbg !545
  call void @vd_gc_frame_leave(ptr %15), !dbg !545
  ret void, !dbg !545

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %25, align 4, !dbg !545
  br label %error_return, !dbg !545

worker.cancelled3:                                ; preds = %block2
  call void @vd_async_cleanup_leave(), !dbg !545
  call void @vd_gc_frame_leave(ptr %15), !dbg !545
  ret void, !dbg !545

worker.continue4:                                 ; preds = %block2
  call void @vd_async_cleanup_leave(), !dbg !545
  call void @vd_gc_frame_leave(ptr %15), !dbg !545
  ret void, !dbg !545
}

define internal void @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a6465696e69743a3a24626f6479242f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e__v1(ptr %0, ptr %1) !dbg !546 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca ptr, align 8
  store ptr %0, ptr %3, align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %6 = insertvalue { ptr, i64, ptr, i64 } %5, i64 8, 1
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, ptr @gc.offsets.382, 2
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, i64 1, 3
  %9 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %10 = insertvalue { ptr, i64, ptr, i64 } %9, i64 8, 1
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, ptr @gc.offsets.383, 2
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, i64 1, 3
  %13 = alloca ptr, align 8
  store ptr null, ptr %13, align 8
  %14 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 8, 1
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, ptr @gc.offsets.384, 2
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 1, 3
  %18 = alloca ptr, align 8
  store ptr null, ptr %18, align 8
  %19 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %18, 0
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 8, 1
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, ptr @gc.offsets.385, 2
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 1, 3
  %23 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %23, align 8
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %23, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 80, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.386, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 2, 3
  %28 = alloca [5 x { ptr, i64, ptr, i64 }], align 8
  %29 = getelementptr inbounds [5 x { ptr, i64, ptr, i64 }], ptr %28, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %8, ptr %29, align 8
  %30 = getelementptr inbounds [5 x { ptr, i64, ptr, i64 }], ptr %28, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %12, ptr %30, align 8
  %31 = getelementptr inbounds [5 x { ptr, i64, ptr, i64 }], ptr %28, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %17, ptr %31, align 8
  %32 = getelementptr inbounds [5 x { ptr, i64, ptr, i64 }], ptr %28, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %22, ptr %32, align 8
  %33 = getelementptr inbounds [5 x { ptr, i64, ptr, i64 }], ptr %28, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %27, ptr %33, align 8
  %34 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %34, ptr %28, i64 5)
  call void @vd_async_cleanup_enter()
  call void @vd_gc_poll()
  %35 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %35, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_async_cleanup_leave()
  call void @vd_gc_frame_leave(ptr %34)
  ret void

worker.continue:                                  ; preds = %block0
  %36 = load ptr, ptr %3, align 8, !dbg !547
  store ptr %36, ptr %13, align 8, !dbg !547
  store ptr %36, ptr %4, align 8, !dbg !547
  %37 = load ptr, ptr %4, align 8, !dbg !548
  store ptr %37, ptr %18, align 8, !dbg !548
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %23, align 8, !dbg !548
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !548
  %38 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 6, !dbg !548
  %39 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 7, !dbg !548
  %40 = icmp eq ptr %37, null, !dbg !548
  br i1 %40, label %numeric_error, label %numeric_valid, !dbg !548

numeric_error:                                    ; preds = %worker.continue
  %41 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !548
  store ptr @203, ptr %41, align 8, !dbg !548
  call void @vd_async_cleanup_leave(), !dbg !548
  call void @vd_gc_frame_leave(ptr %34), !dbg !548
  ret void, !dbg !548

numeric_valid:                                    ; preds = %worker.continue
  %42 = getelementptr %"/@stdlib/console.void::terminal_session", ptr %37, i32 0, i32 0, !dbg !548
  %43 = load i64, ptr %42, align 8, !dbg !548
  call void @vd_console_v2(ptr %38, ptr %39, ptr %2, i32 22, i64 0, ptr null, i64 %43, i64 -1, ptr %1), !dbg !548
  %44 = load ptr, ptr %1, align 8, !dbg !548
  %45 = icmp ne ptr %44, null, !dbg !548
  br i1 %45, label %selected.failure, label %selected.valid, !dbg !548

selected.failure:                                 ; preds = %numeric_valid
  %46 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !548
  %47 = load i32, ptr %46, align 4, !dbg !548
  %48 = icmp ult i32 %47, 32, !dbg !548
  br i1 %48, label %trace_caller, label %trace_limit, !dbg !548

selected.valid:                                   ; preds = %numeric_valid
  %49 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !548
  %50 = load i64, ptr %49, align 8, !dbg !548
  %51 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 0, !dbg !548
  store i64 %50, ptr %51, align 8, !dbg !548
  %52 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !548
  %53 = load i64, ptr %52, align 8, !dbg !548
  %54 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 1, !dbg !548
  store i64 %53, ptr %54, align 8, !dbg !548
  %55 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !548
  %56 = load i64, ptr %55, align 8, !dbg !548
  %57 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 2, !dbg !548
  store i64 %56, ptr %57, align 8, !dbg !548
  %58 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !548
  %59 = load i64, ptr %58, align 8, !dbg !548
  %60 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 3, !dbg !548
  store i64 %59, ptr %60, align 8, !dbg !548
  %61 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !548
  %62 = load i64, ptr %61, align 8, !dbg !548
  %63 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 4, !dbg !548
  store i64 %62, ptr %63, align 8, !dbg !548
  %64 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !548
  %65 = load i64, ptr %64, align 8, !dbg !548
  %66 = trunc i64 %65 to i1, !dbg !548
  %67 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 5, !dbg !548
  store i1 %66, ptr %67, align 1, !dbg !548
  %68 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !548
  %69 = load i64, ptr %68, align 8, !dbg !548
  %70 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 8, !dbg !548
  store i64 %69, ptr %70, align 8, !dbg !548
  %71 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !548
  %72 = load i64, ptr %71, align 8, !dbg !548
  %73 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %23, i32 0, i32 9, !dbg !548
  store i64 %72, ptr %73, align 8, !dbg !548
  %74 = load %"/@stdlib/console.void::_reply", ptr %23, align 8, !dbg !548
  store %"/@stdlib/console.void::_reply" %74, ptr %23, align 8, !dbg !548
  call void @vd_async_cleanup_leave(), !dbg !548
  call void @vd_gc_frame_leave(ptr %34), !dbg !548
  ret void, !dbg !548

trace_caller:                                     ; preds = %selected.failure
  %75 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !548
  %76 = getelementptr [32 x ptr], ptr %75, i32 0, i32 %47, !dbg !548
  store ptr @204, ptr %76, align 8, !dbg !548
  %77 = add i32 %47, 1, !dbg !548
  store i32 %77, ptr %46, align 4, !dbg !548
  br label %error_return, !dbg !548

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_async_cleanup_leave(), !dbg !548
  call void @vd_gc_frame_leave(ptr %34), !dbg !548
  ret void, !dbg !548

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %46, align 4, !dbg !548
  br label %error_return, !dbg !548
}

define %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a626567696e5f6d6f6465__v1(ptr %0, i1 %1, i1 %2, i1 %3, ptr %4) !dbg !549 {
block0:
  %5 = alloca [8 x i64], align 8
  %6 = alloca i8, i64 8, align 8
  %7 = alloca i1, align 1
  store i1 false, ptr %7, align 1
  %8 = alloca i1, align 1
  store i1 false, ptr %8, align 1
  %9 = alloca i1, align 1
  store i1 false, ptr %9, align 1
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %12, align 8
  %13 = alloca i64, align 8
  store i64 0, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = alloca i64, align 8
  store i64 0, ptr %15, align 8
  %16 = alloca i64, align 8
  store i64 0, ptr %16, align 8
  %17 = alloca i64, align 8
  store i64 0, ptr %17, align 8
  %18 = alloca i64, align 8
  store i64 0, ptr %18, align 8
  %19 = alloca i64, align 8
  store i64 0, ptr %19, align 8
  %20 = alloca i64, align 8
  store i64 0, ptr %20, align 8
  %21 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %21, align 8
  %22 = alloca i64, align 8
  store i64 0, ptr %22, align 8
  %23 = alloca i64, align 8
  store i64 0, ptr %23, align 8
  %24 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %24, align 8
  %25 = alloca ptr, align 8
  store ptr null, ptr %25, align 8
  %26 = alloca ptr, align 8
  store ptr null, ptr %26, align 8
  %27 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %27, align 8
  %28 = alloca ptr, align 8
  store ptr null, ptr %28, align 8
  %29 = alloca ptr, align 8
  store ptr null, ptr %29, align 8
  %30 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 8, 1
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, ptr @gc.offsets.387, 2
  %33 = insertvalue { ptr, i64, ptr, i64 } %32, i64 1, 3
  %34 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %12, 0
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 80, 1
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, ptr @gc.offsets.388, 2
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 2, 3
  %38 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %24, 0
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 80, 1
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, ptr @gc.offsets.389, 2
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 2, 3
  %42 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %25, 0
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, i64 8, 1
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, ptr @gc.offsets.390, 2
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 1, 3
  %46 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %26, 0
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 8, 1
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, ptr @gc.offsets.391, 2
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 1, 3
  %50 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %27, 0
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 72, 1
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, ptr @gc.offsets.392, 2
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 4, 3
  %54 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %28, 0
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 8, 1
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, ptr @gc.offsets.393, 2
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 1, 3
  %58 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %29, 0
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, i64 8, 1
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, ptr @gc.offsets.394, 2
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 1, 3
  %62 = alloca ptr, align 8
  store ptr null, ptr %62, align 8
  %63 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %62, 0
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, i64 8, 1
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, ptr @gc.offsets.395, 2
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, i64 1, 3
  %67 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %67, align 8
  %68 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %67, 0
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, i64 80, 1
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, ptr @gc.offsets.396, 2
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 2, 3
  %72 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %72, align 8
  %73 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %72, 0
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, i64 80, 1
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, ptr @gc.offsets.397, 2
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, i64 2, 3
  %77 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %77, align 8
  %78 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %77, 0
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, i64 80, 1
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, ptr @gc.offsets.398, 2
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, i64 2, 3
  %82 = alloca ptr, align 8
  store ptr null, ptr %82, align 8
  %83 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %82, 0
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, i64 8, 1
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, ptr @gc.offsets.399, 2
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, i64 1, 3
  %87 = alloca ptr, align 8
  store ptr null, ptr %87, align 8
  %88 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %87, 0
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, i64 8, 1
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, ptr @gc.offsets.400, 2
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, i64 1, 3
  %92 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %92, align 8
  %93 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %92, 0
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, i64 80, 1
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, ptr @gc.offsets.401, 2
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, i64 2, 3
  %97 = alloca ptr, align 8
  store ptr null, ptr %97, align 8
  %98 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %97, 0
  %99 = insertvalue { ptr, i64, ptr, i64 } %98, i64 8, 1
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, ptr @gc.offsets.402, 2
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, i64 1, 3
  %102 = alloca ptr, align 8
  store ptr null, ptr %102, align 8
  %103 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %102, 0
  %104 = insertvalue { ptr, i64, ptr, i64 } %103, i64 8, 1
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, ptr @gc.offsets.403, 2
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, i64 1, 3
  %107 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %107, align 8
  %108 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %107, 0
  %109 = insertvalue { ptr, i64, ptr, i64 } %108, i64 72, 1
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, ptr @gc.offsets.404, 2
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, i64 4, 3
  %112 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %112, align 8
  %113 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %112, 0
  %114 = insertvalue { ptr, i64, ptr, i64 } %113, i64 72, 1
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, ptr @gc.offsets.405, 2
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, i64 4, 3
  %117 = alloca %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %117, align 8
  %118 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %117, 0
  %119 = insertvalue { ptr, i64, ptr, i64 } %118, i64 88, 1
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, ptr @gc.offsets.406, 2
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, i64 5, 3
  %122 = alloca ptr, align 8
  store ptr null, ptr %122, align 8
  %123 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %122, 0
  %124 = insertvalue { ptr, i64, ptr, i64 } %123, i64 8, 1
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, ptr @gc.offsets.407, 2
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, i64 1, 3
  %127 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %127, align 8
  %128 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %127, 0
  %129 = insertvalue { ptr, i64, ptr, i64 } %128, i64 80, 1
  %130 = insertvalue { ptr, i64, ptr, i64 } %129, ptr @gc.offsets.408, 2
  %131 = insertvalue { ptr, i64, ptr, i64 } %130, i64 2, 3
  %132 = alloca ptr, align 8
  store ptr null, ptr %132, align 8
  %133 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %132, 0
  %134 = insertvalue { ptr, i64, ptr, i64 } %133, i64 8, 1
  %135 = insertvalue { ptr, i64, ptr, i64 } %134, ptr @gc.offsets.409, 2
  %136 = insertvalue { ptr, i64, ptr, i64 } %135, i64 1, 3
  %137 = alloca ptr, align 8
  store ptr null, ptr %137, align 8
  %138 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %137, 0
  %139 = insertvalue { ptr, i64, ptr, i64 } %138, i64 8, 1
  %140 = insertvalue { ptr, i64, ptr, i64 } %139, ptr @gc.offsets.410, 2
  %141 = insertvalue { ptr, i64, ptr, i64 } %140, i64 1, 3
  %142 = alloca ptr, align 8
  store ptr null, ptr %142, align 8
  %143 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %142, 0
  %144 = insertvalue { ptr, i64, ptr, i64 } %143, i64 8, 1
  %145 = insertvalue { ptr, i64, ptr, i64 } %144, ptr @gc.offsets.411, 2
  %146 = insertvalue { ptr, i64, ptr, i64 } %145, i64 1, 3
  %147 = alloca %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %147, align 8
  %148 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %147, 0
  %149 = insertvalue { ptr, i64, ptr, i64 } %148, i64 88, 1
  %150 = insertvalue { ptr, i64, ptr, i64 } %149, ptr @gc.offsets.412, 2
  %151 = insertvalue { ptr, i64, ptr, i64 } %150, i64 5, 3
  %152 = alloca [26 x { ptr, i64, ptr, i64 }], align 8
  %153 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %33, ptr %153, align 8
  %154 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %37, ptr %154, align 8
  %155 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %41, ptr %155, align 8
  %156 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %45, ptr %156, align 8
  %157 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %49, ptr %157, align 8
  %158 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %53, ptr %158, align 8
  %159 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %57, ptr %159, align 8
  %160 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %61, ptr %160, align 8
  %161 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %66, ptr %161, align 8
  %162 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %71, ptr %162, align 8
  %163 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %76, ptr %163, align 8
  %164 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %81, ptr %164, align 8
  %165 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %86, ptr %165, align 8
  %166 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %91, ptr %166, align 8
  %167 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %96, ptr %167, align 8
  %168 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %101, ptr %168, align 8
  %169 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %106, ptr %169, align 8
  %170 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %111, ptr %170, align 8
  %171 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %116, ptr %171, align 8
  %172 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %121, ptr %172, align 8
  %173 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %126, ptr %173, align 8
  %174 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %131, ptr %174, align 8
  %175 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %136, ptr %175, align 8
  %176 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %141, ptr %176, align 8
  %177 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 24
  store { ptr, i64, ptr, i64 } %146, ptr %177, align 8
  %178 = getelementptr inbounds [26 x { ptr, i64, ptr, i64 }], ptr %152, i32 0, i32 25
  store { ptr, i64, ptr, i64 } %151, ptr %178, align 8
  %179 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %179, ptr %152, i64 26)
  call void @vd_gc_poll()
  %180 = call i1 @vd_worker_checkpoint(ptr %4)
  br i1 %180, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !555
  %181 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !555
  br i1 %181, label %worker.cancelled1, label %worker.continue2, !dbg !555

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !556
  %182 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !556
  br i1 %182, label %worker.cancelled3, label %worker.continue4, !dbg !556

block3:                                           ; preds = %worker.continue4, %worker.continue2
  call void @vd_gc_poll(), !dbg !556
  %183 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !556
  br i1 %183, label %worker.cancelled5, label %worker.continue6, !dbg !556

block4:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !557
  %184 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !557
  br i1 %184, label %worker.cancelled7, label %worker.continue8, !dbg !557

block5:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !558
  %185 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !558
  br i1 %185, label %worker.cancelled9, label %worker.continue10, !dbg !558

block6:                                           ; preds = %worker.continue10, %worker.continue8
  call void @vd_gc_poll(), !dbg !558
  %186 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !558
  br i1 %186, label %worker.cancelled11, label %worker.continue12, !dbg !558

block7:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !559
  %187 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !559
  br i1 %187, label %worker.cancelled13, label %worker.continue14, !dbg !559

block8:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !560
  %188 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !560
  br i1 %188, label %worker.cancelled15, label %worker.continue16, !dbg !560

block9:                                           ; preds = %worker.continue16, %worker.continue14
  call void @vd_gc_poll(), !dbg !560
  %189 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !560
  br i1 %189, label %worker.cancelled17, label %worker.continue18, !dbg !560

block10:                                          ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !561
  %190 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !561
  br i1 %190, label %worker.cancelled19, label %worker.continue20, !dbg !561

block11:                                          ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !562
  %191 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !562
  br i1 %191, label %worker.cancelled32, label %worker.continue33, !dbg !562

block12:                                          ; preds = %worker.continue33
  call void @vd_gc_poll(), !dbg !562
  %192 = call i1 @vd_worker_checkpoint(ptr %4), !dbg !562
  br i1 %192, label %worker.cancelled34, label %worker.continue35, !dbg !562

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %179)
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i1 %1, ptr %7, align 1, !dbg !563
  store i1 %2, ptr %8, align 1, !dbg !564
  store i1 %3, ptr %9, align 1, !dbg !565
  store i64 0, ptr %10, align 8, !dbg !566
  %193 = load i1, ptr %7, align 1, !dbg !555
  br i1 %193, label %block1, label %block2, !dbg !555

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %179), !dbg !555
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !555

worker.continue2:                                 ; preds = %block1
  %194 = load i64, ptr %10, align 8, !dbg !556
  store i64 %194, ptr %13, align 8, !dbg !556
  store i64 1, ptr %14, align 8, !dbg !567
  %195 = load i64, ptr %13, align 8, !dbg !568
  %196 = load i64, ptr %14, align 8, !dbg !568
  %197 = add i64 %195, %196, !dbg !556
  store i64 %197, ptr %10, align 8, !dbg !556
  br label %block3, !dbg !556

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %179), !dbg !556
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !556

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !556

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %179), !dbg !556
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !556

worker.continue6:                                 ; preds = %block3
  %198 = load i1, ptr %8, align 1, !dbg !557
  br i1 %198, label %block4, label %block5, !dbg !557

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %179), !dbg !557
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !557

worker.continue8:                                 ; preds = %block4
  %199 = load i64, ptr %10, align 8, !dbg !558
  store i64 %199, ptr %15, align 8, !dbg !558
  store i64 2, ptr %16, align 8, !dbg !569
  %200 = load i64, ptr %15, align 8, !dbg !570
  %201 = load i64, ptr %16, align 8, !dbg !570
  %202 = add i64 %200, %201, !dbg !558
  store i64 %202, ptr %10, align 8, !dbg !558
  br label %block6, !dbg !558

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr %179), !dbg !558
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !558

worker.continue10:                                ; preds = %block5
  br label %block6, !dbg !558

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %179), !dbg !558
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !558

worker.continue12:                                ; preds = %block6
  %203 = load i1, ptr %9, align 1, !dbg !559
  br i1 %203, label %block7, label %block8, !dbg !559

worker.cancelled13:                               ; preds = %block7
  call void @vd_gc_frame_leave(ptr %179), !dbg !559
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !559

worker.continue14:                                ; preds = %block7
  %204 = load i64, ptr %10, align 8, !dbg !560
  store i64 %204, ptr %17, align 8, !dbg !560
  store i64 4, ptr %18, align 8, !dbg !571
  %205 = load i64, ptr %17, align 8, !dbg !572
  %206 = load i64, ptr %18, align 8, !dbg !572
  %207 = add i64 %205, %206, !dbg !560
  store i64 %207, ptr %10, align 8, !dbg !560
  br label %block9, !dbg !560

worker.cancelled15:                               ; preds = %block8
  call void @vd_gc_frame_leave(ptr %179), !dbg !560
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !560

worker.continue16:                                ; preds = %block8
  br label %block9, !dbg !560

worker.cancelled17:                               ; preds = %block9
  call void @vd_gc_frame_leave(ptr %179), !dbg !560
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !560

worker.continue18:                                ; preds = %block9
  store i64 0, ptr %19, align 8, !dbg !573
  %208 = load i64, ptr %19, align 8, !dbg !574
  store i64 %208, ptr %20, align 8, !dbg !574
  %209 = load i64, ptr %20, align 8, !dbg !574
  call void @llvm.memset.p0.i64(ptr align 8 %6, i8 0, i64 8, i1 false), !dbg !574
  %210 = getelementptr %"/@stdlib/console.void::terminal_session", ptr %6, i32 0, i32 0, !dbg !574
  store i64 %209, ptr %210, align 8, !dbg !574
  call void @vd_gc_construct_typed(ptr %62, i64 8, ptr @gc.offsets.413, i64 0, ptr %6, ptr @205, ptr %4), !dbg !574
  %211 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !574
  %212 = load ptr, ptr %211, align 8, !dbg !574
  %213 = icmp ne ptr %212, null, !dbg !574
  br i1 %213, label %numeric_error, label %numeric_valid, !dbg !574

numeric_error:                                    ; preds = %worker.continue18
  %214 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !574
  store ptr @206, ptr %214, align 8, !dbg !574
  call void @vd_gc_frame_leave(ptr %179), !dbg !574
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !574

numeric_valid:                                    ; preds = %worker.continue18
  %215 = load ptr, ptr %62, align 8, !dbg !574
  store ptr %215, ptr %62, align 8, !dbg !574
  store ptr %215, ptr %11, align 8, !dbg !575
  %216 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !576
  store %"/@stdlib/console.void::input" %216, ptr %21, align 8, !dbg !576
  %217 = load i64, ptr %10, align 8, !dbg !577
  store i64 %217, ptr %22, align 8, !dbg !577
  %218 = load %"/@stdlib/console.void::input", ptr %21, align 8, !dbg !578
  %219 = load i64, ptr %22, align 8, !dbg !578
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %67, align 8, !dbg !578
  store [8 x i64] zeroinitializer, ptr %5, align 8, !dbg !578
  %220 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 6, !dbg !578
  %221 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 7, !dbg !578
  %222 = extractvalue %"/@stdlib/console.void::input" %218, 0, !dbg !578
  call void @vd_console_v2(ptr %220, ptr %221, ptr %5, i32 20, i64 %222, ptr null, i64 %219, i64 -1, ptr %4), !dbg !578
  %223 = load ptr, ptr %4, align 8, !dbg !578
  %224 = icmp ne ptr %223, null, !dbg !578
  br i1 %224, label %selected.failure, label %selected.valid, !dbg !578

selected.failure:                                 ; preds = %numeric_valid
  %225 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 1, !dbg !578
  %226 = load i32, ptr %225, align 4, !dbg !578
  %227 = icmp ult i32 %226, 32, !dbg !578
  br i1 %227, label %trace_caller, label %trace_limit, !dbg !578

selected.valid:                                   ; preds = %numeric_valid
  %228 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 0, !dbg !578
  %229 = load i64, ptr %228, align 8, !dbg !578
  %230 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 0, !dbg !578
  store i64 %229, ptr %230, align 8, !dbg !578
  %231 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 1, !dbg !578
  %232 = load i64, ptr %231, align 8, !dbg !578
  %233 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 1, !dbg !578
  store i64 %232, ptr %233, align 8, !dbg !578
  %234 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 2, !dbg !578
  %235 = load i64, ptr %234, align 8, !dbg !578
  %236 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 2, !dbg !578
  store i64 %235, ptr %236, align 8, !dbg !578
  %237 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 3, !dbg !578
  %238 = load i64, ptr %237, align 8, !dbg !578
  %239 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 3, !dbg !578
  store i64 %238, ptr %239, align 8, !dbg !578
  %240 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 4, !dbg !578
  %241 = load i64, ptr %240, align 8, !dbg !578
  %242 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 4, !dbg !578
  store i64 %241, ptr %242, align 8, !dbg !578
  %243 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 5, !dbg !578
  %244 = load i64, ptr %243, align 8, !dbg !578
  %245 = trunc i64 %244 to i1, !dbg !578
  %246 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 5, !dbg !578
  store i1 %245, ptr %246, align 1, !dbg !578
  %247 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 6, !dbg !578
  %248 = load i64, ptr %247, align 8, !dbg !578
  %249 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 8, !dbg !578
  store i64 %248, ptr %249, align 8, !dbg !578
  %250 = getelementptr inbounds [8 x i64], ptr %5, i32 0, i32 7, !dbg !578
  %251 = load i64, ptr %250, align 8, !dbg !578
  %252 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %67, i32 0, i32 9, !dbg !578
  store i64 %251, ptr %252, align 8, !dbg !578
  %253 = load %"/@stdlib/console.void::_reply", ptr %67, align 8, !dbg !578
  store %"/@stdlib/console.void::_reply" %253, ptr %67, align 8, !dbg !578
  store %"/@stdlib/console.void::_reply" %253, ptr %12, align 8, !dbg !579
  %254 = load %"/@stdlib/console.void::_reply", ptr %12, align 8, !dbg !580
  store %"/@stdlib/console.void::_reply" %254, ptr %72, align 8, !dbg !580
  %255 = extractvalue %"/@stdlib/console.void::_reply" %254, 0, !dbg !581
  store i64 %255, ptr %23, align 8, !dbg !561
  %256 = load i64, ptr %23, align 8, !dbg !561
  %257 = icmp ne i64 %256, 0, !dbg !561
  br i1 %257, label %block10, label %block11, !dbg !561

trace_caller:                                     ; preds = %selected.failure
  %258 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 2, !dbg !578
  %259 = getelementptr [32 x ptr], ptr %258, i32 0, i32 %226, !dbg !578
  store ptr @207, ptr %259, align 8, !dbg !578
  %260 = add i32 %226, 1, !dbg !578
  store i32 %260, ptr %225, align 4, !dbg !578
  br label %error_return, !dbg !578

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %179), !dbg !578
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !578

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %225, align 4, !dbg !578
  br label %error_return, !dbg !578

worker.cancelled19:                               ; preds = %block10
  call void @vd_gc_frame_leave(ptr %179), !dbg !561
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !561

worker.continue20:                                ; preds = %block10
  %261 = load %"/@stdlib/console.void::_reply", ptr %12, align 8, !dbg !582
  store %"/@stdlib/console.void::_reply" %261, ptr %77, align 8, !dbg !582
  store %"/@stdlib/console.void::_reply" %261, ptr %24, align 8, !dbg !582
  call void @vd_string_literal(ptr %82, ptr @208, i64 10, ptr %4), !dbg !583
  %262 = load ptr, ptr %82, align 8, !dbg !583
  %263 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !583
  %264 = load ptr, ptr %263, align 8, !dbg !583
  %265 = icmp ne ptr %264, null, !dbg !583
  br i1 %265, label %numeric_error21, label %numeric_valid22, !dbg !583

numeric_error21:                                  ; preds = %worker.continue20
  %266 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !583
  store ptr @209, ptr %266, align 8, !dbg !583
  call void @vd_gc_frame_leave(ptr %179), !dbg !583
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !583

numeric_valid22:                                  ; preds = %worker.continue20
  store ptr %262, ptr %82, align 8, !dbg !583
  store ptr %262, ptr %25, align 8, !dbg !583
  call void @vd_string_literal(ptr %87, ptr @210, i64 5, ptr %4), !dbg !584
  %267 = load ptr, ptr %87, align 8, !dbg !584
  %268 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !584
  %269 = load ptr, ptr %268, align 8, !dbg !584
  %270 = icmp ne ptr %269, null, !dbg !584
  br i1 %270, label %numeric_error23, label %numeric_valid24, !dbg !584

numeric_error23:                                  ; preds = %numeric_valid22
  %271 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !584
  store ptr @211, ptr %271, align 8, !dbg !584
  call void @vd_gc_frame_leave(ptr %179), !dbg !584
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !584

numeric_valid24:                                  ; preds = %numeric_valid22
  store ptr %267, ptr %87, align 8, !dbg !584
  store ptr %267, ptr %26, align 8, !dbg !584
  %272 = load %"/@stdlib/console.void::_reply", ptr %24, align 8, !dbg !585
  store %"/@stdlib/console.void::_reply" %272, ptr %92, align 8, !dbg !585
  %273 = load ptr, ptr %25, align 8, !dbg !585
  store ptr %273, ptr %97, align 8, !dbg !585
  %274 = load ptr, ptr %26, align 8, !dbg !585
  store ptr %274, ptr %102, align 8, !dbg !585
  %275 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %272, ptr %273, ptr %274, ptr %4), !dbg !585
  %276 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !585
  %277 = load ptr, ptr %276, align 8, !dbg !585
  %278 = icmp ne ptr %277, null, !dbg !585
  br i1 %278, label %propagate_error, label %call_success, !dbg !585

propagate_error:                                  ; preds = %numeric_valid24
  %279 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 1, !dbg !585
  %280 = load i32, ptr %279, align 4, !dbg !585
  %281 = icmp ult i32 %280, 32, !dbg !585
  br i1 %281, label %trace_caller25, label %trace_limit27, !dbg !585

call_success:                                     ; preds = %numeric_valid24
  store %"/@stdlib/console.void::io_error" %275, ptr %107, align 8, !dbg !585
  store %"/@stdlib/console.void::io_error" %275, ptr %27, align 8, !dbg !585
  %282 = load %"/@stdlib/console.void::io_error", ptr %27, align 8, !dbg !562
  store %"/@stdlib/console.void::io_error" %282, ptr %112, align 8, !dbg !562
  %283 = insertvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, ptr null, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %282, 2, !dbg !562
  %284 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, 0, !dbg !562
  %285 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, 0, !dbg !562
  %286 = icmp eq i32 %285, 0, !dbg !562
  br i1 %286, label %validate_active_payload, label %validate_payload_done, !dbg !562

trace_caller25:                                   ; preds = %propagate_error
  %287 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 2, !dbg !585
  %288 = getelementptr [32 x ptr], ptr %287, i32 0, i32 %280, !dbg !585
  store ptr @212, ptr %288, align 8, !dbg !585
  %289 = add i32 %280, 1, !dbg !585
  store i32 %289, ptr %279, align 4, !dbg !585
  br label %error_return26, !dbg !585

error_return26:                                   ; preds = %trace_caller25, %trace_limit27
  call void @vd_gc_frame_leave(ptr %179), !dbg !585
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !585

trace_limit27:                                    ; preds = %propagate_error
  store i32 33, ptr %279, align 4, !dbg !585
  br label %error_return26, !dbg !585

validate_active_payload:                          ; preds = %call_success
  %290 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, 1, !dbg !562
  %291 = icmp eq ptr %290, null, !dbg !562
  br i1 %291, label %numeric_error28, label %numeric_valid29, !dbg !562

validate_payload_done:                            ; preds = %numeric_valid29, %call_success
  %292 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, 0, !dbg !562
  %293 = icmp eq i32 %292, 1, !dbg !562
  br i1 %293, label %validate_active_payload30, label %validate_payload_done31, !dbg !562

numeric_error28:                                  ; preds = %validate_active_payload
  %294 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !562
  store ptr @213, ptr %294, align 8, !dbg !562
  call void @vd_gc_frame_leave(ptr %179), !dbg !562
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !562

numeric_valid29:                                  ; preds = %validate_active_payload
  br label %validate_payload_done, !dbg !562

validate_active_payload30:                        ; preds = %validate_payload_done
  %295 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, 2, !dbg !562
  %296 = extractvalue %"/@stdlib/console.void::io_error" %295, 0, !dbg !562
  %297 = extractvalue %"/@stdlib/console.void::io_error" %295, 1, !dbg !562
  %298 = extractvalue %"/@stdlib/console.void::io_error" %295, 2, !dbg !562
  %299 = extractvalue %"/@stdlib/console.void::io_error_kind" %298, 0, !dbg !562
  %300 = extractvalue %"/@stdlib/console.void::io_error" %295, 3, !dbg !562
  %301 = extractvalue %"/@stdlib/console.void::io_error" %295, 4, !dbg !562
  %302 = extractvalue %"/@stdlib/console.void::io_error" %295, 5, !dbg !562
  %303 = extractvalue %"/@stdlib/console.void::io_error" %295, 6, !dbg !562
  %304 = extractvalue %"/@stdlib/console.void::io_error" %295, 7, !dbg !562
  %305 = extractvalue %"/@stdlib/console.void::io_error" %295, 8, !dbg !562
  br label %validate_payload_done31, !dbg !562

validate_payload_done31:                          ; preds = %validate_active_payload30, %validate_payload_done
  store %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, ptr %117, align 8, !dbg !562
  call void @vd_gc_frame_leave(ptr %179), !dbg !562
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %283, !dbg !562

worker.cancelled32:                               ; preds = %block11
  call void @vd_gc_frame_leave(ptr %179), !dbg !562
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !562

worker.continue33:                                ; preds = %block11
  br label %block12, !dbg !562

worker.cancelled34:                               ; preds = %block12
  call void @vd_gc_frame_leave(ptr %179), !dbg !562
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !562

worker.continue35:                                ; preds = %block12
  %306 = load ptr, ptr %11, align 8, !dbg !586
  store ptr %306, ptr %122, align 8, !dbg !586
  store ptr %306, ptr %28, align 8, !dbg !586
  %307 = load %"/@stdlib/console.void::_reply", ptr %12, align 8, !dbg !587
  store %"/@stdlib/console.void::_reply" %307, ptr %127, align 8, !dbg !587
  %308 = extractvalue %"/@stdlib/console.void::_reply" %307, 8, !dbg !588
  %309 = load ptr, ptr %28, align 8, !dbg !586
  store ptr %309, ptr %132, align 8, !dbg !586
  %310 = icmp eq ptr %309, null, !dbg !586
  br i1 %310, label %numeric_error36, label %numeric_valid37, !dbg !586

numeric_error36:                                  ; preds = %worker.continue35
  %311 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !586
  store ptr @214, ptr %311, align 8, !dbg !586
  call void @vd_gc_frame_leave(ptr %179), !dbg !586
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !586

numeric_valid37:                                  ; preds = %worker.continue35
  %312 = getelementptr %"/@stdlib/console.void::terminal_session", ptr %309, i32 0, i32 0, !dbg !586
  store i64 %308, ptr %312, align 8, !dbg !586
  %313 = load ptr, ptr %11, align 8, !dbg !589
  store ptr %313, ptr %137, align 8, !dbg !589
  store ptr %313, ptr %29, align 8, !dbg !589
  %314 = load ptr, ptr %29, align 8, !dbg !590
  store ptr %314, ptr %142, align 8, !dbg !590
  %315 = insertvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %314, 1, !dbg !590
  %316 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, 0, !dbg !590
  %317 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, 0, !dbg !590
  %318 = icmp eq i32 %317, 0, !dbg !590
  br i1 %318, label %validate_active_payload38, label %validate_payload_done39, !dbg !590

validate_active_payload38:                        ; preds = %numeric_valid37
  %319 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, 1, !dbg !590
  %320 = icmp eq ptr %319, null, !dbg !590
  br i1 %320, label %numeric_error40, label %numeric_valid41, !dbg !590

validate_payload_done39:                          ; preds = %numeric_valid41, %numeric_valid37
  %321 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, 0, !dbg !590
  %322 = icmp eq i32 %321, 1, !dbg !590
  br i1 %322, label %validate_active_payload42, label %validate_payload_done43, !dbg !590

numeric_error40:                                  ; preds = %validate_active_payload38
  %323 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %4, i32 0, i32 0, !dbg !590
  store ptr @215, ptr %323, align 8, !dbg !590
  call void @vd_gc_frame_leave(ptr %179), !dbg !590
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !590

numeric_valid41:                                  ; preds = %validate_active_payload38
  br label %validate_payload_done39, !dbg !590

validate_active_payload42:                        ; preds = %validate_payload_done39
  %324 = extractvalue %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, 2, !dbg !590
  %325 = extractvalue %"/@stdlib/console.void::io_error" %324, 0, !dbg !590
  %326 = extractvalue %"/@stdlib/console.void::io_error" %324, 1, !dbg !590
  %327 = extractvalue %"/@stdlib/console.void::io_error" %324, 2, !dbg !590
  %328 = extractvalue %"/@stdlib/console.void::io_error_kind" %327, 0, !dbg !590
  %329 = extractvalue %"/@stdlib/console.void::io_error" %324, 3, !dbg !590
  %330 = extractvalue %"/@stdlib/console.void::io_error" %324, 4, !dbg !590
  %331 = extractvalue %"/@stdlib/console.void::io_error" %324, 5, !dbg !590
  %332 = extractvalue %"/@stdlib/console.void::io_error" %324, 6, !dbg !590
  %333 = extractvalue %"/@stdlib/console.void::io_error" %324, 7, !dbg !590
  %334 = extractvalue %"/@stdlib/console.void::io_error" %324, 8, !dbg !590
  br label %validate_payload_done43, !dbg !590

validate_payload_done43:                          ; preds = %validate_active_payload42, %validate_payload_done39
  store %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, ptr %147, align 8, !dbg !590
  call void @vd_gc_frame_leave(ptr %179), !dbg !590
  ret %"$result:$array:42:15:/@stdlib/console.void::terminal_session:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %315, !dbg !590
}

define internal %"/@stdlib/console.void::key" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6b6579__v1(i64 %0, ptr %1) !dbg !591 {
block0:
  %2 = alloca i64, align 8
  store i64 0, ptr %2, align 8
  %3 = alloca i64, align 8
  store i64 0, ptr %3, align 8
  %4 = alloca i64, align 8
  store i64 0, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca i64, align 8
  store i64 0, ptr %7, align 8
  %8 = alloca i64, align 8
  store i64 0, ptr %8, align 8
  %9 = alloca i64, align 8
  store i64 0, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca i64, align 8
  store i64 0, ptr %13, align 8
  %14 = alloca i64, align 8
  store i64 0, ptr %14, align 8
  %15 = alloca i64, align 8
  store i64 0, ptr %15, align 8
  %16 = alloca i64, align 8
  store i64 0, ptr %16, align 8
  %17 = alloca i64, align 8
  store i64 0, ptr %17, align 8
  %18 = alloca i64, align 8
  store i64 0, ptr %18, align 8
  %19 = alloca i64, align 8
  store i64 0, ptr %19, align 8
  %20 = alloca i64, align 8
  store i64 0, ptr %20, align 8
  %21 = alloca i64, align 8
  store i64 0, ptr %21, align 8
  %22 = alloca i64, align 8
  store i64 0, ptr %22, align 8
  %23 = alloca i64, align 8
  store i64 0, ptr %23, align 8
  %24 = alloca i64, align 8
  store i64 0, ptr %24, align 8
  %25 = alloca i64, align 8
  store i64 0, ptr %25, align 8
  %26 = alloca i64, align 8
  store i64 0, ptr %26, align 8
  %27 = alloca i64, align 8
  store i64 0, ptr %27, align 8
  %28 = alloca i64, align 8
  store i64 0, ptr %28, align 8
  %29 = alloca i64, align 8
  store i64 0, ptr %29, align 8
  %30 = alloca i64, align 8
  store i64 0, ptr %30, align 8
  %31 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %32 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %32, ptr %31, i64 0)
  call void @vd_gc_poll()
  %33 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %33, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !595
  %34 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !595
  br i1 %34, label %worker.cancelled1, label %worker.continue2, !dbg !595

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !596
  %35 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !596
  br i1 %35, label %worker.cancelled3, label %worker.continue4, !dbg !596

block3:                                           ; preds = %worker.continue4
  call void @vd_gc_poll(), !dbg !596
  %36 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !596
  br i1 %36, label %worker.cancelled5, label %worker.continue6, !dbg !596

block4:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !597
  %37 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !597
  br i1 %37, label %worker.cancelled7, label %worker.continue8, !dbg !597

block5:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !598
  %38 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !598
  br i1 %38, label %worker.cancelled9, label %worker.continue10, !dbg !598

block6:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !598
  %39 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !598
  br i1 %39, label %worker.cancelled11, label %worker.continue12, !dbg !598

block7:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !599
  %40 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !599
  br i1 %40, label %worker.cancelled13, label %worker.continue14, !dbg !599

block8:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !600
  %41 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !600
  br i1 %41, label %worker.cancelled15, label %worker.continue16, !dbg !600

block9:                                           ; preds = %worker.continue16
  call void @vd_gc_poll(), !dbg !600
  %42 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !600
  br i1 %42, label %worker.cancelled17, label %worker.continue18, !dbg !600

block10:                                          ; preds = %worker.continue18
  call void @vd_gc_poll(), !dbg !601
  %43 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !601
  br i1 %43, label %worker.cancelled19, label %worker.continue20, !dbg !601

block11:                                          ; preds = %worker.continue18
  call void @vd_gc_poll(), !dbg !602
  %44 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !602
  br i1 %44, label %worker.cancelled21, label %worker.continue22, !dbg !602

block12:                                          ; preds = %worker.continue22
  call void @vd_gc_poll(), !dbg !602
  %45 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !602
  br i1 %45, label %worker.cancelled23, label %worker.continue24, !dbg !602

block13:                                          ; preds = %worker.continue24
  call void @vd_gc_poll(), !dbg !603
  %46 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !603
  br i1 %46, label %worker.cancelled25, label %worker.continue26, !dbg !603

block14:                                          ; preds = %worker.continue24
  call void @vd_gc_poll(), !dbg !604
  %47 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !604
  br i1 %47, label %worker.cancelled27, label %worker.continue28, !dbg !604

block15:                                          ; preds = %worker.continue28
  call void @vd_gc_poll(), !dbg !604
  %48 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !604
  br i1 %48, label %worker.cancelled29, label %worker.continue30, !dbg !604

block16:                                          ; preds = %worker.continue30
  call void @vd_gc_poll(), !dbg !605
  %49 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !605
  br i1 %49, label %worker.cancelled31, label %worker.continue32, !dbg !605

block17:                                          ; preds = %worker.continue30
  call void @vd_gc_poll(), !dbg !606
  %50 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !606
  br i1 %50, label %worker.cancelled33, label %worker.continue34, !dbg !606

block18:                                          ; preds = %worker.continue34
  call void @vd_gc_poll(), !dbg !606
  %51 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !606
  br i1 %51, label %worker.cancelled35, label %worker.continue36, !dbg !606

block19:                                          ; preds = %worker.continue36
  call void @vd_gc_poll(), !dbg !607
  %52 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !607
  br i1 %52, label %worker.cancelled37, label %worker.continue38, !dbg !607

block20:                                          ; preds = %worker.continue36
  call void @vd_gc_poll(), !dbg !608
  %53 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !608
  br i1 %53, label %worker.cancelled39, label %worker.continue40, !dbg !608

block21:                                          ; preds = %worker.continue40
  call void @vd_gc_poll(), !dbg !608
  %54 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !608
  br i1 %54, label %worker.cancelled41, label %worker.continue42, !dbg !608

block22:                                          ; preds = %worker.continue42
  call void @vd_gc_poll(), !dbg !609
  %55 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !609
  br i1 %55, label %worker.cancelled43, label %worker.continue44, !dbg !609

block23:                                          ; preds = %worker.continue42
  call void @vd_gc_poll(), !dbg !610
  %56 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !610
  br i1 %56, label %worker.cancelled45, label %worker.continue46, !dbg !610

block24:                                          ; preds = %worker.continue46
  call void @vd_gc_poll(), !dbg !610
  %57 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !610
  br i1 %57, label %worker.cancelled47, label %worker.continue48, !dbg !610

block25:                                          ; preds = %worker.continue48
  call void @vd_gc_poll(), !dbg !611
  %58 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !611
  br i1 %58, label %worker.cancelled49, label %worker.continue50, !dbg !611

block26:                                          ; preds = %worker.continue48
  call void @vd_gc_poll(), !dbg !612
  %59 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !612
  br i1 %59, label %worker.cancelled51, label %worker.continue52, !dbg !612

block27:                                          ; preds = %worker.continue52
  call void @vd_gc_poll(), !dbg !612
  %60 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !612
  br i1 %60, label %worker.cancelled53, label %worker.continue54, !dbg !612

block28:                                          ; preds = %worker.continue54
  call void @vd_gc_poll(), !dbg !613
  %61 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !613
  br i1 %61, label %worker.cancelled55, label %worker.continue56, !dbg !613

block29:                                          ; preds = %worker.continue54
  call void @vd_gc_poll(), !dbg !614
  %62 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !614
  br i1 %62, label %worker.cancelled57, label %worker.continue58, !dbg !614

block30:                                          ; preds = %worker.continue58
  call void @vd_gc_poll(), !dbg !614
  %63 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !614
  br i1 %63, label %worker.cancelled59, label %worker.continue60, !dbg !614

block31:                                          ; preds = %worker.continue60
  call void @vd_gc_poll(), !dbg !615
  %64 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !615
  br i1 %64, label %worker.cancelled61, label %worker.continue62, !dbg !615

block32:                                          ; preds = %worker.continue60
  call void @vd_gc_poll(), !dbg !616
  %65 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !616
  br i1 %65, label %worker.cancelled63, label %worker.continue64, !dbg !616

block33:                                          ; preds = %worker.continue64
  call void @vd_gc_poll(), !dbg !616
  %66 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !616
  br i1 %66, label %worker.cancelled65, label %worker.continue66, !dbg !616

block34:                                          ; preds = %worker.continue66
  call void @vd_gc_poll(), !dbg !617
  %67 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !617
  br i1 %67, label %worker.cancelled67, label %worker.continue68, !dbg !617

block35:                                          ; preds = %worker.continue66
  call void @vd_gc_poll(), !dbg !618
  %68 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !618
  br i1 %68, label %worker.cancelled69, label %worker.continue70, !dbg !618

block36:                                          ; preds = %worker.continue70
  call void @vd_gc_poll(), !dbg !618
  %69 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !618
  br i1 %69, label %worker.cancelled71, label %worker.continue72, !dbg !618

block37:                                          ; preds = %worker.continue72
  call void @vd_gc_poll(), !dbg !619
  %70 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !619
  br i1 %70, label %worker.cancelled73, label %worker.continue74, !dbg !619

block38:                                          ; preds = %worker.continue72
  call void @vd_gc_poll(), !dbg !620
  %71 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !620
  br i1 %71, label %worker.cancelled75, label %worker.continue76, !dbg !620

block39:                                          ; preds = %worker.continue76
  call void @vd_gc_poll(), !dbg !620
  %72 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !620
  br i1 %72, label %worker.cancelled77, label %worker.continue78, !dbg !620

block40:                                          ; preds = %worker.continue78
  call void @vd_gc_poll(), !dbg !621
  %73 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !621
  br i1 %73, label %worker.cancelled79, label %worker.continue80, !dbg !621

block41:                                          ; preds = %worker.continue78
  call void @vd_gc_poll(), !dbg !622
  %74 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !622
  br i1 %74, label %worker.cancelled81, label %worker.continue82, !dbg !622

block42:                                          ; preds = %worker.continue82
  call void @vd_gc_poll(), !dbg !622
  %75 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !622
  br i1 %75, label %worker.cancelled83, label %worker.continue84, !dbg !622

block43:                                          ; preds = %worker.continue84
  call void @vd_gc_poll(), !dbg !623
  %76 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !623
  br i1 %76, label %worker.cancelled85, label %worker.continue86, !dbg !623

block44:                                          ; preds = %worker.continue84
  call void @vd_gc_poll(), !dbg !624
  %77 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !624
  br i1 %77, label %worker.cancelled87, label %worker.continue88, !dbg !624

block45:                                          ; preds = %worker.continue88
  call void @vd_gc_poll(), !dbg !624
  %78 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !624
  br i1 %78, label %worker.cancelled89, label %worker.continue90, !dbg !624

block46:                                          ; preds = %worker.continue90
  call void @vd_gc_poll(), !dbg !625
  %79 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !625
  br i1 %79, label %worker.cancelled91, label %worker.continue92, !dbg !625

block47:                                          ; preds = %worker.continue90
  call void @vd_gc_poll(), !dbg !626
  %80 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !626
  br i1 %80, label %worker.cancelled93, label %worker.continue94, !dbg !626

block48:                                          ; preds = %worker.continue94
  call void @vd_gc_poll(), !dbg !626
  %81 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !626
  br i1 %81, label %worker.cancelled95, label %worker.continue96, !dbg !626

block49:                                          ; preds = %worker.continue96
  call void @vd_gc_poll(), !dbg !627
  %82 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !627
  br i1 %82, label %worker.cancelled97, label %worker.continue98, !dbg !627

block50:                                          ; preds = %worker.continue96
  call void @vd_gc_poll(), !dbg !628
  %83 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !628
  br i1 %83, label %worker.cancelled99, label %worker.continue100, !dbg !628

block51:                                          ; preds = %worker.continue100
  call void @vd_gc_poll(), !dbg !628
  %84 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !628
  br i1 %84, label %worker.cancelled101, label %worker.continue102, !dbg !628

block52:                                          ; preds = %worker.continue102
  call void @vd_gc_poll(), !dbg !629
  %85 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !629
  br i1 %85, label %worker.cancelled103, label %worker.continue104, !dbg !629

block53:                                          ; preds = %worker.continue102
  call void @vd_gc_poll(), !dbg !630
  %86 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !630
  br i1 %86, label %worker.cancelled105, label %worker.continue106, !dbg !630

block54:                                          ; preds = %worker.continue106
  call void @vd_gc_poll(), !dbg !630
  %87 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !630
  br i1 %87, label %worker.cancelled107, label %worker.continue108, !dbg !630

block55:                                          ; preds = %worker.continue108
  call void @vd_gc_poll(), !dbg !631
  %88 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !631
  br i1 %88, label %worker.cancelled109, label %worker.continue110, !dbg !631

block56:                                          ; preds = %worker.continue108
  call void @vd_gc_poll(), !dbg !632
  %89 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !632
  br i1 %89, label %worker.cancelled111, label %worker.continue112, !dbg !632

block57:                                          ; preds = %worker.continue112
  call void @vd_gc_poll(), !dbg !632
  %90 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !632
  br i1 %90, label %worker.cancelled113, label %worker.continue114, !dbg !632

block58:                                          ; preds = %worker.continue114
  call void @vd_gc_poll(), !dbg !633
  %91 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !633
  br i1 %91, label %worker.cancelled115, label %worker.continue116, !dbg !633

block59:                                          ; preds = %worker.continue114
  call void @vd_gc_poll(), !dbg !634
  %92 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !634
  br i1 %92, label %worker.cancelled117, label %worker.continue118, !dbg !634

block60:                                          ; preds = %worker.continue118
  call void @vd_gc_poll(), !dbg !634
  %93 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !634
  br i1 %93, label %worker.cancelled119, label %worker.continue120, !dbg !634

block61:                                          ; preds = %worker.continue120
  call void @vd_gc_poll(), !dbg !635
  %94 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !635
  br i1 %94, label %worker.cancelled121, label %worker.continue122, !dbg !635

block62:                                          ; preds = %worker.continue120
  call void @vd_gc_poll(), !dbg !636
  %95 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !636
  br i1 %95, label %worker.cancelled123, label %worker.continue124, !dbg !636

block63:                                          ; preds = %worker.continue124
  call void @vd_gc_poll(), !dbg !636
  %96 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !636
  br i1 %96, label %worker.cancelled125, label %worker.continue126, !dbg !636

block64:                                          ; preds = %worker.continue126
  call void @vd_gc_poll(), !dbg !637
  %97 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !637
  br i1 %97, label %worker.cancelled127, label %worker.continue128, !dbg !637

block65:                                          ; preds = %worker.continue126
  call void @vd_gc_poll(), !dbg !638
  %98 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !638
  br i1 %98, label %worker.cancelled129, label %worker.continue130, !dbg !638

block66:                                          ; preds = %worker.continue130
  call void @vd_gc_poll(), !dbg !638
  %99 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !638
  br i1 %99, label %worker.cancelled131, label %worker.continue132, !dbg !638

block67:                                          ; preds = %worker.continue132
  call void @vd_gc_poll(), !dbg !639
  %100 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !639
  br i1 %100, label %worker.cancelled133, label %worker.continue134, !dbg !639

block68:                                          ; preds = %worker.continue132
  call void @vd_gc_poll(), !dbg !640
  %101 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !640
  br i1 %101, label %worker.cancelled135, label %worker.continue136, !dbg !640

block69:                                          ; preds = %worker.continue136
  call void @vd_gc_poll(), !dbg !640
  %102 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !640
  br i1 %102, label %worker.cancelled137, label %worker.continue138, !dbg !640

block70:                                          ; preds = %worker.continue138
  call void @vd_gc_poll(), !dbg !641
  %103 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !641
  br i1 %103, label %worker.cancelled139, label %worker.continue140, !dbg !641

block71:                                          ; preds = %worker.continue138
  call void @vd_gc_poll(), !dbg !642
  %104 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !642
  br i1 %104, label %worker.cancelled141, label %worker.continue142, !dbg !642

block72:                                          ; preds = %worker.continue142
  call void @vd_gc_poll(), !dbg !642
  %105 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !642
  br i1 %105, label %worker.cancelled143, label %worker.continue144, !dbg !642

block73:                                          ; preds = %worker.continue144
  call void @vd_gc_poll(), !dbg !643
  %106 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !643
  br i1 %106, label %worker.cancelled145, label %worker.continue146, !dbg !643

block74:                                          ; preds = %worker.continue144
  call void @vd_gc_poll(), !dbg !644
  %107 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !644
  br i1 %107, label %worker.cancelled147, label %worker.continue148, !dbg !644

block75:                                          ; preds = %worker.continue148
  call void @vd_gc_poll(), !dbg !644
  %108 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !644
  br i1 %108, label %worker.cancelled149, label %worker.continue150, !dbg !644

block76:                                          ; preds = %worker.continue150
  call void @vd_gc_poll(), !dbg !645
  %109 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !645
  br i1 %109, label %worker.cancelled151, label %worker.continue152, !dbg !645

block77:                                          ; preds = %worker.continue150
  call void @vd_gc_poll(), !dbg !646
  %110 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !646
  br i1 %110, label %worker.cancelled153, label %worker.continue154, !dbg !646

block78:                                          ; preds = %worker.continue154
  call void @vd_gc_poll(), !dbg !646
  %111 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !646
  br i1 %111, label %worker.cancelled155, label %worker.continue156, !dbg !646

block79:                                          ; preds = %worker.continue156
  call void @vd_gc_poll(), !dbg !647
  %112 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !647
  br i1 %112, label %worker.cancelled157, label %worker.continue158, !dbg !647

block80:                                          ; preds = %worker.continue156
  call void @vd_gc_poll(), !dbg !648
  %113 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !648
  br i1 %113, label %worker.cancelled159, label %worker.continue160, !dbg !648

block81:                                          ; preds = %worker.continue160
  call void @vd_gc_poll(), !dbg !648
  %114 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !648
  br i1 %114, label %worker.cancelled161, label %worker.continue162, !dbg !648

block82:                                          ; preds = %worker.continue162
  call void @vd_gc_poll(), !dbg !649
  %115 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !649
  br i1 %115, label %worker.cancelled163, label %worker.continue164, !dbg !649

block83:                                          ; preds = %worker.continue162
  call void @vd_gc_poll(), !dbg !650
  %116 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !650
  br i1 %116, label %worker.cancelled165, label %worker.continue166, !dbg !650

block84:                                          ; preds = %worker.continue166
  call void @vd_gc_poll(), !dbg !650
  %117 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !650
  br i1 %117, label %worker.cancelled167, label %worker.continue168, !dbg !650

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %32)
  ret %"/@stdlib/console.void::key" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i64 %0, ptr %2, align 8, !dbg !651
  %118 = load i64, ptr %2, align 8, !dbg !652
  store i64 %118, ptr %3, align 8, !dbg !595
  %119 = load i64, ptr %3, align 8, !dbg !595
  %120 = icmp eq i64 %119, 0, !dbg !595
  br i1 %120, label %block1, label %block2, !dbg !595

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %32), !dbg !595
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !595

worker.continue2:                                 ; preds = %block1
  call void @vd_gc_frame_leave(ptr %32), !dbg !596
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !596

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %32), !dbg !596
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !596

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !596

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %32), !dbg !596
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !596

worker.continue6:                                 ; preds = %block3
  %121 = load i64, ptr %2, align 8, !dbg !653
  store i64 %121, ptr %4, align 8, !dbg !597
  %122 = load i64, ptr %4, align 8, !dbg !597
  %123 = icmp eq i64 %122, 1, !dbg !597
  br i1 %123, label %block4, label %block5, !dbg !597

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %32), !dbg !597
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !597

worker.continue8:                                 ; preds = %block4
  call void @vd_gc_frame_leave(ptr %32), !dbg !598
  ret %"/@stdlib/console.void::key" { i32 1 }, !dbg !598

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr %32), !dbg !598
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !598

worker.continue10:                                ; preds = %block5
  br label %block6, !dbg !598

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %32), !dbg !598
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !598

worker.continue12:                                ; preds = %block6
  %124 = load i64, ptr %2, align 8, !dbg !654
  store i64 %124, ptr %5, align 8, !dbg !599
  %125 = load i64, ptr %5, align 8, !dbg !599
  %126 = icmp eq i64 %125, 2, !dbg !599
  br i1 %126, label %block7, label %block8, !dbg !599

worker.cancelled13:                               ; preds = %block7
  call void @vd_gc_frame_leave(ptr %32), !dbg !599
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !599

worker.continue14:                                ; preds = %block7
  call void @vd_gc_frame_leave(ptr %32), !dbg !600
  ret %"/@stdlib/console.void::key" { i32 2 }, !dbg !600

worker.cancelled15:                               ; preds = %block8
  call void @vd_gc_frame_leave(ptr %32), !dbg !600
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !600

worker.continue16:                                ; preds = %block8
  br label %block9, !dbg !600

worker.cancelled17:                               ; preds = %block9
  call void @vd_gc_frame_leave(ptr %32), !dbg !600
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !600

worker.continue18:                                ; preds = %block9
  %127 = load i64, ptr %2, align 8, !dbg !655
  store i64 %127, ptr %6, align 8, !dbg !601
  %128 = load i64, ptr %6, align 8, !dbg !601
  %129 = icmp eq i64 %128, 3, !dbg !601
  br i1 %129, label %block10, label %block11, !dbg !601

worker.cancelled19:                               ; preds = %block10
  call void @vd_gc_frame_leave(ptr %32), !dbg !601
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !601

worker.continue20:                                ; preds = %block10
  call void @vd_gc_frame_leave(ptr %32), !dbg !602
  ret %"/@stdlib/console.void::key" { i32 3 }, !dbg !602

worker.cancelled21:                               ; preds = %block11
  call void @vd_gc_frame_leave(ptr %32), !dbg !602
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !602

worker.continue22:                                ; preds = %block11
  br label %block12, !dbg !602

worker.cancelled23:                               ; preds = %block12
  call void @vd_gc_frame_leave(ptr %32), !dbg !602
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !602

worker.continue24:                                ; preds = %block12
  %130 = load i64, ptr %2, align 8, !dbg !656
  store i64 %130, ptr %7, align 8, !dbg !603
  %131 = load i64, ptr %7, align 8, !dbg !603
  %132 = icmp eq i64 %131, 4, !dbg !603
  br i1 %132, label %block13, label %block14, !dbg !603

worker.cancelled25:                               ; preds = %block13
  call void @vd_gc_frame_leave(ptr %32), !dbg !603
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !603

worker.continue26:                                ; preds = %block13
  call void @vd_gc_frame_leave(ptr %32), !dbg !604
  ret %"/@stdlib/console.void::key" { i32 4 }, !dbg !604

worker.cancelled27:                               ; preds = %block14
  call void @vd_gc_frame_leave(ptr %32), !dbg !604
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !604

worker.continue28:                                ; preds = %block14
  br label %block15, !dbg !604

worker.cancelled29:                               ; preds = %block15
  call void @vd_gc_frame_leave(ptr %32), !dbg !604
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !604

worker.continue30:                                ; preds = %block15
  %133 = load i64, ptr %2, align 8, !dbg !657
  store i64 %133, ptr %8, align 8, !dbg !605
  %134 = load i64, ptr %8, align 8, !dbg !605
  %135 = icmp eq i64 %134, 5, !dbg !605
  br i1 %135, label %block16, label %block17, !dbg !605

worker.cancelled31:                               ; preds = %block16
  call void @vd_gc_frame_leave(ptr %32), !dbg !605
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !605

worker.continue32:                                ; preds = %block16
  call void @vd_gc_frame_leave(ptr %32), !dbg !606
  ret %"/@stdlib/console.void::key" { i32 5 }, !dbg !606

worker.cancelled33:                               ; preds = %block17
  call void @vd_gc_frame_leave(ptr %32), !dbg !606
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !606

worker.continue34:                                ; preds = %block17
  br label %block18, !dbg !606

worker.cancelled35:                               ; preds = %block18
  call void @vd_gc_frame_leave(ptr %32), !dbg !606
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !606

worker.continue36:                                ; preds = %block18
  %136 = load i64, ptr %2, align 8, !dbg !658
  store i64 %136, ptr %9, align 8, !dbg !607
  %137 = load i64, ptr %9, align 8, !dbg !607
  %138 = icmp eq i64 %137, 6, !dbg !607
  br i1 %138, label %block19, label %block20, !dbg !607

worker.cancelled37:                               ; preds = %block19
  call void @vd_gc_frame_leave(ptr %32), !dbg !607
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !607

worker.continue38:                                ; preds = %block19
  call void @vd_gc_frame_leave(ptr %32), !dbg !608
  ret %"/@stdlib/console.void::key" { i32 6 }, !dbg !608

worker.cancelled39:                               ; preds = %block20
  call void @vd_gc_frame_leave(ptr %32), !dbg !608
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !608

worker.continue40:                                ; preds = %block20
  br label %block21, !dbg !608

worker.cancelled41:                               ; preds = %block21
  call void @vd_gc_frame_leave(ptr %32), !dbg !608
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !608

worker.continue42:                                ; preds = %block21
  %139 = load i64, ptr %2, align 8, !dbg !659
  store i64 %139, ptr %10, align 8, !dbg !609
  %140 = load i64, ptr %10, align 8, !dbg !609
  %141 = icmp eq i64 %140, 7, !dbg !609
  br i1 %141, label %block22, label %block23, !dbg !609

worker.cancelled43:                               ; preds = %block22
  call void @vd_gc_frame_leave(ptr %32), !dbg !609
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !609

worker.continue44:                                ; preds = %block22
  call void @vd_gc_frame_leave(ptr %32), !dbg !610
  ret %"/@stdlib/console.void::key" { i32 7 }, !dbg !610

worker.cancelled45:                               ; preds = %block23
  call void @vd_gc_frame_leave(ptr %32), !dbg !610
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !610

worker.continue46:                                ; preds = %block23
  br label %block24, !dbg !610

worker.cancelled47:                               ; preds = %block24
  call void @vd_gc_frame_leave(ptr %32), !dbg !610
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !610

worker.continue48:                                ; preds = %block24
  %142 = load i64, ptr %2, align 8, !dbg !660
  store i64 %142, ptr %11, align 8, !dbg !611
  %143 = load i64, ptr %11, align 8, !dbg !611
  %144 = icmp eq i64 %143, 8, !dbg !611
  br i1 %144, label %block25, label %block26, !dbg !611

worker.cancelled49:                               ; preds = %block25
  call void @vd_gc_frame_leave(ptr %32), !dbg !611
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !611

worker.continue50:                                ; preds = %block25
  call void @vd_gc_frame_leave(ptr %32), !dbg !612
  ret %"/@stdlib/console.void::key" { i32 8 }, !dbg !612

worker.cancelled51:                               ; preds = %block26
  call void @vd_gc_frame_leave(ptr %32), !dbg !612
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !612

worker.continue52:                                ; preds = %block26
  br label %block27, !dbg !612

worker.cancelled53:                               ; preds = %block27
  call void @vd_gc_frame_leave(ptr %32), !dbg !612
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !612

worker.continue54:                                ; preds = %block27
  %145 = load i64, ptr %2, align 8, !dbg !661
  store i64 %145, ptr %12, align 8, !dbg !613
  %146 = load i64, ptr %12, align 8, !dbg !613
  %147 = icmp eq i64 %146, 9, !dbg !613
  br i1 %147, label %block28, label %block29, !dbg !613

worker.cancelled55:                               ; preds = %block28
  call void @vd_gc_frame_leave(ptr %32), !dbg !613
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !613

worker.continue56:                                ; preds = %block28
  call void @vd_gc_frame_leave(ptr %32), !dbg !614
  ret %"/@stdlib/console.void::key" { i32 9 }, !dbg !614

worker.cancelled57:                               ; preds = %block29
  call void @vd_gc_frame_leave(ptr %32), !dbg !614
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !614

worker.continue58:                                ; preds = %block29
  br label %block30, !dbg !614

worker.cancelled59:                               ; preds = %block30
  call void @vd_gc_frame_leave(ptr %32), !dbg !614
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !614

worker.continue60:                                ; preds = %block30
  %148 = load i64, ptr %2, align 8, !dbg !662
  store i64 %148, ptr %13, align 8, !dbg !615
  %149 = load i64, ptr %13, align 8, !dbg !615
  %150 = icmp eq i64 %149, 10, !dbg !615
  br i1 %150, label %block31, label %block32, !dbg !615

worker.cancelled61:                               ; preds = %block31
  call void @vd_gc_frame_leave(ptr %32), !dbg !615
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !615

worker.continue62:                                ; preds = %block31
  call void @vd_gc_frame_leave(ptr %32), !dbg !616
  ret %"/@stdlib/console.void::key" { i32 10 }, !dbg !616

worker.cancelled63:                               ; preds = %block32
  call void @vd_gc_frame_leave(ptr %32), !dbg !616
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !616

worker.continue64:                                ; preds = %block32
  br label %block33, !dbg !616

worker.cancelled65:                               ; preds = %block33
  call void @vd_gc_frame_leave(ptr %32), !dbg !616
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !616

worker.continue66:                                ; preds = %block33
  %151 = load i64, ptr %2, align 8, !dbg !663
  store i64 %151, ptr %14, align 8, !dbg !617
  %152 = load i64, ptr %14, align 8, !dbg !617
  %153 = icmp eq i64 %152, 11, !dbg !617
  br i1 %153, label %block34, label %block35, !dbg !617

worker.cancelled67:                               ; preds = %block34
  call void @vd_gc_frame_leave(ptr %32), !dbg !617
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !617

worker.continue68:                                ; preds = %block34
  call void @vd_gc_frame_leave(ptr %32), !dbg !618
  ret %"/@stdlib/console.void::key" { i32 11 }, !dbg !618

worker.cancelled69:                               ; preds = %block35
  call void @vd_gc_frame_leave(ptr %32), !dbg !618
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !618

worker.continue70:                                ; preds = %block35
  br label %block36, !dbg !618

worker.cancelled71:                               ; preds = %block36
  call void @vd_gc_frame_leave(ptr %32), !dbg !618
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !618

worker.continue72:                                ; preds = %block36
  %154 = load i64, ptr %2, align 8, !dbg !664
  store i64 %154, ptr %15, align 8, !dbg !619
  %155 = load i64, ptr %15, align 8, !dbg !619
  %156 = icmp eq i64 %155, 12, !dbg !619
  br i1 %156, label %block37, label %block38, !dbg !619

worker.cancelled73:                               ; preds = %block37
  call void @vd_gc_frame_leave(ptr %32), !dbg !619
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !619

worker.continue74:                                ; preds = %block37
  call void @vd_gc_frame_leave(ptr %32), !dbg !620
  ret %"/@stdlib/console.void::key" { i32 12 }, !dbg !620

worker.cancelled75:                               ; preds = %block38
  call void @vd_gc_frame_leave(ptr %32), !dbg !620
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !620

worker.continue76:                                ; preds = %block38
  br label %block39, !dbg !620

worker.cancelled77:                               ; preds = %block39
  call void @vd_gc_frame_leave(ptr %32), !dbg !620
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !620

worker.continue78:                                ; preds = %block39
  %157 = load i64, ptr %2, align 8, !dbg !665
  store i64 %157, ptr %16, align 8, !dbg !621
  %158 = load i64, ptr %16, align 8, !dbg !621
  %159 = icmp eq i64 %158, 13, !dbg !621
  br i1 %159, label %block40, label %block41, !dbg !621

worker.cancelled79:                               ; preds = %block40
  call void @vd_gc_frame_leave(ptr %32), !dbg !621
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !621

worker.continue80:                                ; preds = %block40
  call void @vd_gc_frame_leave(ptr %32), !dbg !622
  ret %"/@stdlib/console.void::key" { i32 13 }, !dbg !622

worker.cancelled81:                               ; preds = %block41
  call void @vd_gc_frame_leave(ptr %32), !dbg !622
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !622

worker.continue82:                                ; preds = %block41
  br label %block42, !dbg !622

worker.cancelled83:                               ; preds = %block42
  call void @vd_gc_frame_leave(ptr %32), !dbg !622
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !622

worker.continue84:                                ; preds = %block42
  %160 = load i64, ptr %2, align 8, !dbg !666
  store i64 %160, ptr %17, align 8, !dbg !623
  %161 = load i64, ptr %17, align 8, !dbg !623
  %162 = icmp eq i64 %161, 14, !dbg !623
  br i1 %162, label %block43, label %block44, !dbg !623

worker.cancelled85:                               ; preds = %block43
  call void @vd_gc_frame_leave(ptr %32), !dbg !623
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !623

worker.continue86:                                ; preds = %block43
  call void @vd_gc_frame_leave(ptr %32), !dbg !624
  ret %"/@stdlib/console.void::key" { i32 14 }, !dbg !624

worker.cancelled87:                               ; preds = %block44
  call void @vd_gc_frame_leave(ptr %32), !dbg !624
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !624

worker.continue88:                                ; preds = %block44
  br label %block45, !dbg !624

worker.cancelled89:                               ; preds = %block45
  call void @vd_gc_frame_leave(ptr %32), !dbg !624
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !624

worker.continue90:                                ; preds = %block45
  %163 = load i64, ptr %2, align 8, !dbg !667
  store i64 %163, ptr %18, align 8, !dbg !625
  %164 = load i64, ptr %18, align 8, !dbg !625
  %165 = icmp eq i64 %164, 15, !dbg !625
  br i1 %165, label %block46, label %block47, !dbg !625

worker.cancelled91:                               ; preds = %block46
  call void @vd_gc_frame_leave(ptr %32), !dbg !625
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !625

worker.continue92:                                ; preds = %block46
  call void @vd_gc_frame_leave(ptr %32), !dbg !626
  ret %"/@stdlib/console.void::key" { i32 15 }, !dbg !626

worker.cancelled93:                               ; preds = %block47
  call void @vd_gc_frame_leave(ptr %32), !dbg !626
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !626

worker.continue94:                                ; preds = %block47
  br label %block48, !dbg !626

worker.cancelled95:                               ; preds = %block48
  call void @vd_gc_frame_leave(ptr %32), !dbg !626
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !626

worker.continue96:                                ; preds = %block48
  %166 = load i64, ptr %2, align 8, !dbg !668
  store i64 %166, ptr %19, align 8, !dbg !627
  %167 = load i64, ptr %19, align 8, !dbg !627
  %168 = icmp eq i64 %167, 16, !dbg !627
  br i1 %168, label %block49, label %block50, !dbg !627

worker.cancelled97:                               ; preds = %block49
  call void @vd_gc_frame_leave(ptr %32), !dbg !627
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !627

worker.continue98:                                ; preds = %block49
  call void @vd_gc_frame_leave(ptr %32), !dbg !628
  ret %"/@stdlib/console.void::key" { i32 16 }, !dbg !628

worker.cancelled99:                               ; preds = %block50
  call void @vd_gc_frame_leave(ptr %32), !dbg !628
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !628

worker.continue100:                               ; preds = %block50
  br label %block51, !dbg !628

worker.cancelled101:                              ; preds = %block51
  call void @vd_gc_frame_leave(ptr %32), !dbg !628
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !628

worker.continue102:                               ; preds = %block51
  %169 = load i64, ptr %2, align 8, !dbg !669
  store i64 %169, ptr %20, align 8, !dbg !629
  %170 = load i64, ptr %20, align 8, !dbg !629
  %171 = icmp eq i64 %170, 17, !dbg !629
  br i1 %171, label %block52, label %block53, !dbg !629

worker.cancelled103:                              ; preds = %block52
  call void @vd_gc_frame_leave(ptr %32), !dbg !629
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !629

worker.continue104:                               ; preds = %block52
  call void @vd_gc_frame_leave(ptr %32), !dbg !630
  ret %"/@stdlib/console.void::key" { i32 17 }, !dbg !630

worker.cancelled105:                              ; preds = %block53
  call void @vd_gc_frame_leave(ptr %32), !dbg !630
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !630

worker.continue106:                               ; preds = %block53
  br label %block54, !dbg !630

worker.cancelled107:                              ; preds = %block54
  call void @vd_gc_frame_leave(ptr %32), !dbg !630
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !630

worker.continue108:                               ; preds = %block54
  %172 = load i64, ptr %2, align 8, !dbg !670
  store i64 %172, ptr %21, align 8, !dbg !631
  %173 = load i64, ptr %21, align 8, !dbg !631
  %174 = icmp eq i64 %173, 18, !dbg !631
  br i1 %174, label %block55, label %block56, !dbg !631

worker.cancelled109:                              ; preds = %block55
  call void @vd_gc_frame_leave(ptr %32), !dbg !631
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !631

worker.continue110:                               ; preds = %block55
  call void @vd_gc_frame_leave(ptr %32), !dbg !632
  ret %"/@stdlib/console.void::key" { i32 18 }, !dbg !632

worker.cancelled111:                              ; preds = %block56
  call void @vd_gc_frame_leave(ptr %32), !dbg !632
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !632

worker.continue112:                               ; preds = %block56
  br label %block57, !dbg !632

worker.cancelled113:                              ; preds = %block57
  call void @vd_gc_frame_leave(ptr %32), !dbg !632
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !632

worker.continue114:                               ; preds = %block57
  %175 = load i64, ptr %2, align 8, !dbg !671
  store i64 %175, ptr %22, align 8, !dbg !633
  %176 = load i64, ptr %22, align 8, !dbg !633
  %177 = icmp eq i64 %176, 19, !dbg !633
  br i1 %177, label %block58, label %block59, !dbg !633

worker.cancelled115:                              ; preds = %block58
  call void @vd_gc_frame_leave(ptr %32), !dbg !633
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !633

worker.continue116:                               ; preds = %block58
  call void @vd_gc_frame_leave(ptr %32), !dbg !634
  ret %"/@stdlib/console.void::key" { i32 19 }, !dbg !634

worker.cancelled117:                              ; preds = %block59
  call void @vd_gc_frame_leave(ptr %32), !dbg !634
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !634

worker.continue118:                               ; preds = %block59
  br label %block60, !dbg !634

worker.cancelled119:                              ; preds = %block60
  call void @vd_gc_frame_leave(ptr %32), !dbg !634
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !634

worker.continue120:                               ; preds = %block60
  %178 = load i64, ptr %2, align 8, !dbg !672
  store i64 %178, ptr %23, align 8, !dbg !635
  %179 = load i64, ptr %23, align 8, !dbg !635
  %180 = icmp eq i64 %179, 20, !dbg !635
  br i1 %180, label %block61, label %block62, !dbg !635

worker.cancelled121:                              ; preds = %block61
  call void @vd_gc_frame_leave(ptr %32), !dbg !635
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !635

worker.continue122:                               ; preds = %block61
  call void @vd_gc_frame_leave(ptr %32), !dbg !636
  ret %"/@stdlib/console.void::key" { i32 20 }, !dbg !636

worker.cancelled123:                              ; preds = %block62
  call void @vd_gc_frame_leave(ptr %32), !dbg !636
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !636

worker.continue124:                               ; preds = %block62
  br label %block63, !dbg !636

worker.cancelled125:                              ; preds = %block63
  call void @vd_gc_frame_leave(ptr %32), !dbg !636
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !636

worker.continue126:                               ; preds = %block63
  %181 = load i64, ptr %2, align 8, !dbg !673
  store i64 %181, ptr %24, align 8, !dbg !637
  %182 = load i64, ptr %24, align 8, !dbg !637
  %183 = icmp eq i64 %182, 21, !dbg !637
  br i1 %183, label %block64, label %block65, !dbg !637

worker.cancelled127:                              ; preds = %block64
  call void @vd_gc_frame_leave(ptr %32), !dbg !637
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !637

worker.continue128:                               ; preds = %block64
  call void @vd_gc_frame_leave(ptr %32), !dbg !638
  ret %"/@stdlib/console.void::key" { i32 21 }, !dbg !638

worker.cancelled129:                              ; preds = %block65
  call void @vd_gc_frame_leave(ptr %32), !dbg !638
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !638

worker.continue130:                               ; preds = %block65
  br label %block66, !dbg !638

worker.cancelled131:                              ; preds = %block66
  call void @vd_gc_frame_leave(ptr %32), !dbg !638
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !638

worker.continue132:                               ; preds = %block66
  %184 = load i64, ptr %2, align 8, !dbg !674
  store i64 %184, ptr %25, align 8, !dbg !639
  %185 = load i64, ptr %25, align 8, !dbg !639
  %186 = icmp eq i64 %185, 22, !dbg !639
  br i1 %186, label %block67, label %block68, !dbg !639

worker.cancelled133:                              ; preds = %block67
  call void @vd_gc_frame_leave(ptr %32), !dbg !639
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !639

worker.continue134:                               ; preds = %block67
  call void @vd_gc_frame_leave(ptr %32), !dbg !640
  ret %"/@stdlib/console.void::key" { i32 22 }, !dbg !640

worker.cancelled135:                              ; preds = %block68
  call void @vd_gc_frame_leave(ptr %32), !dbg !640
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !640

worker.continue136:                               ; preds = %block68
  br label %block69, !dbg !640

worker.cancelled137:                              ; preds = %block69
  call void @vd_gc_frame_leave(ptr %32), !dbg !640
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !640

worker.continue138:                               ; preds = %block69
  %187 = load i64, ptr %2, align 8, !dbg !675
  store i64 %187, ptr %26, align 8, !dbg !641
  %188 = load i64, ptr %26, align 8, !dbg !641
  %189 = icmp eq i64 %188, 23, !dbg !641
  br i1 %189, label %block70, label %block71, !dbg !641

worker.cancelled139:                              ; preds = %block70
  call void @vd_gc_frame_leave(ptr %32), !dbg !641
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !641

worker.continue140:                               ; preds = %block70
  call void @vd_gc_frame_leave(ptr %32), !dbg !642
  ret %"/@stdlib/console.void::key" { i32 23 }, !dbg !642

worker.cancelled141:                              ; preds = %block71
  call void @vd_gc_frame_leave(ptr %32), !dbg !642
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !642

worker.continue142:                               ; preds = %block71
  br label %block72, !dbg !642

worker.cancelled143:                              ; preds = %block72
  call void @vd_gc_frame_leave(ptr %32), !dbg !642
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !642

worker.continue144:                               ; preds = %block72
  %190 = load i64, ptr %2, align 8, !dbg !676
  store i64 %190, ptr %27, align 8, !dbg !643
  %191 = load i64, ptr %27, align 8, !dbg !643
  %192 = icmp eq i64 %191, 24, !dbg !643
  br i1 %192, label %block73, label %block74, !dbg !643

worker.cancelled145:                              ; preds = %block73
  call void @vd_gc_frame_leave(ptr %32), !dbg !643
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !643

worker.continue146:                               ; preds = %block73
  call void @vd_gc_frame_leave(ptr %32), !dbg !644
  ret %"/@stdlib/console.void::key" { i32 24 }, !dbg !644

worker.cancelled147:                              ; preds = %block74
  call void @vd_gc_frame_leave(ptr %32), !dbg !644
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !644

worker.continue148:                               ; preds = %block74
  br label %block75, !dbg !644

worker.cancelled149:                              ; preds = %block75
  call void @vd_gc_frame_leave(ptr %32), !dbg !644
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !644

worker.continue150:                               ; preds = %block75
  %193 = load i64, ptr %2, align 8, !dbg !677
  store i64 %193, ptr %28, align 8, !dbg !645
  %194 = load i64, ptr %28, align 8, !dbg !645
  %195 = icmp eq i64 %194, 25, !dbg !645
  br i1 %195, label %block76, label %block77, !dbg !645

worker.cancelled151:                              ; preds = %block76
  call void @vd_gc_frame_leave(ptr %32), !dbg !645
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !645

worker.continue152:                               ; preds = %block76
  call void @vd_gc_frame_leave(ptr %32), !dbg !646
  ret %"/@stdlib/console.void::key" { i32 25 }, !dbg !646

worker.cancelled153:                              ; preds = %block77
  call void @vd_gc_frame_leave(ptr %32), !dbg !646
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !646

worker.continue154:                               ; preds = %block77
  br label %block78, !dbg !646

worker.cancelled155:                              ; preds = %block78
  call void @vd_gc_frame_leave(ptr %32), !dbg !646
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !646

worker.continue156:                               ; preds = %block78
  %196 = load i64, ptr %2, align 8, !dbg !678
  store i64 %196, ptr %29, align 8, !dbg !647
  %197 = load i64, ptr %29, align 8, !dbg !647
  %198 = icmp eq i64 %197, 26, !dbg !647
  br i1 %198, label %block79, label %block80, !dbg !647

worker.cancelled157:                              ; preds = %block79
  call void @vd_gc_frame_leave(ptr %32), !dbg !647
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !647

worker.continue158:                               ; preds = %block79
  call void @vd_gc_frame_leave(ptr %32), !dbg !648
  ret %"/@stdlib/console.void::key" { i32 26 }, !dbg !648

worker.cancelled159:                              ; preds = %block80
  call void @vd_gc_frame_leave(ptr %32), !dbg !648
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !648

worker.continue160:                               ; preds = %block80
  br label %block81, !dbg !648

worker.cancelled161:                              ; preds = %block81
  call void @vd_gc_frame_leave(ptr %32), !dbg !648
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !648

worker.continue162:                               ; preds = %block81
  %199 = load i64, ptr %2, align 8, !dbg !679
  store i64 %199, ptr %30, align 8, !dbg !649
  %200 = load i64, ptr %30, align 8, !dbg !649
  %201 = icmp eq i64 %200, 27, !dbg !649
  br i1 %201, label %block82, label %block83, !dbg !649

worker.cancelled163:                              ; preds = %block82
  call void @vd_gc_frame_leave(ptr %32), !dbg !649
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !649

worker.continue164:                               ; preds = %block82
  call void @vd_gc_frame_leave(ptr %32), !dbg !650
  ret %"/@stdlib/console.void::key" { i32 27 }, !dbg !650

worker.cancelled165:                              ; preds = %block83
  call void @vd_gc_frame_leave(ptr %32), !dbg !650
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !650

worker.continue166:                               ; preds = %block83
  br label %block84, !dbg !650

worker.cancelled167:                              ; preds = %block84
  call void @vd_gc_frame_leave(ptr %32), !dbg !650
  ret %"/@stdlib/console.void::key" zeroinitializer, !dbg !650

worker.continue168:                               ; preds = %block84
  call void @vd_gc_frame_leave(ptr %32), !dbg !680
  ret %"/@stdlib/console.void::key" { i32 27 }, !dbg !680
}

define %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f6b6579__v1(ptr %0, i1 %1, i64 %2, ptr %3) !dbg !681 {
block0:
  %4 = alloca [8 x i64], align 8
  %5 = alloca i1, align 1
  store i1 false, ptr %5, align 1
  %6 = alloca i64, align 8
  store i64 0, ptr %6, align 8
  %7 = alloca i64, align 8
  store i64 0, ptr %7, align 8
  %8 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca i64, align 8
  store i64 0, ptr %11, align 8
  %12 = alloca i64, align 8
  store i64 0, ptr %12, align 8
  %13 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %13, align 8
  %14 = alloca ptr, align 8
  store ptr null, ptr %14, align 8
  %15 = alloca ptr, align 8
  store ptr null, ptr %15, align 8
  %16 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %16, align 8
  %17 = alloca ptr, align 8
  store ptr null, ptr %17, align 8
  %18 = alloca %"/@stdlib/console.void::key", align 8
  store %"/@stdlib/console.void::key" zeroinitializer, ptr %18, align 4
  %19 = alloca i64, align 8
  store i64 0, ptr %19, align 8
  %20 = alloca i1, align 1
  store i1 false, ptr %20, align 1
  %21 = alloca i64, align 8
  store i64 0, ptr %21, align 8
  %22 = alloca i64, align 8
  store i64 0, ptr %22, align 8
  %23 = alloca i1, align 1
  store i1 false, ptr %23, align 1
  %24 = alloca i64, align 8
  store i64 0, ptr %24, align 8
  %25 = alloca i64, align 8
  store i64 0, ptr %25, align 8
  %26 = alloca i1, align 1
  store i1 false, ptr %26, align 1
  %27 = alloca i64, align 8
  store i64 0, ptr %27, align 8
  %28 = alloca i64, align 8
  store i64 0, ptr %28, align 8
  %29 = alloca i1, align 1
  store i1 false, ptr %29, align 1
  %30 = alloca i64, align 8
  store i64 0, ptr %30, align 8
  %31 = alloca i64, align 8
  store i64 0, ptr %31, align 8
  %32 = alloca i1, align 1
  store i1 false, ptr %32, align 1
  %33 = alloca i64, align 8
  store i64 0, ptr %33, align 8
  %34 = alloca i64, align 8
  store i64 0, ptr %34, align 8
  %35 = alloca i1, align 1
  store i1 false, ptr %35, align 1
  %36 = alloca i64, align 8
  store i64 0, ptr %36, align 8
  %37 = alloca i64, align 8
  store i64 0, ptr %37, align 8
  %38 = alloca i64, align 8
  store i64 0, ptr %38, align 8
  %39 = alloca i64, align 8
  store i64 0, ptr %39, align 8
  %40 = alloca ptr, align 8
  store ptr null, ptr %40, align 8
  %41 = alloca ptr, align 8
  store ptr null, ptr %41, align 8
  %42 = alloca %"/@stdlib/console.void::key", align 8
  store %"/@stdlib/console.void::key" zeroinitializer, ptr %42, align 4
  %43 = alloca i1, align 1
  store i1 false, ptr %43, align 1
  %44 = alloca i1, align 1
  store i1 false, ptr %44, align 1
  %45 = alloca i1, align 1
  store i1 false, ptr %45, align 1
  %46 = alloca i1, align 1
  store i1 false, ptr %46, align 1
  %47 = alloca i1, align 1
  store i1 false, ptr %47, align 1
  %48 = alloca i1, align 1
  store i1 false, ptr %48, align 1
  %49 = alloca i64, align 8
  store i64 0, ptr %49, align 8
  %50 = alloca ptr, align 8
  store ptr null, ptr %50, align 8
  %51 = alloca %"/@stdlib/console.void::key_event", align 8
  store %"/@stdlib/console.void::key_event" zeroinitializer, ptr %51, align 8
  %52 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, i64 80, 1
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, ptr @gc.offsets.414, 2
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, i64 2, 3
  %56 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, i64 80, 1
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, ptr @gc.offsets.415, 2
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, i64 2, 3
  %60 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %14, 0
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 8, 1
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, ptr @gc.offsets.416, 2
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, i64 1, 3
  %64 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %15, 0
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 8, 1
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, ptr @gc.offsets.417, 2
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, i64 1, 3
  %68 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %16, 0
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, i64 72, 1
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, ptr @gc.offsets.418, 2
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 4, 3
  %72 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %17, 0
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 8, 1
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, ptr @gc.offsets.419, 2
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 1, 3
  %76 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %40, 0
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, i64 8, 1
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, ptr @gc.offsets.420, 2
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, i64 1, 3
  %80 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %41, 0
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, i64 8, 1
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, ptr @gc.offsets.421, 2
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 1, 3
  %84 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %50, 0
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 8, 1
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, ptr @gc.offsets.422, 2
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, i64 1, 3
  %88 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %51, 0
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, i64 40, 1
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, ptr @gc.offsets.423, 2
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, i64 2, 3
  %92 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %92, align 8
  %93 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %92, 0
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, i64 80, 1
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, ptr @gc.offsets.424, 2
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, i64 2, 3
  %97 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %97, align 8
  %98 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %97, 0
  %99 = insertvalue { ptr, i64, ptr, i64 } %98, i64 80, 1
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, ptr @gc.offsets.425, 2
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, i64 2, 3
  %102 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %102, align 8
  %103 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %102, 0
  %104 = insertvalue { ptr, i64, ptr, i64 } %103, i64 80, 1
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, ptr @gc.offsets.426, 2
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, i64 2, 3
  %107 = alloca ptr, align 8
  store ptr null, ptr %107, align 8
  %108 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %107, 0
  %109 = insertvalue { ptr, i64, ptr, i64 } %108, i64 8, 1
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, ptr @gc.offsets.427, 2
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, i64 1, 3
  %112 = alloca ptr, align 8
  store ptr null, ptr %112, align 8
  %113 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %112, 0
  %114 = insertvalue { ptr, i64, ptr, i64 } %113, i64 8, 1
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, ptr @gc.offsets.428, 2
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, i64 1, 3
  %117 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %117, align 8
  %118 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %117, 0
  %119 = insertvalue { ptr, i64, ptr, i64 } %118, i64 80, 1
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, ptr @gc.offsets.429, 2
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, i64 2, 3
  %122 = alloca ptr, align 8
  store ptr null, ptr %122, align 8
  %123 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %122, 0
  %124 = insertvalue { ptr, i64, ptr, i64 } %123, i64 8, 1
  %125 = insertvalue { ptr, i64, ptr, i64 } %124, ptr @gc.offsets.430, 2
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, i64 1, 3
  %127 = alloca ptr, align 8
  store ptr null, ptr %127, align 8
  %128 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %127, 0
  %129 = insertvalue { ptr, i64, ptr, i64 } %128, i64 8, 1
  %130 = insertvalue { ptr, i64, ptr, i64 } %129, ptr @gc.offsets.431, 2
  %131 = insertvalue { ptr, i64, ptr, i64 } %130, i64 1, 3
  %132 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %132, align 8
  %133 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %132, 0
  %134 = insertvalue { ptr, i64, ptr, i64 } %133, i64 72, 1
  %135 = insertvalue { ptr, i64, ptr, i64 } %134, ptr @gc.offsets.432, 2
  %136 = insertvalue { ptr, i64, ptr, i64 } %135, i64 4, 3
  %137 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %137, align 8
  %138 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %137, 0
  %139 = insertvalue { ptr, i64, ptr, i64 } %138, i64 72, 1
  %140 = insertvalue { ptr, i64, ptr, i64 } %139, ptr @gc.offsets.433, 2
  %141 = insertvalue { ptr, i64, ptr, i64 } %140, i64 4, 3
  %142 = alloca %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %142, align 8
  %143 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %142, 0
  %144 = insertvalue { ptr, i64, ptr, i64 } %143, i64 120, 1
  %145 = insertvalue { ptr, i64, ptr, i64 } %144, ptr @gc.offsets.434, 2
  %146 = insertvalue { ptr, i64, ptr, i64 } %145, i64 6, 3
  %147 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %147, align 8
  %148 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %147, 0
  %149 = insertvalue { ptr, i64, ptr, i64 } %148, i64 80, 1
  %150 = insertvalue { ptr, i64, ptr, i64 } %149, ptr @gc.offsets.435, 2
  %151 = insertvalue { ptr, i64, ptr, i64 } %150, i64 2, 3
  %152 = alloca ptr, align 8
  store ptr null, ptr %152, align 8
  %153 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %152, 0
  %154 = insertvalue { ptr, i64, ptr, i64 } %153, i64 8, 1
  %155 = insertvalue { ptr, i64, ptr, i64 } %154, ptr @gc.offsets.436, 2
  %156 = insertvalue { ptr, i64, ptr, i64 } %155, i64 1, 3
  %157 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %157, align 8
  %158 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %157, 0
  %159 = insertvalue { ptr, i64, ptr, i64 } %158, i64 80, 1
  %160 = insertvalue { ptr, i64, ptr, i64 } %159, ptr @gc.offsets.437, 2
  %161 = insertvalue { ptr, i64, ptr, i64 } %160, i64 2, 3
  %162 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %162, align 8
  %163 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %162, 0
  %164 = insertvalue { ptr, i64, ptr, i64 } %163, i64 80, 1
  %165 = insertvalue { ptr, i64, ptr, i64 } %164, ptr @gc.offsets.438, 2
  %166 = insertvalue { ptr, i64, ptr, i64 } %165, i64 2, 3
  %167 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %167, align 8
  %168 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %167, 0
  %169 = insertvalue { ptr, i64, ptr, i64 } %168, i64 80, 1
  %170 = insertvalue { ptr, i64, ptr, i64 } %169, ptr @gc.offsets.439, 2
  %171 = insertvalue { ptr, i64, ptr, i64 } %170, i64 2, 3
  %172 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %172, align 8
  %173 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %172, 0
  %174 = insertvalue { ptr, i64, ptr, i64 } %173, i64 80, 1
  %175 = insertvalue { ptr, i64, ptr, i64 } %174, ptr @gc.offsets.440, 2
  %176 = insertvalue { ptr, i64, ptr, i64 } %175, i64 2, 3
  %177 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %177, align 8
  %178 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %177, 0
  %179 = insertvalue { ptr, i64, ptr, i64 } %178, i64 80, 1
  %180 = insertvalue { ptr, i64, ptr, i64 } %179, ptr @gc.offsets.441, 2
  %181 = insertvalue { ptr, i64, ptr, i64 } %180, i64 2, 3
  %182 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %182, align 8
  %183 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %182, 0
  %184 = insertvalue { ptr, i64, ptr, i64 } %183, i64 80, 1
  %185 = insertvalue { ptr, i64, ptr, i64 } %184, ptr @gc.offsets.442, 2
  %186 = insertvalue { ptr, i64, ptr, i64 } %185, i64 2, 3
  %187 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %187, align 8
  %188 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %187, 0
  %189 = insertvalue { ptr, i64, ptr, i64 } %188, i64 80, 1
  %190 = insertvalue { ptr, i64, ptr, i64 } %189, ptr @gc.offsets.443, 2
  %191 = insertvalue { ptr, i64, ptr, i64 } %190, i64 2, 3
  %192 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %192, align 8
  %193 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %192, 0
  %194 = insertvalue { ptr, i64, ptr, i64 } %193, i64 80, 1
  %195 = insertvalue { ptr, i64, ptr, i64 } %194, ptr @gc.offsets.444, 2
  %196 = insertvalue { ptr, i64, ptr, i64 } %195, i64 2, 3
  %197 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %197, align 8
  %198 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %197, 0
  %199 = insertvalue { ptr, i64, ptr, i64 } %198, i64 80, 1
  %200 = insertvalue { ptr, i64, ptr, i64 } %199, ptr @gc.offsets.445, 2
  %201 = insertvalue { ptr, i64, ptr, i64 } %200, i64 2, 3
  %202 = alloca ptr, align 8
  store ptr null, ptr %202, align 8
  %203 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %202, 0
  %204 = insertvalue { ptr, i64, ptr, i64 } %203, i64 8, 1
  %205 = insertvalue { ptr, i64, ptr, i64 } %204, ptr @gc.offsets.446, 2
  %206 = insertvalue { ptr, i64, ptr, i64 } %205, i64 1, 3
  %207 = alloca ptr, align 8
  store ptr null, ptr %207, align 8
  %208 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %207, 0
  %209 = insertvalue { ptr, i64, ptr, i64 } %208, i64 8, 1
  %210 = insertvalue { ptr, i64, ptr, i64 } %209, ptr @gc.offsets.447, 2
  %211 = insertvalue { ptr, i64, ptr, i64 } %210, i64 1, 3
  %212 = alloca ptr, align 8
  store ptr null, ptr %212, align 8
  %213 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %212, 0
  %214 = insertvalue { ptr, i64, ptr, i64 } %213, i64 8, 1
  %215 = insertvalue { ptr, i64, ptr, i64 } %214, ptr @gc.offsets.448, 2
  %216 = insertvalue { ptr, i64, ptr, i64 } %215, i64 1, 3
  %217 = alloca ptr, align 8
  store ptr null, ptr %217, align 8
  %218 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %217, 0
  %219 = insertvalue { ptr, i64, ptr, i64 } %218, i64 8, 1
  %220 = insertvalue { ptr, i64, ptr, i64 } %219, ptr @gc.offsets.449, 2
  %221 = insertvalue { ptr, i64, ptr, i64 } %220, i64 1, 3
  %222 = alloca ptr, align 8
  store ptr null, ptr %222, align 8
  %223 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %222, 0
  %224 = insertvalue { ptr, i64, ptr, i64 } %223, i64 8, 1
  %225 = insertvalue { ptr, i64, ptr, i64 } %224, ptr @gc.offsets.450, 2
  %226 = insertvalue { ptr, i64, ptr, i64 } %225, i64 1, 3
  %227 = alloca %"/@stdlib/console.void::key_event", align 8
  store %"/@stdlib/console.void::key_event" zeroinitializer, ptr %227, align 8
  %228 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %227, 0
  %229 = insertvalue { ptr, i64, ptr, i64 } %228, i64 40, 1
  %230 = insertvalue { ptr, i64, ptr, i64 } %229, ptr @gc.offsets.451, 2
  %231 = insertvalue { ptr, i64, ptr, i64 } %230, i64 2, 3
  %232 = alloca %"/@stdlib/console.void::key_event", align 8
  store %"/@stdlib/console.void::key_event" zeroinitializer, ptr %232, align 8
  %233 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %232, 0
  %234 = insertvalue { ptr, i64, ptr, i64 } %233, i64 40, 1
  %235 = insertvalue { ptr, i64, ptr, i64 } %234, ptr @gc.offsets.452, 2
  %236 = insertvalue { ptr, i64, ptr, i64 } %235, i64 2, 3
  %237 = alloca %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %237, align 8
  %238 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %237, 0
  %239 = insertvalue { ptr, i64, ptr, i64 } %238, i64 120, 1
  %240 = insertvalue { ptr, i64, ptr, i64 } %239, ptr @gc.offsets.453, 2
  %241 = insertvalue { ptr, i64, ptr, i64 } %240, i64 6, 3
  %242 = alloca [40 x { ptr, i64, ptr, i64 }], align 8
  %243 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %55, ptr %243, align 8
  %244 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %59, ptr %244, align 8
  %245 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %63, ptr %245, align 8
  %246 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %67, ptr %246, align 8
  %247 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %71, ptr %247, align 8
  %248 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %75, ptr %248, align 8
  %249 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %79, ptr %249, align 8
  %250 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %83, ptr %250, align 8
  %251 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %87, ptr %251, align 8
  %252 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %91, ptr %252, align 8
  %253 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %96, ptr %253, align 8
  %254 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %101, ptr %254, align 8
  %255 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %106, ptr %255, align 8
  %256 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %111, ptr %256, align 8
  %257 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %116, ptr %257, align 8
  %258 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %121, ptr %258, align 8
  %259 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %126, ptr %259, align 8
  %260 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %131, ptr %260, align 8
  %261 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %136, ptr %261, align 8
  %262 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %141, ptr %262, align 8
  %263 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %146, ptr %263, align 8
  %264 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %151, ptr %264, align 8
  %265 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %156, ptr %265, align 8
  %266 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %161, ptr %266, align 8
  %267 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 24
  store { ptr, i64, ptr, i64 } %166, ptr %267, align 8
  %268 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 25
  store { ptr, i64, ptr, i64 } %171, ptr %268, align 8
  %269 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 26
  store { ptr, i64, ptr, i64 } %176, ptr %269, align 8
  %270 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 27
  store { ptr, i64, ptr, i64 } %181, ptr %270, align 8
  %271 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 28
  store { ptr, i64, ptr, i64 } %186, ptr %271, align 8
  %272 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 29
  store { ptr, i64, ptr, i64 } %191, ptr %272, align 8
  %273 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 30
  store { ptr, i64, ptr, i64 } %196, ptr %273, align 8
  %274 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 31
  store { ptr, i64, ptr, i64 } %201, ptr %274, align 8
  %275 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 32
  store { ptr, i64, ptr, i64 } %206, ptr %275, align 8
  %276 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 33
  store { ptr, i64, ptr, i64 } %211, ptr %276, align 8
  %277 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 34
  store { ptr, i64, ptr, i64 } %216, ptr %277, align 8
  %278 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 35
  store { ptr, i64, ptr, i64 } %221, ptr %278, align 8
  %279 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 36
  store { ptr, i64, ptr, i64 } %226, ptr %279, align 8
  %280 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 37
  store { ptr, i64, ptr, i64 } %231, ptr %280, align 8
  %281 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 38
  store { ptr, i64, ptr, i64 } %236, ptr %281, align 8
  %282 = getelementptr inbounds [40 x { ptr, i64, ptr, i64 }], ptr %242, i32 0, i32 39
  store { ptr, i64, ptr, i64 } %241, ptr %282, align 8
  %283 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %283, ptr %242, i64 40)
  call void @vd_gc_poll()
  %284 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %284, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !700
  %285 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !700
  br i1 %285, label %worker.cancelled1, label %worker.continue2, !dbg !700

block2:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !701
  %286 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !701
  br i1 %286, label %worker.cancelled3, label %worker.continue4, !dbg !701

block3:                                           ; preds = %worker.continue4, %worker.continue2
  call void @vd_gc_poll(), !dbg !701
  %287 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !701
  br i1 %287, label %worker.cancelled5, label %worker.continue6, !dbg !701

block4:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !702
  %288 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !702
  br i1 %288, label %worker.cancelled7, label %worker.continue8, !dbg !702

block5:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !703
  %289 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !703
  br i1 %289, label %worker.cancelled16, label %worker.continue17, !dbg !703

block6:                                           ; preds = %worker.continue17
  call void @vd_gc_poll(), !dbg !703
  %290 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !703
  br i1 %290, label %worker.cancelled18, label %worker.continue19, !dbg !703

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %283)
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  store i1 %1, ptr %5, align 1, !dbg !704
  store i64 %2, ptr %6, align 8, !dbg !705
  store i64 0, ptr %7, align 8, !dbg !706
  %291 = load i1, ptr %5, align 1, !dbg !700
  br i1 %291, label %block1, label %block2, !dbg !700

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %283), !dbg !700
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !700

worker.continue2:                                 ; preds = %block1
  store i64 1, ptr %7, align 8, !dbg !701
  br label %block3, !dbg !701

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %283), !dbg !701
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !701

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !701

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %283), !dbg !701
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !701

worker.continue6:                                 ; preds = %block3
  %292 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !707
  store %"/@stdlib/console.void::input" %292, ptr %9, align 8, !dbg !707
  %293 = load i64, ptr %7, align 8, !dbg !708
  store i64 %293, ptr %10, align 8, !dbg !708
  %294 = load i64, ptr %6, align 8, !dbg !709
  store i64 %294, ptr %11, align 8, !dbg !709
  %295 = load %"/@stdlib/console.void::input", ptr %9, align 8, !dbg !710
  %296 = load i64, ptr %10, align 8, !dbg !710
  %297 = load i64, ptr %11, align 8, !dbg !710
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %92, align 8, !dbg !710
  store [8 x i64] zeroinitializer, ptr %4, align 8, !dbg !710
  %298 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 6, !dbg !710
  %299 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 7, !dbg !710
  %300 = extractvalue %"/@stdlib/console.void::input" %295, 0, !dbg !710
  call void @vd_console_v2(ptr %298, ptr %299, ptr %4, i32 18, i64 %300, ptr null, i64 %296, i64 %297, ptr %3), !dbg !710
  %301 = load ptr, ptr %3, align 8, !dbg !710
  %302 = icmp ne ptr %301, null, !dbg !710
  br i1 %302, label %selected.failure, label %selected.valid, !dbg !710

selected.failure:                                 ; preds = %worker.continue6
  %303 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !710
  %304 = load i32, ptr %303, align 4, !dbg !710
  %305 = icmp ult i32 %304, 32, !dbg !710
  br i1 %305, label %trace_caller, label %trace_limit, !dbg !710

selected.valid:                                   ; preds = %worker.continue6
  %306 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 0, !dbg !710
  %307 = load i64, ptr %306, align 8, !dbg !710
  %308 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 0, !dbg !710
  store i64 %307, ptr %308, align 8, !dbg !710
  %309 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 1, !dbg !710
  %310 = load i64, ptr %309, align 8, !dbg !710
  %311 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 1, !dbg !710
  store i64 %310, ptr %311, align 8, !dbg !710
  %312 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 2, !dbg !710
  %313 = load i64, ptr %312, align 8, !dbg !710
  %314 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 2, !dbg !710
  store i64 %313, ptr %314, align 8, !dbg !710
  %315 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 3, !dbg !710
  %316 = load i64, ptr %315, align 8, !dbg !710
  %317 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 3, !dbg !710
  store i64 %316, ptr %317, align 8, !dbg !710
  %318 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 4, !dbg !710
  %319 = load i64, ptr %318, align 8, !dbg !710
  %320 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 4, !dbg !710
  store i64 %319, ptr %320, align 8, !dbg !710
  %321 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 5, !dbg !710
  %322 = load i64, ptr %321, align 8, !dbg !710
  %323 = trunc i64 %322 to i1, !dbg !710
  %324 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 5, !dbg !710
  store i1 %323, ptr %324, align 1, !dbg !710
  %325 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 6, !dbg !710
  %326 = load i64, ptr %325, align 8, !dbg !710
  %327 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 8, !dbg !710
  store i64 %326, ptr %327, align 8, !dbg !710
  %328 = getelementptr inbounds [8 x i64], ptr %4, i32 0, i32 7, !dbg !710
  %329 = load i64, ptr %328, align 8, !dbg !710
  %330 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %92, i32 0, i32 9, !dbg !710
  store i64 %329, ptr %330, align 8, !dbg !710
  %331 = load %"/@stdlib/console.void::_reply", ptr %92, align 8, !dbg !710
  store %"/@stdlib/console.void::_reply" %331, ptr %92, align 8, !dbg !710
  store %"/@stdlib/console.void::_reply" %331, ptr %8, align 8, !dbg !711
  %332 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !712
  store %"/@stdlib/console.void::_reply" %332, ptr %97, align 8, !dbg !712
  %333 = extractvalue %"/@stdlib/console.void::_reply" %332, 0, !dbg !713
  store i64 %333, ptr %12, align 8, !dbg !702
  %334 = load i64, ptr %12, align 8, !dbg !702
  %335 = icmp ne i64 %334, 0, !dbg !702
  br i1 %335, label %block4, label %block5, !dbg !702

trace_caller:                                     ; preds = %selected.failure
  %336 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !710
  %337 = getelementptr [32 x ptr], ptr %336, i32 0, i32 %304, !dbg !710
  store ptr @216, ptr %337, align 8, !dbg !710
  %338 = add i32 %304, 1, !dbg !710
  store i32 %338, ptr %303, align 4, !dbg !710
  br label %error_return, !dbg !710

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %283), !dbg !710
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !710

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %303, align 4, !dbg !710
  br label %error_return, !dbg !710

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %283), !dbg !702
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !702

worker.continue8:                                 ; preds = %block4
  %339 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !714
  store %"/@stdlib/console.void::_reply" %339, ptr %102, align 8, !dbg !714
  store %"/@stdlib/console.void::_reply" %339, ptr %13, align 8, !dbg !714
  call void @vd_string_literal(ptr %107, ptr @217, i64 8, ptr %3), !dbg !715
  %340 = load ptr, ptr %107, align 8, !dbg !715
  %341 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !715
  %342 = load ptr, ptr %341, align 8, !dbg !715
  %343 = icmp ne ptr %342, null, !dbg !715
  br i1 %343, label %numeric_error, label %numeric_valid, !dbg !715

numeric_error:                                    ; preds = %worker.continue8
  %344 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !715
  store ptr @218, ptr %344, align 8, !dbg !715
  call void @vd_gc_frame_leave(ptr %283), !dbg !715
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !715

numeric_valid:                                    ; preds = %worker.continue8
  store ptr %340, ptr %107, align 8, !dbg !715
  store ptr %340, ptr %14, align 8, !dbg !715
  call void @vd_string_literal(ptr %112, ptr @219, i64 5, ptr %3), !dbg !716
  %345 = load ptr, ptr %112, align 8, !dbg !716
  %346 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !716
  %347 = load ptr, ptr %346, align 8, !dbg !716
  %348 = icmp ne ptr %347, null, !dbg !716
  br i1 %348, label %numeric_error9, label %numeric_valid10, !dbg !716

numeric_error9:                                   ; preds = %numeric_valid
  %349 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !716
  store ptr @220, ptr %349, align 8, !dbg !716
  call void @vd_gc_frame_leave(ptr %283), !dbg !716
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !716

numeric_valid10:                                  ; preds = %numeric_valid
  store ptr %345, ptr %112, align 8, !dbg !716
  store ptr %345, ptr %15, align 8, !dbg !716
  %350 = load %"/@stdlib/console.void::_reply", ptr %13, align 8, !dbg !717
  store %"/@stdlib/console.void::_reply" %350, ptr %117, align 8, !dbg !717
  %351 = load ptr, ptr %14, align 8, !dbg !717
  store ptr %351, ptr %122, align 8, !dbg !717
  %352 = load ptr, ptr %15, align 8, !dbg !717
  store ptr %352, ptr %127, align 8, !dbg !717
  %353 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %350, ptr %351, ptr %352, ptr %3), !dbg !717
  %354 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !717
  %355 = load ptr, ptr %354, align 8, !dbg !717
  %356 = icmp ne ptr %355, null, !dbg !717
  br i1 %356, label %propagate_error, label %call_success, !dbg !717

propagate_error:                                  ; preds = %numeric_valid10
  %357 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !717
  %358 = load i32, ptr %357, align 4, !dbg !717
  %359 = icmp ult i32 %358, 32, !dbg !717
  br i1 %359, label %trace_caller11, label %trace_limit13, !dbg !717

call_success:                                     ; preds = %numeric_valid10
  store %"/@stdlib/console.void::io_error" %353, ptr %132, align 8, !dbg !717
  store %"/@stdlib/console.void::io_error" %353, ptr %16, align 8, !dbg !717
  %360 = load %"/@stdlib/console.void::io_error", ptr %16, align 8, !dbg !703
  store %"/@stdlib/console.void::io_error" %360, ptr %137, align 8, !dbg !703
  %361 = insertvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, %"/@stdlib/console.void::key_event" zeroinitializer, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %360, 2, !dbg !703
  %362 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, 0, !dbg !703
  %363 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, 0, !dbg !703
  %364 = icmp eq i32 %363, 0, !dbg !703
  br i1 %364, label %validate_active_payload, label %validate_payload_done, !dbg !703

trace_caller11:                                   ; preds = %propagate_error
  %365 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !717
  %366 = getelementptr [32 x ptr], ptr %365, i32 0, i32 %358, !dbg !717
  store ptr @221, ptr %366, align 8, !dbg !717
  %367 = add i32 %358, 1, !dbg !717
  store i32 %367, ptr %357, align 4, !dbg !717
  br label %error_return12, !dbg !717

error_return12:                                   ; preds = %trace_caller11, %trace_limit13
  call void @vd_gc_frame_leave(ptr %283), !dbg !717
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !717

trace_limit13:                                    ; preds = %propagate_error
  store i32 33, ptr %357, align 4, !dbg !717
  br label %error_return12, !dbg !717

validate_active_payload:                          ; preds = %call_success
  %368 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, 1, !dbg !703
  %369 = extractvalue %"/@stdlib/console.void::key_event" %368, 0, !dbg !703
  %370 = extractvalue %"/@stdlib/console.void::key_event" %368, 1, !dbg !703
  %371 = extractvalue %"/@stdlib/console.void::key" %370, 0, !dbg !703
  %372 = extractvalue %"/@stdlib/console.void::key_event" %368, 2, !dbg !703
  %373 = extractvalue %"/@stdlib/console.void::key_event" %368, 3, !dbg !703
  %374 = extractvalue %"/@stdlib/console.void::key_event" %368, 4, !dbg !703
  %375 = extractvalue %"/@stdlib/console.void::key_event" %368, 5, !dbg !703
  %376 = extractvalue %"/@stdlib/console.void::key_event" %368, 6, !dbg !703
  %377 = extractvalue %"/@stdlib/console.void::key_event" %368, 7, !dbg !703
  %378 = extractvalue %"/@stdlib/console.void::key_event" %368, 8, !dbg !703
  %379 = extractvalue %"/@stdlib/console.void::key_event" %368, 9, !dbg !703
  br label %validate_payload_done, !dbg !703

validate_payload_done:                            ; preds = %validate_active_payload, %call_success
  %380 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, 0, !dbg !703
  %381 = icmp eq i32 %380, 1, !dbg !703
  br i1 %381, label %validate_active_payload14, label %validate_payload_done15, !dbg !703

validate_active_payload14:                        ; preds = %validate_payload_done
  %382 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, 2, !dbg !703
  %383 = extractvalue %"/@stdlib/console.void::io_error" %382, 0, !dbg !703
  %384 = extractvalue %"/@stdlib/console.void::io_error" %382, 1, !dbg !703
  %385 = extractvalue %"/@stdlib/console.void::io_error" %382, 2, !dbg !703
  %386 = extractvalue %"/@stdlib/console.void::io_error_kind" %385, 0, !dbg !703
  %387 = extractvalue %"/@stdlib/console.void::io_error" %382, 3, !dbg !703
  %388 = extractvalue %"/@stdlib/console.void::io_error" %382, 4, !dbg !703
  %389 = extractvalue %"/@stdlib/console.void::io_error" %382, 5, !dbg !703
  %390 = extractvalue %"/@stdlib/console.void::io_error" %382, 6, !dbg !703
  %391 = extractvalue %"/@stdlib/console.void::io_error" %382, 7, !dbg !703
  %392 = extractvalue %"/@stdlib/console.void::io_error" %382, 8, !dbg !703
  br label %validate_payload_done15, !dbg !703

validate_payload_done15:                          ; preds = %validate_active_payload14, %validate_payload_done
  store %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, ptr %142, align 8, !dbg !703
  call void @vd_gc_frame_leave(ptr %283), !dbg !703
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %361, !dbg !703

worker.cancelled16:                               ; preds = %block5
  call void @vd_gc_frame_leave(ptr %283), !dbg !703
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !703

worker.continue17:                                ; preds = %block5
  br label %block6, !dbg !703

worker.cancelled18:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %283), !dbg !703
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !703

worker.continue19:                                ; preds = %block6
  %393 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !718
  store %"/@stdlib/console.void::_reply" %393, ptr %147, align 8, !dbg !718
  %394 = extractvalue %"/@stdlib/console.void::_reply" %393, 6, !dbg !719
  store ptr %394, ptr %152, align 8, !dbg !719
  store ptr %394, ptr %17, align 8, !dbg !719
  %395 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !720
  store %"/@stdlib/console.void::_reply" %395, ptr %157, align 8, !dbg !720
  %396 = extractvalue %"/@stdlib/console.void::_reply" %395, 8, !dbg !721
  store i64 %396, ptr %19, align 8, !dbg !721
  %397 = load i64, ptr %19, align 8, !dbg !722
  %398 = call %"/@stdlib/console.void::key" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6b6579__v1(i64 %397, ptr %3), !dbg !722
  %399 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !722
  %400 = load ptr, ptr %399, align 8, !dbg !722
  %401 = icmp ne ptr %400, null, !dbg !722
  br i1 %401, label %propagate_error20, label %call_success21, !dbg !722

propagate_error20:                                ; preds = %worker.continue19
  %402 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !722
  %403 = load i32, ptr %402, align 4, !dbg !722
  %404 = icmp ult i32 %403, 32, !dbg !722
  br i1 %404, label %trace_caller22, label %trace_limit24, !dbg !722

call_success21:                                   ; preds = %worker.continue19
  store %"/@stdlib/console.void::key" %398, ptr %18, align 4, !dbg !722
  %405 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !723
  store %"/@stdlib/console.void::_reply" %405, ptr %162, align 8, !dbg !723
  %406 = extractvalue %"/@stdlib/console.void::_reply" %405, 9, !dbg !724
  store i64 %406, ptr %21, align 8, !dbg !724
  store i64 1, ptr %22, align 8, !dbg !725
  %407 = load i64, ptr %21, align 8, !dbg !726
  %408 = load i64, ptr %22, align 8, !dbg !726
  %409 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %407, i64 %408, ptr %3), !dbg !726
  %410 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !726
  %411 = load ptr, ptr %410, align 8, !dbg !726
  %412 = icmp ne ptr %411, null, !dbg !726
  br i1 %412, label %propagate_error25, label %call_success26, !dbg !726

trace_caller22:                                   ; preds = %propagate_error20
  %413 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !722
  %414 = getelementptr [32 x ptr], ptr %413, i32 0, i32 %403, !dbg !722
  store ptr @222, ptr %414, align 8, !dbg !722
  %415 = add i32 %403, 1, !dbg !722
  store i32 %415, ptr %402, align 4, !dbg !722
  br label %error_return23, !dbg !722

error_return23:                                   ; preds = %trace_caller22, %trace_limit24
  call void @vd_gc_frame_leave(ptr %283), !dbg !722
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !722

trace_limit24:                                    ; preds = %propagate_error20
  store i32 33, ptr %402, align 4, !dbg !722
  br label %error_return23, !dbg !722

propagate_error25:                                ; preds = %call_success21
  %416 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !726
  %417 = load i32, ptr %416, align 4, !dbg !726
  %418 = icmp ult i32 %417, 32, !dbg !726
  br i1 %418, label %trace_caller27, label %trace_limit29, !dbg !726

call_success26:                                   ; preds = %call_success21
  store i1 %409, ptr %20, align 1, !dbg !726
  %419 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !727
  store %"/@stdlib/console.void::_reply" %419, ptr %167, align 8, !dbg !727
  %420 = extractvalue %"/@stdlib/console.void::_reply" %419, 9, !dbg !728
  store i64 %420, ptr %24, align 8, !dbg !728
  store i64 2, ptr %25, align 8, !dbg !729
  %421 = load i64, ptr %24, align 8, !dbg !730
  %422 = load i64, ptr %25, align 8, !dbg !730
  %423 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %421, i64 %422, ptr %3), !dbg !730
  %424 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !730
  %425 = load ptr, ptr %424, align 8, !dbg !730
  %426 = icmp ne ptr %425, null, !dbg !730
  br i1 %426, label %propagate_error30, label %call_success31, !dbg !730

trace_caller27:                                   ; preds = %propagate_error25
  %427 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !726
  %428 = getelementptr [32 x ptr], ptr %427, i32 0, i32 %417, !dbg !726
  store ptr @223, ptr %428, align 8, !dbg !726
  %429 = add i32 %417, 1, !dbg !726
  store i32 %429, ptr %416, align 4, !dbg !726
  br label %error_return28, !dbg !726

error_return28:                                   ; preds = %trace_caller27, %trace_limit29
  call void @vd_gc_frame_leave(ptr %283), !dbg !726
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !726

trace_limit29:                                    ; preds = %propagate_error25
  store i32 33, ptr %416, align 4, !dbg !726
  br label %error_return28, !dbg !726

propagate_error30:                                ; preds = %call_success26
  %430 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !730
  %431 = load i32, ptr %430, align 4, !dbg !730
  %432 = icmp ult i32 %431, 32, !dbg !730
  br i1 %432, label %trace_caller32, label %trace_limit34, !dbg !730

call_success31:                                   ; preds = %call_success26
  store i1 %423, ptr %23, align 1, !dbg !730
  %433 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !731
  store %"/@stdlib/console.void::_reply" %433, ptr %172, align 8, !dbg !731
  %434 = extractvalue %"/@stdlib/console.void::_reply" %433, 9, !dbg !732
  store i64 %434, ptr %27, align 8, !dbg !732
  store i64 4, ptr %28, align 8, !dbg !733
  %435 = load i64, ptr %27, align 8, !dbg !734
  %436 = load i64, ptr %28, align 8, !dbg !734
  %437 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %435, i64 %436, ptr %3), !dbg !734
  %438 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !734
  %439 = load ptr, ptr %438, align 8, !dbg !734
  %440 = icmp ne ptr %439, null, !dbg !734
  br i1 %440, label %propagate_error35, label %call_success36, !dbg !734

trace_caller32:                                   ; preds = %propagate_error30
  %441 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !730
  %442 = getelementptr [32 x ptr], ptr %441, i32 0, i32 %431, !dbg !730
  store ptr @224, ptr %442, align 8, !dbg !730
  %443 = add i32 %431, 1, !dbg !730
  store i32 %443, ptr %430, align 4, !dbg !730
  br label %error_return33, !dbg !730

error_return33:                                   ; preds = %trace_caller32, %trace_limit34
  call void @vd_gc_frame_leave(ptr %283), !dbg !730
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !730

trace_limit34:                                    ; preds = %propagate_error30
  store i32 33, ptr %430, align 4, !dbg !730
  br label %error_return33, !dbg !730

propagate_error35:                                ; preds = %call_success31
  %444 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !734
  %445 = load i32, ptr %444, align 4, !dbg !734
  %446 = icmp ult i32 %445, 32, !dbg !734
  br i1 %446, label %trace_caller37, label %trace_limit39, !dbg !734

call_success36:                                   ; preds = %call_success31
  store i1 %437, ptr %26, align 1, !dbg !734
  %447 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !735
  store %"/@stdlib/console.void::_reply" %447, ptr %177, align 8, !dbg !735
  %448 = extractvalue %"/@stdlib/console.void::_reply" %447, 9, !dbg !736
  store i64 %448, ptr %30, align 8, !dbg !736
  store i64 8, ptr %31, align 8, !dbg !737
  %449 = load i64, ptr %30, align 8, !dbg !738
  %450 = load i64, ptr %31, align 8, !dbg !738
  %451 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %449, i64 %450, ptr %3), !dbg !738
  %452 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !738
  %453 = load ptr, ptr %452, align 8, !dbg !738
  %454 = icmp ne ptr %453, null, !dbg !738
  br i1 %454, label %propagate_error40, label %call_success41, !dbg !738

trace_caller37:                                   ; preds = %propagate_error35
  %455 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !734
  %456 = getelementptr [32 x ptr], ptr %455, i32 0, i32 %445, !dbg !734
  store ptr @225, ptr %456, align 8, !dbg !734
  %457 = add i32 %445, 1, !dbg !734
  store i32 %457, ptr %444, align 4, !dbg !734
  br label %error_return38, !dbg !734

error_return38:                                   ; preds = %trace_caller37, %trace_limit39
  call void @vd_gc_frame_leave(ptr %283), !dbg !734
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !734

trace_limit39:                                    ; preds = %propagate_error35
  store i32 33, ptr %444, align 4, !dbg !734
  br label %error_return38, !dbg !734

propagate_error40:                                ; preds = %call_success36
  %458 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !738
  %459 = load i32, ptr %458, align 4, !dbg !738
  %460 = icmp ult i32 %459, 32, !dbg !738
  br i1 %460, label %trace_caller42, label %trace_limit44, !dbg !738

call_success41:                                   ; preds = %call_success36
  store i1 %451, ptr %29, align 1, !dbg !738
  %461 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !739
  store %"/@stdlib/console.void::_reply" %461, ptr %182, align 8, !dbg !739
  %462 = extractvalue %"/@stdlib/console.void::_reply" %461, 9, !dbg !740
  store i64 %462, ptr %33, align 8, !dbg !740
  store i64 16, ptr %34, align 8, !dbg !741
  %463 = load i64, ptr %33, align 8, !dbg !742
  %464 = load i64, ptr %34, align 8, !dbg !742
  %465 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %463, i64 %464, ptr %3), !dbg !742
  %466 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !742
  %467 = load ptr, ptr %466, align 8, !dbg !742
  %468 = icmp ne ptr %467, null, !dbg !742
  br i1 %468, label %propagate_error45, label %call_success46, !dbg !742

trace_caller42:                                   ; preds = %propagate_error40
  %469 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !738
  %470 = getelementptr [32 x ptr], ptr %469, i32 0, i32 %459, !dbg !738
  store ptr @226, ptr %470, align 8, !dbg !738
  %471 = add i32 %459, 1, !dbg !738
  store i32 %471, ptr %458, align 4, !dbg !738
  br label %error_return43, !dbg !738

error_return43:                                   ; preds = %trace_caller42, %trace_limit44
  call void @vd_gc_frame_leave(ptr %283), !dbg !738
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !738

trace_limit44:                                    ; preds = %propagate_error40
  store i32 33, ptr %458, align 4, !dbg !738
  br label %error_return43, !dbg !738

propagate_error45:                                ; preds = %call_success41
  %472 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !742
  %473 = load i32, ptr %472, align 4, !dbg !742
  %474 = icmp ult i32 %473, 32, !dbg !742
  br i1 %474, label %trace_caller47, label %trace_limit49, !dbg !742

call_success46:                                   ; preds = %call_success41
  store i1 %465, ptr %32, align 1, !dbg !742
  %475 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !743
  store %"/@stdlib/console.void::_reply" %475, ptr %187, align 8, !dbg !743
  %476 = extractvalue %"/@stdlib/console.void::_reply" %475, 9, !dbg !744
  store i64 %476, ptr %36, align 8, !dbg !744
  store i64 32, ptr %37, align 8, !dbg !745
  %477 = load i64, ptr %36, align 8, !dbg !746
  %478 = load i64, ptr %37, align 8, !dbg !746
  %479 = call i1 @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1(i64 %477, i64 %478, ptr %3), !dbg !746
  %480 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !746
  %481 = load ptr, ptr %480, align 8, !dbg !746
  %482 = icmp ne ptr %481, null, !dbg !746
  br i1 %482, label %propagate_error50, label %call_success51, !dbg !746

trace_caller47:                                   ; preds = %propagate_error45
  %483 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !742
  %484 = getelementptr [32 x ptr], ptr %483, i32 0, i32 %473, !dbg !742
  store ptr @227, ptr %484, align 8, !dbg !742
  %485 = add i32 %473, 1, !dbg !742
  store i32 %485, ptr %472, align 4, !dbg !742
  br label %error_return48, !dbg !742

error_return48:                                   ; preds = %trace_caller47, %trace_limit49
  call void @vd_gc_frame_leave(ptr %283), !dbg !742
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !742

trace_limit49:                                    ; preds = %propagate_error45
  store i32 33, ptr %472, align 4, !dbg !742
  br label %error_return48, !dbg !742

propagate_error50:                                ; preds = %call_success46
  %486 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !746
  %487 = load i32, ptr %486, align 4, !dbg !746
  %488 = icmp ult i32 %487, 32, !dbg !746
  br i1 %488, label %trace_caller52, label %trace_limit54, !dbg !746

call_success51:                                   ; preds = %call_success46
  store i1 %479, ptr %35, align 1, !dbg !746
  %489 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !747
  store %"/@stdlib/console.void::_reply" %489, ptr %192, align 8, !dbg !747
  %490 = extractvalue %"/@stdlib/console.void::_reply" %489, 9, !dbg !748
  store i64 %490, ptr %39, align 8, !dbg !749
  %491 = load i64, ptr %39, align 8, !dbg !749
  br i1 false, label %numeric_error55, label %numeric_valid56, !dbg !749

trace_caller52:                                   ; preds = %propagate_error50
  %492 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !746
  %493 = getelementptr [32 x ptr], ptr %492, i32 0, i32 %487, !dbg !746
  store ptr @228, ptr %493, align 8, !dbg !746
  %494 = add i32 %487, 1, !dbg !746
  store i32 %494, ptr %486, align 4, !dbg !746
  br label %error_return53, !dbg !746

error_return53:                                   ; preds = %trace_caller52, %trace_limit54
  call void @vd_gc_frame_leave(ptr %283), !dbg !746
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !746

trace_limit54:                                    ; preds = %propagate_error50
  store i32 33, ptr %486, align 4, !dbg !746
  br label %error_return53, !dbg !746

numeric_error55:                                  ; preds = %call_success51
  %495 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !749
  store ptr @229, ptr %495, align 8, !dbg !749
  call void @vd_gc_frame_leave(ptr %283), !dbg !749
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !749

numeric_valid56:                                  ; preds = %call_success51
  %496 = icmp eq i64 %491, -9223372036854775808, !dbg !749
  %497 = and i1 %496, false, !dbg !749
  %498 = select i1 %497, i64 1, i64 256, !dbg !749
  %499 = sdiv i64 %491, %498, !dbg !749
  %500 = select i1 %497, i64 -9223372036854775808, i64 %499, !dbg !749
  store i64 %500, ptr %38, align 8, !dbg !749
  %501 = load %"/@stdlib/console.void::_reply", ptr %8, align 8, !dbg !750
  store %"/@stdlib/console.void::_reply" %501, ptr %197, align 8, !dbg !750
  %502 = extractvalue %"/@stdlib/console.void::_reply" %501, 7, !dbg !751
  store ptr %502, ptr %202, align 8, !dbg !751
  store ptr %502, ptr %40, align 8, !dbg !751
  %503 = load ptr, ptr %17, align 8, !dbg !752
  store ptr %503, ptr %207, align 8, !dbg !752
  store ptr %503, ptr %41, align 8, !dbg !752
  %504 = load %"/@stdlib/console.void::key", ptr %18, align 4, !dbg !752
  store %"/@stdlib/console.void::key" %504, ptr %42, align 4, !dbg !752
  %505 = load i1, ptr %20, align 1, !dbg !752
  store i1 %505, ptr %43, align 1, !dbg !752
  %506 = load i1, ptr %23, align 1, !dbg !752
  store i1 %506, ptr %44, align 1, !dbg !752
  %507 = load i1, ptr %26, align 1, !dbg !752
  store i1 %507, ptr %45, align 1, !dbg !752
  %508 = load i1, ptr %29, align 1, !dbg !752
  store i1 %508, ptr %46, align 1, !dbg !752
  %509 = load i1, ptr %32, align 1, !dbg !752
  store i1 %509, ptr %47, align 1, !dbg !752
  %510 = load i1, ptr %35, align 1, !dbg !752
  store i1 %510, ptr %48, align 1, !dbg !752
  %511 = load i64, ptr %38, align 8, !dbg !752
  store i64 %511, ptr %49, align 8, !dbg !752
  %512 = load ptr, ptr %40, align 8, !dbg !752
  store ptr %512, ptr %212, align 8, !dbg !752
  store ptr %512, ptr %50, align 8, !dbg !752
  %513 = load ptr, ptr %41, align 8, !dbg !752
  store ptr %513, ptr %217, align 8, !dbg !752
  %514 = load %"/@stdlib/console.void::key", ptr %42, align 4, !dbg !752
  %515 = load i1, ptr %43, align 1, !dbg !752
  %516 = load i1, ptr %44, align 1, !dbg !752
  %517 = load i1, ptr %45, align 1, !dbg !752
  %518 = load i1, ptr %46, align 1, !dbg !752
  %519 = load i1, ptr %47, align 1, !dbg !752
  %520 = load i1, ptr %48, align 1, !dbg !752
  %521 = load i64, ptr %49, align 8, !dbg !752
  %522 = load ptr, ptr %50, align 8, !dbg !752
  store ptr %522, ptr %222, align 8, !dbg !752
  %523 = insertvalue %"/@stdlib/console.void::key_event" zeroinitializer, ptr %513, 0, !dbg !752
  %524 = insertvalue %"/@stdlib/console.void::key_event" %523, %"/@stdlib/console.void::key" %514, 1, !dbg !752
  %525 = insertvalue %"/@stdlib/console.void::key_event" %524, i1 %515, 2, !dbg !752
  %526 = insertvalue %"/@stdlib/console.void::key_event" %525, i1 %516, 3, !dbg !752
  %527 = insertvalue %"/@stdlib/console.void::key_event" %526, i1 %517, 4, !dbg !752
  %528 = insertvalue %"/@stdlib/console.void::key_event" %527, i1 %518, 5, !dbg !752
  %529 = insertvalue %"/@stdlib/console.void::key_event" %528, i1 %519, 6, !dbg !752
  %530 = insertvalue %"/@stdlib/console.void::key_event" %529, i1 %520, 7, !dbg !752
  %531 = insertvalue %"/@stdlib/console.void::key_event" %530, i64 %521, 8, !dbg !752
  %532 = insertvalue %"/@stdlib/console.void::key_event" %531, ptr %522, 9, !dbg !752
  store %"/@stdlib/console.void::key_event" %532, ptr %227, align 8, !dbg !752
  store %"/@stdlib/console.void::key_event" %532, ptr %51, align 8, !dbg !752
  %533 = load %"/@stdlib/console.void::key_event", ptr %51, align 8, !dbg !753
  store %"/@stdlib/console.void::key_event" %533, ptr %232, align 8, !dbg !753
  %534 = insertvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, %"/@stdlib/console.void::key_event" %533, 1, !dbg !753
  %535 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, 0, !dbg !753
  %536 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, 0, !dbg !753
  %537 = icmp eq i32 %536, 0, !dbg !753
  br i1 %537, label %validate_active_payload57, label %validate_payload_done58, !dbg !753

validate_active_payload57:                        ; preds = %numeric_valid56
  %538 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, 1, !dbg !753
  %539 = extractvalue %"/@stdlib/console.void::key_event" %538, 0, !dbg !753
  %540 = extractvalue %"/@stdlib/console.void::key_event" %538, 1, !dbg !753
  %541 = extractvalue %"/@stdlib/console.void::key" %540, 0, !dbg !753
  %542 = extractvalue %"/@stdlib/console.void::key_event" %538, 2, !dbg !753
  %543 = extractvalue %"/@stdlib/console.void::key_event" %538, 3, !dbg !753
  %544 = extractvalue %"/@stdlib/console.void::key_event" %538, 4, !dbg !753
  %545 = extractvalue %"/@stdlib/console.void::key_event" %538, 5, !dbg !753
  %546 = extractvalue %"/@stdlib/console.void::key_event" %538, 6, !dbg !753
  %547 = extractvalue %"/@stdlib/console.void::key_event" %538, 7, !dbg !753
  %548 = extractvalue %"/@stdlib/console.void::key_event" %538, 8, !dbg !753
  %549 = extractvalue %"/@stdlib/console.void::key_event" %538, 9, !dbg !753
  br label %validate_payload_done58, !dbg !753

validate_payload_done58:                          ; preds = %validate_active_payload57, %numeric_valid56
  %550 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, 0, !dbg !753
  %551 = icmp eq i32 %550, 1, !dbg !753
  br i1 %551, label %validate_active_payload59, label %validate_payload_done60, !dbg !753

validate_active_payload59:                        ; preds = %validate_payload_done58
  %552 = extractvalue %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, 2, !dbg !753
  %553 = extractvalue %"/@stdlib/console.void::io_error" %552, 0, !dbg !753
  %554 = extractvalue %"/@stdlib/console.void::io_error" %552, 1, !dbg !753
  %555 = extractvalue %"/@stdlib/console.void::io_error" %552, 2, !dbg !753
  %556 = extractvalue %"/@stdlib/console.void::io_error_kind" %555, 0, !dbg !753
  %557 = extractvalue %"/@stdlib/console.void::io_error" %552, 3, !dbg !753
  %558 = extractvalue %"/@stdlib/console.void::io_error" %552, 4, !dbg !753
  %559 = extractvalue %"/@stdlib/console.void::io_error" %552, 5, !dbg !753
  %560 = extractvalue %"/@stdlib/console.void::io_error" %552, 6, !dbg !753
  %561 = extractvalue %"/@stdlib/console.void::io_error" %552, 7, !dbg !753
  %562 = extractvalue %"/@stdlib/console.void::io_error" %552, 8, !dbg !753
  br label %validate_payload_done60, !dbg !753

validate_payload_done60:                          ; preds = %validate_active_payload59, %validate_payload_done58
  store %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, ptr %237, align 8, !dbg !753
  call void @vd_gc_frame_leave(ptr %283), !dbg !753
  ret %"$result:$array:35:12:/@stdlib/console.void::key_event:growable:$array:34:12:/@stdlib/console.void::io_error:growable" %534, !dbg !753
}

define %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a6b65795f617661696c61626c65__v1(ptr %0, ptr %1) !dbg !754 {
block0:
  %2 = alloca [8 x i64], align 8
  %3 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %3, align 8
  %4 = alloca %"/@stdlib/console.void::input", align 8
  store %"/@stdlib/console.void::input" zeroinitializer, ptr %4, align 8
  %5 = alloca i64, align 8
  store i64 0, ptr %5, align 8
  %6 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %9, align 8
  %10 = alloca i64, align 8
  store i64 0, ptr %10, align 8
  %11 = alloca i1, align 1
  store i1 false, ptr %11, align 1
  %12 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 80, 1
  %14 = insertvalue { ptr, i64, ptr, i64 } %13, ptr @gc.offsets.454, 2
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 2, 3
  %16 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 80, 1
  %18 = insertvalue { ptr, i64, ptr, i64 } %17, ptr @gc.offsets.455, 2
  %19 = insertvalue { ptr, i64, ptr, i64 } %18, i64 2, 3
  %20 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, i64 8, 1
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, ptr @gc.offsets.456, 2
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, i64 1, 3
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.457, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %9, 0
  %29 = insertvalue { ptr, i64, ptr, i64 } %28, i64 72, 1
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, ptr @gc.offsets.458, 2
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, i64 4, 3
  %32 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %32, align 8
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %32, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 80, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.459, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 2, 3
  %37 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %37, align 8
  %38 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %37, 0
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, i64 80, 1
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, ptr @gc.offsets.460, 2
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, i64 2, 3
  %42 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %42, align 8
  %43 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %42, 0
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 80, 1
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, ptr @gc.offsets.461, 2
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 2, 3
  %47 = alloca ptr, align 8
  store ptr null, ptr %47, align 8
  %48 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %47, 0
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, i64 8, 1
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, ptr @gc.offsets.462, 2
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, i64 1, 3
  %52 = alloca ptr, align 8
  store ptr null, ptr %52, align 8
  %53 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %52, 0
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 8, 1
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, ptr @gc.offsets.463, 2
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 1, 3
  %57 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %57, align 8
  %58 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %57, 0
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, i64 80, 1
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, ptr @gc.offsets.464, 2
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, i64 2, 3
  %62 = alloca ptr, align 8
  store ptr null, ptr %62, align 8
  %63 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %62, 0
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, i64 8, 1
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, ptr @gc.offsets.465, 2
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, i64 1, 3
  %67 = alloca ptr, align 8
  store ptr null, ptr %67, align 8
  %68 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %67, 0
  %69 = insertvalue { ptr, i64, ptr, i64 } %68, i64 8, 1
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, ptr @gc.offsets.466, 2
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 1, 3
  %72 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %72, align 8
  %73 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %72, 0
  %74 = insertvalue { ptr, i64, ptr, i64 } %73, i64 72, 1
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, ptr @gc.offsets.467, 2
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, i64 4, 3
  %77 = alloca %"/@stdlib/console.void::io_error", align 8
  store %"/@stdlib/console.void::io_error" zeroinitializer, ptr %77, align 8
  %78 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %77, 0
  %79 = insertvalue { ptr, i64, ptr, i64 } %78, i64 72, 1
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, ptr @gc.offsets.468, 2
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, i64 4, 3
  %82 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %82, align 8
  %83 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %82, 0
  %84 = insertvalue { ptr, i64, ptr, i64 } %83, i64 80, 1
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, ptr @gc.offsets.469, 2
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, i64 4, 3
  %87 = alloca %"/@stdlib/console.void::_reply", align 8
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %87, align 8
  %88 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %87, 0
  %89 = insertvalue { ptr, i64, ptr, i64 } %88, i64 80, 1
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, ptr @gc.offsets.470, 2
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, i64 2, 3
  %92 = alloca %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable", align 8
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, ptr %92, align 8
  %93 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %92, 0
  %94 = insertvalue { ptr, i64, ptr, i64 } %93, i64 80, 1
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, ptr @gc.offsets.471, 2
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, i64 4, 3
  %97 = alloca [18 x { ptr, i64, ptr, i64 }], align 8
  %98 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %15, ptr %98, align 8
  %99 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %19, ptr %99, align 8
  %100 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %23, ptr %100, align 8
  %101 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %27, ptr %101, align 8
  %102 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %31, ptr %102, align 8
  %103 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %36, ptr %103, align 8
  %104 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %41, ptr %104, align 8
  %105 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %46, ptr %105, align 8
  %106 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %51, ptr %106, align 8
  %107 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %56, ptr %107, align 8
  %108 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %61, ptr %108, align 8
  %109 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %66, ptr %109, align 8
  %110 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %71, ptr %110, align 8
  %111 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %76, ptr %111, align 8
  %112 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %81, ptr %112, align 8
  %113 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %86, ptr %113, align 8
  %114 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %91, ptr %114, align 8
  %115 = getelementptr inbounds [18 x { ptr, i64, ptr, i64 }], ptr %97, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %96, ptr %115, align 8
  %116 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %116, ptr %97, i64 18)
  call void @vd_gc_poll()
  %117 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %117, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !757
  %118 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !757
  br i1 %118, label %worker.cancelled1, label %worker.continue2, !dbg !757

block2:                                           ; preds = %selected.valid
  call void @vd_gc_poll(), !dbg !758
  %119 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !758
  br i1 %119, label %worker.cancelled10, label %worker.continue11, !dbg !758

block3:                                           ; preds = %worker.continue11
  call void @vd_gc_poll(), !dbg !758
  %120 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !758
  br i1 %120, label %worker.cancelled12, label %worker.continue13, !dbg !758

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %116)
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer

worker.continue:                                  ; preds = %block0
  %121 = load %"/@stdlib/console.void::input", ptr %0, align 8, !dbg !759
  store %"/@stdlib/console.void::input" %121, ptr %4, align 8, !dbg !759
  %122 = load %"/@stdlib/console.void::input", ptr %4, align 8, !dbg !760
  store %"/@stdlib/console.void::_reply" zeroinitializer, ptr %32, align 8, !dbg !760
  store [8 x i64] zeroinitializer, ptr %2, align 8, !dbg !760
  %123 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 6, !dbg !760
  %124 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 7, !dbg !760
  %125 = extractvalue %"/@stdlib/console.void::input" %122, 0, !dbg !760
  call void @vd_console_v2(ptr %123, ptr %124, ptr %2, i32 19, i64 %125, ptr null, i64 0, i64 -1, ptr %1), !dbg !760
  %126 = load ptr, ptr %1, align 8, !dbg !760
  %127 = icmp ne ptr %126, null, !dbg !760
  br i1 %127, label %selected.failure, label %selected.valid, !dbg !760

selected.failure:                                 ; preds = %worker.continue
  %128 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !760
  %129 = load i32, ptr %128, align 4, !dbg !760
  %130 = icmp ult i32 %129, 32, !dbg !760
  br i1 %130, label %trace_caller, label %trace_limit, !dbg !760

selected.valid:                                   ; preds = %worker.continue
  %131 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 0, !dbg !760
  %132 = load i64, ptr %131, align 8, !dbg !760
  %133 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 0, !dbg !760
  store i64 %132, ptr %133, align 8, !dbg !760
  %134 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 1, !dbg !760
  %135 = load i64, ptr %134, align 8, !dbg !760
  %136 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 1, !dbg !760
  store i64 %135, ptr %136, align 8, !dbg !760
  %137 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 2, !dbg !760
  %138 = load i64, ptr %137, align 8, !dbg !760
  %139 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 2, !dbg !760
  store i64 %138, ptr %139, align 8, !dbg !760
  %140 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 3, !dbg !760
  %141 = load i64, ptr %140, align 8, !dbg !760
  %142 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 3, !dbg !760
  store i64 %141, ptr %142, align 8, !dbg !760
  %143 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 4, !dbg !760
  %144 = load i64, ptr %143, align 8, !dbg !760
  %145 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 4, !dbg !760
  store i64 %144, ptr %145, align 8, !dbg !760
  %146 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 5, !dbg !760
  %147 = load i64, ptr %146, align 8, !dbg !760
  %148 = trunc i64 %147 to i1, !dbg !760
  %149 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 5, !dbg !760
  store i1 %148, ptr %149, align 1, !dbg !760
  %150 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 6, !dbg !760
  %151 = load i64, ptr %150, align 8, !dbg !760
  %152 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 8, !dbg !760
  store i64 %151, ptr %152, align 8, !dbg !760
  %153 = getelementptr inbounds [8 x i64], ptr %2, i32 0, i32 7, !dbg !760
  %154 = load i64, ptr %153, align 8, !dbg !760
  %155 = getelementptr inbounds %"/@stdlib/console.void::_reply", ptr %32, i32 0, i32 9, !dbg !760
  store i64 %154, ptr %155, align 8, !dbg !760
  %156 = load %"/@stdlib/console.void::_reply", ptr %32, align 8, !dbg !760
  store %"/@stdlib/console.void::_reply" %156, ptr %32, align 8, !dbg !760
  store %"/@stdlib/console.void::_reply" %156, ptr %3, align 8, !dbg !761
  %157 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !762
  store %"/@stdlib/console.void::_reply" %157, ptr %37, align 8, !dbg !762
  %158 = extractvalue %"/@stdlib/console.void::_reply" %157, 0, !dbg !763
  store i64 %158, ptr %5, align 8, !dbg !757
  %159 = load i64, ptr %5, align 8, !dbg !757
  %160 = icmp ne i64 %159, 0, !dbg !757
  br i1 %160, label %block1, label %block2, !dbg !757

trace_caller:                                     ; preds = %selected.failure
  %161 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !760
  %162 = getelementptr [32 x ptr], ptr %161, i32 0, i32 %129, !dbg !760
  store ptr @230, ptr %162, align 8, !dbg !760
  %163 = add i32 %129, 1, !dbg !760
  store i32 %163, ptr %128, align 4, !dbg !760
  br label %error_return, !dbg !760

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %116), !dbg !760
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !760

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %128, align 4, !dbg !760
  br label %error_return, !dbg !760

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %116), !dbg !757
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !757

worker.continue2:                                 ; preds = %block1
  %164 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !764
  store %"/@stdlib/console.void::_reply" %164, ptr %42, align 8, !dbg !764
  store %"/@stdlib/console.void::_reply" %164, ptr %6, align 8, !dbg !764
  call void @vd_string_literal(ptr %47, ptr @231, i64 13, ptr %1), !dbg !765
  %165 = load ptr, ptr %47, align 8, !dbg !765
  %166 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !765
  %167 = load ptr, ptr %166, align 8, !dbg !765
  %168 = icmp ne ptr %167, null, !dbg !765
  br i1 %168, label %numeric_error, label %numeric_valid, !dbg !765

numeric_error:                                    ; preds = %worker.continue2
  %169 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !765
  store ptr @232, ptr %169, align 8, !dbg !765
  call void @vd_gc_frame_leave(ptr %116), !dbg !765
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !765

numeric_valid:                                    ; preds = %worker.continue2
  store ptr %165, ptr %47, align 8, !dbg !765
  store ptr %165, ptr %7, align 8, !dbg !765
  call void @vd_string_literal(ptr %52, ptr @233, i64 5, ptr %1), !dbg !766
  %170 = load ptr, ptr %52, align 8, !dbg !766
  %171 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !766
  %172 = load ptr, ptr %171, align 8, !dbg !766
  %173 = icmp ne ptr %172, null, !dbg !766
  br i1 %173, label %numeric_error3, label %numeric_valid4, !dbg !766

numeric_error3:                                   ; preds = %numeric_valid
  %174 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !766
  store ptr @234, ptr %174, align 8, !dbg !766
  call void @vd_gc_frame_leave(ptr %116), !dbg !766
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !766

numeric_valid4:                                   ; preds = %numeric_valid
  store ptr %170, ptr %52, align 8, !dbg !766
  store ptr %170, ptr %8, align 8, !dbg !766
  %175 = load %"/@stdlib/console.void::_reply", ptr %6, align 8, !dbg !767
  store %"/@stdlib/console.void::_reply" %175, ptr %57, align 8, !dbg !767
  %176 = load ptr, ptr %7, align 8, !dbg !767
  store ptr %176, ptr %62, align 8, !dbg !767
  %177 = load ptr, ptr %8, align 8, !dbg !767
  store ptr %177, ptr %67, align 8, !dbg !767
  %178 = call %"/@stdlib/console.void::io_error" @__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1(%"/@stdlib/console.void::_reply" %175, ptr %176, ptr %177, ptr %1), !dbg !767
  %179 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !767
  %180 = load ptr, ptr %179, align 8, !dbg !767
  %181 = icmp ne ptr %180, null, !dbg !767
  br i1 %181, label %propagate_error, label %call_success, !dbg !767

propagate_error:                                  ; preds = %numeric_valid4
  %182 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !767
  %183 = load i32, ptr %182, align 4, !dbg !767
  %184 = icmp ult i32 %183, 32, !dbg !767
  br i1 %184, label %trace_caller5, label %trace_limit7, !dbg !767

call_success:                                     ; preds = %numeric_valid4
  store %"/@stdlib/console.void::io_error" %178, ptr %72, align 8, !dbg !767
  store %"/@stdlib/console.void::io_error" %178, ptr %9, align 8, !dbg !767
  %185 = load %"/@stdlib/console.void::io_error", ptr %9, align 8, !dbg !758
  store %"/@stdlib/console.void::io_error" %185, ptr %77, align 8, !dbg !758
  %186 = insertvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" { i32 1, i1 false, %"/@stdlib/console.void::io_error" zeroinitializer }, %"/@stdlib/console.void::io_error" %185, 2, !dbg !758
  %187 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, 0, !dbg !758
  %188 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, 0, !dbg !758
  %189 = icmp eq i32 %188, 0, !dbg !758
  br i1 %189, label %validate_active_payload, label %validate_payload_done, !dbg !758

trace_caller5:                                    ; preds = %propagate_error
  %190 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !767
  %191 = getelementptr [32 x ptr], ptr %190, i32 0, i32 %183, !dbg !767
  store ptr @235, ptr %191, align 8, !dbg !767
  %192 = add i32 %183, 1, !dbg !767
  store i32 %192, ptr %182, align 4, !dbg !767
  br label %error_return6, !dbg !767

error_return6:                                    ; preds = %trace_caller5, %trace_limit7
  call void @vd_gc_frame_leave(ptr %116), !dbg !767
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !767

trace_limit7:                                     ; preds = %propagate_error
  store i32 33, ptr %182, align 4, !dbg !767
  br label %error_return6, !dbg !767

validate_active_payload:                          ; preds = %call_success
  %193 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, 1, !dbg !758
  br label %validate_payload_done, !dbg !758

validate_payload_done:                            ; preds = %validate_active_payload, %call_success
  %194 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, 0, !dbg !758
  %195 = icmp eq i32 %194, 1, !dbg !758
  br i1 %195, label %validate_active_payload8, label %validate_payload_done9, !dbg !758

validate_active_payload8:                         ; preds = %validate_payload_done
  %196 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, 2, !dbg !758
  %197 = extractvalue %"/@stdlib/console.void::io_error" %196, 0, !dbg !758
  %198 = extractvalue %"/@stdlib/console.void::io_error" %196, 1, !dbg !758
  %199 = extractvalue %"/@stdlib/console.void::io_error" %196, 2, !dbg !758
  %200 = extractvalue %"/@stdlib/console.void::io_error_kind" %199, 0, !dbg !758
  %201 = extractvalue %"/@stdlib/console.void::io_error" %196, 3, !dbg !758
  %202 = extractvalue %"/@stdlib/console.void::io_error" %196, 4, !dbg !758
  %203 = extractvalue %"/@stdlib/console.void::io_error" %196, 5, !dbg !758
  %204 = extractvalue %"/@stdlib/console.void::io_error" %196, 6, !dbg !758
  %205 = extractvalue %"/@stdlib/console.void::io_error" %196, 7, !dbg !758
  %206 = extractvalue %"/@stdlib/console.void::io_error" %196, 8, !dbg !758
  br label %validate_payload_done9, !dbg !758

validate_payload_done9:                           ; preds = %validate_active_payload8, %validate_payload_done
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, ptr %82, align 8, !dbg !758
  call void @vd_gc_frame_leave(ptr %116), !dbg !758
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %186, !dbg !758

worker.cancelled10:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %116), !dbg !758
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !758

worker.continue11:                                ; preds = %block2
  br label %block3, !dbg !758

worker.cancelled12:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %116), !dbg !758
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, !dbg !758

worker.continue13:                                ; preds = %block3
  %207 = load %"/@stdlib/console.void::_reply", ptr %3, align 8, !dbg !768
  store %"/@stdlib/console.void::_reply" %207, ptr %87, align 8, !dbg !768
  %208 = extractvalue %"/@stdlib/console.void::_reply" %207, 8, !dbg !769
  store i64 %208, ptr %10, align 8, !dbg !770
  %209 = load i64, ptr %10, align 8, !dbg !770
  %210 = icmp ne i64 %209, 0, !dbg !770
  store i1 %210, ptr %11, align 1, !dbg !770
  %211 = load i1, ptr %11, align 1, !dbg !771
  %212 = insertvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" zeroinitializer, i1 %211, 1, !dbg !771
  %213 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, 0, !dbg !771
  %214 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, 0, !dbg !771
  %215 = icmp eq i32 %214, 0, !dbg !771
  br i1 %215, label %validate_active_payload14, label %validate_payload_done15, !dbg !771

validate_active_payload14:                        ; preds = %worker.continue13
  %216 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, 1, !dbg !771
  br label %validate_payload_done15, !dbg !771

validate_payload_done15:                          ; preds = %validate_active_payload14, %worker.continue13
  %217 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, 0, !dbg !771
  %218 = icmp eq i32 %217, 1, !dbg !771
  br i1 %218, label %validate_active_payload16, label %validate_payload_done17, !dbg !771

validate_active_payload16:                        ; preds = %validate_payload_done15
  %219 = extractvalue %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, 2, !dbg !771
  %220 = extractvalue %"/@stdlib/console.void::io_error" %219, 0, !dbg !771
  %221 = extractvalue %"/@stdlib/console.void::io_error" %219, 1, !dbg !771
  %222 = extractvalue %"/@stdlib/console.void::io_error" %219, 2, !dbg !771
  %223 = extractvalue %"/@stdlib/console.void::io_error_kind" %222, 0, !dbg !771
  %224 = extractvalue %"/@stdlib/console.void::io_error" %219, 3, !dbg !771
  %225 = extractvalue %"/@stdlib/console.void::io_error" %219, 4, !dbg !771
  %226 = extractvalue %"/@stdlib/console.void::io_error" %219, 5, !dbg !771
  %227 = extractvalue %"/@stdlib/console.void::io_error" %219, 6, !dbg !771
  %228 = extractvalue %"/@stdlib/console.void::io_error" %219, 7, !dbg !771
  %229 = extractvalue %"/@stdlib/console.void::io_error" %219, 8, !dbg !771
  br label %validate_payload_done17, !dbg !771

validate_payload_done17:                          ; preds = %validate_active_payload16, %validate_payload_done15
  store %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, ptr %92, align 8, !dbg !771
  call void @vd_gc_frame_leave(ptr %116), !dbg !771
  ret %"$result:$array:2:1::growable:$array:34:12:/@stdlib/console.void::io_error:growable" %212, !dbg !771
}

define i32 @__vd_2f6d61696e2e766f69643a3a656e747279__v1(i32 %0, ptr %1) !dbg !772 {
block0:
  %2 = alloca [2 x ptr], align 8
  %3 = alloca [6 x ptr], align 8
  %4 = alloca [1 x ptr], align 8
  %5 = alloca i32, align 4
  store i32 0, ptr %5, align 4
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca i32, align 4
  store i32 0, ptr %9, align 4
  %10 = alloca i1, align 1
  store i1 false, ptr %10, align 1
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca ptr, align 8
  store ptr null, ptr %12, align 8
  %13 = alloca ptr, align 8
  store ptr null, ptr %13, align 8
  %14 = alloca ptr, align 8
  store ptr null, ptr %14, align 8
  %15 = alloca ptr, align 8
  store ptr null, ptr %15, align 8
  %16 = alloca ptr, align 8
  store ptr null, ptr %16, align 8
  %17 = alloca %"/@stdlib/console.void::output", align 8
  store %"/@stdlib/console.void::output" zeroinitializer, ptr %17, align 8
  %18 = alloca ptr, align 8
  store ptr null, ptr %18, align 8
  %19 = alloca ptr, align 8
  store ptr null, ptr %19, align 8
  %20 = alloca ptr, align 8
  store ptr null, ptr %20, align 8
  %21 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %6, 0
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 8, 1
  %23 = insertvalue { ptr, i64, ptr, i64 } %22, ptr @gc.offsets.472, 2
  %24 = insertvalue { ptr, i64, ptr, i64 } %23, i64 1, 3
  %25 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %7, 0
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, i64 8, 1
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, ptr @gc.offsets.473, 2
  %28 = insertvalue { ptr, i64, ptr, i64 } %27, i64 1, 3
  %29 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %8, 0
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 8, 1
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, ptr @gc.offsets.474, 2
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 1, 3
  %33 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %11, 0
  %34 = insertvalue { ptr, i64, ptr, i64 } %33, i64 8, 1
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, ptr @gc.offsets.475, 2
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 1, 3
  %37 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %12, 0
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 8, 1
  %39 = insertvalue { ptr, i64, ptr, i64 } %38, ptr @gc.offsets.476, 2
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 1, 3
  %41 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %13, 0
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 8, 1
  %43 = insertvalue { ptr, i64, ptr, i64 } %42, ptr @gc.offsets.477, 2
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 1, 3
  %45 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %14, 0
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 8, 1
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, ptr @gc.offsets.478, 2
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 1, 3
  %49 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %15, 0
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 8, 1
  %51 = insertvalue { ptr, i64, ptr, i64 } %50, ptr @gc.offsets.479, 2
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 1, 3
  %53 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %16, 0
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 8, 1
  %55 = insertvalue { ptr, i64, ptr, i64 } %54, ptr @gc.offsets.480, 2
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 1, 3
  %57 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %18, 0
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 8, 1
  %59 = insertvalue { ptr, i64, ptr, i64 } %58, ptr @gc.offsets.481, 2
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 1, 3
  %61 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %19, 0
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, i64 8, 1
  %63 = insertvalue { ptr, i64, ptr, i64 } %62, ptr @gc.offsets.482, 2
  %64 = insertvalue { ptr, i64, ptr, i64 } %63, i64 1, 3
  %65 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %20, 0
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, i64 8, 1
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, ptr @gc.offsets.483, 2
  %68 = insertvalue { ptr, i64, ptr, i64 } %67, i64 1, 3
  %69 = alloca ptr, align 8
  store ptr null, ptr %69, align 8
  %70 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %69, 0
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, i64 8, 1
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, ptr @gc.offsets.484, 2
  %73 = insertvalue { ptr, i64, ptr, i64 } %72, i64 1, 3
  %74 = alloca ptr, align 8
  store ptr null, ptr %74, align 8
  %75 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %74, 0
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, i64 8, 1
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, ptr @gc.offsets.485, 2
  %78 = insertvalue { ptr, i64, ptr, i64 } %77, i64 1, 3
  %79 = alloca ptr, align 8
  store ptr null, ptr %79, align 8
  %80 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %79, 0
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, i64 8, 1
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, ptr @gc.offsets.486, 2
  %83 = insertvalue { ptr, i64, ptr, i64 } %82, i64 1, 3
  %84 = alloca ptr, align 8
  store ptr null, ptr %84, align 8
  %85 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %84, 0
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, i64 8, 1
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, ptr @gc.offsets.487, 2
  %88 = insertvalue { ptr, i64, ptr, i64 } %87, i64 1, 3
  %89 = alloca ptr, align 8
  store ptr null, ptr %89, align 8
  %90 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %89, 0
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, i64 8, 1
  %92 = insertvalue { ptr, i64, ptr, i64 } %91, ptr @gc.offsets.488, 2
  %93 = insertvalue { ptr, i64, ptr, i64 } %92, i64 1, 3
  %94 = alloca ptr, align 8
  store ptr null, ptr %94, align 8
  %95 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %94, 0
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, i64 8, 1
  %97 = insertvalue { ptr, i64, ptr, i64 } %96, ptr @gc.offsets.489, 2
  %98 = insertvalue { ptr, i64, ptr, i64 } %97, i64 1, 3
  %99 = alloca ptr, align 8
  store ptr null, ptr %99, align 8
  %100 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %99, 0
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, i64 8, 1
  %102 = insertvalue { ptr, i64, ptr, i64 } %101, ptr @gc.offsets.490, 2
  %103 = insertvalue { ptr, i64, ptr, i64 } %102, i64 1, 3
  %104 = alloca ptr, align 8
  store ptr null, ptr %104, align 8
  %105 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %104, 0
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, i64 8, 1
  %107 = insertvalue { ptr, i64, ptr, i64 } %106, ptr @gc.offsets.491, 2
  %108 = insertvalue { ptr, i64, ptr, i64 } %107, i64 1, 3
  %109 = alloca ptr, align 8
  store ptr null, ptr %109, align 8
  %110 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %109, 0
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, i64 8, 1
  %112 = insertvalue { ptr, i64, ptr, i64 } %111, ptr @gc.offsets.492, 2
  %113 = insertvalue { ptr, i64, ptr, i64 } %112, i64 1, 3
  %114 = alloca ptr, align 8
  store ptr null, ptr %114, align 8
  %115 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %114, 0
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, i64 8, 1
  %117 = insertvalue { ptr, i64, ptr, i64 } %116, ptr @gc.offsets.493, 2
  %118 = insertvalue { ptr, i64, ptr, i64 } %117, i64 1, 3
  %119 = alloca ptr, align 8
  store ptr null, ptr %119, align 8
  %120 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %119, 0
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, i64 8, 1
  %122 = insertvalue { ptr, i64, ptr, i64 } %121, ptr @gc.offsets.494, 2
  %123 = insertvalue { ptr, i64, ptr, i64 } %122, i64 1, 3
  %124 = alloca ptr, align 8
  store ptr null, ptr %124, align 8
  %125 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %124, 0
  %126 = insertvalue { ptr, i64, ptr, i64 } %125, i64 8, 1
  %127 = insertvalue { ptr, i64, ptr, i64 } %126, ptr @gc.offsets.495, 2
  %128 = insertvalue { ptr, i64, ptr, i64 } %127, i64 1, 3
  %129 = alloca ptr, align 8
  store ptr null, ptr %129, align 8
  %130 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %129, 0
  %131 = insertvalue { ptr, i64, ptr, i64 } %130, i64 8, 1
  %132 = insertvalue { ptr, i64, ptr, i64 } %131, ptr @gc.offsets.496, 2
  %133 = insertvalue { ptr, i64, ptr, i64 } %132, i64 1, 3
  %134 = alloca ptr, align 8
  store ptr null, ptr %134, align 8
  %135 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %134, 0
  %136 = insertvalue { ptr, i64, ptr, i64 } %135, i64 8, 1
  %137 = insertvalue { ptr, i64, ptr, i64 } %136, ptr @gc.offsets.497, 2
  %138 = insertvalue { ptr, i64, ptr, i64 } %137, i64 1, 3
  %139 = alloca ptr, align 8
  store ptr null, ptr %139, align 8
  %140 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %139, 0
  %141 = insertvalue { ptr, i64, ptr, i64 } %140, i64 8, 1
  %142 = insertvalue { ptr, i64, ptr, i64 } %141, ptr @gc.offsets.498, 2
  %143 = insertvalue { ptr, i64, ptr, i64 } %142, i64 1, 3
  %144 = alloca ptr, align 8
  store ptr null, ptr %144, align 8
  %145 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %144, 0
  %146 = insertvalue { ptr, i64, ptr, i64 } %145, i64 8, 1
  %147 = insertvalue { ptr, i64, ptr, i64 } %146, ptr @gc.offsets.499, 2
  %148 = insertvalue { ptr, i64, ptr, i64 } %147, i64 1, 3
  %149 = alloca ptr, align 8
  store ptr null, ptr %149, align 8
  %150 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %149, 0
  %151 = insertvalue { ptr, i64, ptr, i64 } %150, i64 8, 1
  %152 = insertvalue { ptr, i64, ptr, i64 } %151, ptr @gc.offsets.500, 2
  %153 = insertvalue { ptr, i64, ptr, i64 } %152, i64 1, 3
  %154 = alloca ptr, align 8
  store ptr null, ptr %154, align 8
  %155 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %154, 0
  %156 = insertvalue { ptr, i64, ptr, i64 } %155, i64 8, 1
  %157 = insertvalue { ptr, i64, ptr, i64 } %156, ptr @gc.offsets.501, 2
  %158 = insertvalue { ptr, i64, ptr, i64 } %157, i64 1, 3
  %159 = alloca ptr, align 8
  store ptr null, ptr %159, align 8
  %160 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %159, 0
  %161 = insertvalue { ptr, i64, ptr, i64 } %160, i64 8, 1
  %162 = insertvalue { ptr, i64, ptr, i64 } %161, ptr @gc.offsets.502, 2
  %163 = insertvalue { ptr, i64, ptr, i64 } %162, i64 1, 3
  %164 = alloca ptr, align 8
  store ptr null, ptr %164, align 8
  %165 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %164, 0
  %166 = insertvalue { ptr, i64, ptr, i64 } %165, i64 8, 1
  %167 = insertvalue { ptr, i64, ptr, i64 } %166, ptr @gc.offsets.503, 2
  %168 = insertvalue { ptr, i64, ptr, i64 } %167, i64 1, 3
  %169 = alloca ptr, align 8
  store ptr null, ptr %169, align 8
  %170 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %169, 0
  %171 = insertvalue { ptr, i64, ptr, i64 } %170, i64 8, 1
  %172 = insertvalue { ptr, i64, ptr, i64 } %171, ptr @gc.offsets.504, 2
  %173 = insertvalue { ptr, i64, ptr, i64 } %172, i64 1, 3
  %174 = alloca ptr, align 8
  store ptr null, ptr %174, align 8
  %175 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %174, 0
  %176 = insertvalue { ptr, i64, ptr, i64 } %175, i64 8, 1
  %177 = insertvalue { ptr, i64, ptr, i64 } %176, ptr @gc.offsets.505, 2
  %178 = insertvalue { ptr, i64, ptr, i64 } %177, i64 1, 3
  %179 = alloca ptr, align 8
  store ptr null, ptr %179, align 8
  %180 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %179, 0
  %181 = insertvalue { ptr, i64, ptr, i64 } %180, i64 8, 1
  %182 = insertvalue { ptr, i64, ptr, i64 } %181, ptr @gc.offsets.506, 2
  %183 = insertvalue { ptr, i64, ptr, i64 } %182, i64 1, 3
  %184 = alloca ptr, align 8
  store ptr null, ptr %184, align 8
  %185 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %184, 0
  %186 = insertvalue { ptr, i64, ptr, i64 } %185, i64 8, 1
  %187 = insertvalue { ptr, i64, ptr, i64 } %186, ptr @gc.offsets.507, 2
  %188 = insertvalue { ptr, i64, ptr, i64 } %187, i64 1, 3
  %189 = alloca ptr, align 8
  store ptr null, ptr %189, align 8
  %190 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %189, 0
  %191 = insertvalue { ptr, i64, ptr, i64 } %190, i64 8, 1
  %192 = insertvalue { ptr, i64, ptr, i64 } %191, ptr @gc.offsets.508, 2
  %193 = insertvalue { ptr, i64, ptr, i64 } %192, i64 1, 3
  %194 = alloca ptr, align 8
  store ptr null, ptr %194, align 8
  %195 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %194, 0
  %196 = insertvalue { ptr, i64, ptr, i64 } %195, i64 8, 1
  %197 = insertvalue { ptr, i64, ptr, i64 } %196, ptr @gc.offsets.509, 2
  %198 = insertvalue { ptr, i64, ptr, i64 } %197, i64 1, 3
  %199 = alloca [38 x { ptr, i64, ptr, i64 }], align 8
  %200 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %24, ptr %200, align 8
  %201 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %28, ptr %201, align 8
  %202 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %32, ptr %202, align 8
  %203 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %36, ptr %203, align 8
  %204 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %40, ptr %204, align 8
  %205 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %44, ptr %205, align 8
  %206 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %48, ptr %206, align 8
  %207 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %52, ptr %207, align 8
  %208 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %56, ptr %208, align 8
  %209 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %60, ptr %209, align 8
  %210 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %64, ptr %210, align 8
  %211 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %68, ptr %211, align 8
  %212 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %73, ptr %212, align 8
  %213 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %78, ptr %213, align 8
  %214 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %83, ptr %214, align 8
  %215 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %88, ptr %215, align 8
  %216 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %93, ptr %216, align 8
  %217 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %98, ptr %217, align 8
  %218 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %103, ptr %218, align 8
  %219 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 19
  store { ptr, i64, ptr, i64 } %108, ptr %219, align 8
  %220 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 20
  store { ptr, i64, ptr, i64 } %113, ptr %220, align 8
  %221 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 21
  store { ptr, i64, ptr, i64 } %118, ptr %221, align 8
  %222 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 22
  store { ptr, i64, ptr, i64 } %123, ptr %222, align 8
  %223 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 23
  store { ptr, i64, ptr, i64 } %128, ptr %223, align 8
  %224 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 24
  store { ptr, i64, ptr, i64 } %133, ptr %224, align 8
  %225 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 25
  store { ptr, i64, ptr, i64 } %138, ptr %225, align 8
  %226 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 26
  store { ptr, i64, ptr, i64 } %143, ptr %226, align 8
  %227 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 27
  store { ptr, i64, ptr, i64 } %148, ptr %227, align 8
  %228 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 28
  store { ptr, i64, ptr, i64 } %153, ptr %228, align 8
  %229 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 29
  store { ptr, i64, ptr, i64 } %158, ptr %229, align 8
  %230 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 30
  store { ptr, i64, ptr, i64 } %163, ptr %230, align 8
  %231 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 31
  store { ptr, i64, ptr, i64 } %168, ptr %231, align 8
  %232 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 32
  store { ptr, i64, ptr, i64 } %173, ptr %232, align 8
  %233 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 33
  store { ptr, i64, ptr, i64 } %178, ptr %233, align 8
  %234 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 34
  store { ptr, i64, ptr, i64 } %183, ptr %234, align 8
  %235 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 35
  store { ptr, i64, ptr, i64 } %188, ptr %235, align 8
  %236 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 36
  store { ptr, i64, ptr, i64 } %193, ptr %236, align 8
  %237 = getelementptr inbounds [38 x { ptr, i64, ptr, i64 }], ptr %199, i32 0, i32 37
  store { ptr, i64, ptr, i64 } %198, ptr %237, align 8
  %238 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %238, ptr %199, i64 38)
  call void @vd_gc_poll()
  %239 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %239, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %238)
  ret i32 0

worker.continue:                                  ; preds = %block0
  store i32 %0, ptr %5, align 4, !dbg !775
  call void @vd_string_literal(ptr %69, ptr @236, i64 1, ptr %1), !dbg !776
  %240 = load ptr, ptr %69, align 8, !dbg !776
  %241 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !776
  %242 = load ptr, ptr %241, align 8, !dbg !776
  %243 = icmp ne ptr %242, null, !dbg !776
  br i1 %243, label %numeric_error, label %numeric_valid, !dbg !776

numeric_error:                                    ; preds = %worker.continue
  %244 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !776
  store ptr @237, ptr %244, align 8, !dbg !776
  call void @vd_gc_frame_leave(ptr %238), !dbg !776
  ret i32 0, !dbg !776

numeric_valid:                                    ; preds = %worker.continue
  store ptr %240, ptr %69, align 8, !dbg !776
  store ptr %240, ptr %6, align 8, !dbg !776
  call void @vd_string_literal(ptr %74, ptr @238, i64 1, ptr %1), !dbg !776
  %245 = load ptr, ptr %74, align 8, !dbg !776
  %246 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !776
  %247 = load ptr, ptr %246, align 8, !dbg !776
  %248 = icmp ne ptr %247, null, !dbg !776
  br i1 %248, label %numeric_error1, label %numeric_valid2, !dbg !776

numeric_error1:                                   ; preds = %numeric_valid
  %249 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !776
  store ptr @239, ptr %249, align 8, !dbg !776
  call void @vd_gc_frame_leave(ptr %238), !dbg !776
  ret i32 0, !dbg !776

numeric_valid2:                                   ; preds = %numeric_valid
  store ptr %245, ptr %74, align 8, !dbg !776
  store ptr %245, ptr %7, align 8, !dbg !776
  %250 = load ptr, ptr %7, align 8, !dbg !776
  store ptr %250, ptr %79, align 8, !dbg !776
  %251 = getelementptr inbounds [1 x ptr], ptr %4, i32 0, i32 0, !dbg !776
  store ptr %79, ptr %251, align 8, !dbg !776
  call void @vd_string_join(ptr %84, ptr %4, i64 1, ptr %1), !dbg !776
  %252 = load ptr, ptr %1, align 8, !dbg !776
  %253 = icmp ne ptr %252, null, !dbg !776
  br i1 %253, label %numeric_error3, label %numeric_valid4, !dbg !776

numeric_error3:                                   ; preds = %numeric_valid2
  %254 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !776
  store ptr @240, ptr %254, align 8, !dbg !776
  call void @vd_gc_frame_leave(ptr %238), !dbg !776
  ret i32 0, !dbg !776

numeric_valid4:                                   ; preds = %numeric_valid2
  %255 = load ptr, ptr %84, align 8, !dbg !776
  store ptr %255, ptr %84, align 8, !dbg !776
  call void @vd_console_print(ptr %255, i64 1, i1 false, ptr %1), !dbg !776
  %256 = load ptr, ptr %1, align 8, !dbg !776
  %257 = icmp ne ptr %256, null, !dbg !776
  br i1 %257, label %selected.failure, label %selected.valid, !dbg !776

selected.failure:                                 ; preds = %numeric_valid4
  %258 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !776
  %259 = load i32, ptr %258, align 4, !dbg !776
  %260 = icmp ult i32 %259, 32, !dbg !776
  br i1 %260, label %trace_caller, label %trace_limit, !dbg !776

selected.valid:                                   ; preds = %numeric_valid4
  call void @vd_string_literal(ptr %89, ptr @242, i64 5, ptr %1), !dbg !777
  %261 = load ptr, ptr %89, align 8, !dbg !777
  %262 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !777
  %263 = load ptr, ptr %262, align 8, !dbg !777
  %264 = icmp ne ptr %263, null, !dbg !777
  br i1 %264, label %numeric_error5, label %numeric_valid6, !dbg !777

trace_caller:                                     ; preds = %selected.failure
  %265 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !776
  %266 = getelementptr [32 x ptr], ptr %265, i32 0, i32 %259, !dbg !776
  store ptr @241, ptr %266, align 8, !dbg !776
  %267 = add i32 %259, 1, !dbg !776
  store i32 %267, ptr %258, align 4, !dbg !776
  br label %error_return, !dbg !776

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %238), !dbg !776
  ret i32 0, !dbg !776

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %258, align 4, !dbg !776
  br label %error_return, !dbg !776

numeric_error5:                                   ; preds = %selected.valid
  %268 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !777
  store ptr @243, ptr %268, align 8, !dbg !777
  call void @vd_gc_frame_leave(ptr %238), !dbg !777
  ret i32 0, !dbg !777

numeric_valid6:                                   ; preds = %selected.valid
  store ptr %261, ptr %89, align 8, !dbg !777
  store ptr %261, ptr %8, align 8, !dbg !777
  %269 = load i32, ptr %5, align 4, !dbg !778
  store i32 %269, ptr %9, align 4, !dbg !778
  store i1 true, ptr %10, align 1, !dbg !779
  call void @vd_string_literal(ptr %94, ptr @244, i64 1, ptr %1), !dbg !780
  %270 = load ptr, ptr %94, align 8, !dbg !780
  %271 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !780
  %272 = load ptr, ptr %271, align 8, !dbg !780
  %273 = icmp ne ptr %272, null, !dbg !780
  br i1 %273, label %numeric_error7, label %numeric_valid8, !dbg !780

numeric_error7:                                   ; preds = %numeric_valid6
  %274 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !780
  store ptr @245, ptr %274, align 8, !dbg !780
  call void @vd_gc_frame_leave(ptr %238), !dbg !780
  ret i32 0, !dbg !780

numeric_valid8:                                   ; preds = %numeric_valid6
  store ptr %270, ptr %94, align 8, !dbg !780
  store ptr %270, ptr %11, align 8, !dbg !780
  call void @vd_string_literal(ptr %99, ptr @246, i64 1, ptr %1), !dbg !781
  %275 = load ptr, ptr %99, align 8, !dbg !781
  %276 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !781
  %277 = load ptr, ptr %276, align 8, !dbg !781
  %278 = icmp ne ptr %277, null, !dbg !781
  br i1 %278, label %numeric_error9, label %numeric_valid10, !dbg !781

numeric_error9:                                   ; preds = %numeric_valid8
  %279 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !781
  store ptr @247, ptr %279, align 8, !dbg !781
  call void @vd_gc_frame_leave(ptr %238), !dbg !781
  ret i32 0, !dbg !781

numeric_valid10:                                  ; preds = %numeric_valid8
  store ptr %275, ptr %99, align 8, !dbg !781
  store ptr %275, ptr %12, align 8, !dbg !781
  %280 = load ptr, ptr %8, align 8, !dbg !777
  store ptr %280, ptr %104, align 8, !dbg !777
  %281 = call i1 @vd_scalar_display(ptr %109, i32 11, i64 0, ptr %280, ptr null, i1 false, ptr %1), !dbg !777
  %282 = load ptr, ptr %1, align 8, !dbg !777
  %283 = icmp ne ptr %282, null, !dbg !777
  br i1 %283, label %numeric_error11, label %numeric_valid12, !dbg !777

numeric_error11:                                  ; preds = %numeric_valid10
  %284 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !777
  store ptr @248, ptr %284, align 8, !dbg !777
  call void @vd_gc_frame_leave(ptr %238), !dbg !777
  ret i32 0, !dbg !777

numeric_valid12:                                  ; preds = %numeric_valid10
  %285 = load ptr, ptr %109, align 8, !dbg !777
  store ptr %285, ptr %109, align 8, !dbg !777
  store ptr %285, ptr %13, align 8, !dbg !777
  %286 = load i32, ptr %9, align 4, !dbg !778
  %287 = zext i32 %286 to i64, !dbg !778
  %288 = call i1 @vd_scalar_display(ptr %114, i32 2, i64 %287, ptr null, ptr null, i1 false, ptr %1), !dbg !778
  %289 = load ptr, ptr %1, align 8, !dbg !778
  %290 = icmp ne ptr %289, null, !dbg !778
  br i1 %290, label %numeric_error13, label %numeric_valid14, !dbg !778

numeric_error13:                                  ; preds = %numeric_valid12
  %291 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !778
  store ptr @249, ptr %291, align 8, !dbg !778
  call void @vd_gc_frame_leave(ptr %238), !dbg !778
  ret i32 0, !dbg !778

numeric_valid14:                                  ; preds = %numeric_valid12
  %292 = load ptr, ptr %114, align 8, !dbg !778
  store ptr %292, ptr %114, align 8, !dbg !778
  store ptr %292, ptr %14, align 8, !dbg !778
  %293 = load i1, ptr %10, align 1, !dbg !779
  %294 = zext i1 %293 to i64, !dbg !779
  %295 = call i1 @vd_scalar_display(ptr %119, i32 10, i64 %294, ptr null, ptr null, i1 false, ptr %1), !dbg !779
  %296 = load ptr, ptr %1, align 8, !dbg !779
  %297 = icmp ne ptr %296, null, !dbg !779
  br i1 %297, label %numeric_error15, label %numeric_valid16, !dbg !779

numeric_error15:                                  ; preds = %numeric_valid14
  %298 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !779
  store ptr @250, ptr %298, align 8, !dbg !779
  call void @vd_gc_frame_leave(ptr %238), !dbg !779
  ret i32 0, !dbg !779

numeric_valid16:                                  ; preds = %numeric_valid14
  %299 = load ptr, ptr %119, align 8, !dbg !779
  store ptr %299, ptr %119, align 8, !dbg !779
  store ptr %299, ptr %15, align 8, !dbg !779
  %300 = load ptr, ptr %13, align 8, !dbg !782
  store ptr %300, ptr %124, align 8, !dbg !782
  %301 = load ptr, ptr %11, align 8, !dbg !782
  store ptr %301, ptr %129, align 8, !dbg !782
  %302 = load ptr, ptr %14, align 8, !dbg !782
  store ptr %302, ptr %134, align 8, !dbg !782
  %303 = load ptr, ptr %11, align 8, !dbg !782
  store ptr %303, ptr %139, align 8, !dbg !782
  %304 = load ptr, ptr %15, align 8, !dbg !782
  store ptr %304, ptr %144, align 8, !dbg !782
  %305 = load ptr, ptr %12, align 8, !dbg !782
  store ptr %305, ptr %149, align 8, !dbg !782
  %306 = getelementptr inbounds [6 x ptr], ptr %3, i32 0, i32 0, !dbg !782
  store ptr %124, ptr %306, align 8, !dbg !782
  %307 = getelementptr inbounds [6 x ptr], ptr %3, i32 0, i32 1, !dbg !782
  store ptr %129, ptr %307, align 8, !dbg !782
  %308 = getelementptr inbounds [6 x ptr], ptr %3, i32 0, i32 2, !dbg !782
  store ptr %134, ptr %308, align 8, !dbg !782
  %309 = getelementptr inbounds [6 x ptr], ptr %3, i32 0, i32 3, !dbg !782
  store ptr %139, ptr %309, align 8, !dbg !782
  %310 = getelementptr inbounds [6 x ptr], ptr %3, i32 0, i32 4, !dbg !782
  store ptr %144, ptr %310, align 8, !dbg !782
  %311 = getelementptr inbounds [6 x ptr], ptr %3, i32 0, i32 5, !dbg !782
  store ptr %149, ptr %311, align 8, !dbg !782
  call void @vd_string_join(ptr %154, ptr %3, i64 6, ptr %1), !dbg !782
  %312 = load ptr, ptr %1, align 8, !dbg !782
  %313 = icmp ne ptr %312, null, !dbg !782
  br i1 %313, label %numeric_error17, label %numeric_valid18, !dbg !782

numeric_error17:                                  ; preds = %numeric_valid16
  %314 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !782
  store ptr @251, ptr %314, align 8, !dbg !782
  call void @vd_gc_frame_leave(ptr %238), !dbg !782
  ret i32 0, !dbg !782

numeric_valid18:                                  ; preds = %numeric_valid16
  %315 = load ptr, ptr %154, align 8, !dbg !782
  store ptr %315, ptr %154, align 8, !dbg !782
  call void @vd_console_print(ptr %315, i64 1, i1 false, ptr %1), !dbg !782
  %316 = load ptr, ptr %1, align 8, !dbg !782
  %317 = icmp ne ptr %316, null, !dbg !782
  br i1 %317, label %selected.failure19, label %selected.valid20, !dbg !782

selected.failure19:                               ; preds = %numeric_valid18
  %318 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !782
  %319 = load i32, ptr %318, align 4, !dbg !782
  %320 = icmp ult i32 %319, 32, !dbg !782
  br i1 %320, label %trace_caller21, label %trace_limit23, !dbg !782

selected.valid20:                                 ; preds = %numeric_valid18
  call void @vd_string_literal(ptr %159, ptr @253, i64 3, ptr %1), !dbg !783
  %321 = load ptr, ptr %159, align 8, !dbg !783
  %322 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !783
  %323 = load ptr, ptr %322, align 8, !dbg !783
  %324 = icmp ne ptr %323, null, !dbg !783
  br i1 %324, label %numeric_error24, label %numeric_valid25, !dbg !783

trace_caller21:                                   ; preds = %selected.failure19
  %325 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !782
  %326 = getelementptr [32 x ptr], ptr %325, i32 0, i32 %319, !dbg !782
  store ptr @252, ptr %326, align 8, !dbg !782
  %327 = add i32 %319, 1, !dbg !782
  store i32 %327, ptr %318, align 4, !dbg !782
  br label %error_return22, !dbg !782

error_return22:                                   ; preds = %trace_caller21, %trace_limit23
  call void @vd_gc_frame_leave(ptr %238), !dbg !782
  ret i32 0, !dbg !782

trace_limit23:                                    ; preds = %selected.failure19
  store i32 33, ptr %318, align 4, !dbg !782
  br label %error_return22, !dbg !782

numeric_error24:                                  ; preds = %selected.valid20
  %328 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !783
  store ptr @254, ptr %328, align 8, !dbg !783
  call void @vd_gc_frame_leave(ptr %238), !dbg !783
  ret i32 0, !dbg !783

numeric_valid25:                                  ; preds = %selected.valid20
  store ptr %321, ptr %159, align 8, !dbg !783
  store ptr %321, ptr %16, align 8, !dbg !783
  store %"/@stdlib/console.void::output" { i64 2 }, ptr %17, align 8, !dbg !784
  call void @vd_string_literal(ptr %164, ptr @255, i64 0, ptr %1), !dbg !785
  %329 = load ptr, ptr %164, align 8, !dbg !785
  %330 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !785
  %331 = load ptr, ptr %330, align 8, !dbg !785
  %332 = icmp ne ptr %331, null, !dbg !785
  br i1 %332, label %numeric_error26, label %numeric_valid27, !dbg !785

numeric_error26:                                  ; preds = %numeric_valid25
  %333 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !785
  store ptr @256, ptr %333, align 8, !dbg !785
  call void @vd_gc_frame_leave(ptr %238), !dbg !785
  ret i32 0, !dbg !785

numeric_valid27:                                  ; preds = %numeric_valid25
  store ptr %329, ptr %164, align 8, !dbg !785
  store ptr %329, ptr %18, align 8, !dbg !785
  %334 = load ptr, ptr %16, align 8, !dbg !783
  store ptr %334, ptr %169, align 8, !dbg !783
  %335 = call i1 @vd_scalar_display(ptr %174, i32 11, i64 0, ptr %334, ptr null, i1 false, ptr %1), !dbg !783
  %336 = load ptr, ptr %1, align 8, !dbg !783
  %337 = icmp ne ptr %336, null, !dbg !783
  br i1 %337, label %numeric_error28, label %numeric_valid29, !dbg !783

numeric_error28:                                  ; preds = %numeric_valid27
  %338 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !783
  store ptr @257, ptr %338, align 8, !dbg !783
  call void @vd_gc_frame_leave(ptr %238), !dbg !783
  ret i32 0, !dbg !783

numeric_valid29:                                  ; preds = %numeric_valid27
  %339 = load ptr, ptr %174, align 8, !dbg !783
  store ptr %339, ptr %174, align 8, !dbg !783
  store ptr %339, ptr %19, align 8, !dbg !783
  call void @vd_string_literal(ptr %179, ptr @258, i64 1, ptr %1), !dbg !786
  %340 = load ptr, ptr %179, align 8, !dbg !786
  %341 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !786
  %342 = load ptr, ptr %341, align 8, !dbg !786
  %343 = icmp ne ptr %342, null, !dbg !786
  br i1 %343, label %numeric_error30, label %numeric_valid31, !dbg !786

numeric_error30:                                  ; preds = %numeric_valid29
  %344 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !786
  store ptr @259, ptr %344, align 8, !dbg !786
  call void @vd_gc_frame_leave(ptr %238), !dbg !786
  ret i32 0, !dbg !786

numeric_valid31:                                  ; preds = %numeric_valid29
  store ptr %340, ptr %179, align 8, !dbg !786
  store ptr %340, ptr %20, align 8, !dbg !786
  %345 = load ptr, ptr %19, align 8, !dbg !786
  store ptr %345, ptr %184, align 8, !dbg !786
  %346 = load ptr, ptr %18, align 8, !dbg !786
  store ptr %346, ptr %189, align 8, !dbg !786
  %347 = getelementptr inbounds [2 x ptr], ptr %2, i32 0, i32 0, !dbg !786
  store ptr %184, ptr %347, align 8, !dbg !786
  %348 = getelementptr inbounds [2 x ptr], ptr %2, i32 0, i32 1, !dbg !786
  store ptr %189, ptr %348, align 8, !dbg !786
  call void @vd_string_join(ptr %194, ptr %2, i64 2, ptr %1), !dbg !786
  %349 = load ptr, ptr %1, align 8, !dbg !786
  %350 = icmp ne ptr %349, null, !dbg !786
  br i1 %350, label %numeric_error32, label %numeric_valid33, !dbg !786

numeric_error32:                                  ; preds = %numeric_valid31
  %351 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !786
  store ptr @260, ptr %351, align 8, !dbg !786
  call void @vd_gc_frame_leave(ptr %238), !dbg !786
  ret i32 0, !dbg !786

numeric_valid33:                                  ; preds = %numeric_valid31
  %352 = load ptr, ptr %194, align 8, !dbg !786
  store ptr %352, ptr %194, align 8, !dbg !786
  %353 = load %"/@stdlib/console.void::output", ptr %17, align 8, !dbg !786
  %354 = extractvalue %"/@stdlib/console.void::output" %353, 0, !dbg !786
  call void @vd_console_print(ptr %352, i64 %354, i1 false, ptr %1), !dbg !786
  %355 = load ptr, ptr %1, align 8, !dbg !786
  %356 = icmp ne ptr %355, null, !dbg !786
  br i1 %356, label %selected.failure34, label %selected.valid35, !dbg !786

selected.failure34:                               ; preds = %numeric_valid33
  %357 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !786
  %358 = load i32, ptr %357, align 4, !dbg !786
  %359 = icmp ult i32 %358, 32, !dbg !786
  br i1 %359, label %trace_caller36, label %trace_limit38, !dbg !786

selected.valid35:                                 ; preds = %numeric_valid33
  %360 = load i32, ptr %5, align 4, !dbg !787
  call void @vd_gc_frame_leave(ptr %238), !dbg !787
  ret i32 %360, !dbg !787

trace_caller36:                                   ; preds = %selected.failure34
  %361 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !786
  %362 = getelementptr [32 x ptr], ptr %361, i32 0, i32 %358, !dbg !786
  store ptr @261, ptr %362, align 8, !dbg !786
  %363 = add i32 %358, 1, !dbg !786
  store i32 %363, ptr %357, align 4, !dbg !786
  br label %error_return37, !dbg !786

error_return37:                                   ; preds = %trace_caller36, %trace_limit38
  call void @vd_gc_frame_leave(ptr %238), !dbg !786
  ret i32 0, !dbg !786

trace_limit38:                                    ; preds = %selected.failure34
  store i32 33, ptr %357, align 4, !dbg !786
  br label %error_return37, !dbg !786
}

declare void @vd_gc_frame_enter(ptr, ptr, i64)

declare void @vd_gc_poll()

declare i1 @vd_worker_checkpoint(ptr)

declare void @vd_gc_frame_leave(ptr)

declare void @vd_string_literal(ptr, ptr, i64, ptr)

declare void @vd_console_v2(ptr, ptr, ptr, i32, i64, ptr, i64, i64, ptr)

declare void @vd_async_cleanup_enter()

declare void @vd_async_cleanup_leave()

declare i1 @vd_gc_release(ptr)

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #0

declare void @vd_gc_construct_typed(ptr, i64, ptr, i64, ptr, ptr, ptr)

declare void @vd_string_join(ptr, ptr, i64, ptr)

declare void @vd_console_print(ptr, i64, i1, ptr)

declare i1 @vd_scalar_display(ptr, i32, i64, ptr, ptr, i1, ptr)

attributes #0 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2}

!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "VOID source compiler", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "main.void", directory: "/tmp/VOID-console27-41977497569637")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = distinct !DISubprogram(name: "_error", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6572726f72__v1", scope: !4, file: !4, line: 63, type: !5, scopeLine: 63, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!4 = !DIFile(filename: "console.void", directory: "/home/shmellyorc/Documents/Void.Language/stdlib")
!5 = !DISubroutineType(types: !6)
!6 = !{!7, !25, !10, !10}
!7 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::io_error", scope: !1, file: !1, size: 576, align: 64, elements: !8)
!8 = !{!9, !11, !12, !17, !19, !20, !21, !23, !24}
!9 = !DIDerivedType(tag: DW_TAG_member, name: "operation", scope: !1, file: !1, baseType: !10, size: 64, align: 64)
!10 = !DIDerivedType(tag: DW_TAG_pointer_type, baseType: null, size: 64)
!11 = !DIDerivedType(tag: DW_TAG_member, name: "stream", scope: !1, file: !1, baseType: !10, size: 64, align: 64, offset: 64)
!12 = !DIDerivedType(tag: DW_TAG_member, name: "kind", scope: !1, file: !1, baseType: !13, size: 32, align: 32, offset: 128)
!13 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::io_error_kind", scope: !1, file: !1, size: 32, align: 32, elements: !14)
!14 = !{!15}
!15 = !DIDerivedType(tag: DW_TAG_member, name: "$tag", scope: !1, file: !1, baseType: !16, size: 32, align: 32)
!16 = !DIBasicType(name: "i32", size: 32, encoding: DW_ATE_signed)
!17 = !DIDerivedType(tag: DW_TAG_member, name: "os_code", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 192)
!18 = !DIBasicType(name: "i64", size: 64, encoding: DW_ATE_signed)
!19 = !DIDerivedType(tag: DW_TAG_member, name: "message", scope: !1, file: !1, baseType: !10, size: 64, align: 64, offset: 256)
!20 = !DIDerivedType(tag: DW_TAG_member, name: "bytes_transferred", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 320)
!21 = !DIDerivedType(tag: DW_TAG_member, name: "partial", scope: !1, file: !1, baseType: !22, size: 64, align: 64, offset: 384)
!22 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "readonly [u8]", baseType: null, size: 64)
!23 = !DIDerivedType(tag: DW_TAG_member, name: "cleanup_code", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 448)
!24 = !DIDerivedType(tag: DW_TAG_member, name: "partial_utf16_units", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 512)
!25 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::_reply", scope: !1, file: !1, size: 640, align: 64, elements: !26)
!26 = !{!27, !28, !29, !30, !31, !32, !34, !35, !37, !38}
!27 = !DIDerivedType(tag: DW_TAG_member, name: "kind", scope: !1, file: !1, baseType: !18, size: 64, align: 64)
!28 = !DIDerivedType(tag: DW_TAG_member, name: "os_code", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 64)
!29 = !DIDerivedType(tag: DW_TAG_member, name: "progress", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 128)
!30 = !DIDerivedType(tag: DW_TAG_member, name: "cleanup_code", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 192)
!31 = !DIDerivedType(tag: DW_TAG_member, name: "partial_utf16_units", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 256)
!32 = !DIDerivedType(tag: DW_TAG_member, name: "eof", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 320)
!33 = !DIBasicType(name: "bool", size: 1, encoding: DW_ATE_boolean)
!34 = !DIDerivedType(tag: DW_TAG_member, name: "text", scope: !1, file: !1, baseType: !10, size: 64, align: 64, offset: 384)
!35 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !1, file: !1, baseType: !36, size: 64, align: 64, offset: 448)
!36 = !DIDerivedType(tag: DW_TAG_pointer_type, name: "[u8]", baseType: null, size: 64)
!37 = !DIDerivedType(tag: DW_TAG_member, name: "first", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 512)
!38 = !DIDerivedType(tag: DW_TAG_member, name: "second", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 576)
!39 = !DILocation(line: 65, column: 19, scope: !3)
!40 = !DILocation(line: 66, column: 9, scope: !3)
!41 = !DILocation(line: 67, column: 19, scope: !3)
!42 = !DILocation(line: 68, column: 9, scope: !3)
!43 = !DILocation(line: 69, column: 19, scope: !3)
!44 = !DILocation(line: 70, column: 9, scope: !3)
!45 = !DILocation(line: 71, column: 19, scope: !3)
!46 = !DILocation(line: 72, column: 9, scope: !3)
!47 = !DILocation(line: 73, column: 19, scope: !3)
!48 = !DILocation(line: 74, column: 9, scope: !3)
!49 = !DILocation(line: 75, column: 19, scope: !3)
!50 = !DILocation(line: 76, column: 9, scope: !3)
!51 = !DILocation(line: 77, column: 19, scope: !3)
!52 = !DILocation(line: 78, column: 9, scope: !3)
!53 = !DILocation(line: 79, column: 19, scope: !3)
!54 = !DILocation(line: 80, column: 9, scope: !3)
!55 = !DILocation(line: 63, column: 21, scope: !3)
!56 = !DILocation(line: 63, column: 36, scope: !3)
!57 = !DILocation(line: 63, column: 55, scope: !3)
!58 = !DILocation(line: 64, column: 9, scope: !3)
!59 = !DILocation(line: 65, column: 8, scope: !3)
!60 = !DILocation(line: 65, column: 14, scope: !3)
!61 = !DILocation(line: 67, column: 8, scope: !3)
!62 = !DILocation(line: 67, column: 14, scope: !3)
!63 = !DILocation(line: 69, column: 8, scope: !3)
!64 = !DILocation(line: 69, column: 14, scope: !3)
!65 = !DILocation(line: 71, column: 8, scope: !3)
!66 = !DILocation(line: 71, column: 14, scope: !3)
!67 = !DILocation(line: 73, column: 8, scope: !3)
!68 = !DILocation(line: 73, column: 14, scope: !3)
!69 = !DILocation(line: 75, column: 8, scope: !3)
!70 = !DILocation(line: 75, column: 14, scope: !3)
!71 = !DILocation(line: 77, column: 8, scope: !3)
!72 = !DILocation(line: 77, column: 14, scope: !3)
!73 = !DILocation(line: 79, column: 8, scope: !3)
!74 = !DILocation(line: 79, column: 14, scope: !3)
!75 = !DILocation(line: 81, column: 33, scope: !3)
!76 = !DILocation(line: 81, column: 53, scope: !3)
!77 = !DILocation(line: 81, column: 68, scope: !3)
!78 = !DILocation(line: 81, column: 84, scope: !3)
!79 = !DILocation(line: 81, column: 90, scope: !3)
!80 = !DILocation(line: 81, column: 109, scope: !3)
!81 = !DILocation(line: 81, column: 115, scope: !3)
!82 = !DILocation(line: 81, column: 141, scope: !3)
!83 = !DILocation(line: 81, column: 147, scope: !3)
!84 = !DILocation(line: 81, column: 167, scope: !3)
!85 = !DILocation(line: 81, column: 173, scope: !3)
!86 = !DILocation(line: 81, column: 195, scope: !3)
!87 = !DILocation(line: 81, column: 201, scope: !3)
!88 = !DILocation(line: 81, column: 237, scope: !3)
!89 = !DILocation(line: 81, column: 243, scope: !3)
!90 = !DILocation(line: 81, column: 12, scope: !3)
!91 = distinct !DISubprogram(name: "_stream", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f73747265616d__v1", scope: !4, file: !4, line: 83, type: !92, scopeLine: 83, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!92 = !DISubroutineType(types: !93)
!93 = !{!10, !94}
!94 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::output", scope: !1, file: !1, size: 64, align: 64, elements: !95)
!95 = !{!96}
!96 = !DIDerivedType(tag: DW_TAG_member, name: "_id", scope: !1, file: !1, baseType: !18, size: 64, align: 64)
!97 = !DILocation(line: 84, column: 17, scope: !91)
!98 = !DILocation(line: 85, column: 16, scope: !91)
!99 = !DILocation(line: 83, column: 22, scope: !91)
!100 = !DILocation(line: 84, column: 8, scope: !91)
!101 = !DILocation(line: 84, column: 13, scope: !91)
!102 = !DILocation(line: 86, column: 12, scope: !91)
!103 = distinct !DISubprogram(name: "output::method::write", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7772697465__v1", scope: !4, file: !4, line: 90, type: !104, scopeLine: 90, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!104 = !DISubroutineType(types: !105)
!105 = !{!106, !110, !10}
!106 = !DICompositeType(tag: DW_TAG_structure_type, name: "result<i64, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 704, align: 64, elements: !107)
!107 = !{!15, !108, !109}
!108 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 64)
!109 = !DIDerivedType(tag: DW_TAG_member, name: "$err", scope: !1, file: !1, baseType: !7, size: 576, align: 64, offset: 128)
!110 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !94, size: 64, align: 64)
!111 = !DILocation(line: 92, column: 19, scope: !103)
!112 = !DILocation(line: 93, column: 16, scope: !103)
!113 = !DILocation(line: 90, column: 26, scope: !103)
!114 = !DILocation(line: 91, column: 32, scope: !103)
!115 = !DILocation(line: 91, column: 38, scope: !103)
!116 = !DILocation(line: 91, column: 17, scope: !103)
!117 = !DILocation(line: 91, column: 9, scope: !103)
!118 = !DILocation(line: 92, column: 8, scope: !103)
!119 = !DILocation(line: 92, column: 14, scope: !103)
!120 = !DILocation(line: 93, column: 27, scope: !103)
!121 = !DILocation(line: 93, column: 34, scope: !103)
!122 = !DILocation(line: 93, column: 51, scope: !103)
!123 = !DILocation(line: 93, column: 43, scope: !103)
!124 = !DILocation(line: 93, column: 20, scope: !103)
!125 = !DILocation(line: 94, column: 15, scope: !103)
!126 = !DILocation(line: 94, column: 21, scope: !103)
!127 = !DILocation(line: 94, column: 12, scope: !103)
!128 = distinct !DISubprogram(name: "output::method::write_bytes", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a77726974655f6279746573__v1", scope: !4, file: !4, line: 97, type: !129, scopeLine: 97, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!129 = !DISubroutineType(types: !130)
!130 = !{!106, !110, !22}
!131 = !DILocation(line: 99, column: 19, scope: !128)
!132 = !DILocation(line: 100, column: 16, scope: !128)
!133 = !DILocation(line: 97, column: 38, scope: !128)
!134 = !DILocation(line: 98, column: 38, scope: !128)
!135 = !DILocation(line: 98, column: 44, scope: !128)
!136 = !DILocation(line: 98, column: 17, scope: !128)
!137 = !DILocation(line: 98, column: 9, scope: !128)
!138 = !DILocation(line: 99, column: 8, scope: !128)
!139 = !DILocation(line: 99, column: 14, scope: !128)
!140 = !DILocation(line: 100, column: 27, scope: !128)
!141 = !DILocation(line: 100, column: 34, scope: !128)
!142 = !DILocation(line: 100, column: 57, scope: !128)
!143 = !DILocation(line: 100, column: 49, scope: !128)
!144 = !DILocation(line: 100, column: 20, scope: !128)
!145 = !DILocation(line: 101, column: 15, scope: !128)
!146 = !DILocation(line: 101, column: 21, scope: !128)
!147 = !DILocation(line: 101, column: 12, scope: !128)
!148 = distinct !DISubprogram(name: "output::method::flush", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a666c757368__v1", scope: !4, file: !4, line: 104, type: !149, scopeLine: 104, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!149 = !DISubroutineType(types: !150)
!150 = !{!151, !110}
!151 = !DICompositeType(tag: DW_TAG_structure_type, name: "result<bool, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 640, align: 64, elements: !152)
!152 = !{!15, !153, !154}
!153 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 32)
!154 = !DIDerivedType(tag: DW_TAG_member, name: "$err", scope: !1, file: !1, baseType: !7, size: 576, align: 64, offset: 64)
!155 = !DILocation(line: 106, column: 19, scope: !148)
!156 = !DILocation(line: 107, column: 16, scope: !148)
!157 = !DILocation(line: 105, column: 32, scope: !148)
!158 = !DILocation(line: 105, column: 17, scope: !148)
!159 = !DILocation(line: 105, column: 9, scope: !148)
!160 = !DILocation(line: 106, column: 8, scope: !148)
!161 = !DILocation(line: 106, column: 14, scope: !148)
!162 = !DILocation(line: 107, column: 27, scope: !148)
!163 = !DILocation(line: 107, column: 34, scope: !148)
!164 = !DILocation(line: 107, column: 51, scope: !148)
!165 = !DILocation(line: 107, column: 43, scope: !148)
!166 = !DILocation(line: 107, column: 20, scope: !148)
!167 = !DILocation(line: 108, column: 15, scope: !148)
!168 = !DILocation(line: 108, column: 12, scope: !148)
!169 = distinct !DISubprogram(name: "output::method::is_redirected", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a69735f72656469726563746564__v1", scope: !4, file: !4, line: 110, type: !170, scopeLine: 110, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!170 = !DISubroutineType(types: !171)
!171 = !{!33, !110}
!172 = !DILocation(line: 112, column: 36, scope: !169)
!173 = !DILocation(line: 112, column: 16, scope: !169)
!174 = !DILocation(line: 112, column: 42, scope: !169)
!175 = !DILocation(line: 112, column: 51, scope: !169)
!176 = distinct !DISubprogram(name: "input::method::is_redirected", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a69735f72656469726563746564__v1", scope: !4, file: !4, line: 114, type: !177, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!177 = !DISubroutineType(types: !178)
!178 = !{!33, !179}
!179 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !180, size: 64, align: 64)
!180 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::input", scope: !1, file: !1, size: 64, align: 64, elements: !95)
!181 = !DILocation(line: 116, column: 36, scope: !176)
!182 = !DILocation(line: 116, column: 16, scope: !176)
!183 = !DILocation(line: 116, column: 42, scope: !176)
!184 = !DILocation(line: 116, column: 51, scope: !176)
!185 = distinct !DISubprogram(name: "_text", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f74657874__v1", scope: !4, file: !4, line: 118, type: !186, scopeLine: 118, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!186 = !DISubroutineType(types: !187)
!187 = !{!188, !25, !10}
!188 = !DICompositeType(tag: DW_TAG_structure_type, name: "result</@stdlib/console.void::text_read, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 768, align: 64, elements: !189)
!189 = !{!15, !190, !194}
!190 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !191, size: 128, align: 64, offset: 64)
!191 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::text_read", scope: !1, file: !1, size: 128, align: 64, elements: !192)
!192 = !{!15, !193}
!193 = !DIDerivedType(tag: DW_TAG_member, name: "$text$value", scope: !1, file: !1, baseType: !10, size: 64, align: 64, offset: 64)
!194 = !DIDerivedType(tag: DW_TAG_member, name: "$err", scope: !1, file: !1, baseType: !7, size: 576, align: 64, offset: 192)
!195 = !DILocation(line: 119, column: 19, scope: !185)
!196 = !DILocation(line: 120, column: 16, scope: !185)
!197 = !DILocation(line: 121, column: 14, scope: !185)
!198 = !DILocation(line: 122, column: 16, scope: !185)
!199 = !DILocation(line: 118, column: 20, scope: !185)
!200 = !DILocation(line: 118, column: 35, scope: !185)
!201 = !DILocation(line: 119, column: 8, scope: !185)
!202 = !DILocation(line: 119, column: 14, scope: !185)
!203 = !DILocation(line: 120, column: 27, scope: !185)
!204 = !DILocation(line: 120, column: 34, scope: !185)
!205 = !DILocation(line: 120, column: 45, scope: !185)
!206 = !DILocation(line: 120, column: 20, scope: !185)
!207 = !DILocation(line: 121, column: 8, scope: !185)
!208 = !DILocation(line: 122, column: 29, scope: !185)
!209 = !DILocation(line: 123, column: 30, scope: !185)
!210 = !DILocation(line: 123, column: 36, scope: !185)
!211 = !DILocation(line: 123, column: 25, scope: !185)
!212 = !DILocation(line: 123, column: 12, scope: !185)
!213 = distinct !DISubprogram(name: "input::method::read_char", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f63686172__v1", scope: !4, file: !4, line: 127, type: !214, scopeLine: 127, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!214 = !DISubroutineType(types: !215)
!215 = !{!188, !179, !18}
!216 = !DILocation(line: 127, column: 29, scope: !213)
!217 = !DILocation(line: 128, column: 37, scope: !213)
!218 = !DILocation(line: 128, column: 43, scope: !213)
!219 = !DILocation(line: 128, column: 18, scope: !213)
!220 = !DILocation(line: 128, column: 56, scope: !213)
!221 = !DILocation(line: 128, column: 12, scope: !213)
!222 = distinct !DISubprogram(name: "input::method::read_text", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f74657874__v1", scope: !4, file: !4, line: 131, type: !223, scopeLine: 131, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!223 = !DISubroutineType(types: !224)
!224 = !{!188, !179, !18, !18}
!225 = !DILocation(line: 131, column: 29, scope: !222)
!226 = !DILocation(line: 131, column: 47, scope: !222)
!227 = !DILocation(line: 132, column: 37, scope: !222)
!228 = !DILocation(line: 132, column: 43, scope: !222)
!229 = !DILocation(line: 132, column: 56, scope: !222)
!230 = !DILocation(line: 132, column: 18, scope: !222)
!231 = !DILocation(line: 132, column: 69, scope: !222)
!232 = !DILocation(line: 132, column: 12, scope: !222)
!233 = distinct !DISubprogram(name: "input::method::read_line", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f6c696e65__v1", scope: !4, file: !4, line: 136, type: !214, scopeLine: 136, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!234 = !DILocation(line: 136, column: 29, scope: !233)
!235 = !DILocation(line: 137, column: 37, scope: !233)
!236 = !DILocation(line: 137, column: 43, scope: !233)
!237 = !DILocation(line: 137, column: 18, scope: !233)
!238 = !DILocation(line: 137, column: 56, scope: !233)
!239 = !DILocation(line: 137, column: 12, scope: !233)
!240 = distinct !DISubprogram(name: "input::method::read_bytes", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f6279746573__v1", scope: !4, file: !4, line: 140, type: !241, scopeLine: 140, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!241 = !DISubroutineType(types: !242)
!242 = !{!243, !179, !18, !18}
!243 = !DICompositeType(tag: DW_TAG_structure_type, name: "result</@stdlib/console.void::bytes_read, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 768, align: 64, elements: !244)
!244 = !{!15, !245, !194}
!245 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !246, size: 128, align: 64, offset: 64)
!246 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::bytes_read", scope: !1, file: !1, size: 128, align: 64, elements: !247)
!247 = !{!15, !248}
!248 = !DIDerivedType(tag: DW_TAG_member, name: "$data$value", scope: !1, file: !1, baseType: !36, size: 64, align: 64, offset: 64)
!249 = !DILocation(line: 142, column: 19, scope: !240)
!250 = !DILocation(line: 143, column: 16, scope: !240)
!251 = !DILocation(line: 144, column: 14, scope: !240)
!252 = !DILocation(line: 145, column: 16, scope: !240)
!253 = !DILocation(line: 140, column: 30, scope: !240)
!254 = !DILocation(line: 140, column: 46, scope: !240)
!255 = !DILocation(line: 141, column: 37, scope: !240)
!256 = !DILocation(line: 141, column: 43, scope: !240)
!257 = !DILocation(line: 141, column: 54, scope: !240)
!258 = !DILocation(line: 141, column: 17, scope: !240)
!259 = !DILocation(line: 141, column: 9, scope: !240)
!260 = !DILocation(line: 142, column: 8, scope: !240)
!261 = !DILocation(line: 142, column: 14, scope: !240)
!262 = !DILocation(line: 143, column: 27, scope: !240)
!263 = !DILocation(line: 143, column: 34, scope: !240)
!264 = !DILocation(line: 143, column: 48, scope: !240)
!265 = !DILocation(line: 143, column: 20, scope: !240)
!266 = !DILocation(line: 144, column: 8, scope: !240)
!267 = !DILocation(line: 145, column: 30, scope: !240)
!268 = !DILocation(line: 146, column: 31, scope: !240)
!269 = !DILocation(line: 146, column: 37, scope: !240)
!270 = !DILocation(line: 146, column: 26, scope: !240)
!271 = !DILocation(line: 146, column: 12, scope: !240)
!272 = distinct !DISubprogram(name: "_color_code", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f636f6c6f725f636f6465__v1", scope: !4, file: !4, line: 188, type: !273, scopeLine: 188, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!273 = !DISubroutineType(types: !274)
!274 = !{!18, !275}
!275 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::color", scope: !1, file: !1, size: 32, align: 32, elements: !14)
!276 = !DILocation(line: 190, column: 9, scope: !272)
!277 = !DILocation(line: 191, column: 20, scope: !272)
!278 = !DILocation(line: 192, column: 9, scope: !272)
!279 = !DILocation(line: 193, column: 20, scope: !272)
!280 = !DILocation(line: 194, column: 9, scope: !272)
!281 = !DILocation(line: 195, column: 20, scope: !272)
!282 = !DILocation(line: 196, column: 9, scope: !272)
!283 = !DILocation(line: 197, column: 20, scope: !272)
!284 = !DILocation(line: 198, column: 9, scope: !272)
!285 = !DILocation(line: 199, column: 20, scope: !272)
!286 = !DILocation(line: 200, column: 9, scope: !272)
!287 = !DILocation(line: 201, column: 20, scope: !272)
!288 = !DILocation(line: 202, column: 9, scope: !272)
!289 = !DILocation(line: 203, column: 20, scope: !272)
!290 = !DILocation(line: 204, column: 9, scope: !272)
!291 = !DILocation(line: 205, column: 20, scope: !272)
!292 = !DILocation(line: 206, column: 9, scope: !272)
!293 = !DILocation(line: 207, column: 20, scope: !272)
!294 = !DILocation(line: 208, column: 9, scope: !272)
!295 = !DILocation(line: 209, column: 20, scope: !272)
!296 = !DILocation(line: 210, column: 9, scope: !272)
!297 = !DILocation(line: 211, column: 20, scope: !272)
!298 = !DILocation(line: 212, column: 9, scope: !272)
!299 = !DILocation(line: 213, column: 20, scope: !272)
!300 = !DILocation(line: 214, column: 9, scope: !272)
!301 = !DILocation(line: 215, column: 20, scope: !272)
!302 = !DILocation(line: 216, column: 9, scope: !272)
!303 = !DILocation(line: 217, column: 20, scope: !272)
!304 = !DILocation(line: 218, column: 9, scope: !272)
!305 = !DILocation(line: 219, column: 20, scope: !272)
!306 = !DILocation(line: 220, column: 9, scope: !272)
!307 = !DILocation(line: 221, column: 20, scope: !272)
!308 = !DILocation(line: 188, column: 26, scope: !272)
!309 = !DILocation(line: 189, column: 11, scope: !272)
!310 = !DILocation(line: 189, column: 5, scope: !272)
!311 = distinct !DISubprogram(name: "_flag", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f666c6167__v1", scope: !4, file: !4, line: 224, type: !312, scopeLine: 224, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!312 = !DISubroutineType(types: !313)
!313 = !{!33, !18, !18}
!314 = !DILocation(line: 224, column: 20, scope: !311)
!315 = !DILocation(line: 224, column: 31, scope: !311)
!316 = !DILocation(line: 225, column: 12, scope: !311)
!317 = !DILocation(line: 225, column: 17, scope: !311)
!318 = !DILocation(line: 225, column: 19, scope: !311)
!319 = !DILocation(line: 225, column: 23, scope: !311)
!320 = !DILocation(line: 225, column: 27, scope: !311)
!321 = distinct !DISubprogram(name: "_capabilities", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6361706162696c6974696573__v1", scope: !4, file: !4, line: 227, type: !322, scopeLine: 227, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!322 = !DISubroutineType(types: !323)
!323 = !{!324, !25}
!324 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::terminal_capabilities", scope: !1, file: !1, size: 88, align: 8, elements: !325)
!325 = !{!326, !327, !328, !329, !330, !331, !332, !333, !334, !335, !336}
!326 = !DIDerivedType(tag: DW_TAG_member, name: "text_input", scope: !1, file: !1, baseType: !33, size: 1, align: 8)
!327 = !DIDerivedType(tag: DW_TAG_member, name: "text_output", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 8)
!328 = !DIDerivedType(tag: DW_TAG_member, name: "key_input", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 16)
!329 = !DIDerivedType(tag: DW_TAG_member, name: "input_modes", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 24)
!330 = !DIDerivedType(tag: DW_TAG_member, name: "size", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 32)
!331 = !DIDerivedType(tag: DW_TAG_member, name: "cursor_position", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 40)
!332 = !DIDerivedType(tag: DW_TAG_member, name: "cursor_visibility", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 48)
!333 = !DIDerivedType(tag: DW_TAG_member, name: "color", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 56)
!334 = !DIDerivedType(tag: DW_TAG_member, name: "clear", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 64)
!335 = !DIDerivedType(tag: DW_TAG_member, name: "title", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 72)
!336 = !DIDerivedType(tag: DW_TAG_member, name: "bell", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 80)
!337 = !DILocation(line: 227, column: 28, scope: !321)
!338 = !DILocation(line: 228, column: 16, scope: !321)
!339 = !DILocation(line: 228, column: 22, scope: !321)
!340 = !DILocation(line: 228, column: 9, scope: !321)
!341 = !DILocation(line: 229, column: 53, scope: !321)
!342 = !DILocation(line: 229, column: 59, scope: !321)
!343 = !DILocation(line: 229, column: 47, scope: !321)
!344 = !DILocation(line: 229, column: 83, scope: !321)
!345 = !DILocation(line: 229, column: 89, scope: !321)
!346 = !DILocation(line: 229, column: 77, scope: !321)
!347 = !DILocation(line: 229, column: 111, scope: !321)
!348 = !DILocation(line: 229, column: 117, scope: !321)
!349 = !DILocation(line: 229, column: 105, scope: !321)
!350 = !DILocation(line: 229, column: 141, scope: !321)
!351 = !DILocation(line: 229, column: 147, scope: !321)
!352 = !DILocation(line: 229, column: 135, scope: !321)
!353 = !DILocation(line: 229, column: 164, scope: !321)
!354 = !DILocation(line: 229, column: 170, scope: !321)
!355 = !DILocation(line: 229, column: 158, scope: !321)
!356 = !DILocation(line: 229, column: 199, scope: !321)
!357 = !DILocation(line: 229, column: 205, scope: !321)
!358 = !DILocation(line: 229, column: 193, scope: !321)
!359 = !DILocation(line: 229, column: 236, scope: !321)
!360 = !DILocation(line: 229, column: 242, scope: !321)
!361 = !DILocation(line: 229, column: 230, scope: !321)
!362 = !DILocation(line: 229, column: 261, scope: !321)
!363 = !DILocation(line: 229, column: 267, scope: !321)
!364 = !DILocation(line: 229, column: 255, scope: !321)
!365 = !DILocation(line: 229, column: 287, scope: !321)
!366 = !DILocation(line: 229, column: 293, scope: !321)
!367 = !DILocation(line: 229, column: 281, scope: !321)
!368 = !DILocation(line: 229, column: 313, scope: !321)
!369 = !DILocation(line: 229, column: 319, scope: !321)
!370 = !DILocation(line: 229, column: 307, scope: !321)
!371 = !DILocation(line: 229, column: 338, scope: !321)
!372 = !DILocation(line: 229, column: 344, scope: !321)
!373 = !DILocation(line: 229, column: 332, scope: !321)
!374 = !DILocation(line: 229, column: 12, scope: !321)
!375 = distinct !DISubprogram(name: "input::method::capabilities", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a6361706162696c6974696573__v1", scope: !4, file: !4, line: 232, type: !376, scopeLine: 232, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!376 = !DISubroutineType(types: !377)
!377 = !{!324, !179}
!378 = !DILocation(line: 233, column: 48, scope: !375)
!379 = !DILocation(line: 233, column: 26, scope: !375)
!380 = !DILocation(line: 233, column: 12, scope: !375)
!381 = distinct !DISubprogram(name: "output::method::capabilities", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a6361706162696c6974696573__v1", scope: !4, file: !4, line: 236, type: !382, scopeLine: 236, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!382 = !DISubroutineType(types: !383)
!383 = !{!324, !110}
!384 = !DILocation(line: 237, column: 48, scope: !381)
!385 = !DILocation(line: 237, column: 26, scope: !381)
!386 = !DILocation(line: 237, column: 12, scope: !381)
!387 = distinct !DISubprogram(name: "_ack", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f61636b__v1", scope: !4, file: !4, line: 239, type: !388, scopeLine: 239, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!388 = !DISubroutineType(types: !389)
!389 = !{!151, !25, !10, !10}
!390 = !DILocation(line: 240, column: 19, scope: !387)
!391 = !DILocation(line: 241, column: 16, scope: !387)
!392 = !DILocation(line: 239, column: 19, scope: !387)
!393 = !DILocation(line: 239, column: 34, scope: !387)
!394 = !DILocation(line: 239, column: 53, scope: !387)
!395 = !DILocation(line: 240, column: 8, scope: !387)
!396 = !DILocation(line: 240, column: 14, scope: !387)
!397 = !DILocation(line: 241, column: 27, scope: !387)
!398 = !DILocation(line: 241, column: 34, scope: !387)
!399 = !DILocation(line: 241, column: 45, scope: !387)
!400 = !DILocation(line: 241, column: 20, scope: !387)
!401 = !DILocation(line: 242, column: 15, scope: !387)
!402 = !DILocation(line: 242, column: 12, scope: !387)
!403 = distinct !DISubprogram(name: "output::method::size", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a73697a65__v1", scope: !4, file: !4, line: 245, type: !404, scopeLine: 245, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!404 = !DISubroutineType(types: !405)
!405 = !{!406, !110}
!406 = !DICompositeType(tag: DW_TAG_structure_type, name: "result</@stdlib/console.void::terminal_size, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 768, align: 64, elements: !407)
!407 = !{!15, !408, !194}
!408 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !409, size: 128, align: 64, offset: 64)
!409 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::terminal_size", scope: !1, file: !1, size: 128, align: 64, elements: !410)
!410 = !{!411, !412}
!411 = !DIDerivedType(tag: DW_TAG_member, name: "columns", scope: !1, file: !1, baseType: !18, size: 64, align: 64)
!412 = !DIDerivedType(tag: DW_TAG_member, name: "rows", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 64)
!413 = !DILocation(line: 247, column: 19, scope: !403)
!414 = !DILocation(line: 248, column: 16, scope: !403)
!415 = !DILocation(line: 246, column: 31, scope: !403)
!416 = !DILocation(line: 246, column: 17, scope: !403)
!417 = !DILocation(line: 246, column: 9, scope: !403)
!418 = !DILocation(line: 247, column: 8, scope: !403)
!419 = !DILocation(line: 247, column: 14, scope: !403)
!420 = !DILocation(line: 248, column: 27, scope: !403)
!421 = !DILocation(line: 248, column: 34, scope: !403)
!422 = !DILocation(line: 248, column: 50, scope: !403)
!423 = !DILocation(line: 248, column: 42, scope: !403)
!424 = !DILocation(line: 248, column: 20, scope: !403)
!425 = !DILocation(line: 249, column: 39, scope: !403)
!426 = !DILocation(line: 249, column: 45, scope: !403)
!427 = !DILocation(line: 249, column: 59, scope: !403)
!428 = !DILocation(line: 249, column: 65, scope: !403)
!429 = !DILocation(line: 249, column: 15, scope: !403)
!430 = !DILocation(line: 249, column: 12, scope: !403)
!431 = distinct !DISubprogram(name: "output::method::cursor_position", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a637572736f725f706f736974696f6e__v1", scope: !4, file: !4, line: 252, type: !432, scopeLine: 252, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!432 = !DISubroutineType(types: !433)
!433 = !{!434, !110}
!434 = !DICompositeType(tag: DW_TAG_structure_type, name: "result</@stdlib/console.void::terminal_position, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 768, align: 64, elements: !435)
!435 = !{!15, !436, !194}
!436 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !437, size: 128, align: 64, offset: 64)
!437 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::terminal_position", scope: !1, file: !1, size: 128, align: 64, elements: !438)
!438 = !{!439, !440}
!439 = !DIDerivedType(tag: DW_TAG_member, name: "column", scope: !1, file: !1, baseType: !18, size: 64, align: 64)
!440 = !DIDerivedType(tag: DW_TAG_member, name: "row", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 64)
!441 = !DILocation(line: 254, column: 19, scope: !431)
!442 = !DILocation(line: 255, column: 16, scope: !431)
!443 = !DILocation(line: 253, column: 35, scope: !431)
!444 = !DILocation(line: 253, column: 17, scope: !431)
!445 = !DILocation(line: 253, column: 9, scope: !431)
!446 = !DILocation(line: 254, column: 8, scope: !431)
!447 = !DILocation(line: 254, column: 14, scope: !431)
!448 = !DILocation(line: 255, column: 27, scope: !431)
!449 = !DILocation(line: 255, column: 34, scope: !431)
!450 = !DILocation(line: 255, column: 61, scope: !431)
!451 = !DILocation(line: 255, column: 53, scope: !431)
!452 = !DILocation(line: 255, column: 20, scope: !431)
!453 = !DILocation(line: 256, column: 42, scope: !431)
!454 = !DILocation(line: 256, column: 48, scope: !431)
!455 = !DILocation(line: 256, column: 61, scope: !431)
!456 = !DILocation(line: 256, column: 67, scope: !431)
!457 = !DILocation(line: 256, column: 15, scope: !431)
!458 = !DILocation(line: 256, column: 12, scope: !431)
!459 = distinct !DISubprogram(name: "output::method::set_cursor", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f637572736f72__v1", scope: !4, file: !4, line: 261, type: !460, scopeLine: 261, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!460 = !DISubroutineType(types: !461)
!461 = !{!151, !110, !18, !18}
!462 = !DILocation(line: 261, column: 31, scope: !459)
!463 = !DILocation(line: 261, column: 44, scope: !459)
!464 = !DILocation(line: 262, column: 33, scope: !459)
!465 = !DILocation(line: 262, column: 39, scope: !459)
!466 = !DILocation(line: 262, column: 47, scope: !459)
!467 = !DILocation(line: 262, column: 17, scope: !459)
!468 = !DILocation(line: 262, column: 53, scope: !459)
!469 = !DILocation(line: 262, column: 75, scope: !459)
!470 = !DILocation(line: 262, column: 67, scope: !459)
!471 = !DILocation(line: 262, column: 12, scope: !459)
!472 = distinct !DISubprogram(name: "output::method::set_cursor_visible", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f637572736f725f76697369626c65__v1", scope: !4, file: !4, line: 265, type: !473, scopeLine: 265, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!473 = !DISubroutineType(types: !474)
!474 = !{!151, !110, !33}
!475 = !DILocation(line: 267, column: 8, scope: !472)
!476 = !DILocation(line: 268, column: 9, scope: !472)
!477 = !DILocation(line: 265, column: 39, scope: !472)
!478 = !DILocation(line: 266, column: 9, scope: !472)
!479 = !DILocation(line: 269, column: 34, scope: !472)
!480 = !DILocation(line: 269, column: 40, scope: !472)
!481 = !DILocation(line: 269, column: 17, scope: !472)
!482 = !DILocation(line: 269, column: 47, scope: !472)
!483 = !DILocation(line: 269, column: 77, scope: !472)
!484 = !DILocation(line: 269, column: 69, scope: !472)
!485 = !DILocation(line: 269, column: 12, scope: !472)
!486 = distinct !DISubprogram(name: "output::method::set_color", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f636f6c6f72__v1", scope: !4, file: !4, line: 272, type: !487, scopeLine: 272, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!487 = !DISubroutineType(types: !488)
!488 = !{!151, !110, !275, !275}
!489 = !DILocation(line: 272, column: 30, scope: !486)
!490 = !DILocation(line: 272, column: 49, scope: !486)
!491 = !DILocation(line: 273, column: 32, scope: !486)
!492 = !DILocation(line: 273, column: 50, scope: !486)
!493 = !DILocation(line: 273, column: 38, scope: !486)
!494 = !DILocation(line: 273, column: 75, scope: !486)
!495 = !DILocation(line: 273, column: 63, scope: !486)
!496 = !DILocation(line: 273, column: 17, scope: !486)
!497 = !DILocation(line: 273, column: 89, scope: !486)
!498 = !DILocation(line: 273, column: 110, scope: !486)
!499 = !DILocation(line: 273, column: 102, scope: !486)
!500 = !DILocation(line: 273, column: 12, scope: !486)
!501 = distinct !DISubprogram(name: "output::method::reset_color", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a72657365745f636f6c6f72__v1", scope: !4, file: !4, line: 276, type: !149, scopeLine: 276, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!502 = !DILocation(line: 277, column: 32, scope: !501)
!503 = !DILocation(line: 277, column: 17, scope: !501)
!504 = !DILocation(line: 277, column: 39, scope: !501)
!505 = !DILocation(line: 277, column: 62, scope: !501)
!506 = !DILocation(line: 277, column: 54, scope: !501)
!507 = !DILocation(line: 277, column: 12, scope: !501)
!508 = distinct !DISubprogram(name: "output::method::clear", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a636c656172__v1", scope: !4, file: !4, line: 280, type: !149, scopeLine: 280, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!509 = !DILocation(line: 281, column: 32, scope: !508)
!510 = !DILocation(line: 281, column: 17, scope: !508)
!511 = !DILocation(line: 281, column: 39, scope: !508)
!512 = !DILocation(line: 281, column: 56, scope: !508)
!513 = !DILocation(line: 281, column: 48, scope: !508)
!514 = !DILocation(line: 281, column: 12, scope: !508)
!515 = distinct !DISubprogram(name: "output::method::set_title", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a7365745f7469746c65__v1", scope: !4, file: !4, line: 284, type: !516, scopeLine: 284, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!516 = !DISubroutineType(types: !517)
!517 = !{!151, !110, !10}
!518 = !DILocation(line: 284, column: 30, scope: !515)
!519 = !DILocation(line: 285, column: 32, scope: !515)
!520 = !DILocation(line: 285, column: 38, scope: !515)
!521 = !DILocation(line: 285, column: 17, scope: !515)
!522 = !DILocation(line: 285, column: 45, scope: !515)
!523 = !DILocation(line: 285, column: 66, scope: !515)
!524 = !DILocation(line: 285, column: 58, scope: !515)
!525 = !DILocation(line: 285, column: 12, scope: !515)
!526 = distinct !DISubprogram(name: "output::method::bell", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a6f75747075743a3a6d6574686f643a3a62656c6c__v1", scope: !4, file: !4, line: 288, type: !149, scopeLine: 288, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!527 = !DILocation(line: 289, column: 31, scope: !526)
!528 = !DILocation(line: 289, column: 17, scope: !526)
!529 = !DILocation(line: 289, column: 38, scope: !526)
!530 = !DILocation(line: 289, column: 54, scope: !526)
!531 = !DILocation(line: 289, column: 46, scope: !526)
!532 = !DILocation(line: 289, column: 12, scope: !526)
!533 = distinct !DISubprogram(name: "terminal_session::method::close", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a636c6f7365__v1", scope: !4, file: !4, line: 296, type: !534, scopeLine: 296, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!534 = !DISubroutineType(types: !535)
!535 = !{!151, !536}
!536 = !DIDerivedType(tag: DW_TAG_reference_type, baseType: !10, size: 64, align: 64)
!537 = !DILocation(line: 297, column: 35, scope: !533)
!538 = !DILocation(line: 297, column: 17, scope: !533)
!539 = !DILocation(line: 297, column: 42, scope: !533)
!540 = !DILocation(line: 297, column: 56, scope: !533)
!541 = !DILocation(line: 297, column: 12, scope: !533)
!542 = distinct !DISubprogram(name: "terminal_session::method::deinit", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a6465696e6974__v1", scope: !4, file: !4, line: 299, type: !543, scopeLine: 299, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!543 = !DISubroutineType(types: !544)
!544 = !{null, !536}
!545 = !DILocation(line: 299, column: 30, scope: !542)
!546 = distinct !DISubprogram(name: "terminal_session::method::deinit", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e3a3a6d6574686f643a3a6465696e69743a3a24626f6479242f407374646c69622f636f6e736f6c652e766f69643a3a7465726d696e616c5f73657373696f6e__v1", scope: !4, file: !4, line: 299, type: !543, scopeLine: 299, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!547 = !DILocation(line: 300, column: 22, scope: !546)
!548 = !DILocation(line: 300, column: 5, scope: !546)
!549 = distinct !DISubprogram(name: "input::method::begin_mode", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a626567696e5f6d6f6465__v1", scope: !4, file: !4, line: 303, type: !550, scopeLine: 303, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!550 = !DISubroutineType(types: !551)
!551 = !{!552, !179, !33, !33, !33}
!552 = !DICompositeType(tag: DW_TAG_structure_type, name: "result</@stdlib/console.void::terminal_session, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 704, align: 64, elements: !553)
!553 = !{!15, !554, !109}
!554 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !10, size: 64, align: 64, offset: 64)
!555 = !DILocation(line: 305, column: 8, scope: !549)
!556 = !DILocation(line: 306, column: 9, scope: !549)
!557 = !DILocation(line: 307, column: 8, scope: !549)
!558 = !DILocation(line: 308, column: 9, scope: !549)
!559 = !DILocation(line: 309, column: 8, scope: !549)
!560 = !DILocation(line: 310, column: 9, scope: !549)
!561 = !DILocation(line: 313, column: 19, scope: !549)
!562 = !DILocation(line: 314, column: 16, scope: !549)
!563 = !DILocation(line: 303, column: 30, scope: !549)
!564 = !DILocation(line: 303, column: 49, scope: !549)
!565 = !DILocation(line: 303, column: 74, scope: !549)
!566 = !DILocation(line: 304, column: 9, scope: !549)
!567 = !DILocation(line: 306, column: 18, scope: !549)
!568 = !DILocation(line: 306, column: 15, scope: !549)
!569 = !DILocation(line: 308, column: 18, scope: !549)
!570 = !DILocation(line: 308, column: 15, scope: !549)
!571 = !DILocation(line: 310, column: 18, scope: !549)
!572 = !DILocation(line: 310, column: 15, scope: !549)
!573 = !DILocation(line: 311, column: 45, scope: !549)
!574 = !DILocation(line: 311, column: 19, scope: !549)
!575 = !DILocation(line: 311, column: 9, scope: !549)
!576 = !DILocation(line: 312, column: 31, scope: !549)
!577 = !DILocation(line: 312, column: 37, scope: !549)
!578 = !DILocation(line: 312, column: 17, scope: !549)
!579 = !DILocation(line: 312, column: 9, scope: !549)
!580 = !DILocation(line: 313, column: 8, scope: !549)
!581 = !DILocation(line: 313, column: 14, scope: !549)
!582 = !DILocation(line: 314, column: 27, scope: !549)
!583 = !DILocation(line: 314, column: 34, scope: !549)
!584 = !DILocation(line: 314, column: 48, scope: !549)
!585 = !DILocation(line: 314, column: 20, scope: !549)
!586 = !DILocation(line: 315, column: 5, scope: !549)
!587 = !DILocation(line: 315, column: 22, scope: !549)
!588 = !DILocation(line: 315, column: 28, scope: !549)
!589 = !DILocation(line: 316, column: 15, scope: !549)
!590 = !DILocation(line: 316, column: 12, scope: !549)
!591 = distinct !DISubprogram(name: "_key", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a5f6b6579__v1", scope: !4, file: !4, line: 360, type: !592, scopeLine: 360, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!592 = !DISubroutineType(types: !593)
!593 = !{!594, !18}
!594 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::key", scope: !1, file: !1, size: 32, align: 32, elements: !14)
!595 = !DILocation(line: 361, column: 13, scope: !591)
!596 = !DILocation(line: 362, column: 20, scope: !591)
!597 = !DILocation(line: 363, column: 13, scope: !591)
!598 = !DILocation(line: 364, column: 20, scope: !591)
!599 = !DILocation(line: 365, column: 13, scope: !591)
!600 = !DILocation(line: 366, column: 20, scope: !591)
!601 = !DILocation(line: 367, column: 13, scope: !591)
!602 = !DILocation(line: 368, column: 20, scope: !591)
!603 = !DILocation(line: 369, column: 13, scope: !591)
!604 = !DILocation(line: 370, column: 20, scope: !591)
!605 = !DILocation(line: 371, column: 13, scope: !591)
!606 = !DILocation(line: 372, column: 20, scope: !591)
!607 = !DILocation(line: 373, column: 13, scope: !591)
!608 = !DILocation(line: 374, column: 20, scope: !591)
!609 = !DILocation(line: 375, column: 13, scope: !591)
!610 = !DILocation(line: 376, column: 20, scope: !591)
!611 = !DILocation(line: 377, column: 13, scope: !591)
!612 = !DILocation(line: 378, column: 20, scope: !591)
!613 = !DILocation(line: 379, column: 13, scope: !591)
!614 = !DILocation(line: 380, column: 20, scope: !591)
!615 = !DILocation(line: 381, column: 13, scope: !591)
!616 = !DILocation(line: 382, column: 20, scope: !591)
!617 = !DILocation(line: 383, column: 13, scope: !591)
!618 = !DILocation(line: 384, column: 20, scope: !591)
!619 = !DILocation(line: 385, column: 13, scope: !591)
!620 = !DILocation(line: 386, column: 20, scope: !591)
!621 = !DILocation(line: 387, column: 13, scope: !591)
!622 = !DILocation(line: 388, column: 20, scope: !591)
!623 = !DILocation(line: 389, column: 13, scope: !591)
!624 = !DILocation(line: 390, column: 20, scope: !591)
!625 = !DILocation(line: 391, column: 13, scope: !591)
!626 = !DILocation(line: 392, column: 20, scope: !591)
!627 = !DILocation(line: 393, column: 13, scope: !591)
!628 = !DILocation(line: 394, column: 20, scope: !591)
!629 = !DILocation(line: 395, column: 13, scope: !591)
!630 = !DILocation(line: 396, column: 20, scope: !591)
!631 = !DILocation(line: 397, column: 13, scope: !591)
!632 = !DILocation(line: 398, column: 20, scope: !591)
!633 = !DILocation(line: 399, column: 13, scope: !591)
!634 = !DILocation(line: 400, column: 20, scope: !591)
!635 = !DILocation(line: 401, column: 13, scope: !591)
!636 = !DILocation(line: 402, column: 20, scope: !591)
!637 = !DILocation(line: 403, column: 13, scope: !591)
!638 = !DILocation(line: 404, column: 20, scope: !591)
!639 = !DILocation(line: 405, column: 13, scope: !591)
!640 = !DILocation(line: 406, column: 20, scope: !591)
!641 = !DILocation(line: 407, column: 13, scope: !591)
!642 = !DILocation(line: 408, column: 20, scope: !591)
!643 = !DILocation(line: 409, column: 13, scope: !591)
!644 = !DILocation(line: 410, column: 20, scope: !591)
!645 = !DILocation(line: 411, column: 13, scope: !591)
!646 = !DILocation(line: 412, column: 20, scope: !591)
!647 = !DILocation(line: 413, column: 13, scope: !591)
!648 = !DILocation(line: 414, column: 20, scope: !591)
!649 = !DILocation(line: 415, column: 13, scope: !591)
!650 = !DILocation(line: 416, column: 20, scope: !591)
!651 = !DILocation(line: 360, column: 19, scope: !591)
!652 = !DILocation(line: 361, column: 8, scope: !591)
!653 = !DILocation(line: 363, column: 8, scope: !591)
!654 = !DILocation(line: 365, column: 8, scope: !591)
!655 = !DILocation(line: 367, column: 8, scope: !591)
!656 = !DILocation(line: 369, column: 8, scope: !591)
!657 = !DILocation(line: 371, column: 8, scope: !591)
!658 = !DILocation(line: 373, column: 8, scope: !591)
!659 = !DILocation(line: 375, column: 8, scope: !591)
!660 = !DILocation(line: 377, column: 8, scope: !591)
!661 = !DILocation(line: 379, column: 8, scope: !591)
!662 = !DILocation(line: 381, column: 8, scope: !591)
!663 = !DILocation(line: 383, column: 8, scope: !591)
!664 = !DILocation(line: 385, column: 8, scope: !591)
!665 = !DILocation(line: 387, column: 8, scope: !591)
!666 = !DILocation(line: 389, column: 8, scope: !591)
!667 = !DILocation(line: 391, column: 8, scope: !591)
!668 = !DILocation(line: 393, column: 8, scope: !591)
!669 = !DILocation(line: 395, column: 8, scope: !591)
!670 = !DILocation(line: 397, column: 8, scope: !591)
!671 = !DILocation(line: 399, column: 8, scope: !591)
!672 = !DILocation(line: 401, column: 8, scope: !591)
!673 = !DILocation(line: 403, column: 8, scope: !591)
!674 = !DILocation(line: 405, column: 8, scope: !591)
!675 = !DILocation(line: 407, column: 8, scope: !591)
!676 = !DILocation(line: 409, column: 8, scope: !591)
!677 = !DILocation(line: 411, column: 8, scope: !591)
!678 = !DILocation(line: 413, column: 8, scope: !591)
!679 = !DILocation(line: 415, column: 8, scope: !591)
!680 = !DILocation(line: 417, column: 16, scope: !591)
!681 = distinct !DISubprogram(name: "input::method::read_key", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a726561645f6b6579__v1", scope: !4, file: !4, line: 420, type: !682, scopeLine: 420, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!682 = !DISubroutineType(types: !683)
!683 = !{!684, !179, !33, !18}
!684 = !DICompositeType(tag: DW_TAG_structure_type, name: "result</@stdlib/console.void::key_event, /@stdlib/console.void::io_error>", scope: !1, file: !1, size: 960, align: 64, elements: !685)
!685 = !{!15, !686, !699}
!686 = !DIDerivedType(tag: DW_TAG_member, name: "$ok", scope: !1, file: !1, baseType: !687, size: 320, align: 64, offset: 64)
!687 = !DICompositeType(tag: DW_TAG_structure_type, name: "/@stdlib/console.void::key_event", scope: !1, file: !1, size: 320, align: 64, elements: !688)
!688 = !{!689, !690, !691, !692, !693, !694, !695, !696, !697, !698}
!689 = !DIDerivedType(tag: DW_TAG_member, name: "character", scope: !1, file: !1, baseType: !10, size: 64, align: 64)
!690 = !DIDerivedType(tag: DW_TAG_member, name: "key", scope: !1, file: !1, baseType: !594, size: 32, align: 32, offset: 64)
!691 = !DIDerivedType(tag: DW_TAG_member, name: "shift", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 96)
!692 = !DIDerivedType(tag: DW_TAG_member, name: "alt", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 104)
!693 = !DIDerivedType(tag: DW_TAG_member, name: "control", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 112)
!694 = !DIDerivedType(tag: DW_TAG_member, name: "modifiers_known", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 120)
!695 = !DIDerivedType(tag: DW_TAG_member, name: "key_down_known", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 128)
!696 = !DIDerivedType(tag: DW_TAG_member, name: "key_down", scope: !1, file: !1, baseType: !33, size: 1, align: 8, offset: 136)
!697 = !DIDerivedType(tag: DW_TAG_member, name: "repeat_count", scope: !1, file: !1, baseType: !18, size: 64, align: 64, offset: 192)
!698 = !DIDerivedType(tag: DW_TAG_member, name: "bytes", scope: !1, file: !1, baseType: !22, size: 64, align: 64, offset: 256)
!699 = !DIDerivedType(tag: DW_TAG_member, name: "$err", scope: !1, file: !1, baseType: !7, size: 576, align: 64, offset: 384)
!700 = !DILocation(line: 422, column: 8, scope: !681)
!701 = !DILocation(line: 423, column: 9, scope: !681)
!702 = !DILocation(line: 425, column: 19, scope: !681)
!703 = !DILocation(line: 426, column: 16, scope: !681)
!704 = !DILocation(line: 420, column: 28, scope: !681)
!705 = !DILocation(line: 420, column: 48, scope: !681)
!706 = !DILocation(line: 421, column: 9, scope: !681)
!707 = !DILocation(line: 424, column: 30, scope: !681)
!708 = !DILocation(line: 424, column: 36, scope: !681)
!709 = !DILocation(line: 424, column: 42, scope: !681)
!710 = !DILocation(line: 424, column: 17, scope: !681)
!711 = !DILocation(line: 424, column: 9, scope: !681)
!712 = !DILocation(line: 425, column: 8, scope: !681)
!713 = !DILocation(line: 425, column: 14, scope: !681)
!714 = !DILocation(line: 426, column: 27, scope: !681)
!715 = !DILocation(line: 426, column: 34, scope: !681)
!716 = !DILocation(line: 426, column: 46, scope: !681)
!717 = !DILocation(line: 426, column: 20, scope: !681)
!718 = !DILocation(line: 427, column: 37, scope: !681)
!719 = !DILocation(line: 427, column: 43, scope: !681)
!720 = !DILocation(line: 427, column: 60, scope: !681)
!721 = !DILocation(line: 427, column: 66, scope: !681)
!722 = !DILocation(line: 427, column: 55, scope: !681)
!723 = !DILocation(line: 427, column: 88, scope: !681)
!724 = !DILocation(line: 427, column: 94, scope: !681)
!725 = !DILocation(line: 427, column: 102, scope: !681)
!726 = !DILocation(line: 427, column: 82, scope: !681)
!727 = !DILocation(line: 427, column: 118, scope: !681)
!728 = !DILocation(line: 427, column: 124, scope: !681)
!729 = !DILocation(line: 427, column: 132, scope: !681)
!730 = !DILocation(line: 427, column: 112, scope: !681)
!731 = !DILocation(line: 427, column: 152, scope: !681)
!732 = !DILocation(line: 427, column: 158, scope: !681)
!733 = !DILocation(line: 427, column: 166, scope: !681)
!734 = !DILocation(line: 427, column: 146, scope: !681)
!735 = !DILocation(line: 427, column: 194, scope: !681)
!736 = !DILocation(line: 427, column: 200, scope: !681)
!737 = !DILocation(line: 427, column: 208, scope: !681)
!738 = !DILocation(line: 427, column: 188, scope: !681)
!739 = !DILocation(line: 427, column: 235, scope: !681)
!740 = !DILocation(line: 427, column: 241, scope: !681)
!741 = !DILocation(line: 427, column: 249, scope: !681)
!742 = !DILocation(line: 427, column: 229, scope: !681)
!743 = !DILocation(line: 427, column: 271, scope: !681)
!744 = !DILocation(line: 427, column: 277, scope: !681)
!745 = !DILocation(line: 427, column: 285, scope: !681)
!746 = !DILocation(line: 427, column: 265, scope: !681)
!747 = !DILocation(line: 427, column: 305, scope: !681)
!748 = !DILocation(line: 427, column: 311, scope: !681)
!749 = !DILocation(line: 427, column: 318, scope: !681)
!750 = !DILocation(line: 427, column: 333, scope: !681)
!751 = !DILocation(line: 427, column: 339, scope: !681)
!752 = !DILocation(line: 427, column: 15, scope: !681)
!753 = !DILocation(line: 427, column: 12, scope: !681)
!754 = distinct !DISubprogram(name: "input::method::key_available", linkageName: "__vd_2f407374646c69622f636f6e736f6c652e766f69643a3a696e7075743a3a6d6574686f643a3a6b65795f617661696c61626c65__v1", scope: !4, file: !4, line: 430, type: !755, scopeLine: 430, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!755 = !DISubroutineType(types: !756)
!756 = !{!151, !179}
!757 = !DILocation(line: 432, column: 19, scope: !754)
!758 = !DILocation(line: 433, column: 16, scope: !754)
!759 = !DILocation(line: 431, column: 36, scope: !754)
!760 = !DILocation(line: 431, column: 17, scope: !754)
!761 = !DILocation(line: 431, column: 9, scope: !754)
!762 = !DILocation(line: 432, column: 8, scope: !754)
!763 = !DILocation(line: 432, column: 14, scope: !754)
!764 = !DILocation(line: 433, column: 27, scope: !754)
!765 = !DILocation(line: 433, column: 34, scope: !754)
!766 = !DILocation(line: 433, column: 51, scope: !754)
!767 = !DILocation(line: 433, column: 20, scope: !754)
!768 = !DILocation(line: 434, column: 15, scope: !754)
!769 = !DILocation(line: 434, column: 21, scope: !754)
!770 = !DILocation(line: 434, column: 27, scope: !754)
!771 = !DILocation(line: 434, column: 12, scope: !754)
!772 = distinct !DISubprogram(name: "entry", linkageName: "__vd_2f6d61696e2e766f69643a3a656e747279__v1", scope: !1, file: !1, line: 2, type: !773, scopeLine: 2, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!773 = !DISubroutineType(types: !774)
!774 = !{!16, !16}
!775 = !DILocation(line: 2, column: 12, scope: !772)
!776 = !DILocation(line: 3, column: 5, scope: !772)
!777 = !DILocation(line: 4, column: 11, scope: !772)
!778 = !DILocation(line: 4, column: 20, scope: !772)
!779 = !DILocation(line: 4, column: 23, scope: !772)
!780 = !DILocation(line: 4, column: 35, scope: !772)
!781 = !DILocation(line: 4, column: 46, scope: !772)
!782 = !DILocation(line: 4, column: 5, scope: !772)
!783 = !DILocation(line: 5, column: 11, scope: !772)
!784 = !DILocation(line: 5, column: 33, scope: !772)
!785 = !DILocation(line: 5, column: 47, scope: !772)
!786 = !DILocation(line: 5, column: 5, scope: !772)
!787 = !DILocation(line: 6, column: 12, scope: !772)
