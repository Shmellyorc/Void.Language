/tmp/void-health-phase-harness-1i3kr4z4/api: \
 /lib/x86_64-linux-gnu/Scrt1.o \
 /lib/x86_64-linux-gnu/crti.o \
 /usr/lib/gcc/x86_64-linux-gnu/16/crtbeginS.o \
 /home/shmellyorc/Documents/Void.Language/build/ci-official-release/CMakeFiles/voidc_objects.dir/examples/proof.cpp.o \
 /tmp/void-health-phase-harness-1i3kr4z4/phase.api-support.o \
 /home/shmellyorc/Documents/Void.Language/build/ci-official-release/CMakeFiles/void_llvm.dir/src/backend/llvm/native_cache.cpp.o \
 /tmp/void-health-phase-harness-1i3kr4z4/api.o \
 /home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_cache_identity.a \
 /home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_core.a \
 /home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_runtime.a \
 /home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_native_fixture.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOrcJIT.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMExecutionEngine.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMJITLink.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOrcTargetProcess.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOrcShared.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMWindowsDriver.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOption.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMRuntimeDyld.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMPasses.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCoroutines.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMHipStdPar.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMipo.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMFrontendOpenMP.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMFrontendOffloading.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMLinker.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMVectorize.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86CodeGen.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCFGuard.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMIRPrinter.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMInstrumentation.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAsmPrinter.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMGlobalISel.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMSelectionDAG.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCodeGen.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTarget.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBitWriter.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMObjCARCOpts.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMScalarOpts.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAggressiveInstCombine.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMInstCombine.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTransformUtils.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAnalysis.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMProfileData.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMSymbolize.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoPDB.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoMSF.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoBTF.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoDWARF.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMObject.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMIRReader.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBitReader.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAsmParser.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCore.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMRemarks.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBitstreamReader.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTextAPI.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86AsmParser.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMMCParser.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86Desc.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCodeGenTypes.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86Disassembler.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMMCDisassembler.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86Info.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMMC.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBinaryFormat.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTargetParser.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoCodeView.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMSupport.a \
 /lib/x86_64-linux-gnu/libdl.a \
 /home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDemangle.a \
 /lib/x86_64-linux-gnu/librt.a \
 /lib/x86_64-linux-gnu/libm.so \
 /usr/lib/x86_64-linux-gnu/libm.so.6 \
 /usr/lib/x86_64-linux-gnu/libmvec.so.1 \
 /usr/lib/x86_64-linux-gnu/libz.so \
 /usr/lib/x86_64-linux-gnu/libzstd.so \
 /usr/lib/gcc/x86_64-linux-gnu/16/libstdc++.so \
 /usr/lib/gcc/x86_64-linux-gnu/16/libgcc_s.so \
 /lib/x86_64-linux-gnu/libgcc_s.so.1 \
 /usr/lib/gcc/x86_64-linux-gnu/16/libgcc.a \
 /lib/x86_64-linux-gnu/libc.so \
 /usr/lib/x86_64-linux-gnu/libc.so.6 \
 /usr/lib/x86_64-linux-gnu/libc_nonshared.a \
 /lib64/ld-linux-x86-64.so.2 \
 /usr/lib/gcc/x86_64-linux-gnu/16/crtendS.o \
 /lib/x86_64-linux-gnu/crtn.o

/lib/x86_64-linux-gnu/Scrt1.o:

/lib/x86_64-linux-gnu/crti.o:

/usr/lib/gcc/x86_64-linux-gnu/16/crtbeginS.o:

/home/shmellyorc/Documents/Void.Language/build/ci-official-release/CMakeFiles/voidc_objects.dir/examples/proof.cpp.o:

/tmp/void-health-phase-harness-1i3kr4z4/phase.api-support.o:

/home/shmellyorc/Documents/Void.Language/build/ci-official-release/CMakeFiles/void_llvm.dir/src/backend/llvm/native_cache.cpp.o:

/tmp/void-health-phase-harness-1i3kr4z4/api.o:

/home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_cache_identity.a:

/home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_core.a:

/home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_runtime.a:

/home/shmellyorc/Documents/Void.Language/build/ci-official-release/libvoid_native_fixture.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOrcJIT.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMExecutionEngine.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMJITLink.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOrcTargetProcess.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOrcShared.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMWindowsDriver.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMOption.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMRuntimeDyld.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMPasses.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCoroutines.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMHipStdPar.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMipo.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMFrontendOpenMP.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMFrontendOffloading.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMLinker.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMVectorize.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86CodeGen.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCFGuard.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMIRPrinter.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMInstrumentation.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAsmPrinter.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMGlobalISel.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMSelectionDAG.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCodeGen.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTarget.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBitWriter.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMObjCARCOpts.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMScalarOpts.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAggressiveInstCombine.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMInstCombine.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTransformUtils.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAnalysis.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMProfileData.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMSymbolize.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoPDB.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoMSF.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoBTF.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoDWARF.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMObject.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMIRReader.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBitReader.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMAsmParser.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCore.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMRemarks.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBitstreamReader.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTextAPI.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86AsmParser.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMMCParser.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86Desc.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMCodeGenTypes.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86Disassembler.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMMCDisassembler.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMX86Info.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMMC.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMBinaryFormat.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMTargetParser.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDebugInfoCodeView.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMSupport.a:

/lib/x86_64-linux-gnu/libdl.a:

/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/lib/libLLVMDemangle.a:

/lib/x86_64-linux-gnu/librt.a:

/lib/x86_64-linux-gnu/libm.so:

/usr/lib/x86_64-linux-gnu/libm.so.6:

/usr/lib/x86_64-linux-gnu/libmvec.so.1:

/usr/lib/x86_64-linux-gnu/libz.so:

/usr/lib/x86_64-linux-gnu/libzstd.so:

/usr/lib/gcc/x86_64-linux-gnu/16/libstdc++.so:

/usr/lib/gcc/x86_64-linux-gnu/16/libgcc_s.so:

/lib/x86_64-linux-gnu/libgcc_s.so.1:

/usr/lib/gcc/x86_64-linux-gnu/16/libgcc.a:

/lib/x86_64-linux-gnu/libc.so:

/usr/lib/x86_64-linux-gnu/libc.so.6:

/usr/lib/x86_64-linux-gnu/libc_nonshared.a:

/lib64/ld-linux-x86-64.so.2:

/usr/lib/gcc/x86_64-linux-gnu/16/crtendS.o:

/lib/x86_64-linux-gnu/crtn.o:
