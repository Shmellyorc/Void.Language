from pathlib import Path
import os,json
from bench import measured,W
H=Path('/tmp/void-health-phase-harness-1i3kr4z4')
LLVM=Path('/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/bin')
os.environ['VOID_STDLIB_ROOT']='/home/shmellyorc/Documents/Void.Language/stdlib'
(W/'phases').mkdir(exist_ok=True)
for case in ('tiny','gameplay','dto8','dto16','dto32','dto64','dto128'):
    source=W/'fixtures'/case/'main.void';prefix=W/'phases'/case
    measured('dump-'+case,[H/'phase',source,prefix,'1'],source,timeout=180)
for case in ('tiny','gameplay','dto8'):
    for optimize in (0,1):
        source=W/'fixtures'/case/'main.void';prefix=W/'phases'/(case+'-api'+str(optimize))
        measured('api-'+case+'-'+str(optimize),[H/'api',source,prefix,str(optimize)],source,timeout=300)
for case in ('dto8','dto32','dto128'):
    target=dict(line.split('=',1) for line in (W/'phases'/(case+'.target.txt')).read_text().splitlines())
    for which,level in (('pre',0),('pre',2),('post',2)):
        source=W/'fixtures'/case/'main.void';ir=W/'phases'/(case+'.'+which+'.ll');obj=W/'phases'/(case+'.'+which+'.cg'+str(level)+'.o')
        measured('llc-'+case+'-'+which+'-'+str(level),[LLVM/'llc',ir,'-O='+str(level),'-filetype=obj','-relocation-model=pic','-mcpu='+target['cpu'],'-mattr='+target['features'],'-time-passes','-o',obj],source,timeout=480)
