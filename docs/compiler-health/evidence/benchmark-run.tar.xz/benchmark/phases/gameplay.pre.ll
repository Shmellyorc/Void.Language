; ModuleID = '/main.void'
source_filename = "/main.void"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%"/main.void::point" = type { double, double }

@async.generation = private constant i8 0
@0 = private unnamed_addr constant [18 x i8] c"/main.void::point\00", align 1
@1 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@2 = private unnamed_addr constant [75 x i8] c"16:8|1:x|17:/main.void::point|3:f64|1:0|1:y|17:/main.void::point|3:f64|1:8\00", align 1
@gc.offsets = private constant [0 x i64] zeroinitializer
@3 = private unnamed_addr constant [43 x i8] c"void.array.element.v1/12:/main.void::point\00", align 1
@__vd_types__research = constant [1 x { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 }] [{ ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @0, ptr @1, ptr @2, i64 16, ptr @gc.offsets, i64 0, ptr @3, i32 0 }]
@__vd_type_count__research = constant i64 1
@dynamic_type_keys = private constant [1 x ptr] [ptr @0]
@__vd_witnesses__research = constant [0 x { ptr, ptr, ptr, ptr }] zeroinitializer
@__vd_witness_count__research = constant i64 0
@interface_binding_keys = private constant [0 x ptr] zeroinitializer
@4 = private unnamed_addr constant [158 x i8] c"Called from /@stdlib/math.void::sqrt\0A/home/shmellyorc/Documents/Void.Language/stdlib/math.void:365:16: source call\0A        return _nan<t>()\0A               ^\0A\00", align 1
@5 = private unnamed_addr constant [151 x i8] c"Called from /@stdlib/math.void::sqrt\0A/home/shmellyorc/Documents/Void.Language/stdlib/math.void:366:8: source call\0A    if is_infinite(input):\0A       ^\0A\00", align 1
@6 = private unnamed_addr constant [171 x i8] c"Called from /@stdlib/math.void::clamp\0A/home/shmellyorc/Documents/Void.Language/stdlib/math.void:90:14: source call\0A    return t.clamp(value, lower, upper)\0A             ^\0A\00", align 1
@7 = private unnamed_addr constant [169 x i8] c"Called from /main.void::energy\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:6:14: source call\0A    return m.sqrt(p.x * p.x + p.y * p.y)\0A             ^\0A\00", align 1
@gc.offsets.1 = private constant [1 x i64] zeroinitializer
@gc.offsets.2 = private constant [1 x i64] zeroinitializer
@gc.offsets.3 = private constant [1 x i64] zeroinitializer
@gc.offsets.4 = private constant [1 x i64] zeroinitializer
@gc.offsets.5 = private constant [1 x i64] zeroinitializer
@gc.offsets.6 = private constant [1 x i64] zeroinitializer
@gc.offsets.7 = private constant [1 x i64] zeroinitializer
@gc.offsets.8 = private constant [1 x i64] zeroinitializer
@gc.offsets.9 = private constant [1 x i64] zeroinitializer
@gc.offsets.10 = private constant [1 x i64] zeroinitializer
@gc.offsets.11 = private constant [1 x i64] zeroinitializer
@gc.offsets.12 = private constant [1 x i64] zeroinitializer
@gc.offsets.13 = private constant [1 x i64] zeroinitializer
@gc.offsets.14 = private constant [1 x i64] zeroinitializer
@gc.offsets.15 = private constant [1 x i64] zeroinitializer
@gc.offsets.16 = private constant [1 x i64] zeroinitializer
@gc.offsets.17 = private constant [1 x i64] zeroinitializer
@gc.offsets.18 = private constant [1 x i64] zeroinitializer
@gc.offsets.19 = private constant [1 x i64] zeroinitializer
@8 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@9 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@array.element.fields = private constant [2 x { ptr, i64, i64, i32, i32 }] [{ ptr, i64, i64, i32, i32 } { ptr @8, i64 0, i64 0, i32 9, i32 0 }, { ptr, i64, i64, i32, i32 } { ptr @9, i64 8, i64 0, i32 9, i32 0 }]
@10 = private unnamed_addr constant [43 x i8] c"void.array.element.v1/12:/main.void::point\00", align 1
@array.element = private constant { ptr, i64, i64, i64, ptr } { ptr @10, i64 16, i64 8, i64 2, ptr @array.element.fields }
@11 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:8:27: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@12 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:8:27: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@13 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:8:27: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@14 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@15 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@16 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@17 = private unnamed_addr constant [158 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: List structurally modified during iteration\0AIn function /main.void::main\0A\00", align 1
@18 = private unnamed_addr constant [164 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0A    for p in points:\0A    ^\0AIn function /main.void::main\0A\00", align 1
@19 = private unnamed_addr constant [167 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: List index outside extent\0A    for p in points:\0A    ^\0AIn function /main.void::main\0A\00", align 1
@20 = private unnamed_addr constant [164 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0A    for p in points:\0A    ^\0AIn function /main.void::main\0A\00", align 1
@21 = private unnamed_addr constant [183 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:11:26: source call\0A        total += m.clamp(energy(p), 0, 100)\0A                         ^\0A\00", align 1
@22 = private unnamed_addr constant [177 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:11:20: source call\0A        total += m.clamp(energy(p), 0, 100)\0A                   ^\0A\00", align 1
@23 = private unnamed_addr constant [169 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:11: runtime error: Display operation failed\0A    print(total)\0A          ^\0AIn function /main.void::main\0A\00", align 1
@24 = private unnamed_addr constant [2 x i8] c" \00", align 1
@25 = private unnamed_addr constant [161 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: runtime error: String operation failed\0A    print(total)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@26 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@27 = private unnamed_addr constant [161 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: runtime error: String operation failed\0A    print(total)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@28 = private unnamed_addr constant [158 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: runtime error: Interpolation failed\0A    print(total)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@29 = private unnamed_addr constant [134 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: source call\0A    print(total)\0A    ^\0A\00", align 1
@30 = private unnamed_addr constant [118 x i8] c"Called from /main.void::$app_adapter\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:7:6: source call\0A\00", align 1
@31 = private unnamed_addr constant [147 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/math.void:90:14: runtime error: Clamp bounds are reversed or NaN\0AIn function $numeric::f64::clamp\0A\00", align 1

define double @__vd_2f407374646c69622f6d6174682e766f69643a3a737172743c333a31313a3e__research(double %0, ptr %1) !dbg !3 {
block0:
  %2 = alloca double, align 8
  store double 0.000000e+00, ptr %2, align 8
  %3 = alloca double, align 8
  store double 0.000000e+00, ptr %3, align 8
  %4 = alloca double, align 8
  store double 0.000000e+00, ptr %4, align 8
  %5 = alloca double, align 8
  store double 0.000000e+00, ptr %5, align 8
  %6 = alloca double, align 8
  store double 0.000000e+00, ptr %6, align 8
  %7 = alloca double, align 8
  store double 0.000000e+00, ptr %7, align 8
  %8 = alloca double, align 8
  store double 0.000000e+00, ptr %8, align 8
  %9 = alloca double, align 8
  store double 0.000000e+00, ptr %9, align 8
  %10 = alloca double, align 8
  store double 0.000000e+00, ptr %10, align 8
  %11 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %12 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %12, ptr %11, i64 0)
  call void @vd_gc_poll()
  %13 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %13, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue8, %worker.continue
  call void @vd_gc_poll(), !dbg !8
  %14 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !8
  br i1 %14, label %worker.cancelled1, label %worker.continue2, !dbg !8

block2:                                           ; preds = %worker.continue8
  call void @vd_gc_poll(), !dbg !9
  %15 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !9
  br i1 %15, label %worker.cancelled3, label %worker.continue4, !dbg !9

block3:                                           ; preds = %worker.continue4
  call void @vd_gc_poll(), !dbg !9
  %16 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !9
  br i1 %16, label %worker.cancelled5, label %worker.continue6, !dbg !9

block4:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !10
  %17 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !10
  br i1 %17, label %worker.cancelled7, label %worker.continue8, !dbg !10

block5:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !11
  %18 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !11
  br i1 %18, label %worker.cancelled9, label %worker.continue10, !dbg !11

block6:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !12
  %19 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !12
  br i1 %19, label %worker.cancelled11, label %worker.continue12, !dbg !12

block7:                                           ; preds = %worker.continue12
  call void @vd_gc_poll(), !dbg !12
  %20 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !12
  br i1 %20, label %worker.cancelled13, label %worker.continue14, !dbg !12

block8:                                           ; preds = %call_success16
  call void @vd_gc_poll(), !dbg !13
  %21 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !13
  br i1 %21, label %worker.cancelled20, label %worker.continue21, !dbg !13

block9:                                           ; preds = %call_success16
  call void @vd_gc_poll(), !dbg !14
  %22 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !14
  br i1 %22, label %worker.cancelled22, label %worker.continue23, !dbg !14

block10:                                          ; preds = %worker.continue23
  call void @vd_gc_poll(), !dbg !14
  %23 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !14
  br i1 %23, label %worker.cancelled24, label %worker.continue25, !dbg !14

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %12)
  ret double 0.000000e+00

worker.continue:                                  ; preds = %block0
  store double %0, ptr %2, align 8, !dbg !15
  %24 = load double, ptr %2, align 8, !dbg !16
  store double %24, ptr %5, align 8, !dbg !16
  %25 = load double, ptr %5, align 8, !dbg !17
  store double %25, ptr %3, align 8, !dbg !18
  store double 0.000000e+00, ptr %4, align 8, !dbg !19
  %26 = load double, ptr %3, align 8, !dbg !20
  store double %26, ptr %6, align 8, !dbg !8
  %27 = load double, ptr %3, align 8, !dbg !21
  %28 = load double, ptr %6, align 8, !dbg !8
  %29 = fcmp une double %28, %27, !dbg !8
  br i1 %29, label %block1, label %block4, !dbg !8

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %12), !dbg !8
  ret double 0.000000e+00, !dbg !8

worker.continue2:                                 ; preds = %block1
  %30 = load double, ptr %3, align 8, !dbg !9
  call void @vd_gc_frame_leave(ptr %12), !dbg !9
  ret double %30, !dbg !9

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %12), !dbg !9
  ret double 0.000000e+00, !dbg !9

worker.continue4:                                 ; preds = %block2
  br label %block3, !dbg !9

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %12), !dbg !9
  ret double 0.000000e+00, !dbg !9

worker.continue6:                                 ; preds = %block3
  %31 = load double, ptr %3, align 8, !dbg !22
  store double %31, ptr %8, align 8, !dbg !10
  %32 = load double, ptr %4, align 8, !dbg !23
  %33 = load double, ptr %8, align 8, !dbg !10
  %34 = fcmp olt double %33, %32, !dbg !10
  br i1 %34, label %block5, label %block6, !dbg !10

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %12), !dbg !10
  ret double 0.000000e+00, !dbg !10

worker.continue8:                                 ; preds = %block4
  %35 = load double, ptr %3, align 8, !dbg !24
  store double %35, ptr %7, align 8, !dbg !11
  %36 = load double, ptr %4, align 8, !dbg !25
  %37 = load double, ptr %7, align 8, !dbg !11
  %38 = fcmp oeq double %37, %36, !dbg !11
  br i1 %38, label %block1, label %block2, !dbg !11

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr %12), !dbg !11
  ret double 0.000000e+00, !dbg !11

worker.continue10:                                ; preds = %block5
  %39 = call double @__vd_2f407374646c69622f6d6174682e766f69643a3a5f6e616e3c333a31313a3e__research(ptr %1), !dbg !12
  %40 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !12
  %41 = load ptr, ptr %40, align 8, !dbg !12
  %42 = icmp ne ptr %41, null, !dbg !12
  br i1 %42, label %propagate_error, label %call_success, !dbg !12

propagate_error:                                  ; preds = %worker.continue10
  %43 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !12
  %44 = load i32, ptr %43, align 4, !dbg !12
  %45 = icmp ult i32 %44, 32, !dbg !12
  br i1 %45, label %trace_caller, label %trace_limit, !dbg !12

call_success:                                     ; preds = %worker.continue10
  call void @vd_gc_frame_leave(ptr %12), !dbg !12
  ret double %39, !dbg !12

trace_caller:                                     ; preds = %propagate_error
  %46 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !12
  %47 = getelementptr [32 x ptr], ptr %46, i32 0, i32 %44, !dbg !12
  store ptr @4, ptr %47, align 8, !dbg !12
  %48 = add i32 %44, 1, !dbg !12
  store i32 %48, ptr %43, align 4, !dbg !12
  br label %error_return, !dbg !12

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %12), !dbg !12
  ret double 0.000000e+00, !dbg !12

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %43, align 4, !dbg !12
  br label %error_return, !dbg !12

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %12), !dbg !12
  ret double 0.000000e+00, !dbg !12

worker.continue12:                                ; preds = %block6
  br label %block7, !dbg !12

worker.cancelled13:                               ; preds = %block7
  call void @vd_gc_frame_leave(ptr %12), !dbg !12
  ret double 0.000000e+00, !dbg !12

worker.continue14:                                ; preds = %block7
  %49 = load double, ptr %3, align 8, !dbg !26
  store double %49, ptr %9, align 8, !dbg !26
  %50 = load double, ptr %9, align 8, !dbg !13
  %51 = call i1 @__vd_2f407374646c69622f6d6174682e766f69643a3a69735f696e66696e6974653c333a31313a3e__research(double %50, ptr %1), !dbg !13
  %52 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !13
  %53 = load ptr, ptr %52, align 8, !dbg !13
  %54 = icmp ne ptr %53, null, !dbg !13
  br i1 %54, label %propagate_error15, label %call_success16, !dbg !13

propagate_error15:                                ; preds = %worker.continue14
  %55 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !13
  %56 = load i32, ptr %55, align 4, !dbg !13
  %57 = icmp ult i32 %56, 32, !dbg !13
  br i1 %57, label %trace_caller17, label %trace_limit19, !dbg !13

call_success16:                                   ; preds = %worker.continue14
  br i1 %51, label %block8, label %block9, !dbg !13

trace_caller17:                                   ; preds = %propagate_error15
  %58 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !13
  %59 = getelementptr [32 x ptr], ptr %58, i32 0, i32 %56, !dbg !13
  store ptr @5, ptr %59, align 8, !dbg !13
  %60 = add i32 %56, 1, !dbg !13
  store i32 %60, ptr %55, align 4, !dbg !13
  br label %error_return18, !dbg !13

error_return18:                                   ; preds = %trace_caller17, %trace_limit19
  call void @vd_gc_frame_leave(ptr %12), !dbg !13
  ret double 0.000000e+00, !dbg !13

trace_limit19:                                    ; preds = %propagate_error15
  store i32 33, ptr %55, align 4, !dbg !13
  br label %error_return18, !dbg !13

worker.cancelled20:                               ; preds = %block8
  call void @vd_gc_frame_leave(ptr %12), !dbg !13
  ret double 0.000000e+00, !dbg !13

worker.continue21:                                ; preds = %block8
  %61 = load double, ptr %3, align 8, !dbg !14
  call void @vd_gc_frame_leave(ptr %12), !dbg !14
  ret double %61, !dbg !14

worker.cancelled22:                               ; preds = %block9
  call void @vd_gc_frame_leave(ptr %12), !dbg !14
  ret double 0.000000e+00, !dbg !14

worker.continue23:                                ; preds = %block9
  br label %block10, !dbg !14

worker.cancelled24:                               ; preds = %block10
  call void @vd_gc_frame_leave(ptr %12), !dbg !14
  ret double 0.000000e+00, !dbg !14

worker.continue25:                                ; preds = %block10
  %62 = load double, ptr %3, align 8, !dbg !27
  store double %62, ptr %10, align 8, !dbg !27
  %63 = load double, ptr %10, align 8, !dbg !28
  %64 = call double @llvm.sqrt.f64(double %63), !dbg !28
  call void @vd_gc_frame_leave(ptr %12), !dbg !28
  ret double %64, !dbg !28
}

define double @__vd_2f407374646c69622f6d6174682e766f69643a3a636c616d703c333a31313a3e__research(double %0, double %1, double %2, ptr %3) !dbg !29 {
block0:
  %4 = alloca double, align 8
  store double 0.000000e+00, ptr %4, align 8
  %5 = alloca double, align 8
  store double 0.000000e+00, ptr %5, align 8
  %6 = alloca double, align 8
  store double 0.000000e+00, ptr %6, align 8
  %7 = alloca double, align 8
  store double 0.000000e+00, ptr %7, align 8
  %8 = alloca double, align 8
  store double 0.000000e+00, ptr %8, align 8
  %9 = alloca double, align 8
  store double 0.000000e+00, ptr %9, align 8
  %10 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %11 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %11, ptr %10, i64 0)
  call void @vd_gc_poll()
  %12 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %12, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %11)
  ret double 0.000000e+00

worker.continue:                                  ; preds = %block0
  store double %0, ptr %4, align 8, !dbg !32
  store double %1, ptr %5, align 8, !dbg !33
  store double %2, ptr %6, align 8, !dbg !34
  %13 = load double, ptr %4, align 8, !dbg !35
  store double %13, ptr %7, align 8, !dbg !35
  %14 = load double, ptr %5, align 8, !dbg !36
  store double %14, ptr %8, align 8, !dbg !36
  %15 = load double, ptr %6, align 8, !dbg !37
  store double %15, ptr %9, align 8, !dbg !37
  %16 = load double, ptr %7, align 8, !dbg !38
  %17 = load double, ptr %8, align 8, !dbg !38
  %18 = load double, ptr %9, align 8, !dbg !38
  %19 = call double @__vd_246e756d657269633a3a6636343a3a636c616d70__research(double %16, double %17, double %18, ptr %3), !dbg !38
  %20 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !38
  %21 = load ptr, ptr %20, align 8, !dbg !38
  %22 = icmp ne ptr %21, null, !dbg !38
  br i1 %22, label %propagate_error, label %call_success, !dbg !38

propagate_error:                                  ; preds = %worker.continue
  %23 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 1, !dbg !38
  %24 = load i32, ptr %23, align 4, !dbg !38
  %25 = icmp ult i32 %24, 32, !dbg !38
  br i1 %25, label %trace_caller, label %trace_limit, !dbg !38

call_success:                                     ; preds = %worker.continue
  call void @vd_gc_frame_leave(ptr %11), !dbg !38
  ret double %19, !dbg !38

trace_caller:                                     ; preds = %propagate_error
  %26 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 2, !dbg !38
  %27 = getelementptr [32 x ptr], ptr %26, i32 0, i32 %24, !dbg !38
  store ptr @6, ptr %27, align 8, !dbg !38
  %28 = add i32 %24, 1, !dbg !38
  store i32 %28, ptr %23, align 4, !dbg !38
  br label %error_return, !dbg !38

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %11), !dbg !38
  ret double 0.000000e+00, !dbg !38

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %23, align 4, !dbg !38
  br label %error_return, !dbg !38
}

define internal double @__vd_2f407374646c69622f6d6174682e766f69643a3a5f6e616e3c333a31313a3e__research(ptr %0) !dbg !39 {
block0:
  %1 = alloca double, align 8
  store double 0.000000e+00, ptr %1, align 8
  %2 = alloca double, align 8
  store double 0.000000e+00, ptr %2, align 8
  %3 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %4 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %4, ptr %3, i64 0)
  call void @vd_gc_poll()
  %5 = call i1 @vd_worker_checkpoint(ptr %0)
  br i1 %5, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %4)
  ret double 0.000000e+00

worker.continue:                                  ; preds = %block0
  store double 0.000000e+00, ptr %1, align 8, !dbg !42
  %6 = load double, ptr %1, align 8, !dbg !43
  store double %6, ptr %2, align 8, !dbg !44
  %7 = load double, ptr %1, align 8, !dbg !45
  %8 = load double, ptr %2, align 8, !dbg !44
  %9 = fdiv double %8, %7, !dbg !44
  call void @vd_gc_frame_leave(ptr %4), !dbg !44
  ret double %9, !dbg !44
}

define i1 @__vd_2f407374646c69622f6d6174682e766f69643a3a69735f696e66696e6974653c333a31313a3e__research(double %0, ptr %1) !dbg !46 {
block0:
  %2 = alloca double, align 8
  store double 0.000000e+00, ptr %2, align 8
  %3 = alloca double, align 8
  store double 0.000000e+00, ptr %3, align 8
  %4 = alloca double, align 8
  store double 0.000000e+00, ptr %4, align 8
  %5 = alloca double, align 8
  store double 0.000000e+00, ptr %5, align 8
  %6 = alloca i1, align 1
  store i1 false, ptr %6, align 1
  %7 = alloca double, align 8
  store double 0.000000e+00, ptr %7, align 8
  %8 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %9 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %9, ptr %8, i64 0)
  call void @vd_gc_poll()
  %10 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %10, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !50
  %11 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !50
  br i1 %11, label %worker.cancelled1, label %worker.continue2, !dbg !50

block2:                                           ; preds = %worker.continue2, %worker.continue
  call void @vd_gc_poll(), !dbg !50
  %12 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !50
  br i1 %12, label %worker.cancelled3, label %worker.continue4, !dbg !50

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %9)
  ret i1 false

worker.continue:                                  ; preds = %block0
  store double %0, ptr %2, align 8, !dbg !51
  %13 = load double, ptr %2, align 8, !dbg !52
  store double %13, ptr %4, align 8, !dbg !52
  %14 = load double, ptr %4, align 8, !dbg !53
  store double %14, ptr %3, align 8, !dbg !54
  %15 = load double, ptr %3, align 8, !dbg !55
  store double %15, ptr %5, align 8, !dbg !56
  %16 = load double, ptr %5, align 8, !dbg !56
  %17 = fcmp olt double %16, 0xFFEFFFFFFFFFFFFF, !dbg !56
  store i1 %17, ptr %6, align 1, !dbg !50
  br i1 %17, label %block2, label %block1, !dbg !50

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %9), !dbg !50
  ret i1 false, !dbg !50

worker.continue2:                                 ; preds = %block1
  %18 = load double, ptr %3, align 8, !dbg !57
  store double %18, ptr %7, align 8, !dbg !58
  %19 = load double, ptr %7, align 8, !dbg !58
  %20 = fcmp ogt double %19, 0x7FEFFFFFFFFFFFFF, !dbg !58
  store i1 %20, ptr %6, align 1, !dbg !50
  br label %block2, !dbg !50

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %9), !dbg !50
  ret i1 false, !dbg !50

worker.continue4:                                 ; preds = %block2
  %21 = load i1, ptr %6, align 1, !dbg !50
  call void @vd_gc_frame_leave(ptr %9), !dbg !50
  ret i1 %21, !dbg !50
}

define double @__vd_2f6d61696e2e766f69643a3a656e65726779__research(%"/main.void::point" %0, ptr %1) !dbg !59 {
block0:
  %2 = alloca %"/main.void::point", align 8
  store %"/main.void::point" zeroinitializer, ptr %2, align 8
  %3 = alloca double, align 8
  store double 0.000000e+00, ptr %3, align 8
  %4 = alloca double, align 8
  store double 0.000000e+00, ptr %4, align 8
  %5 = alloca double, align 8
  store double 0.000000e+00, ptr %5, align 8
  %6 = alloca double, align 8
  store double 0.000000e+00, ptr %6, align 8
  %7 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %8 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %8, ptr %7, i64 0)
  call void @vd_gc_poll()
  %9 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %9, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %8)
  ret double 0.000000e+00

worker.continue:                                  ; preds = %block0
  store %"/main.void::point" %0, ptr %2, align 8, !dbg !66
  %10 = load %"/main.void::point", ptr %2, align 8, !dbg !67
  %11 = extractvalue %"/main.void::point" %10, 0, !dbg !68
  store double %11, ptr %4, align 8, !dbg !69
  %12 = load %"/main.void::point", ptr %2, align 8, !dbg !70
  %13 = extractvalue %"/main.void::point" %12, 0, !dbg !71
  %14 = load double, ptr %4, align 8, !dbg !69
  %15 = fmul double %14, %13, !dbg !69
  store double %15, ptr %5, align 8, !dbg !72
  %16 = load %"/main.void::point", ptr %2, align 8, !dbg !73
  %17 = extractvalue %"/main.void::point" %16, 1, !dbg !74
  store double %17, ptr %6, align 8, !dbg !75
  %18 = load %"/main.void::point", ptr %2, align 8, !dbg !76
  %19 = extractvalue %"/main.void::point" %18, 1, !dbg !77
  %20 = load double, ptr %6, align 8, !dbg !75
  %21 = fmul double %20, %19, !dbg !75
  %22 = load double, ptr %5, align 8, !dbg !72
  %23 = fadd double %22, %21, !dbg !72
  store double %23, ptr %3, align 8, !dbg !72
  %24 = load double, ptr %3, align 8, !dbg !78
  %25 = call double @__vd_2f407374646c69622f6d6174682e766f69643a3a737172743c333a31313a3e__research(double %24, ptr %1), !dbg !78
  %26 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !78
  %27 = load ptr, ptr %26, align 8, !dbg !78
  %28 = icmp ne ptr %27, null, !dbg !78
  br i1 %28, label %propagate_error, label %call_success, !dbg !78

propagate_error:                                  ; preds = %worker.continue
  %29 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !78
  %30 = load i32, ptr %29, align 4, !dbg !78
  %31 = icmp ult i32 %30, 32, !dbg !78
  br i1 %31, label %trace_caller, label %trace_limit, !dbg !78

call_success:                                     ; preds = %worker.continue
  call void @vd_gc_frame_leave(ptr %8), !dbg !78
  ret double %25, !dbg !78

trace_caller:                                     ; preds = %propagate_error
  %32 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !78
  %33 = getelementptr [32 x ptr], ptr %32, i32 0, i32 %30, !dbg !78
  store ptr @7, ptr %33, align 8, !dbg !78
  %34 = add i32 %30, 1, !dbg !78
  store i32 %34, ptr %29, align 4, !dbg !78
  br label %error_return, !dbg !78

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %8), !dbg !78
  ret double 0.000000e+00, !dbg !78

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %29, align 4, !dbg !78
  br label %error_return, !dbg !78
}

define void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %0) !dbg !79 {
block0:
  %1 = alloca [2 x ptr], align 8
  %2 = alloca ptr, align 8
  store ptr null, ptr %2, align 8
  %3 = alloca double, align 8
  store double 0.000000e+00, ptr %3, align 8
  %4 = alloca %"/main.void::point", align 8
  store %"/main.void::point" zeroinitializer, ptr %4, align 8
  %5 = alloca double, align 8
  store double 0.000000e+00, ptr %5, align 8
  %6 = alloca double, align 8
  store double 0.000000e+00, ptr %6, align 8
  %7 = alloca double, align 8
  store double 0.000000e+00, ptr %7, align 8
  %8 = alloca double, align 8
  store double 0.000000e+00, ptr %8, align 8
  %9 = alloca %"/main.void::point", align 8
  store %"/main.void::point" zeroinitializer, ptr %9, align 8
  %10 = alloca double, align 8
  store double 0.000000e+00, ptr %10, align 8
  %11 = alloca double, align 8
  store double 0.000000e+00, ptr %11, align 8
  %12 = alloca double, align 8
  store double 0.000000e+00, ptr %12, align 8
  %13 = alloca double, align 8
  store double 0.000000e+00, ptr %13, align 8
  %14 = alloca %"/main.void::point", align 8
  store %"/main.void::point" zeroinitializer, ptr %14, align 8
  %15 = alloca ptr, align 8
  store ptr null, ptr %15, align 8
  %16 = alloca i64, align 8
  store i64 0, ptr %16, align 8
  %17 = alloca i64, align 8
  store i64 0, ptr %17, align 8
  %18 = alloca i64, align 8
  store i64 0, ptr %18, align 8
  %19 = alloca i64, align 8
  store i64 0, ptr %19, align 8
  %20 = alloca i1, align 1
  store i1 false, ptr %20, align 1
  %21 = alloca double, align 8
  store double 0.000000e+00, ptr %21, align 8
  %22 = alloca double, align 8
  store double 0.000000e+00, ptr %22, align 8
  %23 = alloca %"/main.void::point", align 8
  store %"/main.void::point" zeroinitializer, ptr %23, align 8
  %24 = alloca double, align 8
  store double 0.000000e+00, ptr %24, align 8
  %25 = alloca double, align 8
  store double 0.000000e+00, ptr %25, align 8
  %26 = alloca double, align 8
  store double 0.000000e+00, ptr %26, align 8
  %27 = alloca double, align 8
  store double 0.000000e+00, ptr %27, align 8
  %28 = alloca ptr, align 8
  store ptr null, ptr %28, align 8
  %29 = alloca ptr, align 8
  store ptr null, ptr %29, align 8
  %30 = alloca ptr, align 8
  store ptr null, ptr %30, align 8
  %31 = alloca %"/main.void::point", align 8
  store %"/main.void::point" zeroinitializer, ptr %31, align 8
  %32 = alloca ptr, align 8
  store ptr null, ptr %32, align 8
  %33 = alloca i64, align 8
  %34 = alloca ptr, align 8
  store ptr null, ptr %34, align 8
  %35 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %2, 0
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, i64 8, 1
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, ptr @gc.offsets.1, 2
  %38 = insertvalue { ptr, i64, ptr, i64 } %37, i64 1, 3
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %15, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 8, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.2, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 1, 3
  %43 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %28, 0
  %44 = insertvalue { ptr, i64, ptr, i64 } %43, i64 8, 1
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, ptr @gc.offsets.3, 2
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, i64 1, 3
  %47 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %29, 0
  %48 = insertvalue { ptr, i64, ptr, i64 } %47, i64 8, 1
  %49 = insertvalue { ptr, i64, ptr, i64 } %48, ptr @gc.offsets.4, 2
  %50 = insertvalue { ptr, i64, ptr, i64 } %49, i64 1, 3
  %51 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %30, 0
  %52 = insertvalue { ptr, i64, ptr, i64 } %51, i64 8, 1
  %53 = insertvalue { ptr, i64, ptr, i64 } %52, ptr @gc.offsets.5, 2
  %54 = insertvalue { ptr, i64, ptr, i64 } %53, i64 1, 3
  %55 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %34, 0
  %56 = insertvalue { ptr, i64, ptr, i64 } %55, i64 8, 1
  %57 = insertvalue { ptr, i64, ptr, i64 } %56, ptr @gc.offsets.6, 2
  %58 = insertvalue { ptr, i64, ptr, i64 } %57, i64 1, 3
  %59 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %32, 0
  %60 = insertvalue { ptr, i64, ptr, i64 } %59, i64 8, 1
  %61 = insertvalue { ptr, i64, ptr, i64 } %60, ptr @gc.offsets.7, 2
  %62 = insertvalue { ptr, i64, ptr, i64 } %61, i64 1, 3
  %63 = alloca ptr, align 8
  store ptr null, ptr %63, align 8
  %64 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %63, 0
  %65 = insertvalue { ptr, i64, ptr, i64 } %64, i64 8, 1
  %66 = insertvalue { ptr, i64, ptr, i64 } %65, ptr @gc.offsets.8, 2
  %67 = insertvalue { ptr, i64, ptr, i64 } %66, i64 1, 3
  %68 = alloca ptr, align 8
  store ptr null, ptr %68, align 8
  %69 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %68, 0
  %70 = insertvalue { ptr, i64, ptr, i64 } %69, i64 8, 1
  %71 = insertvalue { ptr, i64, ptr, i64 } %70, ptr @gc.offsets.9, 2
  %72 = insertvalue { ptr, i64, ptr, i64 } %71, i64 1, 3
  %73 = alloca ptr, align 8
  store ptr null, ptr %73, align 8
  %74 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %73, 0
  %75 = insertvalue { ptr, i64, ptr, i64 } %74, i64 8, 1
  %76 = insertvalue { ptr, i64, ptr, i64 } %75, ptr @gc.offsets.10, 2
  %77 = insertvalue { ptr, i64, ptr, i64 } %76, i64 1, 3
  %78 = alloca ptr, align 8
  store ptr null, ptr %78, align 8
  %79 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %78, 0
  %80 = insertvalue { ptr, i64, ptr, i64 } %79, i64 8, 1
  %81 = insertvalue { ptr, i64, ptr, i64 } %80, ptr @gc.offsets.11, 2
  %82 = insertvalue { ptr, i64, ptr, i64 } %81, i64 1, 3
  %83 = alloca ptr, align 8
  store ptr null, ptr %83, align 8
  %84 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %83, 0
  %85 = insertvalue { ptr, i64, ptr, i64 } %84, i64 8, 1
  %86 = insertvalue { ptr, i64, ptr, i64 } %85, ptr @gc.offsets.12, 2
  %87 = insertvalue { ptr, i64, ptr, i64 } %86, i64 1, 3
  %88 = alloca ptr, align 8
  store ptr null, ptr %88, align 8
  %89 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %88, 0
  %90 = insertvalue { ptr, i64, ptr, i64 } %89, i64 8, 1
  %91 = insertvalue { ptr, i64, ptr, i64 } %90, ptr @gc.offsets.13, 2
  %92 = insertvalue { ptr, i64, ptr, i64 } %91, i64 1, 3
  %93 = alloca ptr, align 8
  store ptr null, ptr %93, align 8
  %94 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %93, 0
  %95 = insertvalue { ptr, i64, ptr, i64 } %94, i64 8, 1
  %96 = insertvalue { ptr, i64, ptr, i64 } %95, ptr @gc.offsets.14, 2
  %97 = insertvalue { ptr, i64, ptr, i64 } %96, i64 1, 3
  %98 = alloca ptr, align 8
  store ptr null, ptr %98, align 8
  %99 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %98, 0
  %100 = insertvalue { ptr, i64, ptr, i64 } %99, i64 8, 1
  %101 = insertvalue { ptr, i64, ptr, i64 } %100, ptr @gc.offsets.15, 2
  %102 = insertvalue { ptr, i64, ptr, i64 } %101, i64 1, 3
  %103 = alloca ptr, align 8
  store ptr null, ptr %103, align 8
  %104 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %103, 0
  %105 = insertvalue { ptr, i64, ptr, i64 } %104, i64 8, 1
  %106 = insertvalue { ptr, i64, ptr, i64 } %105, ptr @gc.offsets.16, 2
  %107 = insertvalue { ptr, i64, ptr, i64 } %106, i64 1, 3
  %108 = alloca ptr, align 8
  store ptr null, ptr %108, align 8
  %109 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %108, 0
  %110 = insertvalue { ptr, i64, ptr, i64 } %109, i64 8, 1
  %111 = insertvalue { ptr, i64, ptr, i64 } %110, ptr @gc.offsets.17, 2
  %112 = insertvalue { ptr, i64, ptr, i64 } %111, i64 1, 3
  %113 = alloca ptr, align 8
  store ptr null, ptr %113, align 8
  %114 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %113, 0
  %115 = insertvalue { ptr, i64, ptr, i64 } %114, i64 8, 1
  %116 = insertvalue { ptr, i64, ptr, i64 } %115, ptr @gc.offsets.18, 2
  %117 = insertvalue { ptr, i64, ptr, i64 } %116, i64 1, 3
  %118 = alloca ptr, align 8
  store ptr null, ptr %118, align 8
  %119 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %118, 0
  %120 = insertvalue { ptr, i64, ptr, i64 } %119, i64 8, 1
  %121 = insertvalue { ptr, i64, ptr, i64 } %120, ptr @gc.offsets.19, 2
  %122 = insertvalue { ptr, i64, ptr, i64 } %121, i64 1, 3
  %123 = alloca [19 x { ptr, i64, ptr, i64 }], align 8
  %124 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %38, ptr %124, align 8
  %125 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %42, ptr %125, align 8
  %126 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %46, ptr %126, align 8
  %127 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %50, ptr %127, align 8
  %128 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %54, ptr %128, align 8
  %129 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %58, ptr %129, align 8
  %130 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %62, ptr %130, align 8
  %131 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %67, ptr %131, align 8
  %132 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %72, ptr %132, align 8
  %133 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 9
  store { ptr, i64, ptr, i64 } %77, ptr %133, align 8
  %134 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 10
  store { ptr, i64, ptr, i64 } %82, ptr %134, align 8
  %135 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 11
  store { ptr, i64, ptr, i64 } %87, ptr %135, align 8
  %136 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 12
  store { ptr, i64, ptr, i64 } %92, ptr %136, align 8
  %137 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 13
  store { ptr, i64, ptr, i64 } %97, ptr %137, align 8
  %138 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 14
  store { ptr, i64, ptr, i64 } %102, ptr %138, align 8
  %139 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 15
  store { ptr, i64, ptr, i64 } %107, ptr %139, align 8
  %140 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 16
  store { ptr, i64, ptr, i64 } %112, ptr %140, align 8
  %141 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 17
  store { ptr, i64, ptr, i64 } %117, ptr %141, align 8
  %142 = getelementptr inbounds [19 x { ptr, i64, ptr, i64 }], ptr %123, i32 0, i32 18
  store { ptr, i64, ptr, i64 } %122, ptr %142, align 8
  %143 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %143, ptr %123, i64 19)
  call void @vd_gc_poll()
  %144 = call i1 @vd_worker_checkpoint(ptr %0)
  br i1 %144, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue46, %worker.continue44, %numeric_valid8
  call void @vd_gc_poll(), !dbg !82
  %145 = call i1 @vd_worker_checkpoint(ptr %0), !dbg !82
  br i1 %145, label %worker.cancelled9, label %worker.continue10, !dbg !82

block2:                                           ; preds = %numeric_valid14
  call void @vd_gc_poll(), !dbg !82
  %146 = call i1 @vd_worker_checkpoint(ptr %0), !dbg !82
  br i1 %146, label %worker.cancelled15, label %worker.continue16, !dbg !82

block3:                                           ; preds = %call_success24
  call void @vd_gc_poll(), !dbg !83
  %147 = call i1 @vd_worker_checkpoint(ptr %0), !dbg !83
  br i1 %147, label %worker.cancelled28, label %worker.continue29, !dbg !83

block4:                                           ; preds = %numeric_valid14
  call void @vd_gc_poll(), !dbg !82
  %148 = call i1 @vd_worker_checkpoint(ptr %0), !dbg !82
  br i1 %148, label %worker.cancelled30, label %worker.continue31, !dbg !82

block5:                                           ; preds = %worker.continue29
  call void @vd_gc_poll(), !dbg !84
  %149 = call i1 @vd_worker_checkpoint(ptr %0), !dbg !84
  br i1 %149, label %worker.cancelled43, label %worker.continue44, !dbg !84

block6:                                           ; preds = %worker.continue29
  call void @vd_gc_poll(), !dbg !82
  %150 = call i1 @vd_worker_checkpoint(ptr %0), !dbg !82
  br i1 %150, label %worker.cancelled45, label %worker.continue46, !dbg !82

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %143)
  ret void

worker.continue:                                  ; preds = %block0
  store double 3.000000e+00, ptr %5, align 8, !dbg !85
  store double 4.000000e+00, ptr %6, align 8, !dbg !86
  %151 = load double, ptr %5, align 8, !dbg !87
  store double %151, ptr %7, align 8, !dbg !87
  %152 = load double, ptr %6, align 8, !dbg !87
  store double %152, ptr %8, align 8, !dbg !87
  %153 = load double, ptr %7, align 8, !dbg !87
  %154 = load double, ptr %8, align 8, !dbg !87
  %155 = insertvalue %"/main.void::point" zeroinitializer, double %153, 0, !dbg !87
  %156 = insertvalue %"/main.void::point" %155, double %154, 1, !dbg !87
  store %"/main.void::point" %156, ptr %9, align 8, !dbg !87
  store double 5.000000e+00, ptr %10, align 8, !dbg !88
  store double 1.200000e+01, ptr %11, align 8, !dbg !89
  %157 = load double, ptr %10, align 8, !dbg !90
  store double %157, ptr %12, align 8, !dbg !90
  %158 = load double, ptr %11, align 8, !dbg !90
  store double %158, ptr %13, align 8, !dbg !90
  %159 = load double, ptr %12, align 8, !dbg !90
  %160 = load double, ptr %13, align 8, !dbg !90
  %161 = insertvalue %"/main.void::point" zeroinitializer, double %159, 0, !dbg !90
  %162 = insertvalue %"/main.void::point" %161, double %160, 1, !dbg !90
  store %"/main.void::point" %162, ptr %14, align 8, !dbg !90
  %163 = load %"/main.void::point", ptr %9, align 8, !dbg !91
  %164 = load %"/main.void::point", ptr %14, align 8, !dbg !91
  call void @vd_value_array_new(ptr %63, ptr @array.element, i64 2, i32 1, ptr %0), !dbg !91
  %165 = load ptr, ptr %0, align 8, !dbg !91
  %166 = icmp ne ptr %165, null, !dbg !91
  br i1 %166, label %numeric_error, label %numeric_valid, !dbg !91

numeric_error:                                    ; preds = %worker.continue
  %167 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !91
  store ptr @11, ptr %167, align 8, !dbg !91
  call void @vd_gc_frame_leave(ptr %143), !dbg !91
  ret void, !dbg !91

numeric_valid:                                    ; preds = %worker.continue
  store %"/main.void::point" %163, ptr %31, align 8, !dbg !91
  call void @vd_value_array_write(ptr %63, ptr @array.element, i64 0, i32 1, i64 0, ptr %31, i64 0, i32 0, i32 1, ptr %0), !dbg !91
  %168 = load ptr, ptr %0, align 8, !dbg !91
  %169 = icmp ne ptr %168, null, !dbg !91
  br i1 %169, label %numeric_error1, label %numeric_valid2, !dbg !91

numeric_error1:                                   ; preds = %numeric_valid
  %170 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !91
  store ptr @12, ptr %170, align 8, !dbg !91
  call void @vd_gc_frame_leave(ptr %143), !dbg !91
  ret void, !dbg !91

numeric_valid2:                                   ; preds = %numeric_valid
  store %"/main.void::point" %164, ptr %31, align 8, !dbg !91
  call void @vd_value_array_write(ptr %63, ptr @array.element, i64 0, i32 1, i64 1, ptr %31, i64 0, i32 0, i32 1, ptr %0), !dbg !91
  %171 = load ptr, ptr %0, align 8, !dbg !91
  %172 = icmp ne ptr %171, null, !dbg !91
  br i1 %172, label %numeric_error3, label %numeric_valid4, !dbg !91

numeric_error3:                                   ; preds = %numeric_valid2
  %173 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !91
  store ptr @13, ptr %173, align 8, !dbg !91
  call void @vd_gc_frame_leave(ptr %143), !dbg !91
  ret void, !dbg !91

numeric_valid4:                                   ; preds = %numeric_valid2
  %174 = load ptr, ptr %63, align 8, !dbg !91
  store ptr %174, ptr %63, align 8, !dbg !91
  store ptr %174, ptr %2, align 8, !dbg !92
  store double 0.000000e+00, ptr %3, align 8, !dbg !93
  %175 = load ptr, ptr %2, align 8, !dbg !94
  store ptr %175, ptr %68, align 8, !dbg !94
  store ptr %175, ptr %15, align 8, !dbg !82
  %176 = load ptr, ptr %15, align 8, !dbg !82
  store ptr %176, ptr %73, align 8, !dbg !82
  %177 = call i64 @vd_value_array_count(ptr %73, ptr @array.element, ptr %0), !dbg !82
  %178 = load ptr, ptr %0, align 8, !dbg !82
  %179 = icmp ne ptr %178, null, !dbg !82
  br i1 %179, label %numeric_error5, label %numeric_valid6, !dbg !82

numeric_error5:                                   ; preds = %numeric_valid4
  %180 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @14, ptr %180, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid6:                                   ; preds = %numeric_valid4
  store i64 %177, ptr %16, align 8, !dbg !82
  %181 = load ptr, ptr %15, align 8, !dbg !82
  store ptr %181, ptr %78, align 8, !dbg !82
  %182 = call i64 @vd_value_array_version(ptr %78, ptr @array.element, ptr %0), !dbg !82
  %183 = load ptr, ptr %0, align 8, !dbg !82
  %184 = icmp ne ptr %183, null, !dbg !82
  br i1 %184, label %numeric_error7, label %numeric_valid8, !dbg !82

numeric_error7:                                   ; preds = %numeric_valid6
  %185 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @15, ptr %185, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid8:                                   ; preds = %numeric_valid6
  store i64 %182, ptr %17, align 8, !dbg !82
  store i64 0, ptr %18, align 8, !dbg !82
  %186 = load i64, ptr %16, align 8, !dbg !82
  store i64 %186, ptr %19, align 8, !dbg !82
  store i1 true, ptr %20, align 1, !dbg !82
  br label %block1, !dbg !82

worker.cancelled9:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

worker.continue10:                                ; preds = %block1
  %187 = load ptr, ptr %15, align 8, !dbg !82
  store ptr %187, ptr %83, align 8, !dbg !82
  %188 = load i64, ptr %17, align 8, !dbg !82
  %189 = call i64 @vd_value_array_version(ptr %83, ptr @array.element, ptr %0), !dbg !82
  %190 = load ptr, ptr %0, align 8, !dbg !82
  %191 = icmp ne ptr %190, null, !dbg !82
  br i1 %191, label %numeric_error11, label %numeric_valid12, !dbg !82

numeric_error11:                                  ; preds = %worker.continue10
  %192 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @16, ptr %192, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid12:                                  ; preds = %worker.continue10
  %193 = icmp ne i64 %189, %188, !dbg !82
  br i1 %193, label %numeric_error13, label %numeric_valid14, !dbg !82

numeric_error13:                                  ; preds = %numeric_valid12
  %194 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @17, ptr %194, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid14:                                  ; preds = %numeric_valid12
  %195 = load i64, ptr %18, align 8, !dbg !82
  %196 = load i64, ptr %19, align 8, !dbg !82
  %197 = icmp ne i64 %195, %196, !dbg !82
  br i1 %197, label %block2, label %block4, !dbg !82

worker.cancelled15:                               ; preds = %block2
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

worker.continue16:                                ; preds = %block2
  %198 = load ptr, ptr %15, align 8, !dbg !82
  store ptr %198, ptr %88, align 8, !dbg !82
  %199 = load i64, ptr %18, align 8, !dbg !82
  %200 = call i64 @vd_value_array_count(ptr %88, ptr @array.element, ptr %0), !dbg !82
  %201 = load ptr, ptr %0, align 8, !dbg !82
  %202 = icmp ne ptr %201, null, !dbg !82
  br i1 %202, label %numeric_error17, label %numeric_valid18, !dbg !82

numeric_error17:                                  ; preds = %worker.continue16
  %203 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @18, ptr %203, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid18:                                  ; preds = %worker.continue16
  %204 = icmp slt i64 %199, 0, !dbg !82
  %205 = add i64 %199, %200, !dbg !82
  %206 = select i1 %204, i64 %205, i64 %199, !dbg !82
  %207 = icmp uge i64 %206, %200, !dbg !82
  br i1 %207, label %numeric_error19, label %numeric_valid20, !dbg !82

numeric_error19:                                  ; preds = %numeric_valid18
  %208 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @19, ptr %208, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid20:                                  ; preds = %numeric_valid18
  call void @vd_value_array_read(ptr %31, ptr %88, ptr @array.element, i64 0, i32 1, i64 %206, ptr %0), !dbg !82
  %209 = load ptr, ptr %0, align 8, !dbg !82
  %210 = icmp ne ptr %209, null, !dbg !82
  br i1 %210, label %numeric_error21, label %numeric_valid22, !dbg !82

numeric_error21:                                  ; preds = %numeric_valid20
  %211 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !82
  store ptr @20, ptr %211, align 8, !dbg !82
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

numeric_valid22:                                  ; preds = %numeric_valid20
  %212 = load %"/main.void::point", ptr %31, align 8, !dbg !82
  store %"/main.void::point" %212, ptr %4, align 8, !dbg !82
  %213 = load double, ptr %3, align 8, !dbg !83
  store double %213, ptr %21, align 8, !dbg !83
  %214 = load %"/main.void::point", ptr %4, align 8, !dbg !95
  store %"/main.void::point" %214, ptr %23, align 8, !dbg !95
  %215 = load %"/main.void::point", ptr %23, align 8, !dbg !96
  %216 = call double @__vd_2f6d61696e2e766f69643a3a656e65726779__research(%"/main.void::point" %215, ptr %0), !dbg !96
  %217 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !96
  %218 = load ptr, ptr %217, align 8, !dbg !96
  %219 = icmp ne ptr %218, null, !dbg !96
  br i1 %219, label %propagate_error, label %call_success, !dbg !96

propagate_error:                                  ; preds = %numeric_valid22
  %220 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 1, !dbg !96
  %221 = load i32, ptr %220, align 4, !dbg !96
  %222 = icmp ult i32 %221, 32, !dbg !96
  br i1 %222, label %trace_caller, label %trace_limit, !dbg !96

call_success:                                     ; preds = %numeric_valid22
  store double %216, ptr %22, align 8, !dbg !96
  store double 0.000000e+00, ptr %24, align 8, !dbg !97
  store double 1.000000e+02, ptr %25, align 8, !dbg !98
  %223 = load double, ptr %22, align 8, !dbg !99
  %224 = load double, ptr %24, align 8, !dbg !99
  %225 = load double, ptr %25, align 8, !dbg !99
  %226 = call double @__vd_2f407374646c69622f6d6174682e766f69643a3a636c616d703c333a31313a3e__research(double %223, double %224, double %225, ptr %0), !dbg !99
  %227 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !99
  %228 = load ptr, ptr %227, align 8, !dbg !99
  %229 = icmp ne ptr %228, null, !dbg !99
  br i1 %229, label %propagate_error23, label %call_success24, !dbg !99

trace_caller:                                     ; preds = %propagate_error
  %230 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 2, !dbg !96
  %231 = getelementptr [32 x ptr], ptr %230, i32 0, i32 %221, !dbg !96
  store ptr @21, ptr %231, align 8, !dbg !96
  %232 = add i32 %221, 1, !dbg !96
  store i32 %232, ptr %220, align 4, !dbg !96
  br label %error_return, !dbg !96

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %143), !dbg !96
  ret void, !dbg !96

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %220, align 4, !dbg !96
  br label %error_return, !dbg !96

propagate_error23:                                ; preds = %call_success
  %233 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 1, !dbg !99
  %234 = load i32, ptr %233, align 4, !dbg !99
  %235 = icmp ult i32 %234, 32, !dbg !99
  br i1 %235, label %trace_caller25, label %trace_limit27, !dbg !99

call_success24:                                   ; preds = %call_success
  store double %226, ptr %26, align 8, !dbg !99
  %236 = load double, ptr %21, align 8, !dbg !100
  %237 = load double, ptr %26, align 8, !dbg !100
  %238 = fadd double %236, %237, !dbg !83
  store double %238, ptr %3, align 8, !dbg !83
  br label %block3, !dbg !83

trace_caller25:                                   ; preds = %propagate_error23
  %239 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 2, !dbg !99
  %240 = getelementptr [32 x ptr], ptr %239, i32 0, i32 %234, !dbg !99
  store ptr @22, ptr %240, align 8, !dbg !99
  %241 = add i32 %234, 1, !dbg !99
  store i32 %241, ptr %233, align 4, !dbg !99
  br label %error_return26, !dbg !99

error_return26:                                   ; preds = %trace_caller25, %trace_limit27
  call void @vd_gc_frame_leave(ptr %143), !dbg !99
  ret void, !dbg !99

trace_limit27:                                    ; preds = %propagate_error23
  store i32 33, ptr %233, align 4, !dbg !99
  br label %error_return26, !dbg !99

worker.cancelled28:                               ; preds = %block3
  call void @vd_gc_frame_leave(ptr %143), !dbg !83
  ret void, !dbg !83

worker.continue29:                                ; preds = %block3
  %242 = load i1, ptr %20, align 1, !dbg !82
  br i1 %242, label %block5, label %block6, !dbg !82

worker.cancelled30:                               ; preds = %block4
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

worker.continue31:                                ; preds = %block4
  %243 = load double, ptr %3, align 8, !dbg !101
  store double %243, ptr %27, align 8, !dbg !101
  %244 = load double, ptr %27, align 8, !dbg !101
  %245 = bitcast double %244 to i64, !dbg !101
  %246 = call i1 @vd_scalar_display(ptr %93, i32 9, i64 %245, ptr null, ptr null, i1 false, ptr %0), !dbg !101
  %247 = load ptr, ptr %0, align 8, !dbg !101
  %248 = icmp ne ptr %247, null, !dbg !101
  br i1 %248, label %numeric_error32, label %numeric_valid33, !dbg !101

numeric_error32:                                  ; preds = %worker.continue31
  %249 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !101
  store ptr @23, ptr %249, align 8, !dbg !101
  call void @vd_gc_frame_leave(ptr %143), !dbg !101
  ret void, !dbg !101

numeric_valid33:                                  ; preds = %worker.continue31
  %250 = load ptr, ptr %93, align 8, !dbg !101
  store ptr %250, ptr %93, align 8, !dbg !101
  store ptr %250, ptr %28, align 8, !dbg !101
  call void @vd_string_literal(ptr %98, ptr @24, i64 1, ptr %0), !dbg !84
  %251 = load ptr, ptr %98, align 8, !dbg !84
  %252 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !84
  %253 = load ptr, ptr %252, align 8, !dbg !84
  %254 = icmp ne ptr %253, null, !dbg !84
  br i1 %254, label %numeric_error34, label %numeric_valid35, !dbg !84

numeric_error34:                                  ; preds = %numeric_valid33
  %255 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !84
  store ptr @25, ptr %255, align 8, !dbg !84
  call void @vd_gc_frame_leave(ptr %143), !dbg !84
  ret void, !dbg !84

numeric_valid35:                                  ; preds = %numeric_valid33
  store ptr %251, ptr %98, align 8, !dbg !84
  store ptr %251, ptr %29, align 8, !dbg !84
  call void @vd_string_literal(ptr %103, ptr @26, i64 1, ptr %0), !dbg !84
  %256 = load ptr, ptr %103, align 8, !dbg !84
  %257 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !84
  %258 = load ptr, ptr %257, align 8, !dbg !84
  %259 = icmp ne ptr %258, null, !dbg !84
  br i1 %259, label %numeric_error36, label %numeric_valid37, !dbg !84

numeric_error36:                                  ; preds = %numeric_valid35
  %260 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !84
  store ptr @27, ptr %260, align 8, !dbg !84
  call void @vd_gc_frame_leave(ptr %143), !dbg !84
  ret void, !dbg !84

numeric_valid37:                                  ; preds = %numeric_valid35
  store ptr %256, ptr %103, align 8, !dbg !84
  store ptr %256, ptr %30, align 8, !dbg !84
  %261 = load ptr, ptr %28, align 8, !dbg !84
  store ptr %261, ptr %108, align 8, !dbg !84
  %262 = load ptr, ptr %30, align 8, !dbg !84
  store ptr %262, ptr %113, align 8, !dbg !84
  %263 = getelementptr inbounds [2 x ptr], ptr %1, i32 0, i32 0, !dbg !84
  store ptr %108, ptr %263, align 8, !dbg !84
  %264 = getelementptr inbounds [2 x ptr], ptr %1, i32 0, i32 1, !dbg !84
  store ptr %113, ptr %264, align 8, !dbg !84
  call void @vd_string_join(ptr %118, ptr %1, i64 2, ptr %0), !dbg !84
  %265 = load ptr, ptr %0, align 8, !dbg !84
  %266 = icmp ne ptr %265, null, !dbg !84
  br i1 %266, label %numeric_error38, label %numeric_valid39, !dbg !84

numeric_error38:                                  ; preds = %numeric_valid37
  %267 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !84
  store ptr @28, ptr %267, align 8, !dbg !84
  call void @vd_gc_frame_leave(ptr %143), !dbg !84
  ret void, !dbg !84

numeric_valid39:                                  ; preds = %numeric_valid37
  %268 = load ptr, ptr %118, align 8, !dbg !84
  store ptr %268, ptr %118, align 8, !dbg !84
  call void @vd_console_print(ptr %268, i64 1, i1 false, ptr %0), !dbg !84
  %269 = load ptr, ptr %0, align 8, !dbg !84
  %270 = icmp ne ptr %269, null, !dbg !84
  br i1 %270, label %selected.failure, label %selected.valid, !dbg !84

selected.failure:                                 ; preds = %numeric_valid39
  %271 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 1, !dbg !84
  %272 = load i32, ptr %271, align 4, !dbg !84
  %273 = icmp ult i32 %272, 32, !dbg !84
  br i1 %273, label %trace_caller40, label %trace_limit42, !dbg !84

selected.valid:                                   ; preds = %numeric_valid39
  call void @vd_gc_frame_leave(ptr %143), !dbg !84
  ret void, !dbg !84

trace_caller40:                                   ; preds = %selected.failure
  %274 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 2, !dbg !84
  %275 = getelementptr [32 x ptr], ptr %274, i32 0, i32 %272, !dbg !84
  store ptr @29, ptr %275, align 8, !dbg !84
  %276 = add i32 %272, 1, !dbg !84
  store i32 %276, ptr %271, align 4, !dbg !84
  br label %error_return41, !dbg !84

error_return41:                                   ; preds = %trace_caller40, %trace_limit42
  call void @vd_gc_frame_leave(ptr %143), !dbg !84
  ret void, !dbg !84

trace_limit42:                                    ; preds = %selected.failure
  store i32 33, ptr %271, align 4, !dbg !84
  br label %error_return41, !dbg !84

worker.cancelled43:                               ; preds = %block5
  call void @vd_gc_frame_leave(ptr %143), !dbg !84
  ret void, !dbg !84

worker.continue44:                                ; preds = %block5
  %277 = load i64, ptr %18, align 8, !dbg !82
  %278 = add i64 %277, 1, !dbg !82
  store i64 %278, ptr %18, align 8, !dbg !82
  br label %block1, !dbg !82

worker.cancelled45:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %143), !dbg !82
  ret void, !dbg !82

worker.continue46:                                ; preds = %block6
  %279 = load i64, ptr %18, align 8, !dbg !82
  %280 = sub i64 %279, 1, !dbg !82
  store i64 %280, ptr %18, align 8, !dbg !82
  br label %block1, !dbg !82
}

define i32 @__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research(i32 %0, ptr %1) !dbg !102 {
block0:
  %2 = alloca i32, align 4
  store i32 0, ptr %2, align 4
  %3 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %4 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %4, ptr %3, i64 0)
  call void @vd_gc_poll()
  %5 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %5, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %4)
  ret i32 0

worker.continue:                                  ; preds = %block0
  call void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %1), !dbg !106
  %6 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !106
  %7 = load ptr, ptr %6, align 8, !dbg !106
  %8 = icmp ne ptr %7, null, !dbg !106
  br i1 %8, label %propagate_error, label %call_success, !dbg !106

propagate_error:                                  ; preds = %worker.continue
  %9 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !106
  %10 = load i32, ptr %9, align 4, !dbg !106
  %11 = icmp ult i32 %10, 32, !dbg !106
  br i1 %11, label %trace_caller, label %trace_limit, !dbg !106

call_success:                                     ; preds = %worker.continue
  call void @vd_gc_frame_leave(ptr %4), !dbg !106
  ret i32 0, !dbg !106

trace_caller:                                     ; preds = %propagate_error
  %12 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !106
  %13 = getelementptr [32 x ptr], ptr %12, i32 0, i32 %10, !dbg !106
  store ptr @30, ptr %13, align 8, !dbg !106
  %14 = add i32 %10, 1, !dbg !106
  store i32 %14, ptr %9, align 4, !dbg !106
  br label %error_return, !dbg !106

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %4), !dbg !106
  ret i32 0, !dbg !106

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %9, align 4, !dbg !106
  br label %error_return, !dbg !106
}

define internal double @__vd_246e756d657269633a3a6636343a3a636c616d70__research(double %0, double %1, double %2, ptr %3) !dbg !107 {
block0:
  %4 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %5 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %5, ptr %4, i64 0)
  call void @vd_gc_poll()
  %6 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %6, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !108
  %7 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %7, label %worker.cancelled1, label %worker.continue2, !dbg !108

block2:                                           ; preds = %worker.continue2
  call void @vd_gc_poll(), !dbg !108
  %8 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %8, label %worker.cancelled3, label %worker.continue4, !dbg !108

block3:                                           ; preds = %worker.continue4
  call void @vd_gc_poll(), !dbg !108
  %9 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %9, label %worker.cancelled5, label %worker.continue6, !dbg !108

block4:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !108
  %10 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %10, label %worker.cancelled7, label %worker.continue8, !dbg !108

block5:                                           ; preds = %worker.continue6
  call void @vd_gc_poll(), !dbg !108
  %11 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %11, label %worker.cancelled9, label %worker.continue10, !dbg !108

block6:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !108
  %12 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %12, label %worker.cancelled11, label %worker.continue12, !dbg !108

block7:                                           ; preds = %worker.continue10
  call void @vd_gc_poll(), !dbg !108
  %13 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %13, label %worker.cancelled13, label %worker.continue14, !dbg !108

block8:                                           ; preds = %worker.continue4, %worker.continue2, %worker.continue
  call void @vd_gc_poll(), !dbg !108
  %14 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !108
  br i1 %14, label %worker.cancelled15, label %worker.continue16, !dbg !108

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %5)
  ret double 0.000000e+00

worker.continue:                                  ; preds = %block0
  %15 = fcmp une double %1, %1, !dbg !108
  br i1 %15, label %block8, label %block1, !dbg !108

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue2:                                 ; preds = %block1
  %16 = fcmp une double %2, %2, !dbg !108
  br i1 %16, label %block8, label %block2, !dbg !108

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue4:                                 ; preds = %block2
  %17 = fcmp ogt double %1, %2, !dbg !108
  br i1 %17, label %block8, label %block3, !dbg !108

worker.cancelled5:                                ; preds = %block3
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue6:                                 ; preds = %block3
  %18 = fcmp olt double %0, %1, !dbg !108
  br i1 %18, label %block4, label %block5, !dbg !108

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue8:                                 ; preds = %block4
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double %1, !dbg !108

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue10:                                ; preds = %block5
  %19 = fcmp ogt double %0, %2, !dbg !108
  br i1 %19, label %block6, label %block7, !dbg !108

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue12:                                ; preds = %block6
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double %2, !dbg !108

worker.cancelled13:                               ; preds = %block7
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue14:                                ; preds = %block7
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double %0, !dbg !108

worker.cancelled15:                               ; preds = %block8
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

worker.continue16:                                ; preds = %block8
  br i1 true, label %numeric_error, label %numeric_valid, !dbg !108

numeric_error:                                    ; preds = %worker.continue16
  %20 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %3, i32 0, i32 0, !dbg !108
  store ptr @31, ptr %20, align 8, !dbg !108
  call void @vd_gc_frame_leave(ptr %5), !dbg !108
  ret double 0.000000e+00, !dbg !108

numeric_valid:                                    ; preds = %worker.continue16
  unreachable, !dbg !108
}

declare void @vd_gc_frame_enter(ptr, ptr, i64)

declare void @vd_gc_poll()

declare i1 @vd_worker_checkpoint(ptr)

declare void @vd_gc_frame_leave(ptr)

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #0

declare void @vd_value_array_new(ptr, ptr, i64, i32, ptr)

declare void @vd_value_array_write(ptr, ptr, i64, i32, i64, ptr, i64, i32, i32, ptr)

declare i64 @vd_value_array_count(ptr, ptr, ptr)

declare i64 @vd_value_array_version(ptr, ptr, ptr)

declare void @vd_value_array_read(ptr, ptr, ptr, i64, i32, i64, ptr)

declare i1 @vd_scalar_display(ptr, i32, i64, ptr, ptr, i1, ptr)

declare void @vd_string_literal(ptr, ptr, i64, ptr)

declare void @vd_string_join(ptr, ptr, i64, ptr)

declare void @vd_console_print(ptr, i64, i1, ptr)

attributes #0 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2}

!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "VOID source compiler", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "main.void", directory: "/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = distinct !DISubprogram(name: "sqrt", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a737172743c333a31313a3e__research", scope: !4, file: !4, line: 359, type: !5, scopeLine: 359, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!4 = !DIFile(filename: "math.void", directory: "/home/shmellyorc/Documents/Void.Language/stdlib")
!5 = !DISubroutineType(types: !6)
!6 = !{!7, !7}
!7 = !DIBasicType(name: "f64", size: 64, encoding: DW_ATE_float)
!8 = !DILocation(line: 362, column: 14, scope: !3)
!9 = !DILocation(line: 363, column: 16, scope: !3)
!10 = !DILocation(line: 364, column: 14, scope: !3)
!11 = !DILocation(line: 362, column: 32, scope: !3)
!12 = !DILocation(line: 365, column: 16, scope: !3)
!13 = !DILocation(line: 366, column: 8, scope: !3)
!14 = !DILocation(line: 367, column: 16, scope: !3)
!15 = !DILocation(line: 359, column: 14, scope: !3)
!16 = !DILocation(line: 360, column: 32, scope: !3)
!17 = !DILocation(line: 360, column: 17, scope: !3)
!18 = !DILocation(line: 360, column: 9, scope: !3)
!19 = !DILocation(line: 361, column: 9, scope: !3)
!20 = !DILocation(line: 362, column: 8, scope: !3)
!21 = !DILocation(line: 362, column: 17, scope: !3)
!22 = !DILocation(line: 364, column: 8, scope: !3)
!23 = !DILocation(line: 364, column: 16, scope: !3)
!24 = !DILocation(line: 362, column: 26, scope: !3)
!25 = !DILocation(line: 362, column: 35, scope: !3)
!26 = !DILocation(line: 366, column: 20, scope: !3)
!27 = !DILocation(line: 368, column: 26, scope: !3)
!28 = !DILocation(line: 368, column: 12, scope: !3)
!29 = distinct !DISubprogram(name: "clamp", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a636c616d703c333a31313a3e__research", scope: !4, file: !4, line: 89, type: !30, scopeLine: 89, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!30 = !DISubroutineType(types: !31)
!31 = !{!7, !7, !7, !7}
!32 = !DILocation(line: 89, column: 15, scope: !29)
!33 = !DILocation(line: 89, column: 25, scope: !29)
!34 = !DILocation(line: 89, column: 35, scope: !29)
!35 = !DILocation(line: 90, column: 20, scope: !29)
!36 = !DILocation(line: 90, column: 27, scope: !29)
!37 = !DILocation(line: 90, column: 34, scope: !29)
!38 = !DILocation(line: 90, column: 14, scope: !29)
!39 = distinct !DISubprogram(name: "_nan", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a5f6e616e3c333a31313a3e__research", scope: !4, file: !4, line: 22, type: !40, scopeLine: 22, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!40 = !DISubroutineType(types: !41)
!41 = !{!7}
!42 = !DILocation(line: 23, column: 9, scope: !39)
!43 = !DILocation(line: 24, column: 12, scope: !39)
!44 = !DILocation(line: 24, column: 17, scope: !39)
!45 = !DILocation(line: 24, column: 19, scope: !39)
!46 = distinct !DISubprogram(name: "is_infinite", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a69735f696e66696e6974653c333a31313a3e__research", scope: !4, file: !4, line: 116, type: !47, scopeLine: 116, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!47 = !DISubroutineType(types: !48)
!48 = !{!49, !7}
!49 = !DIBasicType(name: "bool", size: 1, encoding: DW_ATE_boolean)
!50 = !DILocation(line: 118, column: 32, scope: !46)
!51 = !DILocation(line: 116, column: 21, scope: !46)
!52 = !DILocation(line: 117, column: 32, scope: !46)
!53 = !DILocation(line: 117, column: 17, scope: !46)
!54 = !DILocation(line: 117, column: 9, scope: !46)
!55 = !DILocation(line: 118, column: 12, scope: !46)
!56 = !DILocation(line: 118, column: 18, scope: !46)
!57 = !DILocation(line: 118, column: 35, scope: !46)
!58 = !DILocation(line: 118, column: 41, scope: !46)
!59 = distinct !DISubprogram(name: "energy", linkageName: "__vd_2f6d61696e2e766f69643a3a656e65726779__research", scope: !1, file: !1, line: 5, type: !60, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!60 = !DISubroutineType(types: !61)
!61 = !{!7, !62}
!62 = !DICompositeType(tag: DW_TAG_structure_type, name: "readonly /main.void::point", scope: !1, file: !1, size: 128, align: 64, elements: !63)
!63 = !{!64, !65}
!64 = !DIDerivedType(tag: DW_TAG_member, name: "x", scope: !1, file: !1, baseType: !7, size: 64, align: 64)
!65 = !DIDerivedType(tag: DW_TAG_member, name: "y", scope: !1, file: !1, baseType: !7, size: 64, align: 64, offset: 64)
!66 = !DILocation(line: 5, column: 19, scope: !59)
!67 = !DILocation(line: 6, column: 19, scope: !59)
!68 = !DILocation(line: 6, column: 21, scope: !59)
!69 = !DILocation(line: 6, column: 23, scope: !59)
!70 = !DILocation(line: 6, column: 25, scope: !59)
!71 = !DILocation(line: 6, column: 27, scope: !59)
!72 = !DILocation(line: 6, column: 29, scope: !59)
!73 = !DILocation(line: 6, column: 31, scope: !59)
!74 = !DILocation(line: 6, column: 33, scope: !59)
!75 = !DILocation(line: 6, column: 35, scope: !59)
!76 = !DILocation(line: 6, column: 37, scope: !59)
!77 = !DILocation(line: 6, column: 39, scope: !59)
!78 = !DILocation(line: 6, column: 14, scope: !59)
!79 = distinct !DISubprogram(name: "main", linkageName: "__vd_2f6d61696e2e766f69643a3a6d61696e__research", scope: !1, file: !1, line: 7, type: !80, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!80 = !DISubroutineType(types: !81)
!81 = !{null}
!82 = !DILocation(line: 10, column: 5, scope: !79)
!83 = !DILocation(line: 11, column: 9, scope: !79)
!84 = !DILocation(line: 12, column: 5, scope: !79)
!85 = !DILocation(line: 8, column: 38, scope: !79)
!86 = !DILocation(line: 8, column: 45, scope: !79)
!87 = !DILocation(line: 8, column: 28, scope: !79)
!88 = !DILocation(line: 8, column: 59, scope: !79)
!89 = !DILocation(line: 8, column: 66, scope: !79)
!90 = !DILocation(line: 8, column: 49, scope: !79)
!91 = !DILocation(line: 8, column: 27, scope: !79)
!92 = !DILocation(line: 8, column: 9, scope: !79)
!93 = !DILocation(line: 9, column: 9, scope: !79)
!94 = !DILocation(line: 10, column: 14, scope: !79)
!95 = !DILocation(line: 11, column: 33, scope: !79)
!96 = !DILocation(line: 11, column: 26, scope: !79)
!97 = !DILocation(line: 11, column: 37, scope: !79)
!98 = !DILocation(line: 11, column: 40, scope: !79)
!99 = !DILocation(line: 11, column: 20, scope: !79)
!100 = !DILocation(line: 11, column: 15, scope: !79)
!101 = !DILocation(line: 12, column: 11, scope: !79)
!102 = distinct !DISubprogram(name: "$app_adapter", linkageName: "__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research", scope: !1, file: !1, line: 7, type: !103, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!103 = !DISubroutineType(types: !104)
!104 = !{!105, !105}
!105 = !DIBasicType(name: "i32", size: 32, encoding: DW_ATE_signed)
!106 = !DILocation(line: 7, column: 6, scope: !102)
!107 = distinct !DISubprogram(name: "f64::clamp", linkageName: "__vd_246e756d657269633a3a6636343a3a636c616d70__research", scope: !4, file: !4, line: 90, type: !30, scopeLine: 90, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!108 = !DILocation(line: 90, column: 14, scope: !107)
