; ModuleID = '/main.void'
source_filename = "/main.void"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%"/main.void::point" = type { double, double }

@0 = private unnamed_addr constant [18 x i8] c"/main.void::point\00", align 1
@1 = private unnamed_addr constant [75 x i8] c"16:8|1:x|17:/main.void::point|3:f64|1:0|1:y|17:/main.void::point|3:f64|1:8\00", align 1
@gc.offsets = private constant [0 x i64] zeroinitializer
@__vd_types__research = local_unnamed_addr constant [1 x { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 }] [{ ptr, ptr, ptr, i64, ptr, i64, ptr, i32 } { ptr @0, ptr @6, ptr @1, i64 16, ptr @gc.offsets, i64 0, ptr @7, i32 0 }]
@__vd_type_count__research = local_unnamed_addr constant i64 1
@__vd_witnesses__research = local_unnamed_addr constant [0 x { ptr, ptr, ptr, ptr }] zeroinitializer
@__vd_witness_count__research = local_unnamed_addr constant i64 0
@2 = private unnamed_addr constant [158 x i8] c"Called from /@stdlib/math.void::sqrt\0A/home/shmellyorc/Documents/Void.Language/stdlib/math.void:365:16: source call\0A        return _nan<t>()\0A               ^\0A\00", align 1
@3 = private unnamed_addr constant [151 x i8] c"Called from /@stdlib/math.void::sqrt\0A/home/shmellyorc/Documents/Void.Language/stdlib/math.void:366:8: source call\0A    if is_infinite(input):\0A       ^\0A\00", align 1
@4 = private unnamed_addr constant [171 x i8] c"Called from /@stdlib/math.void::clamp\0A/home/shmellyorc/Documents/Void.Language/stdlib/math.void:90:14: source call\0A    return t.clamp(value, lower, upper)\0A             ^\0A\00", align 1
@5 = private unnamed_addr constant [169 x i8] c"Called from /main.void::energy\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:6:14: source call\0A    return m.sqrt(p.x * p.x + p.y * p.y)\0A             ^\0A\00", align 1
@gc.offsets.1 = private constant [1 x i64] zeroinitializer
@gc.offsets.2 = private constant [1 x i64] zeroinitializer
@gc.offsets.3 = private constant [1 x i64] zeroinitializer
@gc.offsets.4 = private constant [1 x i64] zeroinitializer
@gc.offsets.5 = private constant [1 x i64] zeroinitializer
@gc.offsets.6 = private constant [1 x i64] zeroinitializer
@gc.offsets.7 = private constant [1 x i64] zeroinitializer
@gc.offsets.8 = private constant [1 x i64] zeroinitializer
@gc.offsets.9 = private constant [1 x i64] zeroinitializer
@gc.offsets.10 = private constant [1 x i64] zeroinitializer
@gc.offsets.11 = private constant [1 x i64] zeroinitializer
@gc.offsets.12 = private constant [1 x i64] zeroinitializer
@gc.offsets.13 = private constant [1 x i64] zeroinitializer
@gc.offsets.14 = private constant [1 x i64] zeroinitializer
@gc.offsets.15 = private constant [1 x i64] zeroinitializer
@gc.offsets.16 = private constant [1 x i64] zeroinitializer
@gc.offsets.17 = private constant [1 x i64] zeroinitializer
@gc.offsets.18 = private constant [1 x i64] zeroinitializer
@gc.offsets.19 = private constant [1 x i64] zeroinitializer
@6 = private unnamed_addr constant [1 x i8] zeroinitializer, align 1
@array.element.fields = private constant [2 x { ptr, i64, i64, i32, i32 }] [{ ptr, i64, i64, i32, i32 } { ptr @6, i64 0, i64 0, i32 9, i32 0 }, { ptr, i64, i64, i32, i32 } { ptr @6, i64 8, i64 0, i32 9, i32 0 }]
@7 = private unnamed_addr constant [43 x i8] c"void.array.element.v1/12:/main.void::point\00", align 1
@array.element = private constant { ptr, i64, i64, i64, ptr } { ptr @7, i64 16, i64 8, i64 2, ptr @array.element.fields }
@8 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:8:27: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@9 = private unnamed_addr constant [137 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0AIn function /main.void::main\0A\00", align 1
@10 = private unnamed_addr constant [158 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: List structurally modified during iteration\0AIn function /main.void::main\0A\00", align 1
@11 = private unnamed_addr constant [167 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: List index outside extent\0A    for p in points:\0A    ^\0AIn function /main.void::main\0A\00", align 1
@12 = private unnamed_addr constant [164 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:10:5: runtime error: Array operation failed\0A    for p in points:\0A    ^\0AIn function /main.void::main\0A\00", align 1
@13 = private unnamed_addr constant [183 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:11:26: source call\0A        total += m.clamp(energy(p), 0, 100)\0A                         ^\0A\00", align 1
@14 = private unnamed_addr constant [177 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:11:20: source call\0A        total += m.clamp(energy(p), 0, 100)\0A                   ^\0A\00", align 1
@15 = private unnamed_addr constant [169 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:11: runtime error: Display operation failed\0A    print(total)\0A          ^\0AIn function /main.void::main\0A\00", align 1
@16 = private unnamed_addr constant [2 x i8] c" \00", align 1
@17 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@18 = private unnamed_addr constant [161 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: runtime error: String operation failed\0A    print(total)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@19 = private unnamed_addr constant [158 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: runtime error: Interpolation failed\0A    print(total)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@20 = private unnamed_addr constant [134 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:12:5: source call\0A    print(total)\0A    ^\0A\00", align 1
@21 = private unnamed_addr constant [118 x i8] c"Called from /main.void::$app_adapter\0A/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay/main.void:7:6: source call\0A\00", align 1
@22 = private unnamed_addr constant [147 x i8] c"/home/shmellyorc/Documents/Void.Language/stdlib/math.void:90:14: runtime error: Clamp bounds are reversed or NaN\0AIn function $numeric::f64::clamp\0A\00", align 1

define double @__vd_2f407374646c69622f6d6174682e766f69643a3a737172743c333a31313a3e__research(double %0, ptr %1) local_unnamed_addr !dbg !3 {
block0:
  %2 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %3 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %3, ptr nonnull %2, i64 0)
  call void @vd_gc_poll()
  %4 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %4, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue8, %worker.continue
  call void @vd_gc_poll(), !dbg !8
  %5 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !8
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !9
  %. = select i1 %5, double 0.000000e+00, double %0, !dbg !9
  br label %common.ret, !dbg !9

block2:                                           ; preds = %worker.continue8
  call void @vd_gc_poll(), !dbg !10
  %6 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !10
  br i1 %6, label %worker.cancelled3, label %worker.continue4, !dbg !10

block4:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !11
  %7 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !11
  br i1 %7, label %worker.cancelled7, label %worker.continue8, !dbg !11

block5:                                           ; preds = %worker.continue6
  br i1 %11, label %worker.cancelled9, label %worker.continue10, !dbg !12

block6:                                           ; preds = %worker.continue6
  br i1 %11, label %worker.cancelled11, label %worker.continue12, !dbg !13

block8:                                           ; preds = %call_success16
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !9
  %.46 = select i1 %28, double 0.000000e+00, double %0, !dbg !9
  br label %common.ret, !dbg !9

block9:                                           ; preds = %call_success16
  br i1 %28, label %worker.cancelled22, label %worker.continue23, !dbg !14

common.ret:                                       ; preds = %block8, %block1, %worker.continue25, %worker.cancelled24, %worker.cancelled22, %error_return18, %worker.cancelled13, %worker.cancelled11, %error_return, %call_success, %worker.cancelled9, %worker.cancelled7, %worker.cancelled5, %worker.cancelled3, %worker.cancelled
  %common.ret.op = phi double [ 0.000000e+00, %worker.cancelled ], [ 0.000000e+00, %worker.cancelled3 ], [ 0.000000e+00, %worker.cancelled5 ], [ 0.000000e+00, %worker.cancelled7 ], [ 0.000000e+00, %worker.cancelled9 ], [ %13, %call_success ], [ 0.000000e+00, %error_return ], [ 0.000000e+00, %worker.cancelled11 ], [ 0.000000e+00, %worker.cancelled13 ], [ 0.000000e+00, %error_return18 ], [ 0.000000e+00, %worker.cancelled22 ], [ 0.000000e+00, %worker.cancelled24 ], [ %34, %worker.continue25 ], [ %., %block1 ], [ %.46, %block8 ]
  ret double %common.ret.op, !dbg !9

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr nonnull %3)
  br label %common.ret

worker.continue:                                  ; preds = %block0
  %8 = fcmp uno double %0, 0.000000e+00, !dbg !8
  br i1 %8, label %block1, label %block4, !dbg !8

worker.cancelled3:                                ; preds = %block2
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !10
  br label %common.ret, !dbg !10

worker.continue4:                                 ; preds = %block2
  call void @vd_gc_poll(), !dbg !10
  %9 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !10
  br i1 %9, label %worker.cancelled5, label %worker.continue6, !dbg !10

worker.cancelled5:                                ; preds = %worker.continue4
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !10
  br label %common.ret, !dbg !10

worker.continue6:                                 ; preds = %worker.continue4
  %10 = fcmp olt double %0, 0.000000e+00, !dbg !11
  call void @vd_gc_poll(), !dbg !9
  %11 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !9
  br i1 %10, label %block5, label %block6, !dbg !11

worker.cancelled7:                                ; preds = %block4
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !11
  br label %common.ret, !dbg !11

worker.continue8:                                 ; preds = %block4
  %12 = fcmp oeq double %0, 0.000000e+00, !dbg !12
  br i1 %12, label %block1, label %block2, !dbg !12

worker.cancelled9:                                ; preds = %block5
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !12
  br label %common.ret, !dbg !12

worker.continue10:                                ; preds = %block5
  %13 = call fastcc double @__vd_2f407374646c69622f6d6174682e766f69643a3a5f6e616e3c333a31313a3e__research(ptr %1), !dbg !13
  %14 = load ptr, ptr %1, align 8, !dbg !13
  %.not44 = icmp eq ptr %14, null, !dbg !13
  br i1 %.not44, label %call_success, label %propagate_error, !dbg !13

propagate_error:                                  ; preds = %worker.continue10
  %15 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !13
  %16 = load i32, ptr %15, align 4, !dbg !13
  %17 = icmp ult i32 %16, 32, !dbg !13
  br i1 %17, label %trace_caller, label %error_return, !dbg !13

call_success:                                     ; preds = %worker.continue10
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !13
  br label %common.ret, !dbg !13

trace_caller:                                     ; preds = %propagate_error
  %18 = getelementptr inbounds i8, ptr %1, i64 16, !dbg !13
  %19 = zext nneg i32 %16 to i64, !dbg !13
  %20 = getelementptr [32 x ptr], ptr %18, i64 0, i64 %19, !dbg !13
  store ptr @2, ptr %20, align 8, !dbg !13
  %21 = add nuw nsw i32 %16, 1, !dbg !13
  br label %error_return, !dbg !13

error_return:                                     ; preds = %propagate_error, %trace_caller
  %storemerge45 = phi i32 [ %21, %trace_caller ], [ 33, %propagate_error ], !dbg !13
  store i32 %storemerge45, ptr %15, align 4, !dbg !13
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !13
  br label %common.ret, !dbg !13

worker.cancelled11:                               ; preds = %block6
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !13
  br label %common.ret, !dbg !13

worker.continue12:                                ; preds = %block6
  call void @vd_gc_poll(), !dbg !13
  %22 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !13
  br i1 %22, label %worker.cancelled13, label %worker.continue14, !dbg !13

worker.cancelled13:                               ; preds = %worker.continue12
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !13
  br label %common.ret, !dbg !13

worker.continue14:                                ; preds = %worker.continue12
  %23 = call i1 @__vd_2f407374646c69622f6d6174682e766f69643a3a69735f696e66696e6974653c333a31313a3e__research(double %0, ptr %1), !dbg !15
  %24 = load ptr, ptr %1, align 8, !dbg !15
  %.not = icmp eq ptr %24, null, !dbg !15
  br i1 %.not, label %call_success16, label %propagate_error15, !dbg !15

propagate_error15:                                ; preds = %worker.continue14
  %25 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !15
  %26 = load i32, ptr %25, align 4, !dbg !15
  %27 = icmp ult i32 %26, 32, !dbg !15
  br i1 %27, label %trace_caller17, label %error_return18, !dbg !15

call_success16:                                   ; preds = %worker.continue14
  call void @vd_gc_poll(), !dbg !9
  %28 = call i1 @vd_worker_checkpoint(ptr nonnull %1), !dbg !9
  br i1 %23, label %block8, label %block9, !dbg !15

trace_caller17:                                   ; preds = %propagate_error15
  %29 = getelementptr inbounds i8, ptr %1, i64 16, !dbg !15
  %30 = zext nneg i32 %26 to i64, !dbg !15
  %31 = getelementptr [32 x ptr], ptr %29, i64 0, i64 %30, !dbg !15
  store ptr @3, ptr %31, align 8, !dbg !15
  %32 = add nuw nsw i32 %26, 1, !dbg !15
  br label %error_return18, !dbg !15

error_return18:                                   ; preds = %propagate_error15, %trace_caller17
  %storemerge = phi i32 [ %32, %trace_caller17 ], [ 33, %propagate_error15 ], !dbg !15
  store i32 %storemerge, ptr %25, align 4, !dbg !15
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !15
  br label %common.ret, !dbg !15

worker.cancelled22:                               ; preds = %block9
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !14
  br label %common.ret, !dbg !14

worker.continue23:                                ; preds = %block9
  call void @vd_gc_poll(), !dbg !14
  %33 = call i1 @vd_worker_checkpoint(ptr nonnull %1), !dbg !14
  br i1 %33, label %worker.cancelled24, label %worker.continue25, !dbg !14

worker.cancelled24:                               ; preds = %worker.continue23
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !14
  br label %common.ret, !dbg !14

worker.continue25:                                ; preds = %worker.continue23
  %34 = call double @llvm.sqrt.f64(double %0), !dbg !16
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !16
  br label %common.ret, !dbg !16
}

define double @__vd_2f407374646c69622f6d6174682e766f69643a3a636c616d703c333a31313a3e__research(double %0, double %1, double %2, ptr %3) local_unnamed_addr !dbg !17 {
block0:
  %4 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %5 = alloca [32 x i8], align 8
  %6 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %6, ptr nonnull %4, i64 0)
  call void @vd_gc_poll()
  %7 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %7, label %common.ret, label %worker.continue

common.ret:                                       ; preds = %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, %block0, %error_return
  %common.ret.op = phi double [ 0.000000e+00, %error_return ], [ 0.000000e+00, %block0 ], [ %common.ret.op.i, %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit ]
  call void @vd_gc_frame_leave(ptr nonnull %6)
  ret double %common.ret.op, !dbg !20

worker.continue:                                  ; preds = %block0
  call void @llvm.lifetime.start.p0(i64 0, ptr nonnull %4)
  call void @llvm.lifetime.start.p0(i64 32, ptr nonnull %5)
  call void @vd_gc_frame_enter(ptr nonnull %5, ptr nonnull %4, i64 0)
  call void @vd_gc_poll()
  %8 = call i1 @vd_worker_checkpoint(ptr %3)
  br i1 %8, label %worker.cancelled.i, label %worker.continue.i

block1.i:                                         ; preds = %worker.continue.i
  call void @vd_gc_poll(), !dbg !21
  %9 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !21
  br i1 %9, label %worker.cancelled1.i, label %worker.continue2.i, !dbg !21

block2.i:                                         ; preds = %worker.continue2.i
  call void @vd_gc_poll(), !dbg !21
  %10 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !21
  br i1 %10, label %worker.cancelled3.i, label %worker.continue4.i, !dbg !21

block3.i:                                         ; preds = %worker.continue4.i
  call void @vd_gc_poll(), !dbg !21
  %11 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !21
  br i1 %11, label %worker.cancelled5.i, label %worker.continue6.i, !dbg !21

block4.i:                                         ; preds = %worker.continue6.i
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  %..i = select i1 %17, double 0.000000e+00, double %1, !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

block5.i:                                         ; preds = %worker.continue6.i
  br i1 %17, label %worker.cancelled9.i, label %worker.continue10.i, !dbg !21

block6.i:                                         ; preds = %worker.continue10.i
  %.19.i = select i1 %19, double 0.000000e+00, double %2, !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

block7.i:                                         ; preds = %worker.continue10.i
  %.20.i = select i1 %19, double 0.000000e+00, double %0, !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

block8.i:                                         ; preds = %worker.continue4.i, %worker.continue2.i, %worker.continue.i
  call void @vd_gc_poll(), !dbg !21
  %12 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !21
  br i1 %12, label %worker.cancelled15.i, label %numeric_error.i, !dbg !21

worker.cancelled.i:                               ; preds = %worker.continue
  call void @vd_gc_frame_leave(ptr nonnull %5)
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit

worker.continue.i:                                ; preds = %worker.continue
  %13 = fcmp uno double %1, 0.000000e+00, !dbg !21
  br i1 %13, label %block8.i, label %block1.i, !dbg !21

worker.cancelled1.i:                              ; preds = %block1.i
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

worker.continue2.i:                               ; preds = %block1.i
  %14 = fcmp uno double %2, 0.000000e+00, !dbg !21
  br i1 %14, label %block8.i, label %block2.i, !dbg !21

worker.cancelled3.i:                              ; preds = %block2.i
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

worker.continue4.i:                               ; preds = %block2.i
  %15 = fcmp ogt double %1, %2, !dbg !21
  br i1 %15, label %block8.i, label %block3.i, !dbg !21

worker.cancelled5.i:                              ; preds = %block3.i
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

worker.continue6.i:                               ; preds = %block3.i
  %16 = fcmp olt double %0, %1, !dbg !21
  call void @vd_gc_poll(), !dbg !21
  %17 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !21
  br i1 %16, label %block4.i, label %block5.i, !dbg !21

worker.cancelled9.i:                              ; preds = %block5.i
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

worker.continue10.i:                              ; preds = %block5.i
  %18 = fcmp ogt double %0, %2, !dbg !21
  call void @vd_gc_poll(), !dbg !21
  %19 = call i1 @vd_worker_checkpoint(ptr %3), !dbg !21
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br i1 %18, label %block6.i, label %block7.i, !dbg !21

worker.cancelled15.i:                             ; preds = %block8.i
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

numeric_error.i:                                  ; preds = %block8.i
  store ptr @22, ptr %3, align 8, !dbg !21
  call void @vd_gc_frame_leave(ptr nonnull %5), !dbg !21
  br label %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit, !dbg !21

__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit: ; preds = %block4.i, %block6.i, %block7.i, %worker.cancelled.i, %worker.cancelled1.i, %worker.cancelled3.i, %worker.cancelled5.i, %worker.cancelled9.i, %worker.cancelled15.i, %numeric_error.i
  %common.ret.op.i = phi double [ 0.000000e+00, %worker.cancelled.i ], [ 0.000000e+00, %worker.cancelled1.i ], [ 0.000000e+00, %worker.cancelled3.i ], [ 0.000000e+00, %worker.cancelled5.i ], [ 0.000000e+00, %worker.cancelled9.i ], [ 0.000000e+00, %worker.cancelled15.i ], [ 0.000000e+00, %numeric_error.i ], [ %..i, %block4.i ], [ %.19.i, %block6.i ], [ %.20.i, %block7.i ]
  call void @llvm.lifetime.end.p0(i64 0, ptr nonnull %4), !dbg !21
  call void @llvm.lifetime.end.p0(i64 32, ptr nonnull %5), !dbg !21
  %20 = load ptr, ptr %3, align 8, !dbg !20
  %.not = icmp eq ptr %20, null, !dbg !20
  br i1 %.not, label %common.ret, label %propagate_error, !dbg !20

propagate_error:                                  ; preds = %__vd_246e756d657269633a3a6636343a3a636c616d70__research.exit
  %21 = getelementptr inbounds i8, ptr %3, i64 8, !dbg !20
  %22 = load i32, ptr %21, align 4, !dbg !20
  %23 = icmp ult i32 %22, 32, !dbg !20
  br i1 %23, label %trace_caller, label %error_return, !dbg !20

trace_caller:                                     ; preds = %propagate_error
  %24 = getelementptr inbounds i8, ptr %3, i64 16, !dbg !20
  %25 = zext nneg i32 %22 to i64, !dbg !20
  %26 = getelementptr [32 x ptr], ptr %24, i64 0, i64 %25, !dbg !20
  store ptr @4, ptr %26, align 8, !dbg !20
  %27 = add nuw nsw i32 %22, 1, !dbg !20
  br label %error_return, !dbg !20

error_return:                                     ; preds = %propagate_error, %trace_caller
  %storemerge = phi i32 [ %27, %trace_caller ], [ 33, %propagate_error ], !dbg !20
  store i32 %storemerge, ptr %21, align 4, !dbg !20
  br label %common.ret, !dbg !20
}

define internal fastcc double @__vd_2f407374646c69622f6d6174682e766f69643a3a5f6e616e3c333a31313a3e__research(ptr %0) unnamed_addr !dbg !24 {
block0:
  %1 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %2 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %2, ptr nonnull %1, i64 0)
  call void @vd_gc_poll()
  %3 = call i1 @vd_worker_checkpoint(ptr %0)
  call void @vd_gc_frame_leave(ptr nonnull %2)
  %. = select i1 %3, double 0.000000e+00, double 0x7FF8000000000000
  ret double %., !dbg !27
}

define i1 @__vd_2f407374646c69622f6d6174682e766f69643a3a69735f696e66696e6974653c333a31313a3e__research(double %0, ptr %1) local_unnamed_addr !dbg !28 {
block0:
  %2 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %3 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %3, ptr nonnull %2, i64 0)
  call void @vd_gc_poll()
  %4 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %4, label %worker.cancelled, label %worker.continue

block1:                                           ; preds = %worker.continue
  call void @vd_gc_poll(), !dbg !32
  %5 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !32
  br i1 %5, label %worker.cancelled1, label %worker.continue2, !dbg !32

block2:                                           ; preds = %worker.continue2, %worker.continue
  %.0 = phi i1 [ true, %worker.continue ], [ %8, %worker.continue2 ], !dbg !32
  call void @vd_gc_poll(), !dbg !32
  %6 = call i1 @vd_worker_checkpoint(ptr %1), !dbg !32
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !32
  %not. = xor i1 %6, true, !dbg !32
  %..0 = select i1 %not., i1 %.0, i1 false, !dbg !32
  br label %common.ret, !dbg !32

common.ret:                                       ; preds = %block2, %worker.cancelled1, %worker.cancelled
  %common.ret.op = phi i1 [ false, %worker.cancelled ], [ false, %worker.cancelled1 ], [ %..0, %block2 ]
  ret i1 %common.ret.op, !dbg !32

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr nonnull %3)
  br label %common.ret

worker.continue:                                  ; preds = %block0
  %7 = fcmp olt double %0, 0xFFEFFFFFFFFFFFFF, !dbg !33
  br i1 %7, label %block2, label %block1, !dbg !32

worker.cancelled1:                                ; preds = %block1
  call void @vd_gc_frame_leave(ptr nonnull %3), !dbg !32
  br label %common.ret, !dbg !32

worker.continue2:                                 ; preds = %block1
  %8 = fcmp ogt double %0, 0x7FEFFFFFFFFFFFFF, !dbg !34
  br label %block2, !dbg !32
}

define double @__vd_2f6d61696e2e766f69643a3a656e65726779__research(%"/main.void::point" %0, ptr %1) local_unnamed_addr !dbg !35 {
block0:
  %2 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %3 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %3, ptr nonnull %2, i64 0)
  call void @vd_gc_poll()
  %4 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %4, label %common.ret, label %worker.continue

common.ret:                                       ; preds = %worker.continue, %block0, %error_return
  %common.ret.op = phi double [ 0.000000e+00, %error_return ], [ 0.000000e+00, %block0 ], [ %8, %worker.continue ]
  call void @vd_gc_frame_leave(ptr nonnull %3)
  ret double %common.ret.op, !dbg !42

worker.continue:                                  ; preds = %block0
  %.fca.0.extract = extractvalue %"/main.void::point" %0, 0, !dbg !43
  %.fca.1.extract = extractvalue %"/main.void::point" %0, 1, !dbg !43
  %5 = fmul double %.fca.0.extract, %.fca.0.extract, !dbg !44
  %6 = fmul double %.fca.1.extract, %.fca.1.extract, !dbg !45
  %7 = fadd double %5, %6, !dbg !46
  %8 = call double @__vd_2f407374646c69622f6d6174682e766f69643a3a737172743c333a31313a3e__research(double %7, ptr %1), !dbg !42
  %9 = load ptr, ptr %1, align 8, !dbg !42
  %.not = icmp eq ptr %9, null, !dbg !42
  br i1 %.not, label %common.ret, label %propagate_error, !dbg !42

propagate_error:                                  ; preds = %worker.continue
  %10 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !42
  %11 = load i32, ptr %10, align 4, !dbg !42
  %12 = icmp ult i32 %11, 32, !dbg !42
  br i1 %12, label %trace_caller, label %error_return, !dbg !42

trace_caller:                                     ; preds = %propagate_error
  %13 = getelementptr inbounds i8, ptr %1, i64 16, !dbg !42
  %14 = zext nneg i32 %11 to i64, !dbg !42
  %15 = getelementptr [32 x ptr], ptr %13, i64 0, i64 %14, !dbg !42
  store ptr @5, ptr %15, align 8, !dbg !42
  %16 = add nuw nsw i32 %11, 1, !dbg !42
  br label %error_return, !dbg !42

error_return:                                     ; preds = %propagate_error, %trace_caller
  %storemerge = phi i32 [ %16, %trace_caller ], [ 33, %propagate_error ], !dbg !42
  store i32 %storemerge, ptr %10, align 4, !dbg !42
  br label %common.ret, !dbg !42
}

define void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %0) local_unnamed_addr !dbg !47 {
block0:
  %1 = alloca [2 x ptr], align 8
  %2 = alloca ptr, align 8
  store ptr null, ptr %2, align 8
  %3 = alloca ptr, align 8
  store ptr null, ptr %3, align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca %"/main.void::point", align 8
  %.fca.1.gep192 = getelementptr inbounds i8, ptr %7, i64 8
  %8 = alloca ptr, align 8
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %7, i8 0, i64 16, i1 false)
  store ptr null, ptr %8, align 8
  %9 = alloca ptr, align 8
  store ptr null, ptr %9, align 8
  %10 = alloca ptr, align 8
  store ptr null, ptr %10, align 8
  %11 = alloca ptr, align 8
  store ptr null, ptr %11, align 8
  %12 = alloca ptr, align 8
  store ptr null, ptr %12, align 8
  %13 = alloca ptr, align 8
  store ptr null, ptr %13, align 8
  %14 = alloca ptr, align 8
  store ptr null, ptr %14, align 8
  %15 = alloca ptr, align 8
  store ptr null, ptr %15, align 8
  %16 = alloca ptr, align 8
  store ptr null, ptr %16, align 8
  %17 = alloca ptr, align 8
  store ptr null, ptr %17, align 8
  %18 = alloca ptr, align 8
  store ptr null, ptr %18, align 8
  %19 = alloca ptr, align 8
  store ptr null, ptr %19, align 8
  %20 = alloca ptr, align 8
  store ptr null, ptr %20, align 8
  %21 = alloca ptr, align 8
  store ptr null, ptr %21, align 8
  %22 = alloca [19 x { ptr, i64, ptr, i64 }], align 8
  store ptr %2, ptr %22, align 8
  %.fca.1.gep = getelementptr inbounds i8, ptr %22, i64 8
  store i64 8, ptr %.fca.1.gep, align 8
  %.fca.2.gep = getelementptr inbounds i8, ptr %22, i64 16
  store ptr @gc.offsets.1, ptr %.fca.2.gep, align 8
  %.fca.3.gep = getelementptr inbounds i8, ptr %22, i64 24
  store i64 1, ptr %.fca.3.gep, align 8
  %23 = getelementptr inbounds i8, ptr %22, i64 32
  store ptr %3, ptr %23, align 8
  %.fca.1.gep50 = getelementptr inbounds i8, ptr %22, i64 40
  store i64 8, ptr %.fca.1.gep50, align 8
  %.fca.2.gep52 = getelementptr inbounds i8, ptr %22, i64 48
  store ptr @gc.offsets.2, ptr %.fca.2.gep52, align 8
  %.fca.3.gep54 = getelementptr inbounds i8, ptr %22, i64 56
  store i64 1, ptr %.fca.3.gep54, align 8
  %24 = getelementptr inbounds i8, ptr %22, i64 64
  store ptr %4, ptr %24, align 8
  %.fca.1.gep58 = getelementptr inbounds i8, ptr %22, i64 72
  store i64 8, ptr %.fca.1.gep58, align 8
  %.fca.2.gep60 = getelementptr inbounds i8, ptr %22, i64 80
  store ptr @gc.offsets.3, ptr %.fca.2.gep60, align 8
  %.fca.3.gep62 = getelementptr inbounds i8, ptr %22, i64 88
  store i64 1, ptr %.fca.3.gep62, align 8
  %25 = getelementptr inbounds i8, ptr %22, i64 96
  store ptr %5, ptr %25, align 8
  %.fca.1.gep66 = getelementptr inbounds i8, ptr %22, i64 104
  store i64 8, ptr %.fca.1.gep66, align 8
  %.fca.2.gep68 = getelementptr inbounds i8, ptr %22, i64 112
  store ptr @gc.offsets.4, ptr %.fca.2.gep68, align 8
  %.fca.3.gep70 = getelementptr inbounds i8, ptr %22, i64 120
  store i64 1, ptr %.fca.3.gep70, align 8
  %26 = getelementptr inbounds i8, ptr %22, i64 128
  store ptr %6, ptr %26, align 8
  %.fca.1.gep74 = getelementptr inbounds i8, ptr %22, i64 136
  store i64 8, ptr %.fca.1.gep74, align 8
  %.fca.2.gep76 = getelementptr inbounds i8, ptr %22, i64 144
  store ptr @gc.offsets.5, ptr %.fca.2.gep76, align 8
  %.fca.3.gep78 = getelementptr inbounds i8, ptr %22, i64 152
  store i64 1, ptr %.fca.3.gep78, align 8
  %27 = getelementptr inbounds i8, ptr %22, i64 160
  store ptr %9, ptr %27, align 8
  %.fca.1.gep82 = getelementptr inbounds i8, ptr %22, i64 168
  store i64 8, ptr %.fca.1.gep82, align 8
  %.fca.2.gep84 = getelementptr inbounds i8, ptr %22, i64 176
  store ptr @gc.offsets.6, ptr %.fca.2.gep84, align 8
  %.fca.3.gep86 = getelementptr inbounds i8, ptr %22, i64 184
  store i64 1, ptr %.fca.3.gep86, align 8
  %28 = getelementptr inbounds i8, ptr %22, i64 192
  store ptr %8, ptr %28, align 8
  %.fca.1.gep90 = getelementptr inbounds i8, ptr %22, i64 200
  store i64 8, ptr %.fca.1.gep90, align 8
  %.fca.2.gep92 = getelementptr inbounds i8, ptr %22, i64 208
  store ptr @gc.offsets.7, ptr %.fca.2.gep92, align 8
  %.fca.3.gep94 = getelementptr inbounds i8, ptr %22, i64 216
  store i64 1, ptr %.fca.3.gep94, align 8
  %29 = getelementptr inbounds i8, ptr %22, i64 224
  store ptr %10, ptr %29, align 8
  %.fca.1.gep98 = getelementptr inbounds i8, ptr %22, i64 232
  store i64 8, ptr %.fca.1.gep98, align 8
  %.fca.2.gep100 = getelementptr inbounds i8, ptr %22, i64 240
  store ptr @gc.offsets.8, ptr %.fca.2.gep100, align 8
  %.fca.3.gep102 = getelementptr inbounds i8, ptr %22, i64 248
  store i64 1, ptr %.fca.3.gep102, align 8
  %30 = getelementptr inbounds i8, ptr %22, i64 256
  store ptr %11, ptr %30, align 8
  %.fca.1.gep106 = getelementptr inbounds i8, ptr %22, i64 264
  store i64 8, ptr %.fca.1.gep106, align 8
  %.fca.2.gep108 = getelementptr inbounds i8, ptr %22, i64 272
  store ptr @gc.offsets.9, ptr %.fca.2.gep108, align 8
  %.fca.3.gep110 = getelementptr inbounds i8, ptr %22, i64 280
  store i64 1, ptr %.fca.3.gep110, align 8
  %31 = getelementptr inbounds i8, ptr %22, i64 288
  store ptr %12, ptr %31, align 8
  %.fca.1.gep114 = getelementptr inbounds i8, ptr %22, i64 296
  store i64 8, ptr %.fca.1.gep114, align 8
  %.fca.2.gep116 = getelementptr inbounds i8, ptr %22, i64 304
  store ptr @gc.offsets.10, ptr %.fca.2.gep116, align 8
  %.fca.3.gep118 = getelementptr inbounds i8, ptr %22, i64 312
  store i64 1, ptr %.fca.3.gep118, align 8
  %32 = getelementptr inbounds i8, ptr %22, i64 320
  store ptr %13, ptr %32, align 8
  %.fca.1.gep122 = getelementptr inbounds i8, ptr %22, i64 328
  store i64 8, ptr %.fca.1.gep122, align 8
  %.fca.2.gep124 = getelementptr inbounds i8, ptr %22, i64 336
  store ptr @gc.offsets.11, ptr %.fca.2.gep124, align 8
  %.fca.3.gep126 = getelementptr inbounds i8, ptr %22, i64 344
  store i64 1, ptr %.fca.3.gep126, align 8
  %33 = getelementptr inbounds i8, ptr %22, i64 352
  store ptr %14, ptr %33, align 8
  %.fca.1.gep130 = getelementptr inbounds i8, ptr %22, i64 360
  store i64 8, ptr %.fca.1.gep130, align 8
  %.fca.2.gep132 = getelementptr inbounds i8, ptr %22, i64 368
  store ptr @gc.offsets.12, ptr %.fca.2.gep132, align 8
  %.fca.3.gep134 = getelementptr inbounds i8, ptr %22, i64 376
  store i64 1, ptr %.fca.3.gep134, align 8
  %34 = getelementptr inbounds i8, ptr %22, i64 384
  store ptr %15, ptr %34, align 8
  %.fca.1.gep138 = getelementptr inbounds i8, ptr %22, i64 392
  store i64 8, ptr %.fca.1.gep138, align 8
  %.fca.2.gep140 = getelementptr inbounds i8, ptr %22, i64 400
  store ptr @gc.offsets.13, ptr %.fca.2.gep140, align 8
  %.fca.3.gep142 = getelementptr inbounds i8, ptr %22, i64 408
  store i64 1, ptr %.fca.3.gep142, align 8
  %35 = getelementptr inbounds i8, ptr %22, i64 416
  store ptr %16, ptr %35, align 8
  %.fca.1.gep146 = getelementptr inbounds i8, ptr %22, i64 424
  store i64 8, ptr %.fca.1.gep146, align 8
  %.fca.2.gep148 = getelementptr inbounds i8, ptr %22, i64 432
  store ptr @gc.offsets.14, ptr %.fca.2.gep148, align 8
  %.fca.3.gep150 = getelementptr inbounds i8, ptr %22, i64 440
  store i64 1, ptr %.fca.3.gep150, align 8
  %36 = getelementptr inbounds i8, ptr %22, i64 448
  store ptr %17, ptr %36, align 8
  %.fca.1.gep154 = getelementptr inbounds i8, ptr %22, i64 456
  store i64 8, ptr %.fca.1.gep154, align 8
  %.fca.2.gep156 = getelementptr inbounds i8, ptr %22, i64 464
  store ptr @gc.offsets.15, ptr %.fca.2.gep156, align 8
  %.fca.3.gep158 = getelementptr inbounds i8, ptr %22, i64 472
  store i64 1, ptr %.fca.3.gep158, align 8
  %37 = getelementptr inbounds i8, ptr %22, i64 480
  store ptr %18, ptr %37, align 8
  %.fca.1.gep162 = getelementptr inbounds i8, ptr %22, i64 488
  store i64 8, ptr %.fca.1.gep162, align 8
  %.fca.2.gep164 = getelementptr inbounds i8, ptr %22, i64 496
  store ptr @gc.offsets.16, ptr %.fca.2.gep164, align 8
  %.fca.3.gep166 = getelementptr inbounds i8, ptr %22, i64 504
  store i64 1, ptr %.fca.3.gep166, align 8
  %38 = getelementptr inbounds i8, ptr %22, i64 512
  store ptr %19, ptr %38, align 8
  %.fca.1.gep170 = getelementptr inbounds i8, ptr %22, i64 520
  store i64 8, ptr %.fca.1.gep170, align 8
  %.fca.2.gep172 = getelementptr inbounds i8, ptr %22, i64 528
  store ptr @gc.offsets.17, ptr %.fca.2.gep172, align 8
  %.fca.3.gep174 = getelementptr inbounds i8, ptr %22, i64 536
  store i64 1, ptr %.fca.3.gep174, align 8
  %39 = getelementptr inbounds i8, ptr %22, i64 544
  store ptr %20, ptr %39, align 8
  %.fca.1.gep178 = getelementptr inbounds i8, ptr %22, i64 552
  store i64 8, ptr %.fca.1.gep178, align 8
  %.fca.2.gep180 = getelementptr inbounds i8, ptr %22, i64 560
  store ptr @gc.offsets.18, ptr %.fca.2.gep180, align 8
  %.fca.3.gep182 = getelementptr inbounds i8, ptr %22, i64 568
  store i64 1, ptr %.fca.3.gep182, align 8
  %40 = getelementptr inbounds i8, ptr %22, i64 576
  store ptr %21, ptr %40, align 8
  %.fca.1.gep186 = getelementptr inbounds i8, ptr %22, i64 584
  store i64 8, ptr %.fca.1.gep186, align 8
  %.fca.2.gep188 = getelementptr inbounds i8, ptr %22, i64 592
  store ptr @gc.offsets.19, ptr %.fca.2.gep188, align 8
  %.fca.3.gep190 = getelementptr inbounds i8, ptr %22, i64 600
  store i64 1, ptr %.fca.3.gep190, align 8
  %41 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %41, ptr nonnull %22, i64 19)
  call void @vd_gc_poll()
  %42 = call i1 @vd_worker_checkpoint(ptr %0)
  br i1 %42, label %common.ret, label %worker.continue

block1:                                           ; preds = %worker.continue29
  %43 = add i64 %.0311, 1, !dbg !50
  %44 = fadd double %.0275310, %72, !dbg !51
  call void @vd_gc_poll(), !dbg !50
  %45 = call i1 @vd_worker_checkpoint(ptr nonnull %0), !dbg !50
  br i1 %45, label %common.ret, label %worker.continue10, !dbg !50

block2:                                           ; preds = %numeric_valid14
  br i1 %59, label %common.ret, label %worker.continue16, !dbg !50

block4:                                           ; preds = %numeric_valid14
  br i1 %59, label %common.ret, label %worker.continue31, !dbg !50

common.ret:                                       ; preds = %worker.continue29, %call_success24, %block2, %block1, %numeric_valid39, %block4, %block1.preheader, %block0, %error_return41, %numeric_error38, %numeric_error36, %numeric_error34, %numeric_error32, %error_return26, %error_return, %numeric_error21, %numeric_error19, %numeric_error17, %numeric_error13, %numeric_error11, %numeric_error7, %numeric_error5, %numeric_error3, %numeric_error1, %numeric_error
  call void @vd_gc_frame_leave(ptr nonnull %41)
  ret void, !dbg !52

worker.continue:                                  ; preds = %block0
  call void @vd_value_array_new(ptr nonnull %10, ptr nonnull @array.element, i64 2, i32 1, ptr %0), !dbg !53
  %46 = load ptr, ptr %0, align 8, !dbg !53
  %.not = icmp eq ptr %46, null, !dbg !53
  br i1 %.not, label %numeric_valid, label %numeric_error, !dbg !53

numeric_error:                                    ; preds = %worker.continue
  store ptr @8, ptr %0, align 8, !dbg !53
  br label %common.ret, !dbg !53

numeric_valid:                                    ; preds = %worker.continue
  store double 3.000000e+00, ptr %7, align 8, !dbg !53
  store double 4.000000e+00, ptr %.fca.1.gep192, align 8, !dbg !53
  call void @vd_value_array_write(ptr nonnull %10, ptr nonnull @array.element, i64 0, i32 1, i64 0, ptr nonnull %7, i64 0, i32 0, i32 1, ptr nonnull %0), !dbg !53
  %47 = load ptr, ptr %0, align 8, !dbg !53
  %.not280 = icmp eq ptr %47, null, !dbg !53
  br i1 %.not280, label %numeric_valid2, label %numeric_error1, !dbg !53

numeric_error1:                                   ; preds = %numeric_valid
  store ptr @8, ptr %0, align 8, !dbg !53
  br label %common.ret, !dbg !53

numeric_valid2:                                   ; preds = %numeric_valid
  store double 5.000000e+00, ptr %7, align 8, !dbg !53
  store double 1.200000e+01, ptr %.fca.1.gep192, align 8, !dbg !53
  call void @vd_value_array_write(ptr nonnull %10, ptr nonnull @array.element, i64 0, i32 1, i64 1, ptr nonnull %7, i64 0, i32 0, i32 1, ptr nonnull %0), !dbg !53
  %48 = load ptr, ptr %0, align 8, !dbg !53
  %.not281 = icmp eq ptr %48, null, !dbg !53
  br i1 %.not281, label %numeric_valid4, label %numeric_error3, !dbg !53

numeric_error3:                                   ; preds = %numeric_valid2
  store ptr @8, ptr %0, align 8, !dbg !53
  br label %common.ret, !dbg !53

numeric_valid4:                                   ; preds = %numeric_valid2
  %49 = load ptr, ptr %10, align 8, !dbg !53
  store ptr %49, ptr %2, align 8, !dbg !54
  store ptr %49, ptr %11, align 8, !dbg !55
  store ptr %49, ptr %3, align 8, !dbg !50
  store ptr %49, ptr %12, align 8, !dbg !50
  %50 = call i64 @vd_value_array_count(ptr nonnull %12, ptr nonnull @array.element, ptr nonnull %0), !dbg !50
  %51 = load ptr, ptr %0, align 8, !dbg !50
  %.not282 = icmp eq ptr %51, null, !dbg !50
  br i1 %.not282, label %numeric_valid6, label %numeric_error5, !dbg !50

numeric_error5:                                   ; preds = %numeric_valid4
  store ptr @9, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

numeric_valid6:                                   ; preds = %numeric_valid4
  %52 = load ptr, ptr %3, align 8, !dbg !50
  store ptr %52, ptr %13, align 8, !dbg !50
  %53 = call i64 @vd_value_array_version(ptr nonnull %13, ptr nonnull @array.element, ptr nonnull %0), !dbg !50
  %54 = load ptr, ptr %0, align 8, !dbg !50
  %.not283 = icmp eq ptr %54, null, !dbg !50
  br i1 %.not283, label %block1.preheader, label %numeric_error7, !dbg !50

block1.preheader:                                 ; preds = %numeric_valid6
  call void @vd_gc_poll(), !dbg !50
  %55 = call i1 @vd_worker_checkpoint(ptr nonnull %0), !dbg !50
  br i1 %55, label %common.ret, label %worker.continue10, !dbg !50

numeric_error7:                                   ; preds = %numeric_valid6
  store ptr @9, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

worker.continue10:                                ; preds = %block1.preheader, %block1
  %.0311 = phi i64 [ %43, %block1 ], [ 0, %block1.preheader ]
  %.0275310 = phi double [ %44, %block1 ], [ 0.000000e+00, %block1.preheader ]
  %56 = load ptr, ptr %3, align 8, !dbg !50
  store ptr %56, ptr %14, align 8, !dbg !50
  %57 = call i64 @vd_value_array_version(ptr nonnull %14, ptr nonnull @array.element, ptr nonnull %0), !dbg !50
  %58 = load ptr, ptr %0, align 8, !dbg !50
  %.not284 = icmp eq ptr %58, null, !dbg !50
  br i1 %.not284, label %numeric_valid12, label %numeric_error11, !dbg !50

numeric_error11:                                  ; preds = %worker.continue10
  store ptr @9, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

numeric_valid12:                                  ; preds = %worker.continue10
  %.not285 = icmp eq i64 %57, %53, !dbg !50
  br i1 %.not285, label %numeric_valid14, label %numeric_error13, !dbg !50

numeric_error13:                                  ; preds = %numeric_valid12
  store ptr @10, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

numeric_valid14:                                  ; preds = %numeric_valid12
  %.not286 = icmp eq i64 %.0311, %50, !dbg !50
  call void @vd_gc_poll(), !dbg !50
  %59 = call i1 @vd_worker_checkpoint(ptr nonnull %0), !dbg !50
  br i1 %.not286, label %block4, label %block2, !dbg !50

worker.continue16:                                ; preds = %block2
  %60 = load ptr, ptr %3, align 8, !dbg !50
  store ptr %60, ptr %15, align 8, !dbg !50
  %61 = call i64 @vd_value_array_count(ptr nonnull %15, ptr nonnull @array.element, ptr nonnull %0), !dbg !50
  %62 = load ptr, ptr %0, align 8, !dbg !50
  %.not292 = icmp eq ptr %62, null, !dbg !50
  br i1 %.not292, label %numeric_valid18, label %numeric_error17, !dbg !50

numeric_error17:                                  ; preds = %worker.continue16
  store ptr @12, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

numeric_valid18:                                  ; preds = %worker.continue16
  %63 = icmp slt i64 %.0311, 0, !dbg !50
  %64 = select i1 %63, i64 %61, i64 0, !dbg !50
  %65 = add i64 %64, %.0311, !dbg !50
  %.not293 = icmp ult i64 %65, %61, !dbg !50
  br i1 %.not293, label %numeric_valid20, label %numeric_error19, !dbg !50

numeric_error19:                                  ; preds = %numeric_valid18
  store ptr @11, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

numeric_valid20:                                  ; preds = %numeric_valid18
  call void @vd_value_array_read(ptr nonnull %7, ptr nonnull %15, ptr nonnull @array.element, i64 0, i32 1, i64 %65, ptr nonnull %0), !dbg !50
  %66 = load ptr, ptr %0, align 8, !dbg !50
  %.not294 = icmp eq ptr %66, null, !dbg !50
  br i1 %.not294, label %numeric_valid22, label %numeric_error21, !dbg !50

numeric_error21:                                  ; preds = %numeric_valid20
  store ptr @12, ptr %0, align 8, !dbg !50
  br label %common.ret, !dbg !50

numeric_valid22:                                  ; preds = %numeric_valid20
  %.fca.0.load = load double, ptr %7, align 8, !dbg !50
  %.fca.0.insert = insertvalue %"/main.void::point" poison, double %.fca.0.load, 0, !dbg !50
  %.fca.1.load = load double, ptr %.fca.1.gep192, align 8, !dbg !50
  %.fca.1.insert = insertvalue %"/main.void::point" %.fca.0.insert, double %.fca.1.load, 1, !dbg !50
  %67 = call double @__vd_2f6d61696e2e766f69643a3a656e65726779__research(%"/main.void::point" %.fca.1.insert, ptr nonnull %0), !dbg !56
  %68 = load ptr, ptr %0, align 8, !dbg !56
  %.not295 = icmp eq ptr %68, null, !dbg !56
  br i1 %.not295, label %call_success, label %propagate_error, !dbg !56

propagate_error:                                  ; preds = %numeric_valid22
  %69 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !56
  %70 = load i32, ptr %69, align 4, !dbg !56
  %71 = icmp ult i32 %70, 32, !dbg !56
  br i1 %71, label %trace_caller, label %error_return, !dbg !56

call_success:                                     ; preds = %numeric_valid22
  %72 = call double @__vd_2f407374646c69622f6d6174682e766f69643a3a636c616d703c333a31313a3e__research(double %67, double 0.000000e+00, double 1.000000e+02, ptr nonnull %0), !dbg !57
  %73 = load ptr, ptr %0, align 8, !dbg !57
  %.not296 = icmp eq ptr %73, null, !dbg !57
  br i1 %.not296, label %call_success24, label %propagate_error23, !dbg !57

trace_caller:                                     ; preds = %propagate_error
  %74 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !56
  %75 = zext nneg i32 %70 to i64, !dbg !56
  %76 = getelementptr [32 x ptr], ptr %74, i64 0, i64 %75, !dbg !56
  store ptr @13, ptr %76, align 8, !dbg !56
  %77 = add nuw nsw i32 %70, 1, !dbg !56
  br label %error_return, !dbg !56

error_return:                                     ; preds = %propagate_error, %trace_caller
  %storemerge298 = phi i32 [ %77, %trace_caller ], [ 33, %propagate_error ], !dbg !56
  store i32 %storemerge298, ptr %69, align 4, !dbg !56
  br label %common.ret, !dbg !56

propagate_error23:                                ; preds = %call_success
  %78 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !57
  %79 = load i32, ptr %78, align 4, !dbg !57
  %80 = icmp ult i32 %79, 32, !dbg !57
  br i1 %80, label %trace_caller25, label %error_return26, !dbg !57

call_success24:                                   ; preds = %call_success
  call void @vd_gc_poll(), !dbg !51
  %81 = call i1 @vd_worker_checkpoint(ptr nonnull %0), !dbg !51
  br i1 %81, label %common.ret, label %worker.continue29, !dbg !51

trace_caller25:                                   ; preds = %propagate_error23
  %82 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !57
  %83 = zext nneg i32 %79 to i64, !dbg !57
  %84 = getelementptr [32 x ptr], ptr %82, i64 0, i64 %83, !dbg !57
  store ptr @14, ptr %84, align 8, !dbg !57
  %85 = add nuw nsw i32 %79, 1, !dbg !57
  br label %error_return26, !dbg !57

error_return26:                                   ; preds = %propagate_error23, %trace_caller25
  %storemerge297 = phi i32 [ %85, %trace_caller25 ], [ 33, %propagate_error23 ], !dbg !57
  store i32 %storemerge297, ptr %78, align 4, !dbg !57
  br label %common.ret, !dbg !57

worker.continue29:                                ; preds = %call_success24
  call void @vd_gc_poll(), !dbg !58
  %86 = call i1 @vd_worker_checkpoint(ptr nonnull %0), !dbg !58
  br i1 %86, label %common.ret, label %block1, !dbg !58

worker.continue31:                                ; preds = %block4
  %87 = bitcast double %.0275310 to i64, !dbg !59
  %88 = call i1 @vd_scalar_display(ptr nonnull %16, i32 9, i64 %87, ptr null, ptr null, i1 false, ptr nonnull %0), !dbg !59
  %89 = load ptr, ptr %0, align 8, !dbg !59
  %.not287 = icmp eq ptr %89, null, !dbg !59
  br i1 %.not287, label %numeric_valid33, label %numeric_error32, !dbg !59

numeric_error32:                                  ; preds = %worker.continue31
  store ptr @15, ptr %0, align 8, !dbg !59
  br label %common.ret, !dbg !59

numeric_valid33:                                  ; preds = %worker.continue31
  %90 = load ptr, ptr %16, align 8, !dbg !59
  store ptr %90, ptr %4, align 8, !dbg !59
  call void @vd_string_literal(ptr nonnull %17, ptr nonnull @16, i64 1, ptr nonnull %0), !dbg !58
  %91 = load ptr, ptr %0, align 8, !dbg !58
  %.not288 = icmp eq ptr %91, null, !dbg !58
  br i1 %.not288, label %numeric_valid35, label %numeric_error34, !dbg !58

numeric_error34:                                  ; preds = %numeric_valid33
  store ptr @18, ptr %0, align 8, !dbg !58
  br label %common.ret, !dbg !58

numeric_valid35:                                  ; preds = %numeric_valid33
  %92 = load ptr, ptr %17, align 8, !dbg !58
  store ptr %92, ptr %5, align 8, !dbg !58
  call void @vd_string_literal(ptr nonnull %18, ptr nonnull @17, i64 1, ptr nonnull %0), !dbg !58
  %93 = load ptr, ptr %0, align 8, !dbg !58
  %.not289 = icmp eq ptr %93, null, !dbg !58
  br i1 %.not289, label %numeric_valid37, label %numeric_error36, !dbg !58

numeric_error36:                                  ; preds = %numeric_valid35
  store ptr @18, ptr %0, align 8, !dbg !58
  br label %common.ret, !dbg !58

numeric_valid37:                                  ; preds = %numeric_valid35
  %94 = load ptr, ptr %18, align 8, !dbg !58
  store ptr %94, ptr %6, align 8, !dbg !58
  %95 = load ptr, ptr %4, align 8, !dbg !58
  store ptr %95, ptr %19, align 8, !dbg !58
  store ptr %94, ptr %20, align 8, !dbg !58
  store ptr %19, ptr %1, align 8, !dbg !58
  %96 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !58
  store ptr %20, ptr %96, align 8, !dbg !58
  call void @vd_string_join(ptr nonnull %21, ptr nonnull %1, i64 2, ptr nonnull %0), !dbg !58
  %97 = load ptr, ptr %0, align 8, !dbg !58
  %.not290 = icmp eq ptr %97, null, !dbg !58
  br i1 %.not290, label %numeric_valid39, label %numeric_error38, !dbg !58

numeric_error38:                                  ; preds = %numeric_valid37
  store ptr @19, ptr %0, align 8, !dbg !58
  br label %common.ret, !dbg !58

numeric_valid39:                                  ; preds = %numeric_valid37
  %98 = load ptr, ptr %21, align 8, !dbg !58
  call void @vd_console_print(ptr %98, i64 1, i1 false, ptr nonnull %0), !dbg !58
  %99 = load ptr, ptr %0, align 8, !dbg !58
  %.not291 = icmp eq ptr %99, null, !dbg !58
  br i1 %.not291, label %common.ret, label %selected.failure, !dbg !58

selected.failure:                                 ; preds = %numeric_valid39
  %100 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !58
  %101 = load i32, ptr %100, align 4, !dbg !58
  %102 = icmp ult i32 %101, 32, !dbg !58
  br i1 %102, label %trace_caller40, label %error_return41, !dbg !58

trace_caller40:                                   ; preds = %selected.failure
  %103 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !58
  %104 = zext nneg i32 %101 to i64, !dbg !58
  %105 = getelementptr [32 x ptr], ptr %103, i64 0, i64 %104, !dbg !58
  store ptr @20, ptr %105, align 8, !dbg !58
  %106 = add nuw nsw i32 %101, 1, !dbg !58
  br label %error_return41, !dbg !58

error_return41:                                   ; preds = %selected.failure, %trace_caller40
  %storemerge = phi i32 [ %106, %trace_caller40 ], [ 33, %selected.failure ], !dbg !58
  store i32 %storemerge, ptr %100, align 4, !dbg !58
  br label %common.ret, !dbg !58
}

define noundef i32 @__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research(i32 %0, ptr %1) local_unnamed_addr !dbg !60 {
block0:
  %2 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %3 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %3, ptr nonnull %2, i64 0)
  call void @vd_gc_poll()
  %4 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %4, label %common.ret, label %worker.continue

common.ret:                                       ; preds = %worker.continue, %block0, %error_return
  call void @vd_gc_frame_leave(ptr nonnull %3)
  ret i32 0, !dbg !64

worker.continue:                                  ; preds = %block0
  call void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %1), !dbg !64
  %5 = load ptr, ptr %1, align 8, !dbg !64
  %.not = icmp eq ptr %5, null, !dbg !64
  br i1 %.not, label %common.ret, label %propagate_error, !dbg !64

propagate_error:                                  ; preds = %worker.continue
  %6 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !64
  %7 = load i32, ptr %6, align 4, !dbg !64
  %8 = icmp ult i32 %7, 32, !dbg !64
  br i1 %8, label %trace_caller, label %error_return, !dbg !64

trace_caller:                                     ; preds = %propagate_error
  %9 = getelementptr inbounds i8, ptr %1, i64 16, !dbg !64
  %10 = zext nneg i32 %7 to i64, !dbg !64
  %11 = getelementptr [32 x ptr], ptr %9, i64 0, i64 %10, !dbg !64
  store ptr @21, ptr %11, align 8, !dbg !64
  %12 = add nuw nsw i32 %7, 1, !dbg !64
  br label %error_return, !dbg !64

error_return:                                     ; preds = %propagate_error, %trace_caller
  %storemerge = phi i32 [ %12, %trace_caller ], [ 33, %propagate_error ], !dbg !64
  store i32 %storemerge, ptr %6, align 4, !dbg !64
  br label %common.ret, !dbg !64
}

declare void @vd_gc_frame_enter(ptr, ptr, i64) local_unnamed_addr

declare void @vd_gc_poll() local_unnamed_addr

declare i1 @vd_worker_checkpoint(ptr) local_unnamed_addr

declare void @vd_gc_frame_leave(ptr) local_unnamed_addr

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #0

declare void @vd_value_array_new(ptr, ptr, i64, i32, ptr) local_unnamed_addr

declare void @vd_value_array_write(ptr, ptr, i64, i32, i64, ptr, i64, i32, i32, ptr) local_unnamed_addr

declare i64 @vd_value_array_count(ptr, ptr, ptr) local_unnamed_addr

declare i64 @vd_value_array_version(ptr, ptr, ptr) local_unnamed_addr

declare void @vd_value_array_read(ptr, ptr, ptr, i64, i32, i64, ptr) local_unnamed_addr

declare i1 @vd_scalar_display(ptr, i32, i64, ptr, ptr, i1, ptr) local_unnamed_addr

declare void @vd_string_literal(ptr, ptr, i64, ptr) local_unnamed_addr

declare void @vd_string_join(ptr, ptr, i64, ptr) local_unnamed_addr

declare void @vd_console_print(ptr, i64, i1, ptr) local_unnamed_addr

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr nocapture) #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #2

attributes #0 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #1 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #2 = { nocallback nofree nounwind willreturn memory(argmem: write) }

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2}

!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "VOID source compiler", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "main.void", directory: "/tmp/void-compiler-health-0w02e0mg/fixtures/gameplay")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = distinct !DISubprogram(name: "sqrt", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a737172743c333a31313a3e__research", scope: !4, file: !4, line: 359, type: !5, scopeLine: 359, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!4 = !DIFile(filename: "math.void", directory: "/home/shmellyorc/Documents/Void.Language/stdlib")
!5 = !DISubroutineType(types: !6)
!6 = !{!7, !7}
!7 = !DIBasicType(name: "f64", size: 64, encoding: DW_ATE_float)
!8 = !DILocation(line: 362, column: 14, scope: !3)
!9 = !DILocation(line: 0, scope: !3)
!10 = !DILocation(line: 363, column: 16, scope: !3)
!11 = !DILocation(line: 364, column: 14, scope: !3)
!12 = !DILocation(line: 362, column: 32, scope: !3)
!13 = !DILocation(line: 365, column: 16, scope: !3)
!14 = !DILocation(line: 367, column: 16, scope: !3)
!15 = !DILocation(line: 366, column: 8, scope: !3)
!16 = !DILocation(line: 368, column: 12, scope: !3)
!17 = distinct !DISubprogram(name: "clamp", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a636c616d703c333a31313a3e__research", scope: !4, file: !4, line: 89, type: !18, scopeLine: 89, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!18 = !DISubroutineType(types: !19)
!19 = !{!7, !7, !7, !7}
!20 = !DILocation(line: 90, column: 14, scope: !17)
!21 = !DILocation(line: 90, column: 14, scope: !22, inlinedAt: !23)
!22 = distinct !DISubprogram(name: "f64::clamp", linkageName: "__vd_246e756d657269633a3a6636343a3a636c616d70__research", scope: !4, file: !4, line: 90, type: !18, scopeLine: 90, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!23 = distinct !DILocation(line: 90, column: 14, scope: !17)
!24 = distinct !DISubprogram(name: "_nan", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a5f6e616e3c333a31313a3e__research", scope: !4, file: !4, line: 22, type: !25, scopeLine: 22, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition, unit: !0)
!25 = !DISubroutineType(types: !26)
!26 = !{!7}
!27 = !DILocation(line: 24, column: 17, scope: !24)
!28 = distinct !DISubprogram(name: "is_infinite", linkageName: "__vd_2f407374646c69622f6d6174682e766f69643a3a69735f696e66696e6974653c333a31313a3e__research", scope: !4, file: !4, line: 116, type: !29, scopeLine: 116, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!29 = !DISubroutineType(types: !30)
!30 = !{!31, !7}
!31 = !DIBasicType(name: "bool", size: 1, encoding: DW_ATE_boolean)
!32 = !DILocation(line: 118, column: 32, scope: !28)
!33 = !DILocation(line: 118, column: 18, scope: !28)
!34 = !DILocation(line: 118, column: 41, scope: !28)
!35 = distinct !DISubprogram(name: "energy", linkageName: "__vd_2f6d61696e2e766f69643a3a656e65726779__research", scope: !1, file: !1, line: 5, type: !36, scopeLine: 5, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!36 = !DISubroutineType(types: !37)
!37 = !{!7, !38}
!38 = !DICompositeType(tag: DW_TAG_structure_type, name: "readonly /main.void::point", scope: !1, file: !1, size: 128, align: 64, elements: !39)
!39 = !{!40, !41}
!40 = !DIDerivedType(tag: DW_TAG_member, name: "x", scope: !1, file: !1, baseType: !7, size: 64, align: 64)
!41 = !DIDerivedType(tag: DW_TAG_member, name: "y", scope: !1, file: !1, baseType: !7, size: 64, align: 64, offset: 64)
!42 = !DILocation(line: 6, column: 14, scope: !35)
!43 = !DILocation(line: 5, column: 19, scope: !35)
!44 = !DILocation(line: 6, column: 23, scope: !35)
!45 = !DILocation(line: 6, column: 35, scope: !35)
!46 = !DILocation(line: 6, column: 29, scope: !35)
!47 = distinct !DISubprogram(name: "main", linkageName: "__vd_2f6d61696e2e766f69643a3a6d61696e__research", scope: !1, file: !1, line: 7, type: !48, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!48 = !DISubroutineType(types: !49)
!49 = !{null}
!50 = !DILocation(line: 10, column: 5, scope: !47)
!51 = !DILocation(line: 11, column: 9, scope: !47)
!52 = !DILocation(line: 0, scope: !47)
!53 = !DILocation(line: 8, column: 27, scope: !47)
!54 = !DILocation(line: 8, column: 9, scope: !47)
!55 = !DILocation(line: 10, column: 14, scope: !47)
!56 = !DILocation(line: 11, column: 26, scope: !47)
!57 = !DILocation(line: 11, column: 20, scope: !47)
!58 = !DILocation(line: 12, column: 5, scope: !47)
!59 = !DILocation(line: 12, column: 11, scope: !47)
!60 = distinct !DISubprogram(name: "$app_adapter", linkageName: "__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research", scope: !1, file: !1, line: 7, type: !61, scopeLine: 7, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!61 = !DISubroutineType(types: !62)
!62 = !{!63, !63}
!63 = !DIBasicType(name: "i32", size: 32, encoding: DW_ATE_signed)
!64 = !DILocation(line: 7, column: 6, scope: !60)
