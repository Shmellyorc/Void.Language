; ModuleID = '/main.void'
source_filename = "/main.void"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@async.generation = private constant i8 0
@__vd_types__research = constant [0 x { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 }] zeroinitializer
@__vd_type_count__research = constant i64 0
@dynamic_type_keys = private constant [0 x ptr] zeroinitializer
@__vd_witnesses__research = constant [0 x { ptr, ptr, ptr, ptr }] zeroinitializer
@__vd_witness_count__research = constant i64 0
@interface_binding_keys = private constant [0 x ptr] zeroinitializer
@gc.offsets = private constant [1 x i64] zeroinitializer
@gc.offsets.1 = private constant [1 x i64] zeroinitializer
@gc.offsets.2 = private constant [1 x i64] zeroinitializer
@gc.offsets.3 = private constant [1 x i64] zeroinitializer
@gc.offsets.4 = private constant [1 x i64] zeroinitializer
@gc.offsets.5 = private constant [1 x i64] zeroinitializer
@gc.offsets.6 = private constant [1 x i64] zeroinitializer
@gc.offsets.7 = private constant [1 x i64] zeroinitializer
@gc.offsets.8 = private constant [1 x i64] zeroinitializer
@0 = private unnamed_addr constant [160 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:11: runtime error: Display operation failed\0A    print(7)\0A          ^\0AIn function /main.void::main\0A\00", align 1
@1 = private unnamed_addr constant [2 x i8] c" \00", align 1
@2 = private unnamed_addr constant [152 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: runtime error: String operation failed\0A    print(7)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@3 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@4 = private unnamed_addr constant [152 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: runtime error: String operation failed\0A    print(7)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@5 = private unnamed_addr constant [149 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: runtime error: Interpolation failed\0A    print(7)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@6 = private unnamed_addr constant [125 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: source call\0A    print(7)\0A    ^\0A\00", align 1
@7 = private unnamed_addr constant [114 x i8] c"Called from /main.void::$app_adapter\0A/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:1:6: source call\0A\00", align 1

define void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %0) !dbg !3 {
block0:
  %1 = alloca [2 x ptr], align 8
  %2 = alloca i32, align 4
  store i32 0, ptr %2, align 4
  %3 = alloca ptr, align 8
  store ptr null, ptr %3, align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %3, 0
  %7 = insertvalue { ptr, i64, ptr, i64 } %6, i64 8, 1
  %8 = insertvalue { ptr, i64, ptr, i64 } %7, ptr @gc.offsets, 2
  %9 = insertvalue { ptr, i64, ptr, i64 } %8, i64 1, 3
  %10 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %4, 0
  %11 = insertvalue { ptr, i64, ptr, i64 } %10, i64 8, 1
  %12 = insertvalue { ptr, i64, ptr, i64 } %11, ptr @gc.offsets.1, 2
  %13 = insertvalue { ptr, i64, ptr, i64 } %12, i64 1, 3
  %14 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %5, 0
  %15 = insertvalue { ptr, i64, ptr, i64 } %14, i64 8, 1
  %16 = insertvalue { ptr, i64, ptr, i64 } %15, ptr @gc.offsets.2, 2
  %17 = insertvalue { ptr, i64, ptr, i64 } %16, i64 1, 3
  %18 = alloca ptr, align 8
  store ptr null, ptr %18, align 8
  %19 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %18, 0
  %20 = insertvalue { ptr, i64, ptr, i64 } %19, i64 8, 1
  %21 = insertvalue { ptr, i64, ptr, i64 } %20, ptr @gc.offsets.3, 2
  %22 = insertvalue { ptr, i64, ptr, i64 } %21, i64 1, 3
  %23 = alloca ptr, align 8
  store ptr null, ptr %23, align 8
  %24 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %23, 0
  %25 = insertvalue { ptr, i64, ptr, i64 } %24, i64 8, 1
  %26 = insertvalue { ptr, i64, ptr, i64 } %25, ptr @gc.offsets.4, 2
  %27 = insertvalue { ptr, i64, ptr, i64 } %26, i64 1, 3
  %28 = alloca ptr, align 8
  store ptr null, ptr %28, align 8
  %29 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %28, 0
  %30 = insertvalue { ptr, i64, ptr, i64 } %29, i64 8, 1
  %31 = insertvalue { ptr, i64, ptr, i64 } %30, ptr @gc.offsets.5, 2
  %32 = insertvalue { ptr, i64, ptr, i64 } %31, i64 1, 3
  %33 = alloca ptr, align 8
  store ptr null, ptr %33, align 8
  %34 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %33, 0
  %35 = insertvalue { ptr, i64, ptr, i64 } %34, i64 8, 1
  %36 = insertvalue { ptr, i64, ptr, i64 } %35, ptr @gc.offsets.6, 2
  %37 = insertvalue { ptr, i64, ptr, i64 } %36, i64 1, 3
  %38 = alloca ptr, align 8
  store ptr null, ptr %38, align 8
  %39 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %38, 0
  %40 = insertvalue { ptr, i64, ptr, i64 } %39, i64 8, 1
  %41 = insertvalue { ptr, i64, ptr, i64 } %40, ptr @gc.offsets.7, 2
  %42 = insertvalue { ptr, i64, ptr, i64 } %41, i64 1, 3
  %43 = alloca ptr, align 8
  store ptr null, ptr %43, align 8
  %44 = insertvalue { ptr, i64, ptr, i64 } undef, ptr %43, 0
  %45 = insertvalue { ptr, i64, ptr, i64 } %44, i64 8, 1
  %46 = insertvalue { ptr, i64, ptr, i64 } %45, ptr @gc.offsets.8, 2
  %47 = insertvalue { ptr, i64, ptr, i64 } %46, i64 1, 3
  %48 = alloca [9 x { ptr, i64, ptr, i64 }], align 8
  %49 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 0
  store { ptr, i64, ptr, i64 } %9, ptr %49, align 8
  %50 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 1
  store { ptr, i64, ptr, i64 } %13, ptr %50, align 8
  %51 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 2
  store { ptr, i64, ptr, i64 } %17, ptr %51, align 8
  %52 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 3
  store { ptr, i64, ptr, i64 } %22, ptr %52, align 8
  %53 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 4
  store { ptr, i64, ptr, i64 } %27, ptr %53, align 8
  %54 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 5
  store { ptr, i64, ptr, i64 } %32, ptr %54, align 8
  %55 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 6
  store { ptr, i64, ptr, i64 } %37, ptr %55, align 8
  %56 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 7
  store { ptr, i64, ptr, i64 } %42, ptr %56, align 8
  %57 = getelementptr inbounds [9 x { ptr, i64, ptr, i64 }], ptr %48, i32 0, i32 8
  store { ptr, i64, ptr, i64 } %47, ptr %57, align 8
  %58 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %58, ptr %48, i64 9)
  call void @vd_gc_poll()
  %59 = call i1 @vd_worker_checkpoint(ptr %0)
  br i1 %59, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %58)
  ret void

worker.continue:                                  ; preds = %block0
  store i32 7, ptr %2, align 4, !dbg !6
  %60 = load i32, ptr %2, align 4, !dbg !6
  %61 = zext i32 %60 to i64, !dbg !6
  %62 = call i1 @vd_scalar_display(ptr %18, i32 2, i64 %61, ptr null, ptr null, i1 false, ptr %0), !dbg !6
  %63 = load ptr, ptr %0, align 8, !dbg !6
  %64 = icmp ne ptr %63, null, !dbg !6
  br i1 %64, label %numeric_error, label %numeric_valid, !dbg !6

numeric_error:                                    ; preds = %worker.continue
  %65 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !6
  store ptr @0, ptr %65, align 8, !dbg !6
  call void @vd_gc_frame_leave(ptr %58), !dbg !6
  ret void, !dbg !6

numeric_valid:                                    ; preds = %worker.continue
  %66 = load ptr, ptr %18, align 8, !dbg !6
  store ptr %66, ptr %18, align 8, !dbg !6
  store ptr %66, ptr %3, align 8, !dbg !6
  call void @vd_string_literal(ptr %23, ptr @1, i64 1, ptr %0), !dbg !7
  %67 = load ptr, ptr %23, align 8, !dbg !7
  %68 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !7
  %69 = load ptr, ptr %68, align 8, !dbg !7
  %70 = icmp ne ptr %69, null, !dbg !7
  br i1 %70, label %numeric_error1, label %numeric_valid2, !dbg !7

numeric_error1:                                   ; preds = %numeric_valid
  %71 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !7
  store ptr @2, ptr %71, align 8, !dbg !7
  call void @vd_gc_frame_leave(ptr %58), !dbg !7
  ret void, !dbg !7

numeric_valid2:                                   ; preds = %numeric_valid
  store ptr %67, ptr %23, align 8, !dbg !7
  store ptr %67, ptr %4, align 8, !dbg !7
  call void @vd_string_literal(ptr %28, ptr @3, i64 1, ptr %0), !dbg !7
  %72 = load ptr, ptr %28, align 8, !dbg !7
  %73 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !7
  %74 = load ptr, ptr %73, align 8, !dbg !7
  %75 = icmp ne ptr %74, null, !dbg !7
  br i1 %75, label %numeric_error3, label %numeric_valid4, !dbg !7

numeric_error3:                                   ; preds = %numeric_valid2
  %76 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !7
  store ptr @4, ptr %76, align 8, !dbg !7
  call void @vd_gc_frame_leave(ptr %58), !dbg !7
  ret void, !dbg !7

numeric_valid4:                                   ; preds = %numeric_valid2
  store ptr %72, ptr %28, align 8, !dbg !7
  store ptr %72, ptr %5, align 8, !dbg !7
  %77 = load ptr, ptr %3, align 8, !dbg !7
  store ptr %77, ptr %33, align 8, !dbg !7
  %78 = load ptr, ptr %5, align 8, !dbg !7
  store ptr %78, ptr %38, align 8, !dbg !7
  %79 = getelementptr inbounds [2 x ptr], ptr %1, i32 0, i32 0, !dbg !7
  store ptr %33, ptr %79, align 8, !dbg !7
  %80 = getelementptr inbounds [2 x ptr], ptr %1, i32 0, i32 1, !dbg !7
  store ptr %38, ptr %80, align 8, !dbg !7
  call void @vd_string_join(ptr %43, ptr %1, i64 2, ptr %0), !dbg !7
  %81 = load ptr, ptr %0, align 8, !dbg !7
  %82 = icmp ne ptr %81, null, !dbg !7
  br i1 %82, label %numeric_error5, label %numeric_valid6, !dbg !7

numeric_error5:                                   ; preds = %numeric_valid4
  %83 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 0, !dbg !7
  store ptr @5, ptr %83, align 8, !dbg !7
  call void @vd_gc_frame_leave(ptr %58), !dbg !7
  ret void, !dbg !7

numeric_valid6:                                   ; preds = %numeric_valid4
  %84 = load ptr, ptr %43, align 8, !dbg !7
  store ptr %84, ptr %43, align 8, !dbg !7
  call void @vd_console_print(ptr %84, i64 1, i1 false, ptr %0), !dbg !7
  %85 = load ptr, ptr %0, align 8, !dbg !7
  %86 = icmp ne ptr %85, null, !dbg !7
  br i1 %86, label %selected.failure, label %selected.valid, !dbg !7

selected.failure:                                 ; preds = %numeric_valid6
  %87 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 1, !dbg !7
  %88 = load i32, ptr %87, align 4, !dbg !7
  %89 = icmp ult i32 %88, 32, !dbg !7
  br i1 %89, label %trace_caller, label %trace_limit, !dbg !7

selected.valid:                                   ; preds = %numeric_valid6
  call void @vd_gc_frame_leave(ptr %58), !dbg !7
  ret void, !dbg !7

trace_caller:                                     ; preds = %selected.failure
  %90 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %0, i32 0, i32 2, !dbg !7
  %91 = getelementptr [32 x ptr], ptr %90, i32 0, i32 %88, !dbg !7
  store ptr @6, ptr %91, align 8, !dbg !7
  %92 = add i32 %88, 1, !dbg !7
  store i32 %92, ptr %87, align 4, !dbg !7
  br label %error_return, !dbg !7

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %58), !dbg !7
  ret void, !dbg !7

trace_limit:                                      ; preds = %selected.failure
  store i32 33, ptr %87, align 4, !dbg !7
  br label %error_return, !dbg !7
}

define i32 @__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research(i32 %0, ptr %1) !dbg !8 {
block0:
  %2 = alloca i32, align 4
  store i32 0, ptr %2, align 4
  %3 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %4 = alloca i8, i64 32, align 8
  call void @vd_gc_frame_enter(ptr %4, ptr %3, i64 0)
  call void @vd_gc_poll()
  %5 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %5, label %worker.cancelled, label %worker.continue

worker.cancelled:                                 ; preds = %block0
  call void @vd_gc_frame_leave(ptr %4)
  ret i32 0

worker.continue:                                  ; preds = %block0
  call void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %1), !dbg !12
  %6 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 0, !dbg !12
  %7 = load ptr, ptr %6, align 8, !dbg !12
  %8 = icmp ne ptr %7, null, !dbg !12
  br i1 %8, label %propagate_error, label %call_success, !dbg !12

propagate_error:                                  ; preds = %worker.continue
  %9 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 1, !dbg !12
  %10 = load i32, ptr %9, align 4, !dbg !12
  %11 = icmp ult i32 %10, 32, !dbg !12
  br i1 %11, label %trace_caller, label %trace_limit, !dbg !12

call_success:                                     ; preds = %worker.continue
  call void @vd_gc_frame_leave(ptr %4), !dbg !12
  ret i32 0, !dbg !12

trace_caller:                                     ; preds = %propagate_error
  %12 = getelementptr inbounds { ptr, i32, [32 x ptr] }, ptr %1, i32 0, i32 2, !dbg !12
  %13 = getelementptr [32 x ptr], ptr %12, i32 0, i32 %10, !dbg !12
  store ptr @7, ptr %13, align 8, !dbg !12
  %14 = add i32 %10, 1, !dbg !12
  store i32 %14, ptr %9, align 4, !dbg !12
  br label %error_return, !dbg !12

error_return:                                     ; preds = %trace_caller, %trace_limit
  call void @vd_gc_frame_leave(ptr %4), !dbg !12
  ret i32 0, !dbg !12

trace_limit:                                      ; preds = %propagate_error
  store i32 33, ptr %9, align 4, !dbg !12
  br label %error_return, !dbg !12
}

declare void @vd_gc_frame_enter(ptr, ptr, i64)

declare void @vd_gc_poll()

declare i1 @vd_worker_checkpoint(ptr)

declare void @vd_gc_frame_leave(ptr)

declare i1 @vd_scalar_display(ptr, i32, i64, ptr, ptr, i1, ptr)

declare void @vd_string_literal(ptr, ptr, i64, ptr)

declare void @vd_string_join(ptr, ptr, i64, ptr)

declare void @vd_console_print(ptr, i64, i1, ptr)

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2}

!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "VOID source compiler", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "main.void", directory: "/tmp/void-compiler-health-0w02e0mg/fixtures/tiny")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = distinct !DISubprogram(name: "main", linkageName: "__vd_2f6d61696e2e766f69643a3a6d61696e__research", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!4 = !DISubroutineType(types: !5)
!5 = !{null}
!6 = !DILocation(line: 2, column: 11, scope: !3)
!7 = !DILocation(line: 2, column: 5, scope: !3)
!8 = distinct !DISubprogram(name: "$app_adapter", linkageName: "__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research", scope: !1, file: !1, line: 1, type: !9, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!9 = !DISubroutineType(types: !10)
!10 = !{!11, !11}
!11 = !DIBasicType(name: "i32", size: 32, encoding: DW_ATE_signed)
!12 = !DILocation(line: 1, column: 6, scope: !8)
