; ModuleID = '/main.void'
source_filename = "/main.void"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@__vd_types__research = local_unnamed_addr constant [0 x { ptr, ptr, ptr, i64, ptr, i64, ptr, i32 }] zeroinitializer
@__vd_type_count__research = local_unnamed_addr constant i64 0
@__vd_witnesses__research = local_unnamed_addr constant [0 x { ptr, ptr, ptr, ptr }] zeroinitializer
@__vd_witness_count__research = local_unnamed_addr constant i64 0
@gc.offsets = private constant [1 x i64] zeroinitializer
@gc.offsets.1 = private constant [1 x i64] zeroinitializer
@gc.offsets.2 = private constant [1 x i64] zeroinitializer
@gc.offsets.3 = private constant [1 x i64] zeroinitializer
@gc.offsets.4 = private constant [1 x i64] zeroinitializer
@gc.offsets.5 = private constant [1 x i64] zeroinitializer
@gc.offsets.6 = private constant [1 x i64] zeroinitializer
@gc.offsets.7 = private constant [1 x i64] zeroinitializer
@gc.offsets.8 = private constant [1 x i64] zeroinitializer
@0 = private unnamed_addr constant [160 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:11: runtime error: Display operation failed\0A    print(7)\0A          ^\0AIn function /main.void::main\0A\00", align 1
@1 = private unnamed_addr constant [2 x i8] c" \00", align 1
@2 = private unnamed_addr constant [2 x i8] c"\0A\00", align 1
@3 = private unnamed_addr constant [152 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: runtime error: String operation failed\0A    print(7)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@4 = private unnamed_addr constant [149 x i8] c"/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: runtime error: Interpolation failed\0A    print(7)\0A    ^\0AIn function /main.void::main\0A\00", align 1
@5 = private unnamed_addr constant [125 x i8] c"Called from /main.void::main\0A/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:2:5: source call\0A    print(7)\0A    ^\0A\00", align 1
@6 = private unnamed_addr constant [114 x i8] c"Called from /main.void::$app_adapter\0A/tmp/void-compiler-health-0w02e0mg/fixtures/tiny/main.void:1:6: source call\0A\00", align 1

define void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %0) local_unnamed_addr !dbg !3 {
block0:
  %1 = alloca [2 x ptr], align 8
  %2 = alloca ptr, align 8
  store ptr null, ptr %2, align 8
  %3 = alloca ptr, align 8
  store ptr null, ptr %3, align 8
  %4 = alloca ptr, align 8
  store ptr null, ptr %4, align 8
  %5 = alloca ptr, align 8
  store ptr null, ptr %5, align 8
  %6 = alloca ptr, align 8
  store ptr null, ptr %6, align 8
  %7 = alloca ptr, align 8
  store ptr null, ptr %7, align 8
  %8 = alloca ptr, align 8
  store ptr null, ptr %8, align 8
  %9 = alloca ptr, align 8
  store ptr null, ptr %9, align 8
  %10 = alloca ptr, align 8
  store ptr null, ptr %10, align 8
  %11 = alloca [9 x { ptr, i64, ptr, i64 }], align 8
  store ptr %2, ptr %11, align 8
  %.fca.1.gep = getelementptr inbounds i8, ptr %11, i64 8
  store i64 8, ptr %.fca.1.gep, align 8
  %.fca.2.gep = getelementptr inbounds i8, ptr %11, i64 16
  store ptr @gc.offsets, ptr %.fca.2.gep, align 8
  %.fca.3.gep = getelementptr inbounds i8, ptr %11, i64 24
  store i64 1, ptr %.fca.3.gep, align 8
  %12 = getelementptr inbounds i8, ptr %11, i64 32
  store ptr %3, ptr %12, align 8
  %.fca.1.gep10 = getelementptr inbounds i8, ptr %11, i64 40
  store i64 8, ptr %.fca.1.gep10, align 8
  %.fca.2.gep12 = getelementptr inbounds i8, ptr %11, i64 48
  store ptr @gc.offsets.1, ptr %.fca.2.gep12, align 8
  %.fca.3.gep14 = getelementptr inbounds i8, ptr %11, i64 56
  store i64 1, ptr %.fca.3.gep14, align 8
  %13 = getelementptr inbounds i8, ptr %11, i64 64
  store ptr %4, ptr %13, align 8
  %.fca.1.gep18 = getelementptr inbounds i8, ptr %11, i64 72
  store i64 8, ptr %.fca.1.gep18, align 8
  %.fca.2.gep20 = getelementptr inbounds i8, ptr %11, i64 80
  store ptr @gc.offsets.2, ptr %.fca.2.gep20, align 8
  %.fca.3.gep22 = getelementptr inbounds i8, ptr %11, i64 88
  store i64 1, ptr %.fca.3.gep22, align 8
  %14 = getelementptr inbounds i8, ptr %11, i64 96
  store ptr %5, ptr %14, align 8
  %.fca.1.gep26 = getelementptr inbounds i8, ptr %11, i64 104
  store i64 8, ptr %.fca.1.gep26, align 8
  %.fca.2.gep28 = getelementptr inbounds i8, ptr %11, i64 112
  store ptr @gc.offsets.3, ptr %.fca.2.gep28, align 8
  %.fca.3.gep30 = getelementptr inbounds i8, ptr %11, i64 120
  store i64 1, ptr %.fca.3.gep30, align 8
  %15 = getelementptr inbounds i8, ptr %11, i64 128
  store ptr %6, ptr %15, align 8
  %.fca.1.gep34 = getelementptr inbounds i8, ptr %11, i64 136
  store i64 8, ptr %.fca.1.gep34, align 8
  %.fca.2.gep36 = getelementptr inbounds i8, ptr %11, i64 144
  store ptr @gc.offsets.4, ptr %.fca.2.gep36, align 8
  %.fca.3.gep38 = getelementptr inbounds i8, ptr %11, i64 152
  store i64 1, ptr %.fca.3.gep38, align 8
  %16 = getelementptr inbounds i8, ptr %11, i64 160
  store ptr %7, ptr %16, align 8
  %.fca.1.gep42 = getelementptr inbounds i8, ptr %11, i64 168
  store i64 8, ptr %.fca.1.gep42, align 8
  %.fca.2.gep44 = getelementptr inbounds i8, ptr %11, i64 176
  store ptr @gc.offsets.5, ptr %.fca.2.gep44, align 8
  %.fca.3.gep46 = getelementptr inbounds i8, ptr %11, i64 184
  store i64 1, ptr %.fca.3.gep46, align 8
  %17 = getelementptr inbounds i8, ptr %11, i64 192
  store ptr %8, ptr %17, align 8
  %.fca.1.gep50 = getelementptr inbounds i8, ptr %11, i64 200
  store i64 8, ptr %.fca.1.gep50, align 8
  %.fca.2.gep52 = getelementptr inbounds i8, ptr %11, i64 208
  store ptr @gc.offsets.6, ptr %.fca.2.gep52, align 8
  %.fca.3.gep54 = getelementptr inbounds i8, ptr %11, i64 216
  store i64 1, ptr %.fca.3.gep54, align 8
  %18 = getelementptr inbounds i8, ptr %11, i64 224
  store ptr %9, ptr %18, align 8
  %.fca.1.gep58 = getelementptr inbounds i8, ptr %11, i64 232
  store i64 8, ptr %.fca.1.gep58, align 8
  %.fca.2.gep60 = getelementptr inbounds i8, ptr %11, i64 240
  store ptr @gc.offsets.7, ptr %.fca.2.gep60, align 8
  %.fca.3.gep62 = getelementptr inbounds i8, ptr %11, i64 248
  store i64 1, ptr %.fca.3.gep62, align 8
  %19 = getelementptr inbounds i8, ptr %11, i64 256
  store ptr %10, ptr %19, align 8
  %.fca.1.gep66 = getelementptr inbounds i8, ptr %11, i64 264
  store i64 8, ptr %.fca.1.gep66, align 8
  %.fca.2.gep68 = getelementptr inbounds i8, ptr %11, i64 272
  store ptr @gc.offsets.8, ptr %.fca.2.gep68, align 8
  %.fca.3.gep70 = getelementptr inbounds i8, ptr %11, i64 280
  store i64 1, ptr %.fca.3.gep70, align 8
  %20 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %20, ptr nonnull %11, i64 9)
  call void @vd_gc_poll()
  %21 = call i1 @vd_worker_checkpoint(ptr %0)
  br i1 %21, label %common.ret, label %worker.continue

common.ret:                                       ; preds = %numeric_valid6, %block0, %error_return, %numeric_error5, %numeric_error3, %numeric_error1, %numeric_error
  call void @vd_gc_frame_leave(ptr nonnull %20)
  ret void, !dbg !6

worker.continue:                                  ; preds = %block0
  %22 = call i1 @vd_scalar_display(ptr nonnull %5, i32 2, i64 7, ptr null, ptr null, i1 false, ptr %0), !dbg !7
  %23 = load ptr, ptr %0, align 8, !dbg !7
  %.not = icmp eq ptr %23, null, !dbg !7
  br i1 %.not, label %numeric_valid, label %numeric_error, !dbg !7

numeric_error:                                    ; preds = %worker.continue
  store ptr @0, ptr %0, align 8, !dbg !7
  br label %common.ret, !dbg !7

numeric_valid:                                    ; preds = %worker.continue
  %24 = load ptr, ptr %5, align 8, !dbg !7
  store ptr %24, ptr %2, align 8, !dbg !7
  call void @vd_string_literal(ptr nonnull %6, ptr nonnull @1, i64 1, ptr nonnull %0), !dbg !8
  %25 = load ptr, ptr %0, align 8, !dbg !8
  %.not71 = icmp eq ptr %25, null, !dbg !8
  br i1 %.not71, label %numeric_valid2, label %numeric_error1, !dbg !8

numeric_error1:                                   ; preds = %numeric_valid
  store ptr @3, ptr %0, align 8, !dbg !8
  br label %common.ret, !dbg !8

numeric_valid2:                                   ; preds = %numeric_valid
  %26 = load ptr, ptr %6, align 8, !dbg !8
  store ptr %26, ptr %3, align 8, !dbg !8
  call void @vd_string_literal(ptr nonnull %7, ptr nonnull @2, i64 1, ptr nonnull %0), !dbg !8
  %27 = load ptr, ptr %0, align 8, !dbg !8
  %.not72 = icmp eq ptr %27, null, !dbg !8
  br i1 %.not72, label %numeric_valid4, label %numeric_error3, !dbg !8

numeric_error3:                                   ; preds = %numeric_valid2
  store ptr @3, ptr %0, align 8, !dbg !8
  br label %common.ret, !dbg !8

numeric_valid4:                                   ; preds = %numeric_valid2
  %28 = load ptr, ptr %7, align 8, !dbg !8
  store ptr %28, ptr %4, align 8, !dbg !8
  %29 = load ptr, ptr %2, align 8, !dbg !8
  store ptr %29, ptr %8, align 8, !dbg !8
  store ptr %28, ptr %9, align 8, !dbg !8
  store ptr %8, ptr %1, align 8, !dbg !8
  %30 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !8
  store ptr %9, ptr %30, align 8, !dbg !8
  call void @vd_string_join(ptr nonnull %10, ptr nonnull %1, i64 2, ptr nonnull %0), !dbg !8
  %31 = load ptr, ptr %0, align 8, !dbg !8
  %.not73 = icmp eq ptr %31, null, !dbg !8
  br i1 %.not73, label %numeric_valid6, label %numeric_error5, !dbg !8

numeric_error5:                                   ; preds = %numeric_valid4
  store ptr @4, ptr %0, align 8, !dbg !8
  br label %common.ret, !dbg !8

numeric_valid6:                                   ; preds = %numeric_valid4
  %32 = load ptr, ptr %10, align 8, !dbg !8
  call void @vd_console_print(ptr %32, i64 1, i1 false, ptr nonnull %0), !dbg !8
  %33 = load ptr, ptr %0, align 8, !dbg !8
  %.not74 = icmp eq ptr %33, null, !dbg !8
  br i1 %.not74, label %common.ret, label %selected.failure, !dbg !8

selected.failure:                                 ; preds = %numeric_valid6
  %34 = getelementptr inbounds i8, ptr %0, i64 8, !dbg !8
  %35 = load i32, ptr %34, align 4, !dbg !8
  %36 = icmp ult i32 %35, 32, !dbg !8
  br i1 %36, label %trace_caller, label %error_return, !dbg !8

trace_caller:                                     ; preds = %selected.failure
  %37 = getelementptr inbounds i8, ptr %0, i64 16, !dbg !8
  %38 = zext nneg i32 %35 to i64, !dbg !8
  %39 = getelementptr [32 x ptr], ptr %37, i64 0, i64 %38, !dbg !8
  store ptr @5, ptr %39, align 8, !dbg !8
  %40 = add nuw nsw i32 %35, 1, !dbg !8
  br label %error_return, !dbg !8

error_return:                                     ; preds = %selected.failure, %trace_caller
  %storemerge = phi i32 [ %40, %trace_caller ], [ 33, %selected.failure ], !dbg !8
  store i32 %storemerge, ptr %34, align 4, !dbg !8
  br label %common.ret, !dbg !8
}

define noundef i32 @__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research(i32 %0, ptr %1) local_unnamed_addr !dbg !9 {
block0:
  %2 = alloca [0 x { ptr, i64, ptr, i64 }], align 8
  %3 = alloca [32 x i8], align 8
  call void @vd_gc_frame_enter(ptr nonnull %3, ptr nonnull %2, i64 0)
  call void @vd_gc_poll()
  %4 = call i1 @vd_worker_checkpoint(ptr %1)
  br i1 %4, label %common.ret, label %worker.continue

common.ret:                                       ; preds = %worker.continue, %block0, %error_return
  call void @vd_gc_frame_leave(ptr nonnull %3)
  ret i32 0, !dbg !13

worker.continue:                                  ; preds = %block0
  call void @__vd_2f6d61696e2e766f69643a3a6d61696e__research(ptr %1), !dbg !13
  %5 = load ptr, ptr %1, align 8, !dbg !13
  %.not = icmp eq ptr %5, null, !dbg !13
  br i1 %.not, label %common.ret, label %propagate_error, !dbg !13

propagate_error:                                  ; preds = %worker.continue
  %6 = getelementptr inbounds i8, ptr %1, i64 8, !dbg !13
  %7 = load i32, ptr %6, align 4, !dbg !13
  %8 = icmp ult i32 %7, 32, !dbg !13
  br i1 %8, label %trace_caller, label %error_return, !dbg !13

trace_caller:                                     ; preds = %propagate_error
  %9 = getelementptr inbounds i8, ptr %1, i64 16, !dbg !13
  %10 = zext nneg i32 %7 to i64, !dbg !13
  %11 = getelementptr [32 x ptr], ptr %9, i64 0, i64 %10, !dbg !13
  store ptr @6, ptr %11, align 8, !dbg !13
  %12 = add nuw nsw i32 %7, 1, !dbg !13
  br label %error_return, !dbg !13

error_return:                                     ; preds = %propagate_error, %trace_caller
  %storemerge = phi i32 [ %12, %trace_caller ], [ 33, %propagate_error ], !dbg !13
  store i32 %storemerge, ptr %6, align 4, !dbg !13
  br label %common.ret, !dbg !13
}

declare void @vd_gc_frame_enter(ptr, ptr, i64) local_unnamed_addr

declare void @vd_gc_poll() local_unnamed_addr

declare i1 @vd_worker_checkpoint(ptr) local_unnamed_addr

declare void @vd_gc_frame_leave(ptr) local_unnamed_addr

declare i1 @vd_scalar_display(ptr, i32, i64, ptr, ptr, i1, ptr) local_unnamed_addr

declare void @vd_string_literal(ptr, ptr, i64, ptr) local_unnamed_addr

declare void @vd_string_join(ptr, ptr, i64, ptr) local_unnamed_addr

declare void @vd_console_print(ptr, i64, i1, ptr) local_unnamed_addr

!llvm.dbg.cu = !{!0}
!llvm.module.flags = !{!2}

!0 = distinct !DICompileUnit(language: DW_LANG_C, file: !1, producer: "VOID source compiler", isOptimized: false, runtimeVersion: 0, emissionKind: FullDebug)
!1 = !DIFile(filename: "main.void", directory: "/tmp/void-compiler-health-0w02e0mg/fixtures/tiny")
!2 = !{i32 2, !"Debug Info Version", i32 3}
!3 = distinct !DISubprogram(name: "main", linkageName: "__vd_2f6d61696e2e766f69643a3a6d61696e__research", scope: !1, file: !1, line: 1, type: !4, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!4 = !DISubroutineType(types: !5)
!5 = !{null}
!6 = !DILocation(line: 2, scope: !3)
!7 = !DILocation(line: 2, column: 11, scope: !3)
!8 = !DILocation(line: 2, column: 5, scope: !3)
!9 = distinct !DISubprogram(name: "$app_adapter", linkageName: "__vd_2f6d61696e2e766f69643a3a246170705f61646170746572__research", scope: !1, file: !1, line: 1, type: !10, scopeLine: 1, flags: DIFlagPrototyped, spFlags: DISPFlagDefinition, unit: !0)
!10 = !DISubroutineType(types: !11)
!11 = !{!12, !12}
!12 = !DIBasicType(name: "i32", size: 32, encoding: DW_ATE_signed)
!13 = !DILocation(line: 1, column: 6, scope: !9)
