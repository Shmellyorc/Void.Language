from pathlib import Path
from bench import measured,cli,W,COMPILER
LLVM=Path('/home/shmellyorc/Documents/Void.Language/.toolchains/ci-investigation/LLVM-19.1.7-Linux-X64/bin')
measured('runtime-root-width',['/tmp/void-root-scan-audit-fee887de/root_scan','5000'],timeout=90)
for case in ('import-json','import-text'):
    source=W/'fixtures'/case/'main.void'
    for mode in ('check','O0','O2'):
        args=[COMPILER,'check' if mode=='check' else 'run',source]+(['--no-opt'] if mode=='O0' else [])
        r=measured(case+'-'+mode,args,source,timeout=180)
        if mode!='check':assert r.stdout==b'7\n'
    measured('dump-'+case,['/tmp/void-health-phase-harness-1i3kr4z4/phase',source,W/'phases'/case,'1'],source,timeout=180)
measured('opt-dto32',[LLVM/'opt','-passes=default<O2>','-time-passes','-disable-output',W/'phases/dto32.pre.ll'],W/'fixtures/dto32/main.void',timeout=180)
for mode in ('O0','O2'):cli('plain8',mode)
for n in (16,32,64,128):
    cli('dto'+str(n),'check')
    for mode in ('O0','O2'):cli('dto'+str(n),mode)
    for mode in ('O0','O2'):cli('plain'+str(n),mode)
