from pathlib import Path
import json,csv,statistics
W=Path(__file__).resolve().parent
ROOT=Path('/home/shmellyorc/Documents/Void.Language')
rs=[json.loads(x) for x in (W/'measurements.jsonl').read_text().splitlines()]
lines=[]
def add(x=''):lines.append(x)
def table(headers,rows):
 add('| '+' | '.join(headers)+' |');add('|'+'|'.join('---' for _ in headers)+'|')
 for row in rows:add('| '+' | '.join(map(str,row))+' |')
 add()
def med(xs,key):return statistics.median(key(r) for r in xs)
def phases(label):
 r=next(r for r in rs if r['label']==label)
 return {x.split('\t')[1]:float(x.split('\t')[2]) for x in (W/r['stderr']).read_text().splitlines() if x.startswith('PHASE\t')}
def group(case,mode):return [r for r in rs if r['label'].startswith(case+'-'+mode+'-')]
def single(label):return next(r for r in rs if r['label']==label)
add('''# Compiler-health benchmark record

27 October 2026. Baseline **`1d4ad15f5215838d209e48bb47ac7c3f52b05371`**.
[Interpretation](REPORT.md), [inventory](ISSUES.md), [repair plan](ROADMAP.md),
[evidence and extraction](evidence/README.md).

## Method and provenance

- Linux 7.2.11 PikaOS x86_64 / glibc 2.44; AMD Ryzen 7 1700X, 8 cores / 16 threads.
  Existing Release build (`-O3 -DNDEBUG`), pinned LLVM **19.1.7**.
- Unchanged CLI SHA-256:
  `3342a2153fc909a98111207db82a8c7b2736983a5311e33a4f68369ec391a952`.
  Manifest source/compiler hashes are checked again at the end. Helpers have
  separate source/library/binary provenance.
- Every measured child has a real **1,048,576-byte soft and hard stack limit**.
  ASLR remains **2**. No ptrace, debugger, perf attachment, sanitizer or CTest run.
- Fresh processes run serially. `wait4` records child user/system CPU, peak RSS,
  faults and context switches; raw records also contain exact commands, cwd,
  load average, source/compiler hashes and output paths. Native-build CPU can
  exceed wall time through child concurrency; peak RSS is the Linux process/
  waited-child high-water value, not summed simultaneous memory of a process tree.
- Host is not CPU-isolated; boost is enabled and load averages are retained.
  No OS page-cache flush or controlled disk-cold condition. “Cold cache” means
  empty **this scratch fixture's** `.void` object cache; warm runs verify `hit`.
- Three samples for normal startup/check/cache-hit groups, five for native runs;
  single cold-cache/build and expensive width/phase/llc observations. Ranges
  describe actual variation, not confidence intervals. Do not turn local seconds
  into universal hardware/platform guarantees.
- CLI output is asserted, including DTO roundtrip equality. The repository's
  existing `tests/text_encoding/crash.py` preserves exact `_crash.void` artifacts
  for abnormal exits/internal IR errors/timeouts. Bound: 480 seconds per costly
  CLI/llc child, smaller limits for smaller probes; no widening after a timeout.

### Workloads

| Fixture | Content / expected stdout |
|---|---|
| tiny | `print(7)`; `7` |
| gameplay | Small game-like math/value/list program using sqrt and clamp on (3,4)/(5,12); `18`. A small proxy, not a full game benchmark. |
| DTO N | Managed DTO with N public i32 fields, parse exact ordered object with `json.parse_as`, stringify equality; N-1 then `true`. N=8,16,32,64,128. |
| plain N | Same managed field width, ordinary named construction and last-field output, without JSON. |
| unused import | Tiny print plus only `use json as json` or `use text as text`; `7`. |

These are new fixed research fixtures. The historical 246.61-second wide O0 and
148.76-second shapes-O2 records are preserved in JSON evidence, but differ in
workload/build history. They are evidence of unacceptable latency, not a valid
controlled speedup comparison to this table.

## Unchanged CLI: startup and execution

All times seconds. CPU is median user+system; RSS is maximum observed MiB.
O0 below means current `--no-opt`: **IR O2 disabled, codegen still LLVM Default**.
`--cache` explicitly selects that unoptimized IR mode. `check-dir` exercises
shared directory/main discovery. Native executables are built independently by
`voidc build`; native run time excludes compilation. AOT uses the existing generic
CPU target, while JIT detects host CPU/features, so AOT build versus JIT compile
is not a same-target LLVM phase comparison.
''')
rows=[]
for case in ('tiny','gameplay','dto8'):
 for mode in ('check','discover','O0','O2','cold-cache','warm-cache','build','native'):
  xs=group(case,mode)
  rows.append([case,{'discover':'check-dir','build':'build O2','native':'native run'}.get(mode,mode),len(xs),f'{med(xs,lambda r:r["seconds"]):.6f}',f'{min(r["seconds"] for r in xs):.6f}–{max(r["seconds"] for r in xs):.6f}',f'{med(xs,lambda r:r["user_seconds"]+r["system_seconds"]):.6f}',f'{max(r["peak_rss_kib"] for r in xs)/1024:.1f}'])
table(['Fixture','Mode','n','Median wall','Wall range','CPU','Peak RSS MiB'],rows)
add('''Invalid CLI startup/usage control took 0.006431 s with expected status 2; it is
only a process/loader/argument-error floor, not an isolated valid-program startup
phase. Directory discovery adds no demonstrated seconds-scale delay in these
small graphs. DTO8 cold compilation is seconds while native/first invocation is
milliseconds; the observed slow launch is predominantly compilation.

## DTO width ladder and plain controls

For width8 use the three-sample medians above. Widths16–128 are one sample each.
CPU/RSS are retained per operation in JSONL; this table shows O0/O2 CPU and O2 RSS.
''')
rows=[]
for n in (8,16,32,64,128):
 g=lambda mode:group('dto'+str(n),mode)
 if not g('O2'):continue
 rows.append([n,f'{med(g("check"),lambda r:r["seconds"]):.4f}',f'{med(g("O0"),lambda r:r["seconds"]):.3f}',f'{med(g("O0"),lambda r:r["user_seconds"]+r["system_seconds"]):.3f}',f'{med(g("O2"),lambda r:r["seconds"]):.3f}',f'{med(g("O2"),lambda r:r["user_seconds"]+r["system_seconds"]):.3f}',f'{max(r["peak_rss_kib"] for r in g("O2"))/1024:.1f}',f'{med(group("plain"+str(n),"O2"),lambda r:r["seconds"]):.4f}' if group('plain'+str(n),'O2') else 'pending'])
table(['Fields','Check wall','O0 wall','O0 CPU','O2 wall','O2 CPU','O2 RSS MiB','Plain O2 wall'],rows)
add('''The width128 O0 run uses about 1.81 GiB peak RSS. Width controls show that wide
ordinary struct construction alone does not explain the DTO compilation cost.
The expensive decoder shape, common imported code and backend processing matter.
No timeout increase is counted as a repair.

## Phase boundaries: scratch API and dump helpers

Helpers include the unchanged production backend in an **O1 scratch translation
unit**, linked to existing Release core/Runtime and pinned LLVM libraries. Public
API helper uses that backend object. These timings corroborate the CLI; they
are not exact same-binary subtraction or production instrumentation. Text dump
and inventory time is measured separately, not charged to LLVM optimization.

Dump-helper seconds, one sample each:
''')
rows=[]
for case in ('tiny','gameplay','dto8','dto16','dto32','dto64','dto128'):
 p=phases('dump-'+case)
 rows.append([case]+[f'{p[k]:.6f}' for k in ('analyze','typed_lower_includes_validation','explicit_ir_validate','llvm_lower_includes_validation','finish_verify_and_ir_opt')])
table(['Fixture','Analysis','Typed lower + validation','Extra validation','LLVM lower + validation','Verify/O2/verify'],rows)
add('''Analysis combines source loading, lex/parse, checking and generic specialization;
this audit does **not** independently time those internal subphases. Typed lowering
also includes validation. The extra validation is a diagnostic probe, not an
additional cost to add blindly to unchanged CLI totals. Host target setup is
~0.3–0.4 ms; explicit-file discovery ~0.02 ms in the dump helper.

Actual public API helper boundaries (seconds):
''')
rows=[]
for case in ('tiny','gameplay','dto8'):
 for level in (0,1):
  p=phases('api-'+case+'-'+str(level))
  rows.append([case,'O2' if level else 'O0',f'{p["jit_configure"]:.6f}',f'{p["jit_compile_raw_includes_validation_lower_opt_materialization"]:.6f}',f'{p["first_invoke"]:.6f}',f'{p["second_invoke"]:.6f}',f'{p["code_reset"]+p["jit_reset"]+p["typed_reset"]+p["analysis_reset"]:.6f}'])
table(['Fixture','Mode','Jit setup','Aggregate compile','First invoke','Second invoke','Explicit teardown'],rows)
add('''Aggregate compile includes public validation, lower/IR optimization, native
machine generation, ORC materialization/linking/lookup and metadata admission.
ORC-only linking and parsing-versus-specialization are **not independently
isolated** here. JIT setup is ~1 ms and exact-IR external codegen alone explains
most DTO aggregate time; neither observation proves ORC has zero cost. First
invoke includes ordinary Runtime initialization/global admission/program output;
teardown sums explicit code/Jit/typed/analysis resets, not process loader costs.

## IR structure and root pressure

Counts are definitions, not declarations. LLVM instruction counts include the
whole emitted module. `root_slots` comes from constant arguments to generated
frame-enter calls; it is registration width, not peak live heap. The worst DTO
root function is the generated **decoder `$json$0`**, not the wide construction
closure. Maximum block below means LLVM IR instructions in a block, not machine
instruction count. Static alloca bytes are summed IR allocations, not final
machine stack-frame size.
''')
rows=[]
for case in ('tiny','gameplay','dto8','dto16','dto32','dto64','dto128','import-json','import-text'):
 a=list(csv.DictReader((W/'phases'/f'{case}.pre.tsv').open(),delimiter='\t'));b=list(csv.DictReader((W/'phases'/f'{case}.post.tsv').open(),delimiter='\t'))
 worst=max(a,key=lambda r:int(r['root_slots']));worstpost=max(b,key=lambda r:int(r['root_slots']))
 rows.append([case,len(a),sum(int(r['instructions']) for r in a),max(int(r['max_block']) for r in a),max(int(r['max_block']) for r in b),worst['root_slots'],worst['alloca_bytes'],worstpost['alloca_bytes'],f'{(W/"phases"/f"{case}.pre.ll").stat().st_size/1048576:.2f} / {(W/"phases"/f"{case}.post.ll").stat().st_size/1048576:.2f}'])
table(['Fixture','Functions pre','Instructions pre','Max block pre','Max block post','Worst roots','Worst alloca bytes pre','Worst alloca bytes post','IR text MiB pre/post'],rows)
add('''Post-O2 DTO128 still has 65 functions and 284,226 instructions. In this coordinated synchronous decoder, each reference instruction's root home
and the complete slot descriptor array are initialized in the entry path. The generator emits repeated fallible/reference-heavy field
branches. The combination explains a source-supported mechanism for the measured
large scheduling regions; a changed-generator experiment is still required to
establish its precise benefit. The existing >=32-field construction closure
reduces one region but leaves the dominant decoder root frame intact.

## Controlled LLVM 19.1.7 machine-code experiments

Each pair uses the **identical dumped pre-O2 IR**, host CPU/features from
`*.target.txt`, PIC relocation and `llc -O=0` or `-O=2 -filetype=obj -time-passes`.
Post rows instead use the helper's O2-optimized IR. This isolates backend pass
policy from frontend work. It does not establish that every pass difference is
scheduling, nor make a modified CLI timing claim.
''')
rows=[]
for r in rs:
 if not r['label'].startswith('llc-'):continue
 _,case,which,level=r['label'].split('-');obj=W/'phases'/f'{case}.{which}.cg{level}.o'
 rows.append([case,which,'O'+level,f'{r["seconds"]:.3f}',f'{r["user_seconds"]+r["system_seconds"]:.3f}',f'{r["peak_rss_kib"]/1024:.1f}',obj.stat().st_size])
table(['Fixture','IR input','Codegen','Wall s','CPU s','RSS MiB','Object bytes'],rows)
add('''Machine pass receipt highlights (pass wall percentages, not process percentages):

| Input | Post-RA top-down scheduling | Machine instruction scheduler | Other notable cost |
|---|---|---|---|
| DTO8 pre / cgO2 | 7.603 s / 50.1% | 4.116 s / 27.1% | X86 instruction selection 11.6%; greedy RA ~0.9% |
| DTO8 post / cgO2 | 14.797 s / 63.3% | 4.254 s / 18.2% | X86 selection 12.8%; greedy RA ~0.4% |
| DTO128 post / cgO2 | 135.644 s / 69.8% | 32.847 s / 16.9% | Selection 5.5%; coalescing 3.4% |

Thus the two schedulers account for ~86.7% of the measured post-O2 DTO128
machine pass time. **Register allocation is not dominant.** This is not proof of
an LLVM bug. Lower codegen changes several passes and generated-code quality;
only an explicit later policy decision may change `--no-opt`. Default O2 is
unchanged. See pinned-source references and risks in [REPORT](REPORT.md).

A separate same-IR DTO32 `opt '-passes=default<O2>' -time-passes -disable-output`
run took 8.443 s wall / 8.206 CPU / 127.6 MiB RSS. Pass wall shares: InstCombine
29.1%, MemCpyOpt 22.3%, DSE 20.8%, SROA 3.9%. IR optimization is substantial and
its cost rises sharply with width. The DSE timing is unrelated evidence from the
historical DSE fault; no causal connection is established.

## Unused source import controls
''')
rows=[]
for case in ('import-json','import-text'):
 for mode in ('check','O0','O2'):
  r=single(case+'-'+mode);rows.append([case,mode,f'{r["seconds"]:.6f}',f'{r["user_seconds"]+r["system_seconds"]:.6f}',f'{r["peak_rss_kib"]/1024:.1f}'])
table(['Fixture','Mode','Wall s','CPU s','RSS MiB'],rows)
add('''These are aggregate costs of unused imported source, not isolated native-link
latency. They confirm a general compilation cost independent of DTO generation.
Existing graph checking and broad function emission are current architecture; later
CLI emission reachability must retain diagnostics, globals, dispatch, metadata,
callbacks, native/export and reload contracts, including existing intentional
deferred checking of unused generic-template bodies.

## Runtime-only root-width experiment

One sweep, 5,000 operations/row, real registered slots and one valid i32 list
count7; other roots null. First and last slot placement, new token for each
operation versus one reused **still-live** token. Setup/allocation measured
separately; no GC, no LLVM. Every query checksum is 35,000.

Nanoseconds per operation, computed from raw CSV wall time:
''')
r=single('runtime-root-width');csvrows=list(csv.DictReader((W/r['stdout']).open()))
rows=[]
for n in (1,64,512,4096,16384):
 row=[n]
 for pos,method in [('last','fresh_root_word_and_list_count'),('last','same_live_token_and_list_count'),('first','fresh_root_word_and_list_count'),('first','same_live_token_and_list_count')]:
  x=next(x for x in csvrows if int(x['slots'])==n and x['position']==pos and x['method']==method);row.append(f'{float(x["wall_seconds"])/int(x["iterations"])*1e9:.1f}')
 rows.append(row)
table(['Roots','Last fresh','Last reused','First fresh','First reused'],rows)
add('''This confirms position-sensitive scanning rather than allocation/GC alone.
Reusing a token does not remove current membership revalidation. Do not claim
this is a full JSON profile or an estimate of frame registration/collection
cost. It motivates precise checked lookup/root-width engineering after smaller
code-generation improvements. Existing `tests/runtime/root_lookup_measure.cpp`
can host later before/after measurements; no new benchmark framework is needed.

## Independent frontend checks and arithmetic scaling

Inference receipts contain **24 `voidc check` invocations**: 17 successes and
7 expected reproduced source errors, no abnormal exit. Propagation direct/list/
dictionary/double-result, existing-task await, direct async-call argument and
choice inference fail; explicit/local controls and immediate-call await pass.
The currently passing immediate await depends on two wrong hints cancelling.
Exact sources and diagnostics are in `inference.tar.gz`.

Single bounded observations (seconds), not repeated statistical medians:

| Shape | Operators | Wall |
|---|---|---|
| Left generic argument | 4 | 0.00661 |
| Left generic argument | 8 | 0.00708 |
| Left generic argument | 12 | 0.01398 |
| Left generic argument | 16 | 0.10508 |
| Left generic argument | 18 | 0.38752 |
| Left generic argument | 20 | 1.51388 |
| Balanced generic argument | 20 | 0.00687 |
| Nongeneric ordinary return, left chain | 20 | 0.53939 |
| Extracted `+=` then generic argument | 20 | 0.00860 |

The source recursion and shape controls establish exponential duplicated hint
work before LLVM. [INFERENCE_REPAIR](INFERENCE_REPAIR.md) specifies the minimal
noncached traversal correction and semantic regressions.

## Reproduction and interpretation limits

Extract evidence archives into a fresh scratch directory; retain the originals.
`benchmark/bench.py`, `phases.py`, `remaining.py` and exact fixtures record the
executed workload/driver, with commands in JSONL. Paths in helper build scripts
and phase-driver constants describe this machine. Adjust paths **in scratch
copies only** for another checkout; do not overwrite baseline evidence or run
against a changing build. Rebuild the scratch helpers with the same pinned
libraries/profile if needed. No preserved binary is silently substituted.

The equivalent bounded CLI operations are:

```text
voidc check <fixture/main.void>
voidc check <fixture-directory>
voidc run <fixture/main.void> --no-opt
voidc run <fixture/main.void>
voidc run <fixture/main.void> --cache       # empty own scratch cache, then hits
voidc build <fixture/main.void> -o <scratch-native>
<scratch-native>
```

Use the supplied Python driver for per-child 1 MiB limits and incident capture.
Do not delete a user's project cache to simulate a cold case; each fixture owns
its scratch cache. `opt`/`llc` commands, host target details, helper source/build
commands, input hashes, phase inventories and complete pre/post IR are preserved.
Machine object sizes/hashes are retained; generated executables/objects and LTO
cache contents are omitted from the compact archive. No original crash artifacts
were produced by these successful bounded runs.

Unisolated areas: individual parsing/checking/specialization costs, ORC-only
linking, editor latency, real long-running async retention and actual-game
throughput. No Windows/macOS/ARM64 execution or across-commit regression test.
These are honest limits, not evidence that those components are defective or
free. Root scan and source shape evidence support focused next experiments;
the audit does not promise a measured speedup before a repair is implemented.
''')
add(f'Current receipt count: **{len(rs)} bounded root-driver operations**, all matching expected status; one is the deliberate status-2 CLI usage control. See final evidence manifest for the frozen count and provenance checks.')
(ROOT/'docs/compiler-health/BENCHMARKS.md').write_text('\n'.join(lines)+'\n')
