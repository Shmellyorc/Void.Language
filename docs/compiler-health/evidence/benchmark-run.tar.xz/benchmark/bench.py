"""Bounded research measurements; uses the repository's incident preservation."""
from pathlib import Path
import os, sys, time, json, hashlib, subprocess, resource, signal, shutil, threading

W=Path(__file__).resolve().parent
ROOT=Path('/home/shmellyorc/Documents/Void.Language')
COMPILER=ROOT/'build/ci-official-release/voidc'
os.environ['VOID_CRASH_EVIDENCE']=str(W/'incidents')
sys.path.insert(0,str(ROOT/'tests/text_encoding'))
from crash import preserve, crashed
RECORDS=W/'measurements.jsonl'

def measured(label, command, source=None, expected=0, timeout=300, stack=True):
    serial=sum(1 for _ in RECORDS.open()) if RECORDS.exists() else 0
    tag=f'{serial:03d}-{label}'
    out=W/'results'/(tag+'.stdout');err=W/'results'/(tag+'.stderr')
    def limit():
        if stack:
            resource.setrlimit(resource.RLIMIT_STACK,(1048576,1048576))
            assert resource.getrlimit(resource.RLIMIT_STACK)==(1048576,1048576)
        os.setsid()
    args=list(map(str,command));before=hashlib.sha256(COMPILER.read_bytes()).hexdigest()
    start=time.perf_counter();expired=False
    with out.open('wb') as stdout,err.open('wb') as stderr:
        process=subprocess.Popen(args,cwd=W,stdout=stdout,stderr=stderr,preexec_fn=limit)
        def expire():
            nonlocal expired
            expired=True
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        alarm=threading.Timer(timeout,expire);alarm.daemon=True;alarm.start()
        pid,status,usage=os.wait4(process.pid,0)
        alarm.cancel();alarm.join()
        process.returncode=os.waitstatus_to_exitcode(status)
    duration=time.perf_counter()-start
    result=subprocess.CompletedProcess(args,process.returncode,out.read_bytes(),err.read_bytes())
    result.timed_out=expired
    record={'label':label,'command':args,'cwd':str(W),'status':result.returncode,'expected_status':expected,
            'seconds':duration,'user_seconds':usage.ru_utime,'system_seconds':usage.ru_stime,
            'peak_rss_kib':usage.ru_maxrss,'minor_faults':usage.ru_minflt,'major_faults':usage.ru_majflt,
            'voluntary_switches':usage.ru_nvcsw,'involuntary_switches':usage.ru_nivcsw,
            'stack_bytes':1048576 if stack else None,'timed_out':expired,'source':str(source) if source else None,
            'source_sha256':hashlib.sha256(Path(source).read_bytes()).hexdigest() if source else None,
            'compiler_sha256_before':before,'compiler_sha256_after':hashlib.sha256(COMPILER.read_bytes()).hexdigest(),
            'stdout':str(out.relative_to(W)),'stderr':str(err.relative_to(W)),'load_average':os.getloadavg()}
    with RECORDS.open('a') as output:output.write(json.dumps(record)+'\n')
    if expired or crashed(result.returncode) or b'VOID IR:' in result.stderr or (result.returncode!=expected and result.returncode not in (0,1,2)):
        preserve(args,W,result,(source,) if source else (),(__file__,W/'manifest.json'))
    print(label,result.returncode,f'{duration:.6f}s',f'cpu={usage.ru_utime+usage.ru_stime:.6f}',f'rss={usage.ru_maxrss}',flush=True)
    if result.returncode!=expected or expired:raise RuntimeError((label,result.returncode,result.stderr[:2000]))
    assert record['compiler_sha256_before']==record['compiler_sha256_after']
    return result

def cli(case, mode, repeat=1):
    src=W/'fixtures'/case/'main.void'
    for i in range(repeat):
        if mode=='check':command=[COMPILER,'check',src]
        elif mode=='discover':command=[COMPILER,'check',src.parent]
        elif mode=='native':command=[src.parent/'native-O2']
        elif mode=='build':command=[COMPILER,'build',src,'-o',src.parent/'native-O2']
        elif mode=='cold-cache':
            cache=src.parent/'.void'
            if cache.exists():shutil.rmtree(cache)
            command=[COMPILER,'run',src,'--cache']
        else:command=[COMPILER,'run',src]+({'O0':['--no-opt'],'O2':[],'warm-cache':['--cache']}[mode])
        r=measured(case+'-'+mode+'-'+str(i),command,src,timeout=480)
        if mode=='cold-cache':assert b'Debug cache: miss' in r.stderr,r.stderr
        if mode=='warm-cache':assert b'Debug cache: hit' in r.stderr,r.stderr
        if mode not in ('check','discover','build'):
            wanted=b'7\n' if case=='tiny' else b'18\n' if case=='gameplay' else ((str(int(case[3:])-1)+'\ntrue\n').encode() if case.startswith('dto') else (str(int(case[5:])-1)+'\n').encode())
            assert r.stdout==wanted,(case,mode,r.stdout,wanted)

if __name__=='__main__':
    selection=sys.argv[1]
    if selection=='startup':
        measured('invalid-cli',[COMPILER],expected=2)
        for case in ('tiny','gameplay','dto8'):
            for mode in ('check','discover','O0','O2'):cli(case,mode,3)
            cli(case,'cold-cache');cli(case,'warm-cache',3);cli(case,'build');cli(case,'native',5)
    elif selection=='dto':
        for count in (8,16,32,64,128):
            case='dto'+str(count)
            cli(case,'check');cli(case,'O0');cli(case,'O2')
            for mode in ('O0','O2'):cli('plain'+str(count),mode)
    else:raise ValueError(selection)
