#include "void/runtime.hpp"
#include <chrono>
#include <ctime>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <sys/resource.h>

using Clock = std::chrono::steady_clock;
struct Stamp { Clock::time_point wall=Clock::now(); std::clock_t cpu=std::clock(); };
void report(const char* method, std::size_t slots, const char* position,
            std::size_t iterations, std::uint64_t checksum, Stamp start) {
    const auto end=Clock::now();const auto cpu=std::clock();
    std::cout<<method<<','<<slots<<','<<position<<','<<iterations<<','<<checksum<<','
        <<std::chrono::duration<double>(end-start.wall).count()<<','
        <<double(cpu-start.cpu)/CLOCKS_PER_SEC<<'\n';
}
int main(int argc,char** argv) {
    try {
        const auto iterations=argc>1?std::stoull(argv[1]):5000ull;
        if(iterations<1000 || iterations>10000)throw std::runtime_error("iterations must be 1000..10000");
        rlimit limit{1048576,1048576};
        if(setrlimit(RLIMIT_STACK,&limit)!=0)throw std::runtime_error("cannot enforce 1 MiB stack");
        if(getrlimit(RLIMIT_STACK,&limit)!=0 || limit.rlim_cur!=1048576 || limit.rlim_max!=1048576)
            throw std::runtime_error("unexpected actual stack limit");
        std::cerr<<"stack_soft="<<limit.rlim_cur<<" stack_hard="<<limit.rlim_max<<" iterations="<<iterations<<'\n';
        std::cout<<std::setprecision(12)<<"method,slots,position,iterations,checksum,wall_seconds,cpu_seconds\n";
        constexpr std::size_t zero=0;
        constexpr std::uint64_t expected_count=7;
        for(std::size_t count:{1u,64u,512u,4096u,16384u}) {
            vd::Runtime runtime(1ull<<40);
            vd::Runtime::Attachment attachment(runtime);
            vd::Runtime::Managed managed(runtime);
            Stamp setup;
            std::vector<void*> homes(count,nullptr);
            std::vector<vd::Runtime::Slot> slots(count);
            for(std::size_t i=0;i<count;++i)slots[i]={&homes[i],sizeof(void*),&zero,1};
            vd::Runtime::Frame frame(runtime,slots.data(),slots.size());
            runtime.list_into(&homes.back(),vd::ScalarEncoding::i32,expected_count);
            if(runtime.list_count(runtime.root_word(&homes.back()),vd::ScalarEncoding::i32)!=expected_count)
                throw std::runtime_error("setup count mismatch");
            report("setup",count,"last",1,expected_count,setup);
            for(const char* position:{"last","first"}) {
                if(position[0]=='f' && count>1){homes[0]=homes.back();homes.back()=nullptr;}
                void** home=position[0]=='f'?&homes.front():&homes.back();
                for(unsigned warm=0;warm<16;++warm)
                    if(runtime.list_count(runtime.root_word(home),vd::ScalarEncoding::i32)!=expected_count)
                        throw std::runtime_error("warmup count mismatch");
                std::uint64_t sum=0;
                Stamp fresh;
                for(std::size_t i=0;i<iterations;++i)sum+=runtime.list_count(runtime.root_word(home),vd::ScalarEncoding::i32);
                report("fresh_root_word_and_list_count",count,position,iterations,sum,fresh);
                if(sum!=iterations*expected_count)throw std::runtime_error("fresh query checksum mismatch");
                auto token=runtime.root_word(home);
                sum=0;
                Stamp cached;
                for(std::size_t i=0;i<iterations;++i)sum+=runtime.list_count(token,vd::ScalarEncoding::i32);
                report("same_live_token_and_list_count",count,position,iterations,sum,cached);
                if(sum!=iterations*expected_count)throw std::runtime_error("live token checksum mismatch");
            }
        }
        return 0;
    }catch(const std::exception& error){std::cerr<<"audit_error="<<error.what()<<'\n';return 1;}
}
