from pathlib import Path
import sys
import support as h

exe, root, work = map(lambda x: Path(x).resolve(), sys.argv[1:])
work.mkdir(parents=True, exist_ok=True)
result = h.run([exe, root, work], cwd=work, timeout=600)
print(result.stdout.decode(), end='')
