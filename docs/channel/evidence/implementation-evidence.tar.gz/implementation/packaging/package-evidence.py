from pathlib import Path
import hashlib, json, shutil, subprocess, tarfile, xml.etree.ElementTree as ET
ROOT=Path.cwd(); E=ROOT/'docs/channel/evidence'; RAW=E/'implementation'
LOCAL=ROOT/'build/channel/evidence-raw'
assert RAW.is_dir() and not LOCAL.exists()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,data):p.write_text(json.dumps(data,indent=2)+'\n')
for p in (ROOT/'build/channel').glob('*.log'):
 target=RAW/'build-logs'/p.name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
shutil.copytree(ROOT/'build/channel/attempts',RAW/'attempts')
(RAW/'packaging').mkdir();shutil.copy2(__file__,RAW/'packaging/package-evidence.py')
profiles={}
for profile,short in [('debug','debug'),('release','release'),('sanitizers','san')]:
 build=ROOT/'build'/('ci-official-'+short)
 saved=RAW/'build-configs'/profile;saved.mkdir(parents=True)
 for filename in ('CMakeCache.txt','void-native.txt','CMakeFiles/void_channel_host.dir/flags.make','CMakeFiles/void_channel_host.dir/link.txt','CMakeFiles/void_channel_benchmark.dir/flags.make'):
  source=build/filename
  if source.exists():shutil.copy2(source,saved/filename.replace('/','_'))
 (RAW/'typed-ir').mkdir(exist_ok=True)
 shutil.copy2(build/'channel-host/typed-ir.txt',RAW/'typed-ir'/(profile+'.txt'))
 p=next(RAW.glob('acceptance-'+profile+'-*/receipt.json'));data=json.loads(p.read_text())
 assert data['status']==0 and data['failed']==0 and not any(x['skipped'] for x in data['tests'])
 receiver=RAW/('receiver-'+short+'.xml')
 cases=list(ET.parse(receiver).getroot().iter('testcase'))
 assert len(cases)==1 and all(c.find('failure') is None and c.find('skipped') is None for c in cases)
 profiles[profile]={'passed':data['passed']+1,'failed':0,'original_selection_passed':data['passed'],
  'original_receipt':'implementation/'+str(p.relative_to(RAW)),
  'original_receipt_sha256':digest(p),'receiver_followup':'implementation/'+receiver.name,
  'receiver_followup_sha256':digest(receiver),'original_command':data['command'],
  'receiver_command':['ctest','--test-dir',str(build),'-R','^channel_receiver$','--output-on-failure'],
  'strict_environment':data['environment'],
  'build_hashes':{name:digest(build/name) for name in ('voidc','voidls','void_channel_host','libvoid_runtime.a','void-native.txt','CMakeCache.txt')},
  'compile_flags':(build/'CMakeFiles/void_channel_host.dir/flags.make').read_text(),
  'link_command':(build/'CMakeFiles/void_channel_host.dir/link.txt').read_text()}
assert sum(x['passed'] for x in profiles.values())==59
assert b'56 JIT/link/native/cache checks; hard stack=1048576' in (RAW/'sanitizers-hard-stack.txt').read_bytes()
followup=list(ET.parse(RAW/'debug-final-followup.xml').getroot().iter('testcase'))
assert len(followup)==2 and all(x.find('failure') is None for x in followup)
protected=ROOT/'README.md';baseline=subprocess.check_output(['git','show','HEAD:README.md'])
assert protected.read_bytes()==baseline
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='72ee05db7e417645d434b3932bfc1e00ffd4ecb6'
assert not subprocess.check_output(['git','diff','--name-only','--','src','include'])
manifest={str(p.relative_to(RAW)):{'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(RAW.rglob('*')) if p.is_file()}
write(RAW/'FILE_MANIFEST.json',manifest)
files=sorted(p for p in RAW.rglob('*') if p.is_file())
archive=E/'implementation-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tf:
 for p in files:tf.add(p,arcname='implementation/'+str(p.relative_to(RAW)),recursive=False)
expected={'implementation/'+str(p.relative_to(RAW)):digest(p) for p in files}
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(expected)
 for member in members:
  assert member.isfile() and member.name in expected
  assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==expected[member.name]
write(E/'IMPLEMENTATION_ARCHIVE.json',{'archive':archive.name,'sha256':digest(archive),'bytes':archive.stat().st_size,
 'members':len(files),'uncompressed_file_bytes':sum(p.stat().st_size for p in files),
 'every_member_reread_and_hash_verified':True,'member_manifest':'implementation/FILE_MANIFEST.json',
 'member_manifest_sha256':digest(RAW/'FILE_MANIFEST.json'),
 'exclusions':['Generated executables, native libraries and cache objects are represented by hashes, not embedded.'],
 'raw_originals_retained_at':str(LOCAL)})
shutil.move(str(RAW),str(LOCAL))
shutil.copy2(LOCAL/'performance.json',E/'performance.json')
legend='# Actual compiler-generated channel typed IR from the final Release host run.\n# Original unmodified listing: implementation/typed-ir/release.txt in the archive.\n# Op legend from include/void/ir.hpp: 25 constant; 39 load; 40 store; 49 gc_read; 50 gc_write; 96 list_push; 110 dict_set.\n# subscribe tail after list_push: local load/store, one held-record gc_write, return_value.\n# clear: local receiver/null preparation, one nullable-state gc_write, return_void.\n'
(E/'typed-ir.txt').write_text(legend+(LOCAL/'typed-ir/release.txt').read_text())
production=[ROOT/'CMakeLists.txt']+[p for directory in ('src','include','stdlib') for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
manual=[ROOT/'docs/README.md',ROOT/'docs/WRENCH_CLANKER.md',ROOT/'README.md']
manual += [p for p in (ROOT/'docs/channel').glob('*.md')]
manual += list((ROOT/'tests/channel').glob('*.*'))+list((ROOT/'examples/channel').glob('*.void'))
inputs=sorted(set(p for p in production+manual if p.is_file()))
hashes={str(p.relative_to(ROOT)):digest(p) for p in inputs}
(E/'SOURCES.sha256').write_text(''.join(value+'  '+name+'\n' for name,value in hashes.items()))
preserved={'docs/channel/RESEARCH.md','docs/channel/evidence/README.md','docs/channel/evidence/RECEIPT.json','docs/channel/evidence/capability-probes.tar.gz'}
provided_modified={'docs/channel/DESIGN.md','docs/channel/ROADMAP.md'}
tracked=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','docs/channel','examples/channel','tests/channel','stdlib/channel.void'],text=True).splitlines()
all_paths=sorted((set(tracked+untracked)|{'docs/channel/evidence/INVENTORY.json','docs/channel/evidence/IMPLEMENTATION_RECEIPT.json'})-preserved)
write(E/'INVENTORY.json',{'baseline':head,'initial_worktree':{'modified':['docs/README.md'],'untracked':['docs/channel/']},
 'implementation_changed_files':[{'path':p,'change':'provided_research_updated' if p in provided_modified else 'preexisting_index_updated' if p=='docs/README.md' else 'modified' if p in tracked else 'new'} for p in all_paths],
 'preexisting_research_preserved':[{'path':p,'sha256':digest(ROOT/p)} for p in sorted(preserved)],
 'excluded_generated_state':['build/ outputs and raw originals','Python bytecode caches'],
 'protected_root_README_unchanged':True})
manifest_lines=(ROOT/'build/ci-official-release/void-native.txt').read_text().splitlines()
tools={}
for name,filename in [('clang',manifest_lines[1]),('linker',manifest_lines[2])]:
 p=Path(filename);tools[name]={'path':filename,'sha256':digest(p)}
version=subprocess.check_output([manifest_lines[1],'--version'],text=True)
assert '19.1.7' in version
record={'baseline':head,'status':'implementation complete; stopped for independent Golden Wrench source/evidence review',
 'date':'2026-10-27','host_scope':'Linux only; native Windows/macOS and independent review not claimed',
 'profiles':profiles,'distinct_configuration_suite_outcomes':{'passed':59,'failed':0,'skipped':0},
 'additional_verification':{'debug_final_semantics_host_and_stack':'2/2 targeted follow-up suites passed',
 'strict_sanitizer_hard_stack':'56 command checks passed; both soft/hard child limits 1048576 bytes',
 'bound_receivers':'7 check/JIT/build/native operations in each profile with hard stacks',
 'host_checks_per_final_run':49708,'lsp_checks_per_profile':55,'rejected_source_programs_per_profile':28,
 'performance_workloads':26,'performance_samples':78},
 'allocation_sweep_paths':{'subscribe_failures_to_first_success':{'fresh_state':423,'existing_capacity':185,'event_and_index_growth':369,'new_topic_existing_registrations':303},
 'modes':['normal JIT','O2 JIT'],'injection':['sustained','one-shot'],
 'unsubscribe_before_after':{'last_subscriber':[31,37],'with_survivor':[37,36]},
 'emit_failures_before_any_delivery':255,'emit_failures_after_partial_delivery':90},
 'archive_receipt_sha256':digest(E/'IMPLEMENTATION_ARCHIVE.json'),'inventory_sha256':digest(E/'INVENTORY.json'),
 'sources_manifest_sha256':digest(E/'SOURCES.sha256'),'source_and_test_hashes':hashes,
 'performance_sha256':digest(E/'performance.json'),'typed_ir_listing_sha256':digest(E/'typed-ir.txt'),
 'tools':tools,'toolchain_version':version,'benchmark_binary_sha256':digest(ROOT/'build/ci-official-release/void_channel_benchmark'),
 'root_README_sha256':digest(protected),'root_README_matches_HEAD':True,
 'compiler_and_runtime_source_unchanged':True,'git_mutations':False,'hosted_CI':False,
 'historical_incidents':'H1-H7 remain distinct unresolved historical observations; no repair claimed',
 'limits':['Generated LLVM code is not universally instrumented by host sanitizers.','RSS is process high-water RSS including JIT/compilation.'],
 'reproduction':['python3 tests/channel/acceptance.py debug','python3 tests/channel/acceptance.py release','python3 tests/channel/acceptance.py sanitizers','python3 tests/channel/performance.py build/ci-official-release/void_channel_benchmark']}
write(E/'IMPLEMENTATION_RECEIPT.json',record)
print(json.dumps({'passed':59,'failed':0,'archive_bytes':archive.stat().st_size,'archive_members':len(files),'source_hashes':len(hashes),'changed_files':len(all_paths),'raw_originals':str(LOCAL)},indent=2))
