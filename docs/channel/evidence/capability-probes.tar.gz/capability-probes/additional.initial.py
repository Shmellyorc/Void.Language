from pathlib import Path
import json,subprocess,resource,time,sys,os,hashlib
W=Path(__file__).resolve().parent;ROOT=Path('/home/shmellyorc/Documents/Void.Language');C=ROOT/'build/ci-official-release/voidc'
os.environ['VOID_CRASH_EVIDENCE']=str(W/'incidents');sys.path.insert(0,str(ROOT/'tests/text_encoding'))
from crash import preserve,crashed
sources={
'nested_snapshot':('''struct source<t>:
    event changed: func(const t)
func (self source<t>) fire(const item: t):
    self.changed.emit(item)
func main():
    var source = source<i32>()
    var log = ""
    var second = func(const n: i32):
        log += "B"
    var third = func(const n: i32):
        log += "C"
    var first = func(const n: i32):
        log += "A"
        if n == 1:
            source.changed -= second
            source.changed += third
            source.fire(2)
    source.changed += first
    source.changed += second
    source.fire(1)
    print(log)
''',0,b'AACB\n'),
'clear_snapshot':('''struct source<t>:
    event changed: func(const t)
func (self source<t>) fire(const item: t):
    self.changed.emit(item)
struct holder<t>:
    current: source<t>?
func main():
    var held = holder<i32>(current = source<i32>())
    var log = ""
    if held.current is Ok(var original):
        var first = func(const n: i32):
            log += "A"
            held.current = null
            var replacement = source<i32>()
            replacement.changed += func(const value: i32):
                log += "C"
            held.current = replacement
            replacement.fire(2)
        var second = func(const n: i32):
            log += "B"
        original.changed += first
        original.changed += second
        original.fire(1)
    print(log)
''',0,b'ACB\n'),
'const_subscription_reject':('''struct source<t>:
    event changed: func(t)
func ignore(n: i32):
    pass
func main():
    const item = source<i32>()
    item.changed += ignore
''',1,None),
'wrong_payload_reject':('''struct source<t>:
    event changed: func(t)
func (self source<t>) fire(item: t):
    self.changed.emit(item)
func main():
    var source = source<i32>()
    source.fire("wrong")
''',1,None),
'async_boundary_reject':('''struct source<t>:
    event changed: func(t)
async func take(item: source<i32>):
    pass
func main():
    var item = source<i32>()
    var pending = take(item)
''',1,None),
'result_handler_reject':('''struct source<t>:
    event changed: func(t)
func value(n: i32) -> i32:
    return n
func main():
    var source = source<i32>()
    source.changed += value
''',1,None)
}
rows=[]
def limit():resource.setrlimit(resource.RLIMIT_STACK,(1048576,1048576))
def execute(name,cmd,src,expected,wanted=None):
 cmd=list(map(str,cmd));st=time.monotonic()
 try:r=subprocess.run(cmd,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=limit,timeout=120)
 except subprocess.TimeoutExpired as e:
  r=subprocess.CompletedProcess(cmd,-9,e.stdout or b'',e.stderr or b'');r.timed_out=True;preserve(cmd,W,r,(src,),(W/'manifest.json',));raise
 (W/'results'/(name+'.stdout')).write_bytes(r.stdout);(W/'results'/(name+'.stderr')).write_bytes(r.stderr)
 rows.append({'name':name,'command':cmd,'status':r.returncode,'expected':expected,'wall_seconds':time.monotonic()-st,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
 (W/'additional.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,r.returncode,repr(r.stdout.decode()),r.stderr.decode()[:450],flush=True)
 if crashed(r.returncode) or b'VOID IR:' in r.stderr:
  preserve(cmd,W,r,(src,),(W/'manifest.json',));raise RuntimeError('stop on abnormal exit')
 assert r.returncode==expected,(name,r.stderr)
 if wanted is not None:assert r.stdout==wanted,(name,r.stdout,wanted)
for name,(text,status,wanted) in sources.items():
 d=W/name;d.mkdir();src=d/'main.void';src.write_text(text)
 execute(name+'-check',[C,'check',src],src,status)
 if status==0:
  for mode in ('O0','O2'):execute(name+'-'+mode,[C,'run',src]+(['--no-opt'] if mode=='O0' else []),src,0,wanted)
src=W/'clear_snapshot/main.void';exe=src.parent/'native'
execute('clear_snapshot-build',[C,'build',src,'-o',exe],src,0)
execute('clear_snapshot-native',[exe],src,0,b'ACB\n')
print('DONE',len(rows),'additional probes',flush=True)
