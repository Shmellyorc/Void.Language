from pathlib import Path
import tempfile,os,sys,json,subprocess,hashlib,resource,time
ROOT=Path('/home/shmellyorc/Documents/Void.Language')
W=Path(tempfile.mkdtemp(prefix='void-channel-research-'))
(W/'results').mkdir();(W/'incidents').mkdir()
C=ROOT/'build/ci-official-release/voidc'
os.environ['VOID_CRASH_EVIDENCE']=str(W/'incidents')
sys.path.insert(0,str(ROOT/'tests/text_encoding'))
from crash import preserve,crashed
fixtures={
'generic_event':'''private struct topic<t>:
    event delivered: func(const t)
private func (self topic<t>) fire(const item: t):
    self.delivered.emit(item)
func main():
    var bucket = topic<i32>()
    var total = 0
    var handler = func(const number: i32):
        total += number
    bucket.delivered += handler
    bucket.fire(7)
    print(total)
''',
'identity_key':'''struct subscription:
    private reserved: bool
func main():
    var entries: {subscription: i32} = {}
    var handle = subscription()
    var unrelated = subscription()
    entries[handle] = 7
    const view = handle
    print(entries.contains(view), entries.contains(unrelated))
    print(entries[view])
    print(entries.remove(view), entries.remove(view))
''',
'unique_wrappers':'''struct emitter:
    event changed: func(const i32)
func (self emitter) fire(number: i32):
    self.changed.emit(number)
func wrap(callback: func(const i32)) -> func(const i32):
    return func(const number: i32):
        callback(number)
func main():
    var total = 0
    var callback = func(const number: i32):
        total += number
    var first = wrap(callback)
    var second = wrap(callback)
    print(first == second, first == first)
    var source = emitter()
    source.changed += first
    source.changed += second
    source.changed -= first
    source.fire(7)
    print(total)
''',
'event_const_payload':'''struct message:
    value: i32
private struct topic<t>:
    event delivered: func(const t)
private func (self topic<t>) fire(const item: t):
    self.delivered.emit(item)
func main():
    var bucket = topic<message>()
    var handler = func(const item: message):
        print(item.value)
    bucket.delivered += handler
    const item = message(value = 7)
    bucket.fire(item)
    const view = bucket
    view.fire(item)
''',
'event_mutable_callback_reject':'''struct message:
    value: i32
struct topic:
    event delivered: func(const message)
func change(item: message):
    item.value = 9
func main():
    var bucket = topic()
    bucket.delivered += change
''',
'empty_generic_reject':'''struct topic<t>:
    event delivered: func(t)
func main():
    var bucket = topic()
''',
'global_topic':'''struct topic<t>:
    event delivered: func(t)
func (self topic<t>) fire(item: t):
    self.delivered.emit(item)
var shared = topic<i32>()
var total = 0
func receive(number: i32):
    total += number
func main():
    shared.delivered += receive
    shared.fire(7)
    print(total)
'''
}
for name,code in fixtures.items():
 d=W/name;d.mkdir();(d/'main.void').write_text(code)
manifest={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'compiler':str(C),'compiler_sha256':hashlib.sha256(C.read_bytes()).hexdigest(),'aslr':Path('/proc/sys/kernel/randomize_va_space').read_text().strip(),'stack_bytes':1048576,'workspace':str(W),'fixtures':{n:hashlib.sha256((W/n/'main.void').read_bytes()).hexdigest() for n in fixtures}}
(W/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(W/'driver.py').write_bytes(Path(__file__).read_bytes())
records=[]
def limit():resource.setrlimit(resource.RLIMIT_STACK,(1048576,1048576))
for name in fixtures:
 src=W/name/'main.void';cmd=[str(C),'check',str(src)]
 start=time.monotonic()
 try:r=subprocess.run(cmd,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=limit,timeout=120)
 except subprocess.TimeoutExpired as e:
  r=subprocess.CompletedProcess(cmd,-9,e.stdout or b'',e.stderr or b'');r.timed_out=True;preserve(cmd,W,r,(src,),(W/'manifest.json',));raise
 (W/'results'/(name+'.stdout')).write_bytes(r.stdout);(W/'results'/(name+'.stderr')).write_bytes(r.stderr)
 records.append({'name':name,'command':cmd,'wall_seconds':time.monotonic()-start,'status':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
 (W/'checks.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,r.returncode,r.stderr.decode(errors='replace')[:600],flush=True)
 if crashed(r.returncode) or b'VOID IR:' in r.stderr:
  preserve(cmd,W,r,(src,),(W/'manifest.json',));raise RuntimeError('stop on abnormal exit')
print('EVIDENCE',W,flush=True)
