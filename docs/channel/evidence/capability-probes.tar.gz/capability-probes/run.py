from pathlib import Path
import os,sys,json,subprocess,time,resource,hashlib
W=Path(__file__).resolve().parent;ROOT=Path('/home/shmellyorc/Documents/Void.Language');C=ROOT/'build/ci-official-release/voidc'
os.environ['VOID_CRASH_EVIDENCE']=str(W/'incidents');sys.path.insert(0,str(ROOT/'tests/text_encoding'))
from crash import preserve,crashed
results=[]
def limit():resource.setrlimit(resource.RLIMIT_STACK,(1048576,1048576))
def run(name,cmd,src,wanted=None):
 cmd=list(map(str,cmd));start=time.monotonic()
 try:r=subprocess.run(cmd,cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE,preexec_fn=limit,timeout=120)
 except subprocess.TimeoutExpired as e:
  r=subprocess.CompletedProcess(cmd,-9,e.stdout or b'',e.stderr or b'');r.timed_out=True;preserve(cmd,W,r,(src,),(W/'manifest.json',));raise
 (W/'results'/(name+'.stdout')).write_bytes(r.stdout);(W/'results'/(name+'.stderr')).write_bytes(r.stderr)
 results.append({'name':name,'command':cmd,'wall_seconds':time.monotonic()-start,'status':r.returncode,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
 (W/'execution.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,r.returncode,repr(r.stdout.decode(errors='replace')),flush=True)
 if crashed(r.returncode) or b'VOID IR:' in r.stderr:
  preserve(cmd,W,r,(src,),(W/'manifest.json',));raise RuntimeError('stop on abnormal exit')
 assert r.returncode==0,(cmd,r.stderr)
 if wanted is not None:assert r.stdout==wanted,(name,r.stdout,wanted)
for name,wanted in [('generic_event',b'7\n'),('identity_key',b'true false\n7\ntrue false\n'),('unique_wrappers',b'false true\n7\n'),('event_const_payload',b'7\n7\n'),('global_topic',b'7\n')]:
 src=W/name/'main.void'
 for mode in ('O0','O2'):
  run(name+'-'+mode,[C,'run',src]+(['--no-opt'] if mode=='O0' else []),src,wanted)
src=W/'generic_event/main.void';exe=W/'generic_event/native'
run('generic_event-build',[C,'build',src,'-o',exe],src)
run('generic_event-native',[exe],src,b'7\n')
print('DONE',len(results),'successful execution/build probes',flush=True)
