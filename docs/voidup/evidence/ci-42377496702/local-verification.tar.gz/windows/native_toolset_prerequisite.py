from pathlib import Path
import datetime,json
share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'toolset-prerequisite';out.mkdir(exist_ok=True)
instances=Path(r'C:\ProgramData\Microsoft\VisualStudio\Packages\_Instances');report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'catalogs':[],'installer':str(Path(r'C:\Program Files (x86)\Microsoft Visual Studio\Installer\setup.exe'))}
for p in instances.glob('*/catalog.json'):
 catalog=json.loads(p.read_text(encoding='utf-8-sig'));packages=catalog.get('packages',[])
 if isinstance(packages,dict):packages=list(packages.values())
 selected=[v for v in packages if any(k in str(v.get('id','')) for k in ['Llvm.ClangToolset','Llvm.Clang'])]
 deps={key for v in selected for key in v.get('dependencies',{})};children=[v for v in packages if v.get('id') in deps]
 report['catalogs'].append({'path':str(p),'records':selected,'direct_dependency_records':children})
report['installer_exists']=Path(report['installer']).is_file()
(out/'catalog-components.json').write_text(json.dumps(report,indent=2)+'\n')
