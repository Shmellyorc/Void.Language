@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\retry-host-paths-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\retry_host_native_paths.py" > "\\vboxsvr\VM\ci-42377496702\retry-host-native-paths-console.log" 2>&1
