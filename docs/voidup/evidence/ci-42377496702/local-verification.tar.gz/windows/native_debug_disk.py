from pathlib import Path
import ctypes,datetime,json,shutil
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');build=root/'build/Debug';record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(root).free,'top_level_outputs':{},'largest':[],'volumes':[]}
for suffix in ['.exe','.pdb','.lib']:
 values=[(p.stat().st_size,str(p.name)) for p in build.glob('*'+suffix) if p.is_file()];record['top_level_outputs'][suffix]={'count':len(values),'bytes':sum(x[0] for x in values)};record['largest']+=sorted(values,reverse=True)[:6]
k=ctypes.WinDLL('kernel32',use_last_error=True);d=ctypes.c_ulong;k.GetVolumePathNameW.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,d];k.GetVolumeInformationW.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,d,ctypes.POINTER(d),ctypes.POINTER(d),ctypes.POINTER(d),ctypes.c_wchar_p,d]
for name in [root,share/'native-second-filesystem']:
 volume=ctypes.create_unicode_buffer(1024);fs=ctypes.create_unicode_buffer(256);label=ctypes.create_unicode_buffer(256);serial=d();maximum=d();flags=d();ok=k.GetVolumePathNameW(str(name),volume,len(volume));error=ctypes.get_last_error() if not ok else 0
 if ok:ok=k.GetVolumeInformationW(volume.value,label,len(label),ctypes.byref(serial),ctypes.byref(maximum),ctypes.byref(flags),fs,len(fs));error=ctypes.get_last_error() if not ok else 0
 record['volumes'].append({'path':str(name),'volume_path':volume.value,'filesystem':fs.value,'serial':serial.value,'flags':flags.value,'ok':bool(ok),'error':error,'st_dev':name.stat().st_dev})
(share/'native-debug-disk-1.json').write_text(json.dumps(record,indent=2)+'\n')
