from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback,zipfile
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native'
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'commands':[],'status':'running'}
def save(): (share/'native-rebuild.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def run(label,command):
 start=time.monotonic()
 with (share/(label+'.log')).open('wb') as stream:r=subprocess.run(list(map(str,command)),cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'command':list(map(str,command)),'status':r.returncode,'seconds':time.monotonic()-start});save()
 if r.returncode:raise RuntimeError(label+' failed; retained log')
save()
try:
 archive=share/'documentation-inputs.zip';m=json.loads((share/'documentation-inputs.json').read_text())
 with archive.open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==m['archive_sha256']
 with zipfile.ZipFile(archive) as z:z.extractall(root)
 for f in m['files']:assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256']
 report['documentation_inputs_verified']=len(m['files'])
 for profile in ['Release','Debug']:
  prefix=root/'.toolchains/http/prefix/windows-schannel-x86_64'/profile
  retained=root/'.toolchains/http/stale-prefixes'/profile;retained.parent.mkdir(parents=True,exist_ok=True);prefix.rename(retained)
 env=dict(os.environ,PATH=str(root/'.toolchains/llvm-23.1.4/bin')+os.pathsep+os.environ['PATH'])
 report['free_bytes_before_build']=shutil.disk_usage(root).free
 for profile in ['Release','Debug']:
  report['stage']='HTTP '+profile;save()
  run('native-http-build-'+profile,[sys.executable,'tools/setup_http_deps.py','--profile',profile,'--jobs','3'])
  run('native-http-rebuilt-verify-'+profile,[sys.executable,'tools/verify_http_dependencies.py',root/'.toolchains/http/prefix/windows-schannel-x86_64'/profile,profile,'Windows','x86_64'])
 for profile in ['Release','Debug']:
  report['stage']='host '+profile;save()
  run('native-host-build-'+profile,[sys.executable,'tools/setup_host_deps.py','--profile',profile,'--jobs','3'])
  run('native-host-verify-'+profile,[sys.executable,'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'])
  run('native-host-negative-'+profile,[sys.executable,'tests/host_capabilities/dependencies.py',root/'.toolchains/host/prefix/windows-x86_64'/profile,profile,'Windows','x86_64'])
 report['status']='PASS';report['stage']='providers verified'
except BaseException as exc:
 report['status']='FAIL';report['error']=repr(exc);report['traceback']=traceback.format_exc();raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 for family in ['voidup','net/http']:
  evidence=root/'docs'/family/'evidence'
  for p in evidence.glob('dependencies-*'):
   shutil.copytree(p,share/'native-provider-evidence'/family/p.name,dirs_exist_ok=True)
