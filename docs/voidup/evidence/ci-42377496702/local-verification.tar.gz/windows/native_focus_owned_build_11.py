from pathlib import Path
import ctypes,json
u=ctypes.windll.user32;matches=[]
@ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
def visit(hwnd,_):
 if not u.IsWindowVisible(hwnd):return True
 n=u.GetWindowTextLengthW(hwnd);text=ctypes.create_unicode_buffer(n+1);u.GetWindowTextW(hwnd,text,n+1)
 if 'VOID native Debug continuation and tests - one worker' in text.value:matches.append({'hwnd':int(hwnd),'title':text.value})
 return True
u.EnumWindows(visit,0)
assert len(matches)==1,matches
hwnd=matches[0]['hwnd'];u.ShowWindow(hwnd,9);matches[0]['focused']=bool(u.SetForegroundWindow(hwnd))
Path(r'\\vboxsvr\VM\ci-42377496702\native-debug-build-focus-11.json').write_text(json.dumps(matches,indent=2)+'\n')
