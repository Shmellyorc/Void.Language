@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_python_inventory.py" > "\\vboxsvr\VM\ci-42377496702\python-inventory-console.log" 2>&1
