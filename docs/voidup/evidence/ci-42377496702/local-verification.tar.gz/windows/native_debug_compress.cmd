@echo off
title VOID task-only Debug output compression - no build running
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_debug_compress.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-compression-console.log" 2>&1
