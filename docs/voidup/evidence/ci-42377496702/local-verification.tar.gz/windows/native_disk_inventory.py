from pathlib import Path
import ctypes,datetime,json,os,shutil,subprocess
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
r={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'groups':{},'errors':[]}
a=ctypes.c_ulonglong();b=ctypes.c_ulonglong();c=ctypes.c_ulonglong();assert k.GetDiskFreeSpaceExW(ctypes.c_wchar_p(str(root)),ctypes.byref(a),ctypes.byref(b),ctypes.byref(c));r['disk']={'available_to_caller':a.value,'volume_bytes':b.value,'free_bytes':c.value}
stack=[root]
while stack:
 directory=stack.pop()
 try:entries=list(os.scandir(directory))
 except OSError as e:r['errors'].append(str(e));continue
 for e in entries:
  try:
   stat=e.stat(follow_symlinks=False)
   if stat.st_file_attributes&0x400:continue
   if e.is_dir(follow_symlinks=False):stack.append(Path(e.path));continue
   if not e.is_file(follow_symlinks=False):continue
   rel=Path(e.path).relative_to(root);parts=rel.parts;group='/'.join(parts[:3] if parts[0]=='build' and len(parts)>3 else parts[:2] if len(parts)>2 else parts[:1]);item=r['groups'].setdefault(group,{'files':0,'logical_bytes':0,'allocated_bytes':0});high=ctypes.c_uint32();low=k.GetCompressedFileSizeW(e.path,ctypes.byref(high));item['files']+=1;item['logical_bytes']+=stat.st_size;item['allocated_bytes']+=(high.value<<32)|low
  except OSError as e:r['errors'].append(str(e))
ps="@{Shadows=(Get-CimInstance Win32_ShadowStorage -ErrorAction SilentlyContinue | Select-Object UsedSpace,AllocatedSpace,MaxSpace);Volumes=(Get-CimInstance Win32_LogicalDisk | Select-Object DeviceID,FreeSpace,Size);Pagefile=(Get-CimInstance Win32_PageFileUsage | Select-Object Name,AllocatedBaseSize,CurrentUsage)} | ConvertTo-Json -Depth 3"
x=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True);r['system_query']={'status':x.returncode,'stdout':x.stdout,'stderr':x.stderr}
(share/'native-debug-disk-inventory.json').write_text(json.dumps(r,indent=2)+'\n')
