@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_toolset_prerequisite.py" > "\\vboxsvr\VM\ci-42377496702\toolset-prerequisite-console.log" 2>&1
