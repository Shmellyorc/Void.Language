@echo off
title VOID post-stop free-space readings - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_free_after_stop.py" > "\\vboxsvr\VM\ci-42377496702\native-free-after-stop.log" 2>&1
