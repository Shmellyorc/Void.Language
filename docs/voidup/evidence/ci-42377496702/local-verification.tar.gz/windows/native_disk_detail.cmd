@echo off
title VOID disk allocation inspection - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_disk_detail.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-disk-detail.log" 2>&1
