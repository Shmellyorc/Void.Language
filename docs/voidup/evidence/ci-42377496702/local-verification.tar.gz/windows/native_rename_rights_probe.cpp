#include "src/runtime/host_internal.hpp"
#include <windows.h>
#include <filesystem>
#include <iostream>
namespace vd::host {Result windows_directory_execute_rename_probe(Request&);}
namespace fs=std::filesystem;using namespace vd::host;
std::string text(const fs::path& p){auto s=p.u8string();return std::string(s.begin(),s.end());}
void show(const char* label,const Result& r){std::cout<<label<<" kind="<<r.kind<<" code="<<r.code<<" detail="<<r.detail<<" published="<<r.flag<<"\n";}
int wmain(int argc,wchar_t** argv){if(argc!=2)return 2;fs::path base(argv[1]);
 int extra=0;
 for(ACCESS_MASK rights:{READ_CONTROL|SYNCHRONIZE|FILE_READ_ATTRIBUTES|DELETE|FILE_LIST_DIRECTORY|GENERIC_WRITE,READ_CONTROL|SYNCHRONIZE|FILE_READ_ATTRIBUTES|FILE_LIST_DIRECTORY|GENERIC_WRITE,READ_CONTROL|SYNCHRONIZE|FILE_READ_ATTRIBUTES|DELETE|FILE_LIST_DIRECTORY,READ_CONTROL|SYNCHRONIZE|FILE_READ_ATTRIBUTES|DELETE,READ_CONTROL|SYNCHRONIZE|FILE_READ_ATTRIBUTES|FILE_LIST_DIRECTORY,READ_CONTROL|SYNCHRONIZE|FILE_READ_ATTRIBUTES|FILE_TRAVERSE}) {
  std::cout<<"CASE "<<extra<<" rights="<<std::hex<<rights<<std::dec<<"\n";
  Request q{};q.operation=dir_create;auto parent=base/(L"root-"+std::to_wstring(extra));q.texts={text(parent)};q.numbers={static_cast<std::int64_t>(rights)};auto r=windows_directory_execute_rename_probe(q);show("create-root",r);if(r.kind)return 1;auto root=q.acquired;
  q={};q.operation=dir_child;q.objects={root};q.texts={"stage"};r=windows_directory_execute_rename_probe(q);show("create-stage",r);if(r.kind)return 1;auto stage=q.acquired;
  q={};q.operation=dir_publish;q.objects={stage,root};q.texts={"release"};q.numbers={extra};r=windows_directory_execute_rename_probe(q);show("publish",r);
  std::cout<<"extra="<<extra<<" old_exists="<<fs::exists(parent/L"stage")<<" destination_exists="<<fs::exists(parent/L"release")<<"\n";
  stage->close();root->close();++extra;
 }
 return 0;
}
