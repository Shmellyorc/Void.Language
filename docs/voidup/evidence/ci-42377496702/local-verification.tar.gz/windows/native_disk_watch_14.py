from pathlib import Path
import datetime,json,shutil,time
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702')
for _ in range(360):
 state=json.loads((share/'native-downstream-14/result.json').read_text())
 record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(root).free,'status':state['status'],'stage':state.get('stage')}
 (share/'native-debug-disk-latest-14.json').write_text(json.dumps(record,indent=2)+'\n')
 with (share/'native-debug-disk-watch-14.jsonl').open('a') as f:f.write(json.dumps(record)+'\n')
 if state['status']!='running':break
 time.sleep(60)
