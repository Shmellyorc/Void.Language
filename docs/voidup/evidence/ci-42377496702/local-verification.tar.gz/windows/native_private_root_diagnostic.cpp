#include "src/runtime/host_internal.hpp"
#include "src/runtime/host_windows.hpp"
#include <iostream>
std::string utf8(const std::wstring& w) {int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),static_cast<int>(w.size()),nullptr,0,nullptr,nullptr);std::string s(n,0);WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,w.data(),static_cast<int>(w.size()),s.data(),n,nullptr,nullptr);return s;}
int wmain(int argc,wchar_t** argv) {
 if(argc!=2)return 2;using namespace vd::host;std::string path=utf8(argv[1]);auto full=win::absolute(path);win::PrivateAccess access;
 for(std::size_t end=7;;) {
  auto part=full.substr(0,end);win::Handle h(CreateFileW(part.c_str(),FILE_LIST_DIRECTORY|READ_CONTROL,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT,nullptr));
  std::cout<<"ancestor="<<utf8(part)<<" open="<<(h.value!=INVALID_HANDLE_VALUE)<<" error="<<(h.value==INVALID_HANDLE_VALUE?GetLastError():0)<<"\n";
  if(h.value!=INVALID_HANDLE_VALUE) {
   PSECURITY_DESCRIPTOR raw=nullptr;auto code=GetSecurityInfo(h.value,SE_FILE_OBJECT,OWNER_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION,nullptr,nullptr,nullptr,nullptr,&raw);
   if(code==ERROR_SUCCESS){LPWSTR text=nullptr;if(ConvertSecurityDescriptorToStringSecurityDescriptorW(raw,SDDL_REVISION_1,OWNER_SECURITY_INFORMATION|DACL_SECURITY_INFORMATION,&text,nullptr)){std::cout<<"sddl="<<utf8(text)<<"\n";LocalFree(text);}LocalFree(raw);}
   try{win::information(h.value,true);access.verify(h.value,true);std::cout<<"ancestor_accepted=1\n";}catch(const std::system_error& e){std::cout<<"ancestor_accepted=0 code="<<e.code().value()<<" message="<<e.what()<<"\n";}
  }
  auto next=full.find(L'\\',end==7?7:end+1);if(next==full.npos)break;end=next;
 }
 Request q{};q.operation=dir_create;q.texts={path};auto r=directory_execute(q);std::cout<<"dir_create kind="<<r.kind<<" code="<<r.code<<" detail="<<r.detail<<" acquired="<<bool(q.acquired)<<"\n";
 if(q.acquired)q.acquired->close();return 0;
}
