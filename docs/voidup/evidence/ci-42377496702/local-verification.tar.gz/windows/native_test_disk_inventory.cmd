@echo off
title VOID generated test-directory inventory - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_test_disk_inventory.py" > "\\vboxsvr\VM\ci-42377496702\native-test-disk-inventory.log" 2>&1
