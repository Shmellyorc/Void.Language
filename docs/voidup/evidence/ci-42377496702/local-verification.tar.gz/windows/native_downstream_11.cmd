@echo off
title VOID native Debug continuation and tests - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\downstream-11-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_downstream_11.py" > "\\vboxsvr\VM\ci-42377496702\downstream-11-console.log" 2>&1
