import ctypes,json,subprocess
from pathlib import Path
u=ctypes.windll.user32;windows=[]
@ctypes.WINFUNCTYPE(ctypes.c_bool,ctypes.c_void_p,ctypes.c_void_p)
def visit(hwnd,_):
 if not u.IsWindowVisible(hwnd):return True
 count=u.GetWindowTextLengthW(hwnd);text=ctypes.create_unicode_buffer(count+1);u.GetWindowTextW(hwnd,text,count+1)
 if 'cmd.exe' in text.value.lower():
  pid=ctypes.c_ulong();u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid));rect=(ctypes.c_long*4)();u.GetWindowRect(hwnd,ctypes.byref(rect));windows.append({'handle':int(hwnd),'pid':pid.value,'title':text.value,'rect':list(rect)})
 return True
u.EnumWindows(visit,0)
ps="Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('cmd.exe','python.exe','ctest.exe','cmake.exe','ninja.exe','clang-cl.exe','voidc.exe') } | Select-Object Name,ProcessId,ParentProcessId,CreationDate,CommandLine | ConvertTo-Json -Depth 3"
r=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True);r.check_returncode()
Path(r'\\vboxsvr\VM\ci-42377496702\native-console-identity.json').write_text(json.dumps({'windows':windows,'processes':json.loads(r.stdout)},indent=2)+'\n')
