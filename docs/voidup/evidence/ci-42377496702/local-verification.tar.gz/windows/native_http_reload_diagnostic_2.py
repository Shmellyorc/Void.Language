from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-http-reload-diagnostic-2';inputs=share/'native-http-reload-diagnostic-inputs-2';out.mkdir(exist_ok=False);sdk=(root/'.toolchains/llvm-23.1.4').resolve();build=root/'build/Debug';private=root/'native-private-temp'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[],'scope':'Disposable fixture-only timing/error observation; original HTTP deadlines and all assertions retained; no production HTTP change.'};installed=False;originals={}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args,allowed=(0,)):
 record['stage']=label;save();start=time.monotonic()
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':list(map(str,args)),'status':r.returncode,'seconds':time.monotonic()-start,'free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode not in allowed:raise RuntimeError(label+' failed; original output retained')
 return r.returncode
try:
 previous=json.loads((share/'native-downstream-13/result.json').read_text());remaining=json.loads((share/'native-downstream-14/result.json').read_text());assert previous['status']=='FAIL' and previous['error']=='KeyboardInterrupt()' and remaining['status']=='PASS' and len(remaining['remaining_tests'])==34,'Complete all350 cases across preserved partial run and exact remaining-case continuation before diagnosis'
 metadata=json.loads((inputs/'inputs.json').read_text())
 for name,item in metadata.items():
  originals[name]=(root/'tests/net/http'/name).read_bytes();assert hashlib.sha256(originals[name]).hexdigest()==item['original_sha256'];assert hashlib.sha256((inputs/name).read_bytes()).hexdigest()==item['diagnostic_sha256']
 record['input_sha256']=metadata;record['original_binary_sha256']=hashlib.sha256((build/'void_http_reload.exe').read_bytes()).hexdigest();save()
 before=out/'source-before';before.mkdir(exist_ok=True)
 for name,data in originals.items():(before/name).write_bytes(data)
 installed=True
 for name in originals:shutil.copyfile(inputs/name,root/'tests/net/http'/name)
 run('build-instrumented',['cmake','--build',build,'--target','void_http_reload','--parallel','1'])
 record['diagnostic_binary_sha256']=hashlib.sha256((build/'void_http_reload.exe').read_bytes()).hexdigest();save()
 result=run('diagnostic-test',['ctest','--test-dir',build,'--output-on-failure','--parallel','1','-R','^http_reload$','--output-junit',out/'diagnostic.xml'],(0,8))
 evidence=out/'fixture-evidence';evidence.mkdir(exist_ok=True)
 for name in ['original.void','final.void','native.stdout','native.stderr','commands.json']:
  source=build/'http-reload-evidence'/name
  if source.is_file():shutil.copy2(source,evidence/name)
 stderr=(evidence/'native.stderr').read_text(errors='replace') if (evidence/'native.stderr').exists() else ''
 record['reproduced_http_timeout']='DIAG failure_result=-30030' in stderr;record['fixture_ctest_exit']=result;record['status']='OBSERVED'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:
 record['original_fixture_rebuild_completed']=False
 try:
  if installed:
   for name,data in originals.items():(root/'tests/net/http'/name).write_bytes(data)
   record['original_source_restored']=all((root/'tests/net/http'/name).read_bytes()==data for name,data in originals.items());save()
   assert record['original_source_restored'],'Original diagnostic fixture bytes were not restored'
   run('rebuild-original',['cmake','--build',build,'--target','void_http_reload','--parallel','1'])
   record['original_fixture_rebuild_completed']=True
   record['restored_binary_sha256']=hashlib.sha256((build/'void_http_reload.exe').read_bytes()).hexdigest()
 except BaseException as restoration_error:
  record['status_before_restoration_failure']=record['status']
  record.update(status='RESTORATION_FAILED',restoration_error=repr(restoration_error),restoration_traceback=traceback.format_exc())
  raise
 finally:
  record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
