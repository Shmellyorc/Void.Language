from pathlib import Path
import ctypes,json,os,shutil,subprocess
share=Path(r"\\vboxsvr\VM\ci-42377496702");out=share/'native-editor-prereqs';out.mkdir(exist_ok=True)
record={'paths':{},'node_candidates':[],'candidate_parents':{},'disk_free_bytes':shutil.disk_usage(Path.home()).free}
for name in ['node','npm','compact']:
 record['paths'][name]=shutil.which(name)
for path in [Path(r'C:\Program Files\nodejs\node.exe'),Path.home()/'AppData/Roaming/nvm',Path.home()/'AppData/Local/fnm',Path(r'C:\hostedtoolcache\windows\node')]:
 record['candidate_parents'][str(path)]=[x.name for x in path.iterdir()] if path.is_dir() else path.is_file()
node=shutil.which('node')
if node:
 run=subprocess.run([node,'--version'],capture_output=True,text=True);record['node_candidates'].append({'path':node,'status':run.returncode,'version':run.stdout.strip(),'stderr':run.stderr})
fs=ctypes.create_unicode_buffer(256);serial=ctypes.c_ulong();maximum=ctypes.c_ulong();flags=ctypes.c_ulong()
assert ctypes.windll.kernel32.GetVolumeInformationW('C:\\',None,0,ctypes.byref(serial),ctypes.byref(maximum),ctypes.byref(flags),fs,len(fs))
record['filesystem']={'name':fs.value,'flags':flags.value,'supports_compression':bool(flags.value&0x10)}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
