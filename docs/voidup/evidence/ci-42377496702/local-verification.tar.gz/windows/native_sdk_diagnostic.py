from pathlib import Path
import datetime,json,shutil,subprocess,sys
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'sdk-diagnostic';out.mkdir(exist_ok=True)
records=list((root/'docs/voidup/evidence').glob('dependencies-windows-x86_64-Release-*'));record=max(records,key=lambda p:p.stat().st_mtime)
report=json.loads((record/'commands.json').read_text());command=next(v['command'] for v in report['commands'] if any(str(a).startswith('-getProperty:') for a in v['command']))
command[-1]='-getProperty:WindowsTargetPlatformVersion,WindowsSDKVersion,WindowsSDKLibVersion,UCRTVersion,WindowsSdkDir,WindowsSdkDir_10,WindowsSDK_IncludePath,WindowsSDK_LibraryPath_x64,UniversalCRTSdkDir,TargetPlatformVersion,WindowsSDK_TargetPlatformVersion,WindowsSdkVerBinPath'
with (out/'evaluated-sdk-properties.log').open('wb') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
vc=Path(r'C:\BuildTools\VS2022\MSBuild\Microsoft\VC\v170')
for name in ['Microsoft.Cpp.Default.props','Microsoft.Cpp.WindowsSDK.props','Microsoft.Cpp.WindowsSDK.targets','Microsoft.Cpp.Clang.props','Microsoft.Cpp.Clang.targets','Microsoft.Cpp.Platform.props','Microsoft.Cpp.Platform.targets']:
 p=vc/name
 if p.exists():shutil.copy2(p,out/name)
toolsets=vc/'Platforms/x64/PlatformToolsets'
state={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'query_command':command,'query_exit':result.returncode,'installed_platform_toolsets':[p.name for p in toolsets.iterdir()] if toolsets.exists() else [],'clangcl_toolset_exists':(toolsets/'ClangCL/Toolset.props').is_file(),'clangcl_targets_exists':(toolsets/'ClangCL/Toolset.targets').is_file()}
(out/'result.json').write_text(json.dumps(state,indent=2)+'\n')
