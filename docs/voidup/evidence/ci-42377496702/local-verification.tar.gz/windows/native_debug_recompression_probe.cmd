@echo off
title VOID task Debug PDB compression allocation check
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_debug_recompression_probe.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-recompression-probe-console.log" 2>&1
