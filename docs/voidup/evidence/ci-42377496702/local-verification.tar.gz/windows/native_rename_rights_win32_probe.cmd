@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\rename-rights-win32-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_rename_rights_win32_probe.py" > "\\vboxsvr\VM\ci-42377496702\rename-rights-win32-console.log" 2>&1
