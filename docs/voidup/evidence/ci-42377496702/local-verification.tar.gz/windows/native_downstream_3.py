from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-downstream-3';out.mkdir(exist_ok=True)
sdk=root/'.toolchains/llvm-23.1.4';deps=root/'.toolchains/llvm-23.1.4-deps';cc=sdk/'bin/clang-cl.exe'
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','jobs':1,'commands':[]}
def save():(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH'],CC=str(cc),CXX=str(cc),LLVM_DIR=str(sdk/'lib/cmake/llvm'),VOID_CLANG=str(sdk/'bin/clang.exe'),VOID_LINKER='',CMAKE_PREFIX_PATH=str(deps),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args,expect=0):
 report['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode!=expect:raise RuntimeError(label+' failed; original log retained')
try:
 assert json.loads((share/'native-host-restart-1.json').read_text())['status']=='PASS','Providers must finish first'
 env['PATH']+=os.pathsep+str(Path(r'C:\Program Files\Git\usr\bin'))
 report['task_only_path_append']=str(Path(r'C:\Program Files\Git\usr\bin'))
 reviews=json.loads((root/'third_party/curl/VOID-PROVENANCE.json').read_text())['approved_corrections']
 report['restored_snapshot_inputs']=[]
 for review in reviews.values():
  source=share/'required-review-inputs'/review['review_diff'];assert hashlib.sha256(source.read_bytes()).hexdigest()==review['sha256']
  target=root/review['review_diff'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
  assert hashlib.sha256(target.read_bytes()).hexdigest()==review['sha256'];report['restored_snapshot_inputs'].append({'path':review['review_diff'],'sha256':review['sha256']})
 failed=root/'build/Release'
 if failed.exists():failed.rename(root/'build/retained-configure-Release-missing-review-patch')
 run('curl-provenance',[sys.executable,'tools/verify_curl_source.py'])
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  run('host-bootstrap-verify-'+profile,[sys.executable,'tools/ci/voidup_bootstrap.py','verify','--configuration',profile,'--evidence',out/('bootstrap-'+profile)])
  run('configure-'+profile,['cmake','-S','.', '-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE='+profile,'-DVOID_SANITIZERS=OFF','-DLLVM_DIR='+str(sdk/'lib/cmake/llvm'),'-DVOID_CLANG='+str(sdk/'bin/clang.exe'),'-DVOID_LINKER=','-DPython3_EXECUTABLE='+sys.executable])
  run('build-'+profile,['cmake','--build',build,'--parallel','1'])
  run('host-test-plan-'+profile,[sys.executable,'tools/ci/voidup_bootstrap.py','test-plan','--configuration',profile,'--build',build,'--evidence',out/('bootstrap-'+profile)])
  run('http-test-plan-'+profile,[sys.executable,'tools/ci/http_bootstrap.py','test-plan','--configuration',profile,'--build',build,'--evidence',out/('http-'+profile)])
  run('focused-tests-'+profile,['ctest','--test-dir',build,'--output-on-failure','-R','^(host_capabilities_dependencies|host_capabilities_portable|host_capabilities_portable_source|voidup_smoke|voidup_ci_integration)$','--output-junit',out/('focused-'+profile+'.xml')])
  run('full-tests-'+profile,['ctest','--test-dir',build,'--output-on-failure','--output-junit',out/('full-'+profile+'.xml')])
 for profile in ['Release','Debug']:
  for label,relative in [('voidc','voidc.exe'),('host-portable','void_host_portable.exe'),('voidup','voidup/voidup.exe')]:
   run('pe-headers-'+profile+'-'+label,[sdk/'bin/llvm-readobj.exe','--file-headers',root/'build'/profile/relative])
 run('install-compiler-Release' ,['cmake','--install',root/'build/Release','--component','compiler','--prefix',root/'build/native-installed-Release'])
 run('native-package-audit',[sys.executable,share/'native_package_check.py'])
 report['status']='PASS'
except BaseException as exc:report['status']='FAIL';report['error']=repr(exc);report['traceback']=traceback.format_exc();raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  for relative in ['CMakeCache.txt','CMakeFiles/CMakeConfigureLog.yaml','Testing/Temporary/LastTest.log','compile_commands.json','void-llvm-dependencies-'+profile+'.txt']:
   source=build/relative
   if source.is_file():target=out/profile/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
