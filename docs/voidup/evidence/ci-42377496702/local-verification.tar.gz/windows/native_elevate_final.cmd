@echo off
title VOID native CI - request existing administrator token
powershell -NoProfile -Command "Start-Process -FilePath 'C:\Windows\System32\cmd.exe' -ArgumentList '/d /c \\vboxsvr\VM\ci-42377496702\native_final_checks.cmd' -Verb RunAs" > "\\vboxsvr\VM\ci-42377496702\native-elevate-final.log" 2>&1
