@echo off
title VOID native prerequisite inspection - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_editor_prereqs.py" > "\\vboxsvr\VM\ci-42377496702\native-editor-prereqs-console.log" 2>&1
