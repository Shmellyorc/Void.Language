from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback,zipfile
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-final-checks';out.mkdir(exist_ok=False)
sdk=(root/'.toolchains/llvm-23.1.4').resolve();private=root/'native-private-temp';node=root/'.toolchains/native-editor/node-v24.19.0-win-x64';editor=root/'editors/vscode'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','jobs':1,'commands':[]}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args,cwd=root):
 record['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as log:result=subprocess.run(argv,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':argv,'status':result.returncode,'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage(root).free});save()
 if result.returncode:raise RuntimeError(label+' failed; original output retained')
try:
 assert json.loads((share/'native-post-tests/result.json').read_text())['status']=='PASS','Finish final native test corrections, provider and package verification first'
 package=share/'native-node-prerequisite';download=json.loads((package/'verified-download.json').read_text());archive=package/'node-v24.19.0-win-x64.zip';assert hashlib.sha256(archive.read_bytes()).hexdigest()==download['sha256']=='57f71ab3652e797d84acddc79c81cc9ff1c6ddb2a1974cdb83f00fee9bff4c73'
 assert not node.exists(),'Do not overwrite an existing local prerequisite'
 node.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(archive) as source:
  for name in source.namelist():assert name.startswith(node.name+'/') and '..' not in Path(name).parts and not Path(name).is_absolute(),name
  source.extractall(node.parent)
 env['npm_config_cache']=str(node.parent/'npm-cache')
 env['PATH']=str(node)+os.pathsep+env['PATH'];env['VOIDLS_TEST_SERVER']=env['VOIDLS_PATH']=str(root/'build/Debug/voidls.exe')
 record['node']=download;record['node']['scope']='Verified official task-local ZIP, no installer/global environment change';record['node']['executable_sha256']=hashlib.sha256((node/'node.exe').read_bytes()).hexdigest();save()
 run('node-version',[node/'node.exe','--version']);assert (out/'node-version.log').read_bytes().strip()==b'v24.19.0'
 npm=[node/'node.exe',node/'node_modules/npm/bin/npm-cli.js'];run('npm-version',npm+['--version'])
 inputs={name:hashlib.sha256((editor/name).read_bytes()).hexdigest() for name in ['package.json','package-lock.json']};record['editor_input_sha256']=inputs;save()
 run('npm-ci',npm+['ci'],editor)
 run('npm-test',npm+['test'],editor)
 run('npm-test-host',npm+['run','test:host'],editor)
 run('npm-package',npm+['run','package'],editor)
 assert inputs=={name:hashlib.sha256((editor/name).read_bytes()).hexdigest() for name in inputs},'Editor dependency inputs changed'
 vsix=editor/'dist/void-language-0.1.0.vsix';record['vsix']={'path':str(vsix),'bytes':vsix.stat().st_size,'sha256':hashlib.sha256(vsix.read_bytes()).hexdigest()}
 record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:
 record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
