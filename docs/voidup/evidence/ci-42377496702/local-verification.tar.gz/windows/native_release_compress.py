from pathlib import Path
import ctypes,datetime,hashlib,json,shutil,subprocess,traceback
root=Path.home()/'VoidCI42377496702-Native';build=root/'build/Release';share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'native-release-compression';out.mkdir(exist_ok=True)
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','scope':'Classic NTFS compression of task-owned generated Release EXE/PDB files only; directory inheritance unchanged. No deletion, WOF /EXE mode, reparse changes, source or build-setting changes.','files':[],'free_before':shutil.disk_usage(root).free}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetFileAttributesW.argtypes=[ctypes.c_wchar_p];k.GetFileAttributesW.restype=ctypes.c_uint32
k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
def disk_size(p):
 high=ctypes.c_uint32();low=k.GetCompressedFileSizeW(str(p),ctypes.byref(high))
 assert low!=0xffffffff or ctypes.get_last_error()==0
 return (high.value<<32)|low
try:
 previous=json.loads((share/'native-downstream-12/result.json').read_text());assert previous['status']=='FAIL' and previous['error']=='KeyboardInterrupt()'
 ps="Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('ninja.exe','cmake.exe','clang-cl.exe','lld-link.exe','ctest.exe') -or $_.Name -like 'void*.exe' } | Select-Object Name,ProcessId,CommandLine | ConvertTo-Json -Depth 3"
 check=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True);check.check_returncode();(out/'process-boundary.json').write_text(check.stdout or '[]\n');assert not check.stdout.strip(),'No native build or test process may remain before output compression'
 compact=Path(r'C:\Windows\System32\compact.exe');assert compact.is_file()
 with (out/'compact.log').open('wb') as log:
  record['directory_attributes_before']=k.GetFileAttributesW(str(build));assert not record['directory_attributes_before']&0x400
  for file in sorted(list(build.glob('*.exe'))+list(build.glob('*.pdb'))):
   assert file.is_file() and not file.is_symlink() and not k.GetFileAttributesW(str(file))&0x400
   entry={'name':file.name,'logical_bytes':file.stat().st_size,'sha256_before':sha(file),'disk_bytes_before':disk_size(file)}
   r=subprocess.run([str(compact),'/C','/I','/Q',str(file)],stdout=log,stderr=subprocess.STDOUT);assert r.returncode==0,(file,r.returncode)
   entry.update(sha256_after=sha(file),disk_bytes_after=disk_size(file),attributes=k.GetFileAttributesW(str(file)))
   assert entry['sha256_before']==entry['sha256_after'] and entry['attributes']&0x800 and not entry['attributes']&0x400
   record['files'].append(entry);save()
 record.update(status='PASS',free_after=shutil.disk_usage(root).free,file_count=len(record['files']),all_logical_hashes_preserved=True,directory_attributes_after=k.GetFileAttributesW(str(build)))
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
