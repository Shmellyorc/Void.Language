@echo off
title VOID Debug free-space monitor - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_disk_watch_14.py"
