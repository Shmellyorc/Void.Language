@echo off
title VOID final portable and editor checks - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\native-final-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_final_checks.py" > "\\vboxsvr\VM\ci-42377496702\native-final-console.log" 2>&1
