from pathlib import Path
import json,os,shutil,subprocess
share=Path(r'\\vboxsvr\VM\ci-42377496702');results={'py_launcher':shutil.which('py'),'candidates':[]}
if results['py_launcher']:
 r=subprocess.run([results['py_launcher'],'-0p'],capture_output=True,text=True);results['launcher']={'status':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
for base in [Path(os.environ['LOCALAPPDATA'])/'Programs/Python',Path('C:/Program Files'),Path('C:/')]:
 for executable in base.glob('Python*/python.exe'):
  r=subprocess.run([str(executable),'--version'],capture_output=True,text=True);results['candidates'].append({'path':str(executable),'status':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
(share/'native-python-inventory.json').write_text(json.dumps(results,indent=2)+'\n')
