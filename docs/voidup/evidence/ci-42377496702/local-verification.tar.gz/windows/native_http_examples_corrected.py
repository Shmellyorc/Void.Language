from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-http-examples-corrected';out.mkdir(exist_ok=False);sdk=(root/'.toolchains/llvm-23.1.4').resolve();private=root/'native-private-temp'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[],'scope':'Only existing http_examples aggregate CTest watchdog300→600 after unchanged19-command nativeDebug proof302.535s. Per-command120s and all positive/negative assertions unchanged.'}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args):
 record['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode:raise RuntimeError(label+' failed; output retained')
try:
 direct=json.loads((share/'native-http-examples-debug-direct/result.json').read_text());assert direct['status']=='PASS' and direct['completed_commands']==19 and direct['seconds']>300
 assert json.loads((share/'native-http-reload-corrected/result.json').read_text())['status']=='PASS'
 expected=json.loads((share/'native-http-examples-corrected-input.json').read_text());cmake=root/'CMakeLists.txt';candidate=share/'source-overlays/CMakeLists.txt';source=root/'tests/net/http/examples.py'
 assert hashlib.sha256(cmake.read_bytes()).hexdigest()==expected['cmake_before'];assert hashlib.sha256(candidate.read_bytes()).hexdigest()==expected['cmake_after'];assert hashlib.sha256(source.read_bytes()).hexdigest()==expected['examples_sha256']
 shutil.copyfile(cmake,out/'CMakeLists-before.txt');shutil.copyfile(candidate,cmake);shutil.copyfile(cmake,out/'CMakeLists-after.txt');record['input_sha256']=expected;save()
 names=[x['name'] for x in json.loads((share/'native-debug-between-tests-compression-2/all-tests.json').read_text())['tests']]
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  run('configure-'+profile,['cmake','-S',root,'-B',build])
  plan=subprocess.run(['ctest','--test-dir',str(build),'--show-only=json-v1'],cwd=root,env=env,capture_output=True);plan.check_returncode();(out/(profile+'-test-plan.json')).write_bytes(plan.stdout);tests=json.loads(plan.stdout)['tests'];assert [x['name'] for x in tests]==names
  actual=next(t for t in tests if t['name']=='http_examples');assert next(v['value'] for v in actual['properties'] if v['name']=='TIMEOUT')==600
  assert next(v['value'] for t in tests if t['name']=='http_reload' for v in t['properties'] if v['name']=='TIMEOUT')==240
  previous=build/'http-examples-evidence'
  if previous.exists():shutil.copytree(previous,out/(profile+'-prior-evidence'))
  run('tests-'+profile,['ctest','--test-dir',build,'--output-on-failure','--parallel','1','-R','^http_examples$','--output-junit',out/(profile+'.xml')])
  shutil.copytree(previous,out/(profile+'-evidence'));assert len(json.loads((previous/'commands.json').read_text()))==19
 assert hashlib.sha256(source.read_bytes()).hexdigest()==expected['examples_sha256'];record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
