@echo off
title VOID native Windows CI - elevated Release checks and Debug (one worker)
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\downstream-10-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_downstream_10.py" > "\\vboxsvr\VM\ci-42377496702\downstream-10-console.log" 2>&1
