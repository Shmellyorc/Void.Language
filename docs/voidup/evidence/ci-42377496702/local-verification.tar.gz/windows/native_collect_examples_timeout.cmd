@echo off
title VOID preserve HTTP timeout evidence - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_collect_examples_timeout.py" > "\\vboxsvr\VM\ci-42377496702\native-examples-timeout-collect.log" 2>&1
