from pathlib import Path
import hashlib,json,os,shutil,subprocess
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-owner-rights-candidate';out.mkdir(exist_ok=True)
work=root/'build/native-owner-rights-candidate';work.mkdir(exist_ok=True);source=work/'matrix.cpp';shutil.copyfile(share/'native_owner_rights_matrix.cpp',source)
header=share/'source-overlays/src/runtime/host_windows.hpp';assert hashlib.sha256(header.read_bytes()).hexdigest()=='62e4c5667841e93ab7c405f7d54891f2784205e26e7b0c732f7d2962a615893b';shutil.copyfile(header,work/'host_windows_candidate.hpp')
cc=(root/'.toolchains/llvm-23.1.4/bin/clang-cl.exe').resolve();exe=work/'matrix.exe';env=dict(os.environ,PATH=str(cc.parent)+os.pathsep+os.environ['PATH']);records=[]
for label,argv in [('compile',[cc,'/nologo','/std:c++20','/EHsc','/MT',source,'/Fe'+str(exe),'/Fo'+str(work/'matrix.obj'),'/link','advapi32.lib']),('run',[exe,root/'native-private-temp/owner-rights-matrix'])]:
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(list(map(str,argv)),cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'label':label,'argv':list(map(str,argv)),'status':r.returncode});(out/'result.json').write_text(json.dumps({'candidate_sha256':hashlib.sha256(header.read_bytes()).hexdigest(),'commands':records},indent=2)+'\n');r.check_returncode()
