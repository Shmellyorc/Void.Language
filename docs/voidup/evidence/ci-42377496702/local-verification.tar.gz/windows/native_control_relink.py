from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-control-relink';out.mkdir(exist_ok=False);sdk=(root/'.toolchains/llvm-23.1.4').resolve();private=root/'native-private-temp'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[],'profiles':{},'scope':'Existing workflow final voidc-only warm relink equivalent, local control-mode flags, parallel1. Preserve prior generated EXE/PDB by rename. No hosted cache-mode/performance acceptance, no source touch or broad fixture rebuild.'}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  while chunk:=f.read(1024*1024):h.update(chunk)
 return h.hexdigest()
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args):
 record['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode:raise RuntimeError(label+' failed; original binaries and output retained')
try:
 for name in ['native-post-tests','native-final-checks']:assert json.loads((share/name/'result.json').read_text())['status']=='PASS',name
 expected=json.loads((share/'native-final-source-manifest.json').read_text());assert all(sha(root/name)==digest for name,digest in expected.items())
 for profile in ['Release','Debug']:
  assert shutil.disk_usage(root).free>3*1024**3,'Keep at least one GiB above the two GiB floor before preserving/relinking task outputs'
  build=root/'build'/profile;detail={'before':{},'after':{}};record['profiles'][profile]=detail
  shutil.copyfile(build/'.ninja_log',out/(profile+'-ninja-before.log'));shutil.copyfile(build/'CMakeCache.txt',out/(profile+'-CMakeCache.txt'))
  assert all(not (build/('voidc.before-native-control-relink.'+suffix)).exists() for suffix in ['exe','pdb'])
  for suffix in ['exe','pdb']:
   source=build/('voidc.'+suffix)
   if source.exists():
    backup=build/('voidc.before-native-control-relink.'+suffix);assert not backup.exists();detail['before'][suffix]={'path':str(source),'backup':str(backup),'sha256':sha(source),'bytes':source.stat().st_size};save();source.rename(backup);assert sha(backup)==detail['before'][suffix]['sha256']
  run('relink-'+profile,['cmake','--build',build,'--parallel','1','--target','voidc','--verbose'])
  shutil.copyfile(build/'.ninja_log',out/(profile+'-ninja-after.log'))
  for suffix in ['exe','pdb']:
   binary=build/('voidc.'+suffix)
   if binary.exists():detail['after'][suffix]={'sha256':sha(binary),'bytes':binary.stat().st_size}
  run('version-'+profile,[build/'voidc.exe','--version']);run('help-'+profile,[build/'voidc.exe','--help']);run('pe-headers-'+profile,[sdk/'bin/llvm-readobj.exe','--file-headers',build/'voidc.exe'])
 run('final-native-environment',[sys.executable,share/'native_environment_final.py'])
 assert all(sha(root/name)==digest for name,digest in expected.items());record['source_identity_unchanged']=True;record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
