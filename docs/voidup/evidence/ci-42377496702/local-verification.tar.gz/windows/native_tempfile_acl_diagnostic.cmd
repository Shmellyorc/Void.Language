@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_tempfile_acl_diagnostic.py" > "\\vboxsvr\VM\ci-42377496702\tempfile-acl-console.log" 2>&1
