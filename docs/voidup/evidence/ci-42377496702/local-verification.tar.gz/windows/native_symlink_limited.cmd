@echo off
title VOID native limited-token symlink diagnosis
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_symlink_probe.py" limited > "\\vboxsvr\VM\ci-42377496702\symlink-limited-console.log" 2>&1
