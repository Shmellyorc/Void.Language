from pathlib import Path
import datetime,json,subprocess
share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'native-idle-final.json';assert not out.exists()
query="Get-CimInstance Win32_Process | Where-Object { $_.Name -in @('ctest.exe','ninja.exe','cmake.exe','clang-cl.exe','lld-link.exe','llvm-lib.exe','voidc.exe','voidls.exe') -or $_.ExecutablePath -like 'C:\\Users\\a\\VoidCI42377496702-Native\\*' } | Select-Object Name,ProcessId,ParentProcessId,ExecutablePath | ConvertTo-Json -Depth 3"
r=subprocess.run(['powershell','-NoProfile','-Command',query],capture_output=True,text=True);r.check_returncode();items=json.loads(r.stdout) if r.stdout.strip() else [];record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'processes':items,'scope':'Read-only native compiler/build/test and task-local executable process inventory after completed chain.'};out.write_text(json.dumps(record,indent=2)+'\n');assert not items,'Unexpected native task/compiler process still active'
