from pathlib import Path
import datetime,json,shutil,time
s=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native'
records=[]
for index in range(3):
 records.append({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(root).free});(s/'native-free-after-stop-11.json').write_text(json.dumps(records,indent=2)+'\n')
 if index<2:time.sleep(15)
