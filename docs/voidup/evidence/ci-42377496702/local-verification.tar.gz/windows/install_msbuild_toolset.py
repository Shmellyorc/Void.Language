from pathlib import Path
import datetime,json,subprocess,sys,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'toolset-prerequisite';out.mkdir(exist_ok=True)
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'component':'Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset','status':'preflight'}
def save():(out/'installation.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 catalog_path=Path(r'C:\ProgramData\Microsoft\VisualStudio\Packages\_Instances\3fa163fc\catalog.json');catalog=json.loads(catalog_path.read_text(encoding='utf-8-sig'));packages=catalog['packages'];index={}
 for p in packages:index.setdefault(p['id'],[]).append(p)
 visited=set();pending=[report['component']];records=[]
 while pending:
  name=pending.pop()
  if name in visited:continue
  visited.add(name);assert name in index,('Catalog dependency absent',name)
  for record in index[name]:records.append(record);pending.extend(record.get('dependencies',{}))
 forbidden={'Microsoft.VisualStudio.Component.VC.Llvm.Clang','Microsoft.VisualStudio.ComponentGroup.NativeDesktop.Llvm.Clang','Microsoft.VisualStudio.VC.Llvm.Clang','Microsoft.VisualStudio.VC.Llvm.Base'}
 assert not visited&forbidden,('Forbidden compiler dependency',visited&forbidden)
 (out/'support-only-dependency-closure.json').write_text(json.dumps({'catalog':str(catalog_path),'component':report['component'],'package_ids':sorted(visited),'records':records,'forbidden_compiler_dependencies':sorted(forbidden),'forbidden_dependencies_present':False},indent=2)+'\n')
 installer=Path(r'C:\Program Files (x86)\Microsoft Visual Studio\Installer\setup.exe');assert installer.is_file()
 argv=['modify','--installPath',r'C:\BuildTools\VS2022','--add',report['component'],'--passive','--norestart','--noUpdateInstaller']
 report['installer']=str(installer);report['arguments']=argv;report['status']='installing support targets only';save()
 quoted=subprocess.list2cmdline(argv).replace("'","''");ps="$p = Start-Process -FilePath '"+str(installer)+"' -Verb RunAs -ArgumentList '"+quoted+"' -Wait -PassThru; exit $p.ExitCode"
 with (out/'installer-console.log').open('wb') as log:result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',ps],stdout=log,stderr=subprocess.STDOUT)
 report['exit_code']=result.returncode;report['status']='PASS' if result.returncode in [0,3010] else 'FAIL'
 toolsets=Path(r'C:\BuildTools\VS2022\MSBuild\Microsoft\VC\v170\Platforms\x64\PlatformToolsets');report['clangcl_props_present']=(toolsets/'ClangCL/Toolset.props').is_file();report['clangcl_targets_present']=(toolsets/'ClangCL/Toolset.targets').is_file()
except BaseException as e:report['status']='FAIL';report['error']=repr(e);report['traceback']=traceback.format_exc();raise
finally:report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
