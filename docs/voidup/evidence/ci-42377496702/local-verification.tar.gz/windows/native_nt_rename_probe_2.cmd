@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\nt-rename-2-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_nt_rename_probe_2.py" > "\\vboxsvr\VM\ci-42377496702\nt-rename-2-console.log" 2>&1
