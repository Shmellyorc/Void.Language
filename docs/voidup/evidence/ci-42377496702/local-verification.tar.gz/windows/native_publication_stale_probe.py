from pathlib import Path
import json,os,shutil,subprocess
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-publication-stale-probe';out.mkdir(exist_ok=True);work=root/'build/native-publication-stale-probe';work.mkdir(exist_ok=True)
for name in ['native_publication_stale_probe.cpp','host_directory_windows_publication_candidate_4.cpp']:shutil.copyfile(share/name,work/name)
lines=(root/'build/Release/void-native.txt').read_text().splitlines();cc=Path(lines[1]);exe=work/'probe.exe';env=dict(os.environ,PATH=str(cc.parent)+os.pathsep+os.environ['PATH'],TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'));records=[]
census=subprocess.run(['powershell','-NoProfile','-Command',"Get-Process clang,clang-cl,cmake,ninja,voidc,MSBuild -ErrorAction SilentlyContinue | Select-Object ProcessName,Id,Path | ConvertTo-Json"],capture_output=True,text=True);(out/'prior-build-processes.log').write_text(census.stdout+census.stderr);assert not census.stdout.strip(),'Prior task compiler still running; do not overlap'
command=[cc,'--driver-mode=g++','-std=c++20','-fno-rtti','-I'+str(root),'-I'+str(root/'include'),'-I'+str(root/'src/runtime'),work/'native_publication_stale_probe.cpp',work/'host_directory_windows_publication_candidate_4.cpp',*lines[3:],'-o',exe]
base=root/'native-private-temp/publication-stale-probe';base.mkdir()
for label,argv in [('compile',command),('run',[exe,base])]:
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(list(map(str,argv)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 records.append({'label':label,'argv':list(map(str,argv)),'status':r.returncode});(out/'result.json').write_text(json.dumps(records,indent=2)+'\n');r.check_returncode()
