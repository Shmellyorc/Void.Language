@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_focus_owned_build.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-build-focus.log" 2>&1
