from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback,zipfile
share=Path(r'\\vboxsvr\VM\ci-42377496702')
root=Path.home()/'VoidCI42377496702-Native'
old=Path(r'C:\Users\a\Documents\ChatGPT\Void TEMP\Void-native')
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'commands':[],'status':'running'}
def save(): (share/'native-prepare.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(label,command,cwd=None,env=None):
 start=time.monotonic()
 with (share/(label+'.log')).open('wb') as stream:r=subprocess.run(list(map(str,command)),cwd=cwd or root,env=env,stdout=stream,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'command':list(map(str,command)),'status':r.returncode,'seconds':time.monotonic()-start});save()
 if r.returncode:raise RuntimeError(label+' failed; retained log')
 return r
save()
try:
 manifest=json.loads((share/'transfer-inventory.json').read_text())
 assert not root.exists(),'Fresh native root required'
 archive=share/'void-native-snapshot.zip'
 assert digest(archive)==manifest['archive_sha256'],'Source transfer archive hash mismatch'
 root.mkdir()
 report['stage']='extracting source snapshot';save()
 with zipfile.ZipFile(archive) as z:z.extractall(root)
 for entry in manifest['source_files']:assert digest(root/entry['path'])==entry['sha256'],entry['path']
 report['source_files_verified']=len(manifest['source_files']);report['stage']='preparing verified dependency inputs';save()
 sdk=old/'.toolchains/llvm-23.1.4';new_sdk=root/'.toolchains/llvm-23.1.4';new_sdk.parent.mkdir(parents=True,exist_ok=True)
 run('sdk-junction',['cmd.exe','/d','/c','mklink','/J',str(new_sdk),str(sdk.resolve())])
 for relative in ['.toolchains/http/downloads','.toolchains/http/prefix/windows-schannel-x86_64/Debug','.toolchains/http/prefix/windows-schannel-x86_64/Release']:
  target=root/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(old/relative,target)
 target=root/'.toolchains/host/downloads';target.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(share/'host-downloads',target)
 report['existing_sdk_companions']={str(p):p.exists() for p in [sdk.resolve().with_name(sdk.resolve().name+'-deps'),old/'.toolchains/llvm-23.1.4-deps',sdk.resolve().with_name(sdk.resolve().name+'-deps-build')]}
 sys.path.insert(0,str(root/'tools/ci'));import llvm_sdk
 selected=llvm_sdk.windows_clangcl(new_sdk);report['clangcl_selection']=selected
 (share/'native-clangcl-selection.json').write_text(json.dumps(selected,indent=2)+'\n')
 vc=Path(r'C:\BuildTools\VS2022\MSBuild\Microsoft\VC\v170');lines=[]
 for path in vc.rglob('*'):
  if path.is_file() and path.suffix in ['.props','.targets']:
   text=path.read_text(encoding='utf-8-sig')
   if 'LLVMToolsVersion' in text:
    target=share/'microsoft-targets'/path.relative_to(vc);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
    lines.extend({'path':str(path),'line':n,'text':line} for n,line in enumerate(text.splitlines(),1) if any(k in line for k in ['LLVMToolsVersion','LLVMInstallDir','CLToolExe','LinkToolExe','LibToolExe']))
 report['msbuild_selector_sources']=lines
 run('native-baseline',['git','rev-parse','HEAD'])
 run('native-msbuild-version',['msbuild','-version','-nologo'])
 run('native-ci-integration',[sys.executable,'tests/voidup/ci_integration.py'])
 env=dict(os.environ,PATH=str(new_sdk/'bin')+os.pathsep+os.environ['PATH'])
 for profile in ['Release','Debug']:
  run('native-http-verify-'+profile,[sys.executable,'tools/verify_http_dependencies.py',root/'.toolchains/http/prefix/windows-schannel-x86_64'/profile,profile,'Windows','x86_64'],env=env)
  report['stage']='building host '+profile;save()
  run('native-host-build-'+profile,[sys.executable,'tools/setup_host_deps.py','--profile',profile,'--jobs','3'],env=env)
  run('native-host-verify-'+profile,[sys.executable,'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'],env=env)
  run('native-host-negative-'+profile,[sys.executable,'tests/host_capabilities/dependencies.py',root/'.toolchains/host/prefix/windows-x86_64'/profile,profile,'Windows','x86_64'],env=env)
 report['status']='PASS';report['stage']='providers verified'
except BaseException as exc:
 report['status']='FAIL';report['error']=repr(exc);report['traceback']=traceback.format_exc();raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 evidence=root/'docs/voidup/evidence'
 if evidence.exists():shutil.copytree(evidence,share/'native-provider-evidence',dirs_exist_ok=True)
