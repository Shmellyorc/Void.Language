from pathlib import Path
import datetime,json,shutil,time
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');output=share/'native-debug-disk-watch-13.jsonl';latest=share/'native-debug-disk-latest-13.json';started=time.monotonic()
while time.monotonic()-started<21600:
 state=json.loads((share/'native-downstream-13/result.json').read_text());record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(root).free,'stage':state.get('stage'),'status':state['status'],'outputs':{}}
 for profile in ['Release','Debug']:
  build=root/'build'/profile;values=[]
  for suffix in ['.exe','.pdb']:
   for file in build.glob('*'+suffix):
    try:values.append({'name':file.name,'size':file.stat().st_size})
    except OSError:pass
  record['outputs'][profile]=values
 record['low_space']=record['free_bytes']<6*1024**3
 with output.open('a') as stream:stream.write(json.dumps(record)+'\n')
 latest.write_text(json.dumps(record,indent=2)+'\n')
 if state['status']!='running':break
 time.sleep(30)
