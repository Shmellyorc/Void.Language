@echo off
title VOID Debug disk monitor - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_disk_watch_13.py" > "\\vboxsvr\VM\ci-42377496702\native-disk-watch-13.log" 2>&1
