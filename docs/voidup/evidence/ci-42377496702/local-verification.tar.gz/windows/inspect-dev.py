from pathlib import Path
import datetime,json,os,shutil,subprocess,sys
out=Path(r'\\vboxsvr\VM\ci-42377496702');report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'environment':{k:os.environ.get(k) for k in ['VSCMD_ARG_TGT_ARCH','VSINSTALLDIR','VCINSTALLDIR','VCTargetsPath','VCToolsVersion','WindowsSDKVersion','VCToolsInstallDir','WindowsSdkDir','INCLUDE','LIB']},'which':{name:shutil.which(name) for name in ['git','cmake','ninja','msbuild','clang-cl']}}
vs=Path(r'C:\BuildTools\VS2022');report['msbuild_files']=[str(p) for p in vs.rglob('MSBuild.exe')];report['cpp_targets']=[str(p) for p in vs.rglob('Microsoft.Cpp*') if p.is_file()]
checkout=Path(r'C:\Users\a\Documents\ChatGPT\Void TEMP\Void-native')
report['toolchains_children']=[str(p) for p in (checkout/'.toolchains').iterdir()]
for bundle in ['Debug','Release']:
 p=checkout/'.toolchains/http/prefix/windows-schannel-x86_64'/bundle
 report.setdefault('http_prefixes',{})[bundle]={'exists':p.exists(),'receipt':json.loads((p/'VOID-HTTP-DEPENDENCIES.json').read_text()) if (p/'VOID-HTTP-DEPENDENCIES.json').is_file() else None}
(out/'native-dev-inspection.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print('native developer inspection complete')
