@echo off
title VOID task directory allocation inventory - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_disk_inventory.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-disk-inventory.log" 2>&1
