@echo off
title VOID native full Debug tests and package verification - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\downstream-13-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_downstream_13.py" > "\\vboxsvr\VM\ci-42377496702\downstream-13-console.log" 2>&1
