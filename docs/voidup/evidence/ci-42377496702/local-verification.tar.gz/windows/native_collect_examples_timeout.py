from pathlib import Path
import ctypes,datetime,hashlib,json,shutil,subprocess
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'native-http-examples-debug-timeout-13';out.mkdir(exist_ok=True);source=root/'build/Debug/http-examples-evidence';record={'collected':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sha256':{}}
for p in source.iterdir():
 if p.is_file() and p.suffix in {'.json','.stdout','.stderr'}:shutil.copy2(p,out/p.name);record['sha256'][p.name]=hashlib.sha256((out/p.name).read_bytes()).hexdigest()
ps="Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'void*.exe' -or $_.Name -in @('python.exe','ctest.exe','cmake.exe','ninja.exe','clang.exe','clang-cl.exe','lld-link.exe','cmd.exe') } | Select-Object Name,ProcessId,ParentProcessId,CreationDate,CommandLine | ConvertTo-Json -Depth 3"
r=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True);r.check_returncode();record['processes']=json.loads(r.stdout)
k=ctypes.WinDLL('kernel32',use_last_error=True);k.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_bool,ctypes.c_uint32];k.OpenProcess.restype=ctypes.c_void_p;k.CloseHandle.argtypes=[ctypes.c_void_p];k.QueryFullProcessImageNameW.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)]
for p in record['processes']:
 handle=k.OpenProcess(0x1000,False,p['ProcessId'])
 if handle:
  buf=ctypes.create_unicode_buffer(32768);size=ctypes.c_uint32(len(buf));ok=k.QueryFullProcessImageNameW(handle,0,buf,ctypes.byref(size));p['image_path']=buf.value if ok else None;k.CloseHandle(handle)
 else:p['image_query_error']=ctypes.get_last_error()
(out/'collection.json').write_text(json.dumps(record,indent=2)+'\n')
