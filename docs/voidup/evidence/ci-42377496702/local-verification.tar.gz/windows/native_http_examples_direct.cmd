@echo off
title VOID unchanged HTTP examples diagnostic - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\native-http-examples-direct-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_http_examples_direct.py" > "\\vboxsvr\VM\ci-42377496702\native-http-examples-direct-console.log" 2>&1
