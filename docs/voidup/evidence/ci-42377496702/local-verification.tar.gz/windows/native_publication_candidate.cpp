#include "src/runtime/host_internal.hpp"
#include <windows.h>
#include <filesystem>
#include <iostream>
#include <stdexcept>
namespace vd::host {Result windows_directory_execute_candidate(Request&);}
namespace fs=std::filesystem;using namespace vd::host;
unsigned checks=0;void check(bool b,const char*s){std::cout<<s<<" "<<b<<"\n";if(!b)throw std::runtime_error(s);++checks;}
std::string text(const fs::path&p){auto s=p.u8string();return {s.begin(),s.end()};}
Result run(Request&q){auto r=windows_directory_execute_candidate(q);std::cout<<"op="<<q.operation<<" kind="<<r.kind<<" code="<<r.code<<" detail="<<r.detail<<" published="<<r.flag<<"\n";return r;}
std::shared_ptr<Object> child(std::shared_ptr<Object> p,const char* name){Request q{};q.operation=dir_child;q.objects={p};q.texts={name};auto r=run(q);check(!r.kind&&q.acquired,"create-child");return q.acquired;}
struct Borrow:vd::filesystem::FileBorrow{std::shared_ptr<vd::filesystem::File> f;Borrow(std::shared_ptr<vd::filesystem::File>x):f(x){}std::shared_ptr<vd::filesystem::File> file()const noexcept override{return f;}};
std::shared_ptr<vd::filesystem::File> file(std::shared_ptr<Object> p,const char* name,const char* value){Request q{};q.operation=dir_file;q.objects={p};q.texts={name};q.numbers={1};auto r=run(q);check(!r.kind&&q.acquired_file,"create-file");vd::filesystem::Request w(vd::filesystem::Operation::write_bytes);w.file=q.acquired_file;w.bytes=value;check(vd::filesystem::run(w).completed==w.bytes.size(),"write-file");return q.acquired_file;}
int wmain(int argc,wchar_t**argv){try{if(argc!=2)return 2;fs::path base(argv[1]);Request q{};q.operation=dir_create;q.texts={text(base/L"root")};auto r=run(q);check(!r.kind&&q.acquired,"create-root");auto root=q.acquired;auto stage=child(root,"stage");auto other=child(root,"other");
q={};q.operation=dir_admit;q.texts={text(base/L"root")};r=run(q);check(!r.kind&&q.acquired,"held-target-alias");auto alias=q.acquired;
q={};q.operation=dir_publish;q.objects={stage,root};q.texts={"release"};r=run(q);check(r.flag,"directory-same-parent");check(!fs::exists(base/L"root/stage")&&fs::exists(base/L"root/release"),"directory-identity-moved");
auto collision=child(root,"collision");q={};q.operation=dir_publish;q.objects={collision,root};q.texts={"release"};r=run(q);check(r.kind&&!r.flag&&fs::exists(base/L"root/collision")&&fs::exists(base/L"root/release"),"directory-exclusive-collision");
q={};q.operation=dir_publish;q.objects={stage,other};q.texts={"cross"};r=run(q);check(r.flag&&!fs::exists(base/L"root/release")&&fs::exists(base/L"root/other/cross"),"directory-cross-parent");
auto first=file(root,"first","original");q={};q.operation=dir_replace;q.objects={root,other};q.texts={"first","published"};q.numbers={0};q.file=std::make_shared<Borrow>(first);r=run(q);check(r.flag&&fs::exists(base/L"root/other/published")&&!fs::exists(base/L"root/first"),"file-exclusive-cross-parent");check(vd::filesystem::close(*first).error==vd::filesystem::ErrorKind::success,"close-first");
auto second=file(root,"second","replacement");q={};q.operation=dir_replace;q.objects={root,other};q.texts={"second","published"};q.numbers={0};q.file=std::make_shared<Borrow>(second);r=run(q);check(r.kind&&!r.flag&&fs::exists(base/L"root/second"),"file-exclusive-collision");q.numbers={1};r=run(q);check(r.flag&&!fs::exists(base/L"root/second"),"file-atomic-replacement");char bytes[11]{};check(vd::filesystem::read_at(*second,0,bytes,sizeof(bytes)).completed==11&&std::string_view(bytes,11)=="replacement","replacement-held-bytes");check(vd::filesystem::close(*second).error==vd::filesystem::ErrorKind::success,"close-second");
check(!collision->close()&&!stage->close()&&!other->close()&&!alias->close()&&!root->close(),"all-directory-close");std::cout<<"PASS "<<checks<<" checks\n";return 0;}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}}
