@echo off
title VOID local control-mode voidc-only relink - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\native-control-relink-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_control_relink.py" > "\\vboxsvr\VM\ci-42377496702\native-control-relink-console.log" 2>&1
