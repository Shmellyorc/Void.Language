from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-downstream-9';out.mkdir(exist_ok=True)
sdk=root/'.toolchains/llvm-23.1.4';deps=root/'.toolchains/llvm-23.1.4-deps';cc=sdk/'bin/clang-cl.exe'
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','jobs':1,'commands':[]}
def save():(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH'],CC=str(cc),CXX=str(cc),LLVM_DIR=str(sdk/'lib/cmake/llvm'),VOID_CLANG=str((sdk/'bin/clang.exe').resolve()),VOID_LINKER='',CMAKE_PREFIX_PATH=str(deps),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args,expect=0):
 report['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as f:r=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode!=expect:raise RuntimeError(label+' failed; original log retained')
try:
 assert json.loads((share/'native-host-restart-1.json').read_text())['status']=='PASS','Providers must finish first'
 env['PATH']+=os.pathsep+str(Path(r'C:\Program Files\Git\usr\bin'))
 sys.path.insert(0,str(root/'tools/ci'));from llvm_sdk import windows_clangcl
 selected=windows_clangcl(sdk);driver=(sdk/'bin/clang.exe').resolve()
 assert driver.parent.parent==Path(selected['sdk'])
 report['physical_sdk_selection']=selected;report['physical_clang']=str(driver);report['physical_clang_sha256']=hashlib.sha256(driver.read_bytes()).hexdigest();save()
 helper=root/'build/Release/void_windows_native_staging.exe';private=root/'native-private-temp'
 result=subprocess.run([str(helper),'--inspect-root'],input=str(private)+'\n',capture_output=True,text=True,encoding='utf-8',cwd=root,env=env)
 (out/'verify-existing-private-temp.log').write_text(result.stdout+result.stderr);result.check_returncode();assert 'inherited_root_admitted=1' in result.stdout
 previous=(share/'native-downstream-5/create-private-task-temporary-root.log').read_text().split('sddl=',1)[1].splitlines()[0]
 assert result.stdout.split('sddl=',1)[1].splitlines()[0]==previous,'Task-owned private TEMP ACL changed'
 env['TMP']=env['TEMP']=str(private);report['private_temporary_root']=str(private);report['source_overlays']={};save()
 for name,digest in {'src/runtime/host_directory_windows.cpp':'69f4d918ec63d99ff3adf4ad64906db79318369402911b8a14d993cd4a283557','tests/host_capabilities/portable_source.py':'420f9694bcb9f84f801bf16f5ff1f7d8f357e27342e416e9984989be123b1640','src/runtime/host_windows.hpp':'62e4c5667841e93ab7c405f7d54891f2784205e26e7b0c732f7d2962a615893b','tests/host_capabilities/portable.cpp':'2eb32c405aa05823ab53e67278e4baf82b69d1332522b128cb3d9bfd249f21e0'}.items():
  source=share/'source-overlays'/name;assert hashlib.sha256(source.read_bytes()).hexdigest()==digest
  before=out/'source-before'/name;before.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,before);shutil.copyfile(source,root/name);report['source_overlays'][name]=digest
 save()
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  if profile=='Debug':run('host-bootstrap-verify-'+profile,[sys.executable,'tools/ci/voidup_bootstrap.py','verify','--configuration',profile,'--evidence',out/('bootstrap-'+profile)])
  if profile=='Debug':run('configure-'+profile,['cmake','-S','.', '-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE='+profile,'-DVOID_SANITIZERS=OFF','-DLLVM_DIR='+str(sdk/'lib/cmake/llvm'),'-DVOID_CLANG='+str((sdk/'bin/clang.exe').resolve()),'-DVOID_LINKER=','-DPython3_EXECUTABLE='+sys.executable])
  run('focused-build-'+profile,['cmake','--build',build,'--target','voidc','void_host_portable','voidup','--parallel','1'])
  run('focused-tests-'+profile,['ctest','--test-dir',build,'--output-on-failure','-R','^(host_capabilities_dependencies|host_capabilities_portable|host_capabilities_portable_source|voidup_smoke|voidup_ci_integration)$','--output-junit',out/('focused-'+profile+'.xml')])
  run('build-'+profile,['cmake','--build',build,'--parallel','1'])
  run('host-test-plan-'+profile,[sys.executable,'tools/ci/voidup_bootstrap.py','test-plan','--configuration',profile,'--build',build,'--evidence',out/('bootstrap-'+profile)])
  run('http-test-plan-'+profile,[sys.executable,'tools/ci/http_bootstrap.py','test-plan','--configuration',profile,'--build',build,'--evidence',out/('http-'+profile)])
  run('full-tests-'+profile,['ctest','--test-dir',build,'--output-on-failure','--output-junit',out/('full-'+profile+'.xml')])
 for profile in ['Release','Debug']:
  for label,relative in [('voidc','voidc.exe'),('host-portable','void_host_portable.exe'),('voidup','voidup/voidup.exe')]:
   run('pe-headers-'+profile+'-'+label,[sdk/'bin/llvm-readobj.exe','--file-headers',root/'build'/profile/relative])
 run('install-compiler-Release' ,['cmake','--install',root/'build/Release','--component','compiler','--prefix',root/'build/native-installed-Release'])
 run('native-package-audit',[sys.executable,share/'native_package_check.py'])
 report['status']='PASS'
except BaseException as exc:report['status']='FAIL';report['error']=repr(exc);report['traceback']=traceback.format_exc();raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  for relative in ['CMakeCache.txt','CMakeFiles/CMakeConfigureLog.yaml','Testing/Temporary/LastTest.log','compile_commands.json','void-llvm-dependencies-'+profile+'.txt']:
   source=build/relative
   if source.is_file():target=out/profile/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
