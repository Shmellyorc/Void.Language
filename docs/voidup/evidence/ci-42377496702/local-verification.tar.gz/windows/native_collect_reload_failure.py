from pathlib import Path
import hashlib,json,shutil
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');source=root/'build/Debug/http-reload-evidence';out=share/'native-http-reload-debug-failure-13';out.mkdir(exist_ok=True);record={}
for name in ['original.void','final.void','native.stdout','native.stderr','commands.json']:
 path=source/name;destination=out/name;shutil.copy2(path,destination);record[name]=hashlib.sha256(destination.read_bytes()).hexdigest()
(out/'sha256.json').write_text(json.dumps(record,indent=2)+'\n')
