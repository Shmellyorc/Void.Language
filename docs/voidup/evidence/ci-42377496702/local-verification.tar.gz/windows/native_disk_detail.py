from pathlib import Path
import ctypes,json,shutil,subprocess,time
root=Path.home()/'VoidCI42377496702-Native';build=root/'build/Debug';share=Path(r'\\vboxsvr\VM\ci-42377496702');k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
r={'free_bytes':shutil.disk_usage(root).free,'debug_files':{},'dirs':{}}
for f in build.iterdir():
 if f.is_file():
  group=f.suffix;entry=r['debug_files'].setdefault(group,{'count':0,'logical':0,'allocated':0,'compressed':0});st=f.stat();high=ctypes.c_uint32();low=k.GetCompressedFileSizeW(str(f),ctypes.byref(high));entry['count']+=1;entry['logical']+=st.st_size;entry['allocated']+=(high.value<<32)|low;entry['compressed']+=bool(st.st_file_attributes&0x800)
for name in ['build/Debug/CMakeFiles','build/Debug/.void-cache','native-private-temp']:
 p=root/name;r['dirs'][name]={'files':0,'logical':0}
 if p.is_dir():
  for f in p.rglob('*'):
   try:
    if f.is_file() and not f.is_symlink():r['dirs'][name]['files']+=1;r['dirs'][name]['logical']+=f.stat().st_size
   except OSError:pass
ps="@{Memory=(Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize,FreeVirtualMemory,TotalVirtualMemorySize);Pagefile=(Get-CimInstance Win32_PageFileUsage | Select-Object Name,AllocatedBaseSize,CurrentUsage,PeakUsage)} | ConvertTo-Json -Depth 3"
x=subprocess.run(['powershell','-NoProfile','-Command',ps],capture_output=True,text=True);r['memory']=json.loads(x.stdout) if x.returncode==0 else x.stderr
(share/'native-debug-disk-detail.json').write_text(json.dumps(r,indent=2)+'\n')
