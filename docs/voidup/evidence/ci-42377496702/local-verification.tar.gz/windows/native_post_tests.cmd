@echo off
title VOID final provider package and PE verification - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\native-post-tests-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_post_tests.py" > "\\vboxsvr\VM\ci-42377496702\native-post-tests-console.log" 2>&1
