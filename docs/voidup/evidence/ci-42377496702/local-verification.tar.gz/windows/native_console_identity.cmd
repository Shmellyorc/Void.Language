@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_console_identity.py" > "\\vboxsvr\VM\ci-42377496702\native-console-identity.log" 2>&1
