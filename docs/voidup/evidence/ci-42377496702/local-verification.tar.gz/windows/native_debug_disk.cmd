@echo off
title VOID Debug disk and filesystem identity (read only)
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_debug_disk.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-disk-1.log" 2>&1
