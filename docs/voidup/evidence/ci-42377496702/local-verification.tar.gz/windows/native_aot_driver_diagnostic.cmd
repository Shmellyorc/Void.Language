@echo off
title VOID native AOT linker identity (read only)
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\aot-driver-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_aot_driver_diagnostic.py" > "\\vboxsvr\VM\ci-42377496702\aot-driver-console.log" 2>&1
