from pathlib import Path
import ctypes,datetime,json,os,shutil
root=Path.home()/'VoidCI42377496702-Native';build=root/'build/Debug';share=Path(r'\\vboxsvr\VM\ci-42377496702');k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
report={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(root).free,'directories':[]}
for folder in build.iterdir():
 if not folder.is_dir() or folder.is_symlink() or folder.is_junction():continue
 row={'name':folder.name,'attributes':folder.stat().st_file_attributes,'files':0,'logical_bytes':0,'allocated_bytes':0,'suffixes':{}};stack=[folder]
 while stack:
  directory=stack.pop()
  try:entries=list(os.scandir(directory))
  except OSError:continue
  for e in entries:
   try:
    st=e.stat(follow_symlinks=False)
    if st.st_file_attributes&0x400:continue
    if e.is_dir(follow_symlinks=False):stack.append(Path(e.path));continue
    if not e.is_file(follow_symlinks=False):continue
    high=ctypes.c_uint32();low=k.GetCompressedFileSizeW(e.path,ctypes.byref(high));allocated=(high.value<<32)|low
    row['files']+=1;row['logical_bytes']+=st.st_size;row['allocated_bytes']+=allocated
    group=row['suffixes'].setdefault(Path(e.path).suffix,{'files':0,'logical_bytes':0,'allocated_bytes':0,'compressed':0});group['files']+=1;group['logical_bytes']+=st.st_size;group['allocated_bytes']+=allocated;group['compressed']+=bool(st.st_file_attributes&0x800)
   except OSError:pass
 report['directories'].append(row)
(share/'native-debug-test-directory-inventory.json').write_text(json.dumps(report,indent=2)+'\n')
