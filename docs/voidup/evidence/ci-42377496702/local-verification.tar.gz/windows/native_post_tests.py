from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-post-tests';out.mkdir(exist_ok=False);sdk=(root/'.toolchains/llvm-23.1.4').resolve();private=root/'native-private-temp'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[],'scope':'Final source identity, actual native provider verification, PE stack headers, compiler component install/corresponding-source reconstruction and installed executable smoke. No build or test coverage substitution.'}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args):
 record['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode:raise RuntimeError(label+' failed; output retained')
try:
 for name in ['native-downstream-14','native-http-reload-corrected','native-http-examples-corrected']:assert json.loads((share/name/'result.json').read_text())['status']=='PASS',name
 expected=json.loads((share/'native-final-source-manifest.json').read_text());actual={name:hashlib.sha256((root/name).read_bytes()).hexdigest() if (root/name).is_file() else None for name in expected};record['source_identity']={'expected':expected,'actual':actual};save();assert expected==actual,'Final source byte identity mismatch'
 record['pe_stacks']={}
 for profile in ['Release','Debug']:
  prefix=root/'.toolchains/host/prefix/windows-x86_64'/profile
  run('verify-host-'+profile,[sys.executable,root/'tools/verify_host_deps.py','--prefix',prefix,'--profile',profile,'--platform','Windows','--architecture','x86_64'])
  receipt=prefix/'VOID-HOST-DEPENDENCIES.json';shutil.copyfile(receipt,out/('host-receipt-'+profile+'.json'))
  for label,relative in [('voidc','voidc.exe'),('host-portable','void_host_portable.exe'),('voidup','voidup/voidup.exe')]:
   key=profile+'-'+label;binary=root/'build'/profile/relative
   run('pe-headers-'+key,[sdk/'bin/llvm-readobj.exe','--file-headers',binary])
   headers=(out/('pe-headers-'+key+'.log')).read_text();reserve=re.search(r'SizeOfStackReserve: (\S+)',headers);commit=re.search(r'SizeOfStackCommit: (\S+)',headers);assert reserve and commit
   record['pe_stacks'][key]={'path':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'reserve_bytes':int(reserve.group(1),0),'commit_bytes':int(commit.group(1),0)};save()
 installed=root/'build/native-installed-Release'
 run('install-compiler-Release',['cmake','--install',root/'build/Release','--component','compiler','--prefix',installed])
 run('native-package-audit',[sys.executable,share/'native_package_check.py'])
 run('installed-compiler-version',[installed/'bin/voidc.exe','--version']);run('installed-compiler-help',[installed/'bin/voidc.exe','--help'])
 app=installed/'bin/voidup.exe';record['voidup_in_compiler_component']=app.exists()
 if app.exists():run('installed-voidup-help',[app,'--help'])
 record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
