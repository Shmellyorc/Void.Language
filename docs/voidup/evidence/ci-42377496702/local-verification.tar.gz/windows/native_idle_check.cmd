@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_idle_check.py" > "\\vboxsvr\VM\ci-42377496702\native-idle-final.log" 2>&1
