from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[],'status':'running','jobs':1}
def save():(share/'native-host-restart-1.json').write_text(json.dumps(report,indent=2)+'\n')
def run(label,args,expect=0):
 start=time.monotonic()
 with (share/(label+'.log')).open('wb') as f:r=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'command':list(map(str,args)),'status':r.returncode,'seconds':time.monotonic()-start});save()
 if (expect==0 and r.returncode!=0) or (expect=='failure' and r.returncode==0):raise RuntimeError(label+' unexpected exit')
 return r
save()
try:
 overlay=share/'source-overlays/tools/setup_host_deps_native.py';digest=hashlib.sha256(overlay.read_bytes()).hexdigest();assert digest=='42b30dc4d52bd66d55ad779ed3c2162c0ac0043654b5326011a4eee3a6f67bca'
 shutil.copyfile(overlay,root/'tools/setup_host_deps_native.py');report['source_overlay_sha256']=digest
 for kind in ['build','prefix']:
  interrupted=root/'.toolchains/host'/kind/'windows-x86_64/Release'
  if interrupted.exists():
   destination=root/'.toolchains/host'/('retained-'+kind)/'Release-user-restart-interrupted';destination.parent.mkdir(parents=True,exist_ok=True);interrupted.rename(destination)
 vc=Path(r'C:\BuildTools\VS2022\MSBuild\Microsoft\VC\v170');copied=[]
 for path in vc.rglob('*'):
  if path.is_file() and path.suffix in ['.props','.targets'] and ('ClangCl' in path.name or 'ClangCL' in str(path) or 'ClangCl' in str(path)):
   dest=share/'installed-clangcl-targets'/path.relative_to(vc);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest);copied.append(str(path))
 report['installed_clangcl_targets']=copied
 report['bundled_compiler_present']={str(path):path.is_file() for path in [Path(r'C:\BuildTools\VS2022\VC\Tools\Llvm\bin\clang-cl.exe'),Path(r'C:\BuildTools\VS2022\VC\Tools\Llvm\x64\bin\clang-cl.exe')]}
 env=dict(os.environ,PATH=str(root/'.toolchains/llvm-23.1.4/bin')+os.pathsep+os.environ['PATH'])
 for profile in ['Release','Debug']:
  report['stage']='host '+profile;save()
  run('native-host-restart-1-build-'+profile,[sys.executable,'tools/setup_host_deps.py','--profile',profile,'--jobs','1'])
  run('native-host-restart-1-verify-'+profile,[sys.executable,'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'])
  run('native-host-restart-1-negative-'+profile,[sys.executable,'tests/host_capabilities/dependencies.py',root/'.toolchains/host/prefix/windows-x86_64'/profile,profile,'Windows','x86_64'])
  record=json.loads((root/'.toolchains/host/prefix/windows-x86_64'/profile/'VOID-HOST-DEPENDENCIES.json').read_text());(share/('native-host-receipt-'+profile+'.json')).write_text(json.dumps(record,indent=2)+'\n')
  command=next(v['command'] for v in record['commands'] if any(str(a).startswith('-getProperty:') for a in v['command']))[:-1]
  command=[('/p:LLVMToolsVersion=invalid' if a.startswith('/p:LLVMToolsVersion=') else a) for a in command]
  command+=['/t:VoidVerifyPinnedClangCL','/v:normal','/m:1'];run('native-restart-1-invalid-selector-'+profile,command,expect='failure')
 report['status']='PASS';report['stage']='host providers verified'
except BaseException as exc:report['status']='FAIL';report['error']=repr(exc);report['traceback']=traceback.format_exc();raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 for p in (root/'docs/voidup/evidence').glob('dependencies-*'):shutil.copytree(p,share/'native-provider-evidence/voidup'/p.name,dirs_exist_ok=True)
