from pathlib import Path
import json,os,subprocess,tempfile
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-tempfile-acl-diagnostic';out.mkdir(exist_ok=True)
os.environ['TMP']=os.environ['TEMP']=str(root/'native-private-temp');tempfile.tempdir=None
folder=Path(tempfile.mkdtemp(prefix='VOID portable 雪 # % '));child=folder/'capability-private'
record={'folder':str(folder),'python':__import__('sys').version,'command':[str(root/'build/native_private_root_diagnostic_2.exe'),str(child)]}
r=subprocess.run(record['command'],capture_output=True);record['status']=r.returncode;(out/'diagnostic.log').write_bytes(r.stdout+r.stderr);(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
