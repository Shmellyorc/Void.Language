@echo off
title VOID HTTP examples aggregate watchdog verification - one worker
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\native-http-examples-corrected-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_http_examples_corrected.py" > "\\vboxsvr\VM\ci-42377496702\native-http-examples-corrected-console.log" 2>&1
