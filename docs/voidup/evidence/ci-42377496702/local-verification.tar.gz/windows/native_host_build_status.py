from pathlib import Path
import datetime,json,shutil,subprocess
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'status-2';out.mkdir(exist_ok=True)
report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_bytes':shutil.disk_usage(root).free}
receipts=list((root/'docs/voidup/evidence').glob('dependencies-*'))
if receipts:
 receipt=max(receipts,key=lambda p:p.stat().st_mtime);report['receipt']=str(receipt)
 if (receipt/'commands.json').is_file():shutil.copy2(receipt/'commands.json',out/'commands.json')
 latest=sorted([p for p in receipt.iterdir() if p.suffix in ['.stdout','.stderr','.log']],key=lambda p:p.stat().st_mtime,reverse=True)[:4]
 for p in latest:(out/(p.name+'.tail')).write_bytes(p.read_bytes()[-6000:])
 report['latest_logs']=[p.name for p in latest]
report['processes']=json.loads(subprocess.check_output(['powershell.exe','-NoProfile','-NonInteractive','-Command',"Get-Process | Where-Object {$_.ProcessName -match 'python|clang|cmake|ninja|msbuild|lld|llvm|curl'} | Select-Object Id,ProcessName,CPU | ConvertTo-Json"],text=True))
(out/'status.json').write_text(json.dumps(report,indent=2)+'\n')
