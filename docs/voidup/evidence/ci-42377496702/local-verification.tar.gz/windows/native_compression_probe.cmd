@echo off
title VOID compression attribute inspection - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_compression_probe.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-compression-probe.log" 2>&1
