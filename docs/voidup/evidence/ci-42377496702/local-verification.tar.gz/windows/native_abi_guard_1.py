from pathlib import Path
import hashlib,json,subprocess,sys
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=root/'build/native-abi-guards';out.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tools'));from setup_host_deps_native import verify_static_crt
cc=root/'.toolchains/llvm-23.1.4/bin/clang-cl.exe';readobj=cc.parent/'llvm-readobj.exe';librarian=cc.parent/'llvm-lib.exe'
source=out/'fixture.c';source.write_text('int fixture(void) { return 1; }\n');records=[]
for name,flags,accepted in [('MT',['/MT'],True),('MD',['/MD'],False),('MTd',['/MTd'],False),('MDd',['/MDd'],False),('MT-no-defaultlibs',['/MT','/Zl'],False)]:
 obj=out/(name+'.obj');lib=out/(name+'.lib');commands=[]
 for argv in [[cc,'/nologo','/c',source,'/Fo'+str(obj),*flags],[librarian,'/nologo','/OUT:'+str(lib),obj]]:
  result=subprocess.run(list(map(str,argv)),capture_output=True,text=True);commands.append({'argv':list(map(str,argv)),'status':result.returncode,'stdout':result.stdout,'stderr':result.stderr});result.check_returncode()
 result=subprocess.run([str(readobj),'--coff-directives',str(lib)],capture_output=True,text=True);result.check_returncode();(out/(name+'.txt')).write_text(result.stdout)
 rejection=None
 try:verify_static_crt(result.stdout);actual=True
 except ValueError as e:actual=False;rejection=str(e)
 assert actual==accepted,(name,actual,result.stdout)
 records.append({'name':name,'commands':commands,'coff_directives':result.stdout,'accepted':actual,'expected':accepted,'rejection':rejection})
for profile in ['Release','Debug']:
 prefix=root/'.toolchains/host/prefix/windows-x86_64'/profile
 for name in ['libsodium.lib','archive.lib']:
  result=subprocess.run([str(readobj),'--coff-directives',str(prefix/'lib'/name)],capture_output=True,text=True);result.check_returncode();verify_static_crt(result.stdout)
  (out/(profile+'-'+name+'.directives')).write_text(result.stdout)
  records.append({'profile':profile,'library':name,'accepted':True,'sha256':hashlib.sha256((prefix/'lib'/name).read_bytes()).hexdigest(),'coff_evidence_sha256':hashlib.sha256(result.stdout.encode()).hexdigest()})
for profile in ['Release','Debug']:
 receipt=json.loads((share/('native-host-receipt-'+profile+'.json')).read_text())
 base=next(v['command'] for v in receipt['commands'] if any(str(a).startswith('-getProperty:') for a in v['command']))[:-1]
 for name,changed,diagnostic in [('full-release-resource-selector',{'LLVMToolsVersion':'23.1.4'},'VOID requires the SDK-derived LLVM 23.1.4 toolset selector.'),('missing-resource',{'VoidPinnedResourceDir':str(out/'nonexistent-resource')},'Pinned LLVM compiler/resources are missing; ambient fallback is prohibited.')]:
  argv=[next(('/p:'+key+'='+value for key,value in changed.items() if arg.startswith('/p:'+key+'=')),arg) for arg in base]
  argv+=['/t:VoidVerifyPinnedClangCL','/v:normal','/m:1']
  result=subprocess.run(argv,capture_output=True,text=True);output=result.stdout+result.stderr
  assert result.returncode!=0 and diagnostic in output,(name,result.returncode,output)
  (share/('native-guard-'+profile+'-'+name+'.log')).write_text(output)
  records.append({'profile':profile,'negative':name,'argv':argv,'status':result.returncode,'expected_diagnostic':diagnostic,'passed':True})
(share/'native-static-abi-guards.json').write_text(json.dumps(records,indent=2)+'\n');print('Native static ABI guards: 5 selection cases and 4 actual provider archives passed')
