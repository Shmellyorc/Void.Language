from pathlib import Path
import hashlib,json,os,shutil,subprocess,tempfile
root=Path.home()/'VoidCI42377496702-Native';out=Path(r'\\vboxsvr\VM\ci-42377496702')/'native-aot-driver-diagnostic';out.mkdir(exist_ok=True)
config=root/'build/Release/void-native.txt';lines=config.read_text().splitlines();shutil.copyfile(config,out/'void-native-Release.txt');driver=Path(lines[1]);env=dict(os.environ,PATH=str(driver.parent)+os.pathsep+os.environ['PATH'],TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'))
with tempfile.TemporaryDirectory(prefix='aot-driver-readonly-',dir=root/'native-private-temp') as folder:
 work=Path(folder);obj=next((root/'build/Release').glob('*normal.obj'));shutil.copyfile(obj,work/'program.o');shutil.copyfile(lines[3],work/'runtime.lib');shutil.copyfile(lines[4],work/'fixture.lib')
 command=[str(driver),'--driver-mode=g++']
 if lines[2]:command+=['--ld-path='+lines[2]]
 command+=['-working-directory',str(work),'program.o','runtime.lib','fixture.lib','-o','program.exe',*lines[5:],'-###']
 r=subprocess.run(command,cwd=root,env=env,capture_output=True);(out/'driver.log').write_bytes(r.stdout+r.stderr)
 record={'scope':'Read-only -### reproduction of native_build.cpp driver arguments; no linker execution','argv':command,'status':r.returncode,'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'input_object':str(obj),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'output_created':(work/'program.exe').exists()};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');r.check_returncode();assert not record['output_created']
