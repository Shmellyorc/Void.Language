from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-downstream-11';out.mkdir(exist_ok=True)
sdk=root/'.toolchains/llvm-23.1.4';deps=root/'.toolchains/llvm-23.1.4-deps';cc=sdk/'bin/clang-cl.exe';private=root/'native-private-temp'
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','jobs':1,'commands':[],'continuation':'Attempt10 Debug build interrupted before ENOSPC; exact generated outputs compressed without logical-byte changes. Existing Ninja progress is reused.'}
def save():(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',CC=str(cc),CXX=str(cc),LLVM_DIR=str(sdk/'lib/cmake/llvm'),VOID_CLANG=str((sdk/'bin/clang.exe').resolve()),VOID_LINKER='',CMAKE_PREFIX_PATH=str(deps),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1',TMP=str(private),TEMP=str(private),VOID_IO_SECOND_VOLUME=str(share/'native-second-filesystem'))
def run(label,args):
 report['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as f:result=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'argv':argv,'status':result.returncode,'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage(root).free});save()
 if result.returncode:raise RuntimeError(label+' failed; original log retained')
try:
 assert ctypes.windll.shell32.IsUserAnAdmin(),'Use the existing authorized same-user administrator token for actual symlink tests'
 previous=json.loads((share/'native-downstream-10/result.json').read_text());assert previous['status']=='FAIL' and previous['error']=='KeyboardInterrupt()' and previous['stage']=='build-Debug'
 compression=json.loads((share/'native-debug-compression/result.json').read_text());assert compression['status']=='PASS' and compression['all_logical_hashes_preserved']
 report['compression_evidence']='native-debug-compression/result.json';report['admin_token']=True;save()
 sys.path.insert(0,str(root/'tools/ci'));from llvm_sdk import windows_clangcl
 report['sdk_selection']=windows_clangcl(sdk);save()
 for name,digest in previous['source_overlays'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 name='tests/host_capabilities/portable.cpp';source=share/'source-overlays'/name;digest=hashlib.sha256(source.read_bytes()).hexdigest();assert digest=='901a9a599a075b8d7849e008681e936b9783a467da8f4f468d61249200b0eb08'
 saved=out/'source-before'/name;saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,saved);shutil.copyfile(source,root/name)
 report['source_overlays']=dict(previous['source_overlays']);report['source_overlays'][name]=digest;report['portable_cast_only']='Bounded fixture byte count explicitly cast to int64_t to remove sign comparison warning; no runtime/provider change';save()
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  run('portable-build-'+profile,['cmake','--build',build,'--target','void_host_portable','--parallel','1'])
  run('portable-test-'+profile,['ctest','--test-dir',build,'--output-on-failure','--parallel','1','-R','^host_capabilities_portable$','--output-junit',out/('portable-'+profile+'.xml')])
 build=root/'build/Debug'
 run('build-Debug',['cmake','--build',build,'--parallel','1'])
 run('host-test-plan-Debug',[sys.executable,'tools/ci/voidup_bootstrap.py','test-plan','--configuration','Debug','--build',build,'--evidence',out/'bootstrap-Debug'])
 run('http-test-plan-Debug',[sys.executable,'tools/ci/http_bootstrap.py','test-plan','--configuration','Debug','--build',build,'--evidence',out/'http-Debug'])
 run('full-tests-Debug',['ctest','--test-dir',build,'--output-on-failure','--output-junit',out/'full-Debug.xml'])
 for profile in ['Release','Debug']:
  for label,relative in [('voidc','voidc.exe'),('host-portable','void_host_portable.exe'),('voidup','voidup/voidup.exe')]:run('pe-headers-'+profile+'-'+label,[sdk/'bin/llvm-readobj.exe','--file-headers',root/'build'/profile/relative])
 run('install-compiler-Release',['cmake','--install',root/'build/Release','--component','compiler','--prefix',root/'build/native-installed-Release'])
 run('native-package-audit',[sys.executable,share/'native_package_check.py'])
 run('installed-compiler-version',[root/'build/native-installed-Release/bin/voidc.exe','--version'])
 run('installed-compiler-help',[root/'build/native-installed-Release/bin/voidc.exe','--help'])
 report['status']='PASS'
except BaseException as error:report.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 for profile in ['Release','Debug']:
  for name in ['portable-'+profile+'.json','portable-source-'+profile+'.json']:
   source=root/'docs/voidup/evidence/portability'/name
   if source.is_file():target=out/'host-evidence'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
  for relative in ['CMakeCache.txt','CMakeFiles/CMakeConfigureLog.yaml','Testing/Temporary/LastTest.log','compile_commands.json','void-llvm-dependencies-'+profile+'.txt']:
   source=root/'build'/profile/relative
   if source.is_file():target=out/profile/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
