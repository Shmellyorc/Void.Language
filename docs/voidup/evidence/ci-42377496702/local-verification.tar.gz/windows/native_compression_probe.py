from pathlib import Path
import ctypes,json,shutil
root=Path.home()/'VoidCI42377496702-Native';build=root/'build/Debug';share=Path(r'\\vboxsvr\VM\ci-42377496702');k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
record={'directory_attributes':build.stat().st_file_attributes,'free_bytes':shutil.disk_usage(root).free,'files':[]}
for file in sorted(list(build.glob('*.exe'))+list(build.glob('*.pdb')),key=lambda x:x.stat().st_mtime)[-24:]:
 stat=file.stat();high=ctypes.c_uint32();low=k.GetCompressedFileSizeW(str(file),ctypes.byref(high));record['files'].append({'name':file.name,'attributes':stat.st_file_attributes,'logical_bytes':stat.st_size,'allocated_bytes':(high.value<<32)|low})
(share/'native-debug-compression-probe.json').write_text(json.dumps(record,indent=2)+'\n')
