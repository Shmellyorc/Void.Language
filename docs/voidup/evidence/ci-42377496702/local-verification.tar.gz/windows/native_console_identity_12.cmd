@echo off
title VOID console identity inspection - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_console_identity_12.py" > "\\vboxsvr\VM\ci-42377496702\native-console-identity-12.log" 2>&1
