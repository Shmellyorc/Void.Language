@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42377496702\publication-candidate-3-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_publication_candidate_3.py" > "\\vboxsvr\VM\ci-42377496702\publication-candidate-3-console.log" 2>&1
