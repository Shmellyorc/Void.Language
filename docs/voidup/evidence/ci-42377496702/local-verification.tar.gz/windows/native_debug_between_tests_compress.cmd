@echo off
title VOID task-only Debug allocation compaction - no build running
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_debug_between_tests_compress.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-between-tests-compression-console.log" 2>&1
