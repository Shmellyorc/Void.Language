from pathlib import Path
import datetime,json,platform,shutil,subprocess,sys
out=Path(r'\\vboxsvr\VM\ci-42377496702');report={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'machine':platform.machine(),'python':sys.executable,'paths':{},'which':{name:shutil.which(name) for name in ['git','cmake','ninja','msbuild','clang-cl']}}
checkout=Path(r'C:\Users\a\Documents\ChatGPT\Void TEMP\Void-native')
candidates=[checkout,checkout/'.toolchains/llvm-23.1.4',checkout/'.toolchains/native-schannel/sdk/clang+llvm-23.1.4-x86_64-pc-windows-msvc',Path(r'C:\BuildTools\VS2022'),Path(r'C:\gcc\bin'),Path(r'C:\Program Files (x86)\Windows Kits\10')]
for path in candidates:report['paths'][str(path)]={'exists':path.exists(),'resolved':str(path.resolve())}
vc=Path(r'C:\BuildTools\VS2022\MSBuild\Microsoft\VC')
rows=[]
if vc.exists():
 for path in vc.rglob('*ClangCl*'):
  if path.is_file() and path.suffix in ['.props','.targets']:
   target=out/'microsoft-targets'/path.relative_to(vc);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)
   for n,line in enumerate(path.read_text(encoding='utf-8-sig').splitlines(),1):
    if any(key in line for key in ['LLVMToolsVersion','LLVMInstallDir','ClangClFixup','CLToolExe','LibToolExe','LinkToolExe']):rows.append({'path':str(path),'line':n,'text':line})
report['msbuild_target_selection_lines']=rows
for sdk in candidates[1:3]:
 receipt=sdk/'void-sdk-identity.json'
 if receipt.is_file():report.setdefault('sdk_receipts',{})[str(sdk)]=json.loads(receipt.read_text(encoding='utf-8'))
report['disk_usage']={drive:dict(zip(('total','used','free'),shutil.disk_usage(drive))) for drive in ['C:\\']}
(out/'native-inspection.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))
