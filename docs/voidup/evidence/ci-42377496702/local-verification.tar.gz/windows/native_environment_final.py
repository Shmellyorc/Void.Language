from pathlib import Path
import ctypes,datetime,json,os,platform,shutil,subprocess,sys
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'native-final-environment.json';assert not out.exists()
query="$os=Get-CimInstance Win32_OperatingSystem; $page=Get-CimInstance Win32_PageFileUsage; [pscustomobject]@{ Caption=$os.Caption;Version=$os.Version;BuildNumber=$os.BuildNumber;TotalVisibleMemoryKB=$os.TotalVisibleMemorySize;FreePhysicalMemoryKB=$os.FreePhysicalMemory;PageFiles=@($page|Select-Object AllocatedBaseSize,CurrentUsage,PeakUsage) }|ConvertTo-Json -Depth 5"
r=subprocess.run(['powershell','-NoProfile','-Command',query],capture_output=True,text=True);r.check_returncode()
record={'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'platform':platform.platform(),'python':sys.version,'python_executable':sys.executable,'cpu_count':os.cpu_count(),'admin_token':bool(ctypes.windll.shell32.IsUserAnAdmin()),'free_bytes':shutil.disk_usage(root).free,'windows':json.loads(r.stdout),'vc_environment':{key:os.environ.get(key) for key in ['VCToolsVersion','WindowsSDKVersion','VSCMD_VER']},'native_root':str(root),'scope':'Read-only final guest resource and selected native platform prerequisite evidence; no VM/system settings changed.'}
out.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
