@echo off
title VOID task-only Debug allocation compaction - no build running
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_debug_force_compress.py" > "\\vboxsvr\VM\ci-42377496702\native-debug-forced-compression-console.log" 2>&1
