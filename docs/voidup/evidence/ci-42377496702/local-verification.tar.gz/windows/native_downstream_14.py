from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-downstream-14';out.mkdir(exist_ok=False)
sdk=root/'.toolchains/llvm-23.1.4';deps=root/'.toolchains/llvm-23.1.4-deps';cc=sdk/'bin/clang-cl.exe';private=root/'native-private-temp'
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','jobs':1,'commands':[],'continuation':'Attempt13 completed316cases(314pass,2retainedHTTPfailures), then was intentionally interrupted in case317 at2.126GiB free. Run only the34 uncompleted cases after preserving the exact original inventory and restoring disk margin; no broad repeat or rebuild.'}
def save():(out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',CC=str(cc),CXX=str(cc),LLVM_DIR=str(sdk/'lib/cmake/llvm'),VOID_CLANG=str((sdk/'bin/clang.exe').resolve()),VOID_LINKER='',CMAKE_PREFIX_PATH=str(deps),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1',TMP=str(private),TEMP=str(private),VOID_IO_SECOND_VOLUME=str(share/'native-second-filesystem'))
def run(label,args):
 report['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as f:result=subprocess.run(argv,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 report['commands'].append({'label':label,'argv':argv,'status':result.returncode,'seconds':time.monotonic()-start,'disk_free_bytes':shutil.disk_usage(root).free});save()
 if result.returncode:raise RuntimeError(label+' failed; original log retained')
try:
 assert ctypes.windll.shell32.IsUserAnAdmin(),'Use the existing authorized same-user administrator token'
 previous=json.loads((share/'native-downstream-13/result.json').read_text());assert previous['status']=='FAIL' and previous['error']=='KeyboardInterrupt()' and previous['stage']=='full-tests-Debug'
 compact=json.loads((share/'native-debug-between-tests-compression-2/result.json').read_text());assert compact['status']=='PASS' and compact['all_logical_hashes_preserved'] and compact['safe_margin_reached']
 assert shutil.disk_usage(root).free>4*1024**3,'Require restored disk margin before remaining native tests'
 report['admin_token']=True;report['free_at_resume']=shutil.disk_usage(root).free;report['source_overlays']=previous['source_overlays'];report['completed_build_and_plans']='native-downstream-12/result.json';report['partial_inventory']='native-debug-between-tests-compression-2/partial-test-inventory.json';report['forced_compression']='native-debug-between-tests-compression-2/result.json';save()
 for name,digest in report['source_overlays'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
 sys.path.insert(0,str(root/'tools/ci'));from llvm_sdk import windows_clangcl
 report['sdk_selection']=windows_clangcl(sdk);save()
 build=root/'build/Debug'
 remaining=share/'native-debug-between-tests-compression-2/remaining-tests.txt';names=remaining.read_text().splitlines();assert len(names)==34 and names[0]=='async_retention_sprint5'
 plan=subprocess.run(['ctest','--test-dir',str(build),'--show-only=json-v1'],cwd=root,env=env,capture_output=True);plan.check_returncode();assert [x['name'] for x in json.loads(plan.stdout)['tests'][316:]]==names
 report['remaining_tests']=names;save()
 run('remaining-tests-Debug',['ctest','--test-dir',build,'--output-on-failure','--parallel','1','--tests-from-file',remaining,'--output-junit',out/'remaining-Debug.xml'])
 report['status']='PASS'
except BaseException as error:report.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 for profile in ['Release','Debug']:
  for name in ['portable-'+profile+'.json','portable-source-'+profile+'.json']:
   source=root/'docs/voidup/evidence/portability'/name
   if source.is_file():target=out/'host-evidence'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
  for relative in ['CMakeCache.txt','CMakeFiles/CMakeConfigureLog.yaml','Testing/Temporary/LastTest.log','compile_commands.json','void-llvm-dependencies-'+profile+'.txt']:
   source=root/'build'/profile/relative
   if source.is_file():target=out/profile/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
