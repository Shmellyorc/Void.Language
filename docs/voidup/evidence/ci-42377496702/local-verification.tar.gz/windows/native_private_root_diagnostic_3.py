from pathlib import Path
import json,os,shutil,subprocess,sys,time
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-private-root-diagnostic-3';out.mkdir(exist_ok=True)
source=root/'build/native_private_root_diagnostic_2.cpp';shutil.copyfile(share/source.name,source);exe=source.with_suffix('.exe')
extra=root/'build/host_directory_windows_diagnostic_3.cpp';shutil.copyfile(share/extra.name,extra)
lines=(root/'build/Release/void-native.txt').read_text().splitlines();cc=Path(lines[1]);env=dict(os.environ,PATH=str(cc.parent)+os.pathsep+os.environ['PATH'],TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'))
command=[str(cc),'--driver-mode=g++','-std=c++20','-fno-rtti','-I'+str(root),'-I'+str(root/'include'),'-I'+str(root/'src/runtime'),str(source),str(extra),*lines[3:],'-o',str(exe)]
with (out/'compile.log').open('wb') as f:r=subprocess.run(command,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT)
record={'compile':{'argv':command,'status':r.returncode}};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');r.check_returncode()
folder=root/'native-private-temp'/'native-root-probe';folder.mkdir(exist_ok=True);path=folder/'capability-private-3'
r=subprocess.run([str(exe),str(path)],env=env,cwd=root,capture_output=True);(out/'diagnostic.log').write_bytes(r.stdout+r.stderr);record['run']={'argv':[str(exe),str(path)],'status':r.returncode};(out/'result.json').write_text(json.dumps(record,indent=2)+'\n');r.check_returncode()
