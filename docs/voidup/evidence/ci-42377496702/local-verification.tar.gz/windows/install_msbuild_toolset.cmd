@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\install_msbuild_toolset.py" > "\\vboxsvr\VM\ci-42377496702\install-msbuild-toolset-console.log" 2>&1
