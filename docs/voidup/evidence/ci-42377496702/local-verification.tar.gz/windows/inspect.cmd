@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_host_inventory.py" > "\\vboxsvr\VM\ci-42377496702\inspect-console.log" 2>&1
