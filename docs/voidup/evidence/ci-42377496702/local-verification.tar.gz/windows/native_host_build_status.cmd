@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_host_build_status.py" > "\\vboxsvr\VM\ci-42377496702\native-host-build-status-console.log" 2>&1
