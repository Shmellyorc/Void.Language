@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_build_status.py" > "\\vboxsvr\VM\ci-42377496702\native-build-status-console.log" 2>&1
