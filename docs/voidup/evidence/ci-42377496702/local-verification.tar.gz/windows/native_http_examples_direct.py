from pathlib import Path
import ctypes,datetime,hashlib,json,os,shutil,signal,subprocess,sys,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-http-examples-debug-direct';out.mkdir(exist_ok=False);sdk=(root/'.toolchains/llvm-23.1.4').resolve();build=root/'build/Debug';private=root/'native-private-temp'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','scope':'Unchanged nineteen-check HTTP examples fixture, unchanged120s per-command guard; task-only600s overall diagnostic capture. Existing CTest300s limit and original timeout evidence are untouched.'}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
try:
 previous=json.loads((share/'native-downstream-13/result.json').read_text());remaining=json.loads((share/'native-downstream-14/result.json').read_text());assert previous['status']=='FAIL' and previous['error']=='KeyboardInterrupt()' and remaining['status']=='PASS' and len(remaining['remaining_tests'])==34,'Complete all350 cases across preserved partial run and exact remaining-case continuation before diagnosis'
 assert json.loads((share/'native-http-reload-corrected/result.json').read_text())['status']=='PASS','Finish the sequential reload correction checks first'
 source=root/'tests/net/http/examples.py';record['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
 expected=json.loads((share/'native-http-examples-debug-direct-input.json').read_text());assert record['source_sha256']==expected['source_sha256']
 argv=list(map(str,[sys.executable,source,build/'voidc.exe',build/'void_http_example_host.exe','--evidence',out/'fixture-evidence']));record['argv']=argv;record['free_before']=shutil.disk_usage(root).free;save();started=time.monotonic()
 with (out/'run.log').open('wb') as log:
  process=subprocess.Popen(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NEW_PROCESS_GROUP);record['owned_pid']=process.pid;save()
  try:status=process.wait(timeout=600)
  except subprocess.TimeoutExpired:
   record['overall_timeout']=True;save();process.send_signal(signal.CTRL_BREAK_EVENT)
   try:process.wait(timeout=10)
   except subprocess.TimeoutExpired:
    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT,check=True);process.wait(timeout=10)
   raise
 record.update(exit_code=status,seconds=time.monotonic()-started,free_after=shutil.disk_usage(root).free)
 commands=json.loads((out/'fixture-evidence/commands.json').read_text());record['completed_commands']=len(commands);record['command_seconds']=sum(item['seconds'] for item in commands)
 assert hashlib.sha256(source.read_bytes()).hexdigest()==record['source_sha256'],'Fixture source changed'
 assert status==0 and len(commands)==19,'Keep all nineteen checks and original diagnostics'
 for name in ['cancellation-peer.json','cancellation-timeout-peer.json']:assert (out/'fixture-evidence'/name).is_file(),name
 record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
