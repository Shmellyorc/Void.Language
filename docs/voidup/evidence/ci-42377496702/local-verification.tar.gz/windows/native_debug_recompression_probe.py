from pathlib import Path
import ctypes,datetime,hashlib,json,shutil,subprocess
root=Path.home()/'VoidCI42377496702-Native';share=Path(r'\\vboxsvr\VM\ci-42377496702');out=share/'native-debug-recompression-probe';out.mkdir(exist_ok=True);assert json.loads((share/'native-release-compression/result.json').read_text())['status']=='PASS'
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
file=root/'build/Debug/void_tests.pdb';assert file.is_file()
def entry():
 high=ctypes.c_uint32();low=k.GetCompressedFileSizeW(str(file),ctypes.byref(high));return {'attributes':file.stat().st_file_attributes,'logical':file.stat().st_size,'allocated':(high.value<<32)|low,'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'free':shutil.disk_usage(root).free}
r={'file':str(file),'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':entry()};assert r['before']['attributes']&0x800 and not r['before']['attributes']&0x400
with (out/'compact.log').open('wb') as log:result=subprocess.run([r'C:\Windows\System32\compact.exe','/C','/F','/Q',str(file)],stdout=log,stderr=subprocess.STDOUT)
r['status']=result.returncode;r['after']=entry();assert result.returncode==0 and r['after']['sha256']==r['before']['sha256'] and r['after']['attributes']&0x800 and not r['after']['attributes']&0x400
memory=subprocess.run(['powershell','-NoProfile','-Command',"@{Memory=(Get-CimInstance Win32_OperatingSystem | Select-Object FreePhysicalMemory,TotalVisibleMemorySize,FreeVirtualMemory,TotalVirtualMemorySize);Pagefile=(Get-CimInstance Win32_PageFileUsage | Select-Object Name,AllocatedBaseSize,CurrentUsage,PeakUsage)} | ConvertTo-Json -Depth 3"],capture_output=True,text=True);r['memory']=json.loads(memory.stdout) if memory.returncode==0 else memory.stderr
(out/'result.json').write_text(json.dumps(r,indent=2)+'\n')
