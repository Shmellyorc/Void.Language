from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time,traceback
share=Path(r'\\vboxsvr\VM\ci-42377496702');root=Path.home()/'VoidCI42377496702-Native';out=share/'native-http-reload-corrected';out.mkdir(exist_ok=False);sdk=(root/'.toolchains/llvm-23.1.4').resolve();private=root/'native-private-temp'
record={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','commands':[],'scope':'Only deliberate-held-response fixture barrier/options corrected after native timeout/download proof. Original C++ assertions, process/CTest deadlines and separate deadline tests unchanged.'}
def save():(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
env=dict(os.environ,PATH=str(sdk/'bin')+os.pathsep+os.environ['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin',TMP=str(private),TEMP=str(private),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
def run(label,args):
 record['stage']=label;save();start=time.monotonic();argv=list(map(str,args))
 with (out/(label+'.log')).open('wb') as log:r=subprocess.run(argv,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':argv,'status':r.returncode,'seconds':time.monotonic()-start,'free_bytes':shutil.disk_usage(root).free});save()
 if r.returncode:raise RuntimeError(label+' failed; output retained')
try:
 assert json.loads((share/'native-downstream-14/result.json').read_text())['status']=='PASS'
 diagnostic=json.loads((share/'native-http-reload-diagnostic-2/result.json').read_text());assert diagnostic['status']=='OBSERVED' and diagnostic['reproduced_http_timeout'] and diagnostic['original_source_restored'] and diagnostic['original_fixture_rebuild_completed']
 source=root/'tests/net/http/reload.py';candidate=share/'source-overlays/tests/net/http/reload.py'
 assert hashlib.sha256(source.read_bytes()).hexdigest()=='6bf4efb6f5672e0b58c46d0ac4880f948d8f4e94ca8a4533d24a7b84842132f5'
 digest=hashlib.sha256(candidate.read_bytes()).hexdigest();assert digest=='4a52fe4e83eb187e5b2c4ca0a3dc7d14826aabaec2ae5b507afae3cba18d53c2'
 assert hashlib.sha256((root/'tests/net/http/reload.cpp').read_bytes()).hexdigest()=='666ed02a121cea6b4af21d4228bb943cb51862b6224eb6df7236291d250dd628'
 shutil.copyfile(source,out/'reload-before.py');shutil.copyfile(candidate,source);shutil.copyfile(source,out/'reload-after.py');record['source_sha256']=digest;save()
 for profile in ['Release','Debug']:
  build=root/'build'/profile
  run('tests-'+profile,['ctest','--test-dir',build,'--output-on-failure','--parallel','1','-R','^(http_reload|http_timeouts)$','--output-junit',out/(profile+'.xml')])
  evidence=build/'http-reload-evidence'
  if evidence.exists():shutil.copytree(evidence,out/(profile+'-reload-evidence'))
 record['status']='PASS'
except BaseException as error:record.update(status='FAIL',error=repr(error),traceback=traceback.format_exc());raise
finally:record['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
