#include "host_windows_candidate.hpp"
#include <filesystem>
#include <iostream>
namespace fs=std::filesystem;
using namespace vd::host::win;
int wmain(int argc,wchar_t** argv)try {
 if(argc!=2)return 2;fs::path root(argv[1]);PrivateAccess access;SECURITY_ATTRIBUTES attributes=access.attributes;
 if(!CreateDirectoryW(root.c_str(),&attributes))fail();
 LPWSTR value=nullptr;if(!ConvertSidToStringSidW(access.sid(),&value))fail();std::wstring owner(value);LocalFree(value);
 struct Test {const wchar_t* name;const wchar_t* extra;bool ancestor;bool accepted;};
 unsigned passed=0;
 for(auto t:{Test{L"owner-rights-ancestor",L"",true,true},Test{L"owner-rights-leaf",L"",false,false},Test{L"everyone-write",L"(A;;0x100;;;WD)",true,false},Test{L"foreign-write",L"(A;;0x1301bf;;;S-1-5-21-2359293625-2559315270-4274458766-3208099622)",true,false}}) {
  std::wstring sddl=L"O:"+owner+L"D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;FA;;;OW)"+t.extra;
  PSECURITY_DESCRIPTOR descriptor=nullptr;if(!ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl.c_str(),SDDL_REVISION_1,&descriptor,nullptr))fail();
  SECURITY_ATTRIBUTES security{sizeof(SECURITY_ATTRIBUTES),descriptor,FALSE};auto path=root/t.name;BOOL created=CreateDirectoryW(path.c_str(),&security);auto create_error=GetLastError();LocalFree(descriptor);if(!created)fail(create_error);
  Handle h(CreateFileW(path.c_str(),FILE_LIST_DIRECTORY|FILE_READ_ATTRIBUTES|READ_CONTROL,FILE_SHARE_READ|FILE_SHARE_WRITE|FILE_SHARE_DELETE,nullptr,OPEN_EXISTING,FILE_FLAG_BACKUP_SEMANTICS|FILE_FLAG_OPEN_REPARSE_POINT,nullptr));if(h.value==INVALID_HANDLE_VALUE)fail();
  bool actual=true;int code=0;try{access.verify(h.value,t.ancestor);}catch(const std::system_error& e){actual=false;code=e.code().value();}
  std::wcout<<t.name<<L" ancestor="<<t.ancestor<<L" admitted="<<actual<<L" expected="<<t.accepted<<L" native_error="<<code<<L"\n";
  if(actual!=t.accepted || (!actual && code!=ERROR_ACCESS_DENIED))return 1;++passed;
 }
 std::cout<<passed<<" OWNER_RIGHTS policy checks passed\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<"\n";return 1;}
