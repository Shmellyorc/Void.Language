@echo off
title VOID Debug disk monitor - read only
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42377496702\native_disk_watch_11.py" > "\\vboxsvr\VM\ci-42377496702\native-disk-watch-11.log" 2>&1
