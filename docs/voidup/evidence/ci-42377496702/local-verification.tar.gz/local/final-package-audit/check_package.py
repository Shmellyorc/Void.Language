from pathlib import Path
import hashlib,json,shutil,subprocess,sys,tempfile
root=Path.cwd();out=root/'build/ci-42377496702/final-package-audit';sys.path.insert(0,str(root/'tools'))
from verify_host_deps import RECIPES,sha,source_policy
record={'scope':'Fresh component installation after final-recipe Release verification. Installed recipes used for offline source reconstruction.','commands':[]}
def run(label,args,expected=0):
 r=subprocess.run(list(map(str,args)),cwd=root,capture_output=True)
 (out/(label+'.log')).write_bytes(r.stdout+r.stderr)
 record['commands'].append({'label':label,'argv':list(map(str,args)),'status':r.returncode})
 (out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
 assert (r.returncode==0)==(expected==0),(label,r.returncode)
 return r
with tempfile.TemporaryDirectory(prefix='package-check-',dir=out) as tmp:
 work=Path(tmp);prefix=work/'installed'
 run('install',['cmake','--install',root/'build/voidup-backport-integration/Release','--prefix',prefix,'--component','compiler'])
 host=prefix/'share/void/licenses/host';bundle=host/'corresponding-source';repro=bundle/'repro'
 receipt=json.loads((host/'VOID-HOST-DEPENDENCIES.json').read_text());assert receipt['schema']==3 and receipt['source_provenance']==source_policy()
 for name in RECIPES:assert sha(repro/name)==receipt['recipe_sha256'][name],name
 for name in ['libsodium','libarchive']:
  pin=receipt['pins'][name];assert sha(bundle/pin['url'].rsplit('/',1)[-1])==pin['sha256']
 for name in ['libsodium/LICENSE','libarchive/COPYING']:assert (host/name).is_file(),name
 assert sha(host/'patches/libsodium-1.0.22/asan-alignment.patch')==receipt['source_provenance']['patch']['sha256']
 reconstructed=work/'reconstructed'
 result=run('reconstruct',[sys.executable,repro/'tools/verify_host_deps.py','--archives',bundle,'--reconstruct-source',reconstructed])
 assert json.loads(result.stdout)==receipt['source_provenance']
 for name,digest in receipt['source_provenance']['postimages'].items():assert sha(reconstructed/name)==digest
 copied=work/'damaged-bundle';shutil.copytree(bundle,copied)
 bad=copied/'repro/third_party/host-patches/libsodium-1.0.22/asan-alignment.patch';bad.write_bytes(bad.read_bytes()+b'\nchanged\n')
 rejected=run('tampered-patch-rejected',[sys.executable,copied/'repro/tools/verify_host_deps.py','--archives',copied,'--reconstruct-source',work/'must-not-exist'],1)
 assert b'patch policy mismatch' in rejected.stderr and not (work/'must-not-exist').exists()
 record.update(result='PASS',receipt_build_identity=receipt['build_identity'],receipt_sha256=sha(host/'VOID-HOST-DEPENDENCIES.json'),recipe_count=len(RECIPES),patched_postimages=len(receipt['source_provenance']['postimages']),licenses_present=True,archives_verified=True,source_reconstructed=True,tampered_patch_rejected=True,source_provenance=receipt['source_provenance'],temporary_files_removed_on_exit=True)
(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({k:record[k] for k in ('result','recipe_count','patched_postimages','source_reconstructed','tampered_patch_rejected')}))
