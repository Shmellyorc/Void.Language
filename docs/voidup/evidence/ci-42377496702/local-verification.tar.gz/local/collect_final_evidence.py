"""Curate task evidence after all writers stop; never remove source evidence."""
from pathlib import Path
import hashlib,json,tarfile
ROOT=Path(__file__).resolve().parents[2]
SHARED=Path('/home/shmellyorc/VM/ci-42377496702')
OUT=ROOT/'docs/voidup/evidence/ci-42377496702'
SUFFIXES={'.json','.jsonl','.csv','.tsv','.log','.xml','.txt','.stdout','.stderr','.py','.cmd','.ps1','.cpp','.h','.hpp','.patch','.trs','.res','.c','.void'}
GENERATED_TREES={'node_modules','.vscode-test','.toolchains','installed','reconstructed','damaged-bundle'}
PROVIDER_RECORDS={'commands.json','sodium-configure.log','sodium-build.log','sodium-tests.log',
 'test-suite.log','sodium-install.log','http-closure.log','archive-configure.log',
 'archive-build.log','archive-install.log','sodium_utils2.log','sodium_utils2.trs',
 'sodium_utils2.res','sodium_utils3.log','sodium_utils3.trs','sodium_utils3.res'}
items={}
def take(path,name):
 if path.name.startswith('native-resume-checkpoint-') or GENERATED_TREES.intersection(Path(name).parts):return
 if path.is_file() and not path.is_symlink() and path.suffix in SUFFIXES:
  items[name]=path
for p in SHARED.iterdir():
 if p.is_file():take(p,'windows/'+p.name)
 elif p.is_dir() and (p.name.startswith('native-') or p.name in {'archive-first-configure-failure','sdk-diagnostic','toolset-prerequisite','status-1','status-2','source-overlays'}):
  for f in p.rglob('*'):
   if f.is_file():take(f,'windows/'+str(f.relative_to(SHARED)))
local=ROOT/'build/ci-42377496702'
for name in ['host-responsiveness-incident.json','pause-confirmation.json','resume-resource-check.json','run_linux_fresh.py','run_linux_fresh_continue.py','run_ubuntu_fresh.py','run_ubuntu_fresh_continue.py','collect_final_evidence.py','final_inventory.py']:
 take(local/name,'local/'+name)
for name in ['resumed-source-checks','linux-fresh','final-package-audit','ubuntu-fresh']:
 base=local/name
 if base.exists():
  for f in base.rglob('*'):
   rel=f.relative_to(base)
   # Aggregate qualification records only, not disposable extracted/build trees.
   if any(x in {'build','build-aligned','source','installed','reconstructed','damaged-bundle','retained-provider-evidence'} for x in rel.parts):continue
   if name=='ubuntu-fresh' and 'provider-evidence' in rel.parts and f.name not in PROVIDER_RECORDS:continue
   take(f,'local/'+name+'/'+str(rel))
# Add fresh provider aggregate logs explicitly; exclude repetitive per-test output
# only where the complete test-suite.log and original recipe logs are retained.
for r in [local/'linux-fresh/results.json',local/'linux-fresh/continuation-results.json']:
 if not r.exists():continue
 for name in json.loads(r.read_text()).get('evidence',[]):
  base=Path(name)
  if not base.exists():base=local/'linux-fresh/retained-provider-evidence'/base.name
  if base.exists():
   for f in base.rglob('*'):
    if f.is_file() and f.name in PROVIDER_RECORDS:take(f,'linux-providers/'+base.name+'/'+str(f.relative_to(base)))
index={'scope':'Actual local/native records for CI42377496702; failures and interruptions retained. Original hosted records are in original-ci.tar.gz.','excluded':'Generated dependency/install trees, binaries, archives, UI screenshots and internal continuation checkpoints remain local. Fresh passing upstream suites retain aggregate named-test logs and the two ASan output-oracle records; redundant per-test pass/output files remain in retained-provider-evidence and ubuntu-fresh/provider-evidence.','members':[]}
OUT.mkdir(parents=True,exist_ok=True)
archive=OUT/'local-verification.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for name,path in sorted(items.items()):
  data=path.read_bytes();index['members'].append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});tar.add(path,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for item in index['members']:
  assert hashlib.sha256(tar.extractfile(item['path']).read()).hexdigest()==item['sha256'],item['path']
index['archive']={'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(OUT/'local-verification-index.json').write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'members':len(items),'archive':index['archive']},indent=2))
