"""Fresh Ubuntu24 provider compatibility check, only after native builds stop."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'build/ci-42377496702/ubuntu-fresh'
SOURCE=OUT/'source'
VM='voidup-portability-ubuntu'
record={'scope':'Ubuntu24.04 container userspace on PikaOS kernel; Release providers and87 upstream tests plus native Runtime host tests on hard1MiB stack, not full hosted Ubuntu job.','jobs':1,'commands':[],'status':'running'}
def save():(OUT/'results.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args):
 record['stage']=label;save();start=time.monotonic()
 with (OUT/(label+'.log')).open('wb') as log:r=subprocess.run(list(map(str,args)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':list(map(str,args)),'exit_code':r.returncode,'seconds':time.monotonic()-start});save()
 if r.returncode:
  record['status']='FAIL';save();raise RuntimeError(label+' failed; original log retained')
if OUT.exists():raise RuntimeError('Refuse to overwrite existing Ubuntu qualification')
OUT.mkdir()
try:
 # Copy only the tracked recipe/verification inputs and the receipt negative test.
 tracked=subprocess.check_output(['git','ls-files','-z','tools','cmake','third_party','tests/host_capabilities/dependencies.py','docs/net/http/evidence/curl-8.23.0-cookie-oom-candidate.patch','docs/net/http/evidence/curl-8.23.0-http2-window-candidate.patch'],cwd=ROOT).decode().split('\0')
 record['source_inputs']={}
 for name in filter(None,tracked):
  source=ROOT/name
  if not source.is_file():continue
  target=SOURCE/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
  record['source_inputs'][name]=hashlib.sha256(source.read_bytes()).hexdigest()
 links={'.toolchains/llvm-23.1.4':ROOT/'.toolchains/llvm-23.1.4',
 '.toolchains/http':ROOT/'build/voidup-integration-ubuntu-bootstrap/.toolchains/http',
 '.toolchains/host/downloads':ROOT/'.toolchains/host/downloads',
 '.toolchains/host/sources':ROOT/'.toolchains/host/sources'}
 for name,target in links.items():
  assert target.is_dir(),target
  link=SOURCE/name;link.parent.mkdir(parents=True,exist_ok=True);link.symlink_to(target,target_is_directory=True)
 record['reused_verified_inputs']={name:str(target) for name,target in links.items()};save()
 state=subprocess.check_output(['podman','inspect',VM,'--format','{{.State.Status}}'],text=True).strip();record['original_container_state']=state;save()
 if state!='running':run('start-container',['podman','start',VM])
 run('identity',['podman','exec',VM,'python3','-c','import platform,json;print(json.dumps({"platform":platform.platform(),"libc":platform.libc_ver(),"os_release":open("/etc/os-release").read()}))'])
 run('providers',['podman','exec',VM,'python3',SOURCE/'tools/setup_host_deps.py','--profile','Release','--jobs','1'])
 prefix=SOURCE/'.toolchains/host/prefix/Release'
 run('verify',['podman','exec',VM,'python3',SOURCE/'tools/verify_host_deps.py','--prefix',prefix,'--profile','Release','--platform','Linux','--architecture','x86_64'])
 run('receipt-negatives',['podman','exec',VM,'python3',SOURCE/'tests/host_capabilities/dependencies.py',prefix,'Release','Linux','x86_64'])
 sdk=ROOT/'.toolchains/llvm-23.1.4';build=OUT/'build'
 http=ROOT/'build/voidup-integration-ubuntu-bootstrap/.toolchains/http/prefix/linux-aws-lc-5.12.0/Release'
 run('configure-host',['podman','exec','-e','CMAKE_BUILD_PARALLEL_LEVEL=1','-w',ROOT,VM,'cmake','-S',ROOT,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON','-DVOID_SANITIZERS=OFF','-DCMAKE_C_COMPILER='+str(sdk/'bin/clang'),'-DCMAKE_CXX_COMPILER='+str(sdk/'bin/clang++'),'-DCMAKE_AR='+str(sdk/'bin/llvm-ar'),'-DCMAKE_RANLIB='+str(sdk/'bin/llvm-ranlib'),'-DCMAKE_LINKER='+str(sdk/'bin/ld.lld'),'-DLLVM_DIR='+str(sdk/'lib/cmake/llvm'),'-DVOID_CLANG='+str(sdk/'bin/clang'),'-DVOID_LINKER='+str(sdk/'bin/ld.lld'),'-DPython3_EXECUTABLE=/usr/bin/python3','-DVOID_HOST_DEPS_ROOT='+str(prefix),'-DVOID_HTTP_DEPS_ROOT='+str(http)])
 run('build-host',['podman','exec','-w',ROOT,VM,'cmake','--build',build,'--target','void_host_portable','--parallel','1'])
 run('host-tests',['podman','exec','-e','VOID_HOST_EVIDENCE_DIR='+str(OUT/'host-evidence'),'-e','VOID_CRASH_EVIDENCE='+str(OUT/'crashes'),'-e','CTEST_PARALLEL_LEVEL=1','-w',ROOT,VM,'python3','-c','import os,resource,sys;resource.setrlimit(resource.RLIMIT_STACK,(1048576,1048576));os.execvp(sys.argv[1],sys.argv[1:])','ctest','--test-dir',build,'-j','1','-R','^(host_capabilities_dependencies|host_capabilities_portable)$','--output-on-failure','--output-junit',OUT/'host-tests.xml'])
 record['receipt']=json.loads((prefix/'VOID-HOST-DEPENDENCIES.json').read_text());record['hard_stack_bytes']=1048576;record['status']='PASS';record.pop('stage',None);save()
except BaseException as error:
 record['status']='FAIL';record['error']=repr(error);save();raise
finally:
 evidence=SOURCE/'docs/voidup/evidence'
 if evidence.exists():
  target=OUT/'provider-evidence';target.mkdir(exist_ok=True)
  for entry in evidence.iterdir():
   if entry.is_dir():shutil.copytree(entry,target/entry.name)
 if record.get('original_container_state')=='exited':
  # Stop only the existing task container started above; never manage the VM.
  run('stop-container',['podman','stop',VM])

record.pop('stage',None);save()
