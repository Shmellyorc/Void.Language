"""Write this repair's explicit review inventory; never stage files."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
BASE = "799a29e3c0b0e204abecd4dc1f14356bf1df3443"
OUT = ROOT / "docs/voidup/evidence/ci-42377496702"
SOURCE = {
    ".gitattributes", "tools/setup_host_deps_native.py",
    "src/runtime/host_directory_windows.cpp", "src/runtime/host_windows.hpp",
    "tests/host_capabilities/portable.cpp", "tests/host_capabilities/portable_source.py",
    "tests/stage8/sprint4.py", "tests/stage9/workflow.py", "tests/voidup/ci_integration.py",
    # Only include these if the pending native diagnostics justify their repair.
    "tests/net/http/reload.py", "CMakeLists.txt",
}
REPORT = "docs/voidup/INTEGRATION_REPORT.md"
ARTIFACTS = {
    "original-ci.tar.gz", "original-ci-index.json", "source.patch",
    "documentation.patch", "local-verification.tar.gz", "local-verification-index.json",
    "commit-paths.txt", "commit-paths.nul", "commit-inventory.json",
}

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)

def paths(*args):
    return {x.decode() for x in git(*args).split(b"\0") if x}

assert git("rev-parse", "HEAD").decode().strip() == BASE
assert not git("diff", "--cached", "--name-only", "-z"), "Staged changes require separate review"
changed = paths("diff", "--name-only", "-z", "HEAD")
assert changed <= SOURCE | {REPORT}, sorted(changed - SOURCE - {REPORT})
assert REPORT in changed
source = sorted(changed & SOURCE)
assert source
git("diff", "--check")
(OUT / "source.patch").write_bytes(git("diff", "--binary", "HEAD", "--", *source))
(OUT / "documentation.patch").write_bytes(git("diff", "--binary", "HEAD", "--", REPORT))

artifact_paths = {str((OUT / name).relative_to(ROOT)) for name in ARTIFACTS}
untracked = paths("ls-files", "--others", "--exclude-standard", "-z")
assert untracked <= artifact_paths, sorted(untracked - artifact_paths)
intended = sorted(changed | artifact_paths)
(OUT / "commit-paths.txt").write_text("\n".join(intended) + "\n")
(OUT / "commit-paths.nul").write_bytes(b"".join(x.encode() + b"\0" for x in intended))
manifest_path = str((OUT / "commit-inventory.json").relative_to(ROOT))
entries = []
for name in intended:
    path = ROOT / name
    assert not path.is_symlink(), name
    if name == manifest_path:
        entries.append({"path": name, "sha256": None, "reason": "This manifest cannot hash itself"})
    else:
        data = path.read_bytes()
        entries.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

record = {
    "baseline": BASE,
    "scope": "Exact current repair delta; earlier 159/5879-path inventories are historical",
    "staged": 0,
    "tracked_modified": len(changed),
    "untracked_intended": len(artifact_paths),
    "total_intended": len(intended),
    "source_paths": source,
    "entries": entries,
    "excluded_generated_roots": [
        "build/", ".toolchains/", "/home/shmellyorc/VM/ci-42377496702/",
        "C:\\Users\\a\\VoidCI42377496702-Native\\",
    ],
    "unexpected_pending_paths": [],
    "staging_command_not_executed": "git --literal-pathspecs add --pathspec-from-file=docs/voidup/evidence/ci-42377496702/commit-paths.nul --pathspec-file-nul",
    "suggested_commit_title": "Repair native Windows VOIDUP and preserve LLVM 23 provider provenance [skip ci]",
}
(OUT / "commit-inventory.json").write_text(json.dumps(record, indent=2) + "\n")
assert paths("ls-files", "--others", "--exclude-standard", "-z") == artifact_paths
print(json.dumps({key: record[key] for key in ("staged", "tracked_modified", "untracked_intended", "total_intended")}, indent=2))
