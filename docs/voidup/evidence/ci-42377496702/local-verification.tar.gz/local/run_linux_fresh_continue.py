"""Sequential local qualification, launched only after native Windows builds stop."""
from pathlib import Path
import json,os,resource,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'build/ci-42377496702/linux-fresh'
OUT.mkdir(exist_ok=True)
record={'status':'running','jobs':1,'commands':[],'retained_prefixes':[],'evidence':[], 'continued_from':'results.json', 'reason':'Original Release frontend was Not Run because focused harness omitted void_tests target; original result retained.'}
def save():
 (OUT/'continuation-results.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,argv,env=None,small_stack=False):
 available=next(int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
 if available<4*1024*1024:raise RuntimeError('Less than 4GiB host memory available; no build started')
 record['stage']=label;save();start=time.monotonic()
 def stack():resource.setrlimit(resource.RLIMIT_STACK,(1024*1024,1024*1024))
 with (OUT/(label+'.log')).open('wb') as log:
  p=subprocess.Popen(list(map(str,argv)),cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,preexec_fn=stack if small_stack else None)
  record['active_pid']=p.pid;save();code=p.wait()
 record.pop('active_pid',None);record['commands'].append({'label':label,'argv':list(map(str,argv)),'exit_code':code,'seconds':time.monotonic()-start,'hard_stack_bytes':1024*1024 if small_stack else None});save()
 if code:raise RuntimeError(label+' failed; original diagnostics retained')
try:
 original=json.loads((OUT/'results.json').read_text())
 assert original['status']=='FAIL' and original['stage']=='Release-frontend-stack'
 compiler=ROOT/'build/voidup-backport-integration/Release'
 run('Release-frontend-build',['cmake','--build',compiler,'--parallel','1','--target','void_tests'])
 run('Release-frontend-stack-corrected',['ctest','--test-dir',compiler,'-R','^frontend$','--output-on-failure','--output-junit',OUT/'Release-frontend-corrected.xml'],small_stack=True)
 for profile in ('Debug','strict'):
  prefix=ROOT/'.toolchains/host/prefix'/profile
  retained=ROOT/'.toolchains/host/retained/ci-42377496702'/profile
  build=OUT/'build'/profile
  if retained.exists() or build.exists():raise RuntimeError('Refuse to overwrite existing qualification: '+profile)
  if not prefix.is_dir() or prefix.is_symlink():raise RuntimeError('Expected generated physical provider prefix: '+str(prefix))
  retained.parent.mkdir(parents=True,exist_ok=True)
  prefix.rename(retained)
  record['retained_prefixes'].append({'original':str(prefix),'retained':str(retained)});save()
  before=set((ROOT/'docs/voidup/evidence').glob('dependencies-linux-*'))
  try:run(profile+'-providers',[sys.executable,ROOT/'tools/setup_host_deps.py','--profile',profile,'--jobs','1','--build-dir',build])
  finally:
   record['evidence']+=list(map(str,sorted(set((ROOT/'docs/voidup/evidence').glob('dependencies-linux-*'))-before)));save()
  run(profile+'-verify',[sys.executable,ROOT/'tools/verify_host_deps.py','--prefix',prefix,'--profile',profile,'--platform','Linux','--architecture','x86_64'])
  run(profile+'-receipt-negatives',[sys.executable,ROOT/'tests/host_capabilities/dependencies.py',prefix,profile,'Linux','x86_64'])
  configuration='Sanitizers' if profile=='strict' else profile
  for provider in ('http','voidup'):
   run(profile+'-'+provider+'-closure',[sys.executable,ROOT/('tools/ci/'+provider+'_bootstrap.py'),'verify','--configuration',configuration,'--evidence',OUT/(profile+'-'+provider)])
  host_evidence=OUT/(profile+'-host-evidence');host_evidence.mkdir(exist_ok=True)
  env=dict(os.environ,VOID_HOST_EVIDENCE_DIR=str(host_evidence),VOID_CRASH_EVIDENCE=str(OUT/(profile+'-crashes')),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
  if profile=='strict':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86',ASAN_SYMBOLIZER_PATH=str(ROOT/'.toolchains/llvm-23.1.4/bin/llvm-symbolizer'))
  compiler=ROOT/'build/voidup-backport-integration'/profile
  run(profile+'-configure',['cmake','-S',ROOT,'-B',compiler],env)
  for provider in ('http','voidup'):
   run(profile+'-'+provider+'-test-plan',[sys.executable,ROOT/('tools/ci/'+provider+'_bootstrap.py'),'test-plan','--configuration',configuration,'--build',compiler,'--evidence',OUT/(profile+'-'+provider)],env)
  run(profile+'-build',['cmake','--build',compiler,'--parallel','1','--target','voidc','voidls','void_host_portable','void_host_child','void_host_capabilities','void_sprint4_tests','void_http_reload','void_http_timeouts','void_http_example_host','voidup']+(['void_tests'] if profile!='strict' else []),env)
  run(profile+'-focused',['ctest','--test-dir',compiler,'-R','^(host_capabilities.*|voidup_smoke|voidup_ci_integration)$','--output-on-failure','--output-junit',OUT/(profile+'-tests.xml')],env,small_stack=True)
  run(profile+'-application-oracles',['ctest','--test-dir',compiler,'-R','^(application_workflow_stage9|application_native_sprint4)$','--output-on-failure','--output-junit',OUT/(profile+'-application-oracles.xml')],env,small_stack=True)
  run(profile+'-http-fixtures',['ctest','--test-dir',compiler,'-R','^(http_reload|http_timeouts|http_examples)$','--output-on-failure','--output-junit',OUT/(profile+'-http-fixtures.xml')],env,small_stack=True)
  if profile!='strict':
   run(profile+'-frontend-stack',['ctest','--test-dir',compiler,'-R','^frontend$','--output-on-failure','--output-junit',OUT/(profile+'-frontend.xml')],env,small_stack=True)
 run('final-package',[sys.executable,ROOT/'build/ci-42377496702/final-package-audit/check_package.py'])
 record['status']='PASS';record.pop('stage',None);save()
except BaseException as error:
 record['status']='FAIL';record['error']=repr(error);save();raise
