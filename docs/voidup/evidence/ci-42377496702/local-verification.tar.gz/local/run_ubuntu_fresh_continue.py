"""Fresh Ubuntu24 provider compatibility check, only after native builds stop."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'build/ci-42377496702/ubuntu-fresh'
SOURCE=OUT/'source'
VM='voidup-portability-ubuntu'
record={'scope':'Ubuntu24.04 container userspace on PikaOS kernel; Release providers and87 upstream tests plus native Runtime host tests on hard1MiB stack, not full hosted Ubuntu job.','jobs':1,'commands':[],'status':'running','continued_from':'results.json','reason':'Original CMake used root checkout while providers were built from disposable source; five logical LLVM tool paths differed though tool hashes matched. Keep guard and receipts unchanged; align CMake/source context.'}
def save():(OUT/'continuation-results.json').write_text(json.dumps(record,indent=2)+'\n')
def run(label,args):
 record['stage']=label;save();start=time.monotonic()
 with (OUT/(label+'.log')).open('wb') as log:r=subprocess.run(list(map(str,args)),cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 record['commands'].append({'label':label,'argv':list(map(str,args)),'exit_code':r.returncode,'seconds':time.monotonic()-start});save()
 if r.returncode:
  record['status']='FAIL';save();raise RuntimeError(label+' failed; original log retained')

assert OUT.exists() and json.loads((OUT/'results.json').read_text())['status']=='FAIL'
assert not (OUT/'continuation-results.json').exists()
try:
 # Complete the disposable source context; leave originals and initial subset intact.
 tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
 record['additional_source_inputs']={}
 for name in filter(None,tracked):
  if name.startswith(('docs/','website/')):continue
  source=ROOT/name
  if not source.is_file() or source.is_symlink():continue
  target=SOURCE/name;target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert target.read_bytes()==source.read_bytes(),name
  else:shutil.copy2(source,target)
  record['additional_source_inputs'][name]=hashlib.sha256(source.read_bytes()).hexdigest()
 for name in ['llvm-23.1.4-deps','ninja-1.13.2']:
  target=ROOT/'.toolchains'/name;link=SOURCE/'.toolchains'/name
  if target.is_dir() and not link.exists():link.symlink_to(target,target_is_directory=True)
 receipt=SOURCE/'.toolchains/host/prefix/Release/VOID-HOST-DEPENDENCIES.json'
 record['original_receipt_sha256']=hashlib.sha256(receipt.read_bytes()).hexdigest();save()
 state=subprocess.check_output(['podman','inspect',VM,'--format','{{.State.Status}}'],text=True).strip();record['original_container_state']=state;save()
 if state!='running':run('continue-start-container',['podman','start',VM])
 prefix=SOURCE/'.toolchains/host/prefix/Release';sdk=SOURCE/'.toolchains/llvm-23.1.4';build=OUT/'build-aligned'
 assert not build.exists()
 http=ROOT/'build/voidup-integration-ubuntu-bootstrap/.toolchains/http/prefix/linux-aws-lc-5.12.0/Release'
 run('configure-host-aligned',['podman','exec','-e','CMAKE_BUILD_PARALLEL_LEVEL=1','-w',SOURCE,VM,'cmake','-S',SOURCE,'-B',build,'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=ON','-DVOID_SANITIZERS=OFF','-DCMAKE_C_COMPILER='+str(sdk/'bin/clang'),'-DCMAKE_CXX_COMPILER='+str(sdk/'bin/clang++'),'-DCMAKE_AR='+str(sdk/'bin/llvm-ar'),'-DCMAKE_RANLIB='+str(sdk/'bin/llvm-ranlib'),'-DCMAKE_LINKER='+str(sdk/'bin/ld.lld'),'-DLLVM_DIR='+str(sdk/'lib/cmake/llvm'),'-DVOID_CLANG='+str(sdk/'bin/clang'),'-DVOID_LINKER='+str(sdk/'bin/ld.lld'),'-DPython3_EXECUTABLE=/usr/bin/python3','-DVOID_HOST_DEPS_ROOT='+str(prefix),'-DVOID_HTTP_DEPS_ROOT='+str(http)])
 run('build-host-aligned',['podman','exec','-w',SOURCE,VM,'cmake','--build',build,'--target','void_host_portable','--parallel','1'])
 run('host-tests-aligned',['podman','exec','-e','VOID_HOST_EVIDENCE_DIR='+str(OUT/'host-evidence'),'-e','VOID_CRASH_EVIDENCE='+str(OUT/'crashes'),'-e','CTEST_PARALLEL_LEVEL=1','-w',SOURCE,VM,'python3','-c','import os,resource,sys;resource.setrlimit(resource.RLIMIT_STACK,(1048576,1048576));os.execvp(sys.argv[1],sys.argv[1:])','ctest','--test-dir',build,'-j','1','-R','^(host_capabilities_dependencies|host_capabilities_portable)$','--output-on-failure','--output-junit',OUT/'host-tests-aligned.xml'])
 assert hashlib.sha256(receipt.read_bytes()).hexdigest()==record['original_receipt_sha256']
 record['receipt_unchanged']=True;record['receipt']=json.loads(receipt.read_text());record['hard_stack_bytes']=1048576;record['status']='PASS';record.pop('stage',None);save()
except BaseException as error:
 record['status']='FAIL';record['error']=repr(error);save();raise
finally:
 if record.get('original_container_state')=='exited':run('continue-stop-container',['podman','stop',VM])
record.pop('stage',None);save()
