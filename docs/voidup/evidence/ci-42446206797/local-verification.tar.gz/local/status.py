from pathlib import Path
import json,re,datetime
w=Path(__file__).resolve().parent;n=Path('/home/shmellyorc/VM/ci-42446206797')
print(datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'))
for d,name in [(n,'integration-native-results.json'),(w,'linux-integrated-results.json'),(w,'editor-linux-integrated-results.json'),(n,'audit-results.json'),(n,'editor-native-resume-results.json'),(n,'audit-final-results.json')]:
 p=d/name
 if p.exists():
  try:r=json.loads(p.read_text())
  except json.JSONDecodeError:continue
  print(name,r.get('status'),r.get('stage'),str(r.get('error',''))[-200:])
for name in ['integration-native-full-Release.log']:
 p=n/name
 if p.exists():
  s=p.read_text(errors='replace');lines=[l.strip() for l in s.splitlines() if re.search(r'(Test\s+#|Start\s+\d+:|tests passed|Total Test time)',l)]
  print(name,lines[-2:]);bad=[l.strip() for l in s.splitlines() if '***Failed' in l or '***Timeout' in l];print('CURRENT failures',bad) if bad else None
