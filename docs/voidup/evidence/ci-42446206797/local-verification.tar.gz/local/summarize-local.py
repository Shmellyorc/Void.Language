from pathlib import Path
import json,xml.etree.ElementTree as ET,hashlib
work=Path(__file__).resolve().parent;native=Path('/home/shmellyorc/VM/ci-42446206797');rows=[]
for directory,label in [(native,'native'),(work,'linux')]:
 for path in sorted(directory.glob('*.xml')):
  try:root=ET.parse(path).getroot()
  except ET.ParseError:continue
  cases=root.findall('.//testcase')
  failures=[x.attrib.get('name') for x in cases if x.find('failure') is not None or x.find('error') is not None]
  skips=[x.attrib.get('name') for x in cases if x.find('skipped') is not None or x.attrib.get('status')=='notrun']
  rows.append({'scope':label,'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'tests':len(cases),'passed':len(cases)-len(failures)-len(skips),'failed':failures,'skipped':skips,'seconds':sum(float(x.attrib.get('time','0')) for x in cases)})
(work/'local-results-summary.json').write_text(json.dumps(rows,indent=2)+'\n')
for row in rows:print(row['scope'],row['file'],row['passed'],'/',row['tests'],'failed',row['failed'],'skipped',row['skipped'])
