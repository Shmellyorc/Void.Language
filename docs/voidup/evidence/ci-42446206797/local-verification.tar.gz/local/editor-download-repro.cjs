const fs=require('node:fs'), path=require('node:path'), os=require('node:os'), Module=require('node:module');
const {PassThrough}=require('node:stream'),dc=require('node:diagnostics_channel'),assert=require('node:assert/strict');
const filename=path.resolve('editors/vscode/node_modules/@vscode/test-electron/out/download.js');
const mod=new Module(filename,module);mod.filename=filename;mod.paths=Module._nodeModulePaths(path.dirname(filename));
mod._compile(fs.readFileSync(filename,'utf8')+'\nexports.probe=unzipVSCode;\n',filename);
(async()=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'VOID-downloader-abort-'));const tracked=[];
 const observer=({process:child})=>{const closed=new Promise(resolve=>child.once('close',resolve));tracked.push({child,closed});};
 dc.subscribe('child_process',observer);
 try{
  const stream=new PassThrough();setTimeout(()=>stream.destroy(new Error('controlled input abort')),100);
  await assert.rejects(mod.exports.probe({report(){}},tmp,'linux-x64',{format:'tgz',stream,length:1000}),/controlled input abort/);
  await new Promise(resolve=>setTimeout(resolve,100));
  assert.equal(tracked.length,1);
  const before=tracked.map(({child})=>({pid:child.pid,spawnfile:child.spawnfile,exitCode:child.exitCode,signalCode:child.signalCode,stdinDestroyed:child.stdin.destroyed}));
  assert.equal(before[0].exitCode,null);assert.equal(before[0].stdinDestroyed,false);
  for(const {child} of tracked)child.stdin.destroy();
  await Promise.race([Promise.all(tracked.map(x=>x.closed)),new Promise((_,reject)=>setTimeout(()=>reject(new Error('Owned tar did not close after input EOF')),3000).unref())]);
  console.log(JSON.stringify({result:'PASS',demonstrated:'Exact pinned upstream unzipVSCode rejects aborted input but leaves tar alive with stdin open; explicit owned stdin close reaps tar.',before,after:tracked.map(({child})=>({pid:child.pid,exitCode:child.exitCode,signalCode:child.signalCode,stdinDestroyed:child.stdin.destroyed}))},null,2));
 }finally{dc.unsubscribe('child_process',observer);for(const {child}of tracked)if(child.exitCode===null&&child.signalCode===null)child.kill();fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(error=>{console.error(error);process.exitCode=1;});
