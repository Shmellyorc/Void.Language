from pathlib import Path
import json,hashlib,subprocess,tarfile,ast,re
root=Path.cwd();work=root/'build/ci-42446206797';evidence=root/'docs/voidup/evidence/ci-42446206797'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
results={}
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b8776526c83d6c5668490bad8c2c1fc7a35b1f0f'
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
subprocess.run(['git','diff','--check'],check=True)
for name,record in read(work/'protected-inputs.json')['files'].items():assert sha(root/name)==record['sha256'],name
results['protected_inputs']=15
for name,digest in read(Path('/home/shmellyorc/VM/ci-42446206797/integration-source-hashes.json')).items():assert sha(root/name)==digest,('Untested source change',name)
for name,digest in read(work/'editor-source-hashes.json').items():assert sha(root/name)==digest,name
for name,digest in read(work/'editor-protected-inputs.json').items():assert sha(root/name)==digest,name
results['frozen_native_source_files']=8
results['frozen_editor_source_files']=3
inventory=read(evidence/'commit-inventory.json');paths=inventory['paths'];assert len(paths)==len(set(paths))==21
assert (evidence/'commit-paths.txt').read_text().splitlines()==paths
assert (evidence/'commit-paths.nul').read_bytes()==b''.join(p.encode()+b'\0' for p in paths)
for p,h in inventory['sha256'].items():assert sha(root/p)==h,p
assert inventory['suggested_title'].endswith('[skip ci]')
results['intended_paths']=len(paths)
results['archives']={}
for label in ['original-ci','local-verification']:
 index=read(evidence/(label+'-index.json'));archive=evidence/index['archive'];assert sha(archive)==index['sha256']
 expected={p['path']:p for p in index['files']}
 with tarfile.open(archive,'r:gz') as t:
  assert {p.name for p in t.getmembers()}==set(expected)
  for m in t.getmembers():
   assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
   data=t.extractfile(m).read();record=expected[m.name];assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'],m.name
 results['archives'][label]={'files':len(expected),'bytes':archive.stat().st_size,'sha256':index['sha256']}
for p in ['tests/cli/install.py','tests/host_capabilities/portable.py','tests/host_capabilities/portable_source.py','tests/host_capabilities/staged_child.py','tests/stage9/workflow.py','tools/test_platform.py']:ast.parse((root/p).read_text(),filename=p)
active=(root/'docs/voidup/INTEGRATION_REPORT.md').read_text().split('\n---\n',1)[0]
assert '_PENDING' not in active
links=[]
for target in re.findall(r'\]\(([^)]+)\)',active):
 if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',target) or target.startswith('#'):continue
 file=target.split('#',1)[0]
 if file:assert ((root/'docs/voidup')/file).exists(),target;links.append(target)
results['active_local_links']=links
results['result']='PASS'
(work/'delivery-verification.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
