from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil,xml.etree.ElementTree as ET
root=Path.cwd();work=root/'build/ci-42446206797';native=Path('/home/shmellyorc/VM/ci-42446206797');evidence=root/'docs/voidup/evidence/ci-42446206797'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b8776526c83d6c5668490bad8c2c1fc7a35b1f0f'
assert not subprocess.check_output(['git','diff','--cached','--name-only'])
assert read(work/'ci-collector.json')['status']=='complete'
for p in [native/'integration-native-results.json',native/'audit-final-results.json',native/'relocate-controls.json',work/'linux-integrated-results.json']:assert read(p)['status']=='PASS',p
assert read(native/'all-source-comparison-final.json')['matched']
assert read(native/'relocate-shared-controls.json')['status']=='PASS'
for name,digest in {**read(native/'integration-source-hashes.json'),**read(work/'editor-source-hashes.json')}.items():assert sha(root/name)==digest,('Untested source change',name)
for name,digest in read(work/'editor-protected-inputs.json').items():assert sha(root/name)==digest,name
assert read(work/'editor-download-candidate.json')['result']=='PASS'
assert read(work/'patch-integrated-reconstruction.json')['matched']
assert read(work/'editor-linux-integrated-results.json')['status']=='PASS'
assert read(native/'editor-native-resume-results.json')['status']=='PASS'
original_results=read(work/'original-results.json');assert len(original_results['jobs'])==7 and all(j['status']=='completed' for j in original_results['jobs'])
for xml,total in [(native/'debug-storage-resume-full-Debug.xml',351),(native/'integration-native-full-Release.xml',351),(native/'integration-native-focused-Debug.xml',7),(native/'integration-native-focused-Release.xml',7),*((work/('linux-integrated-'+profile+'.xml'),7) for profile in ['Release','Debug','strict'])]:
 cases=ET.parse(xml).getroot().findall('.//testcase');assert len(cases)==total,xml
 assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None and c.attrib.get('status')!='notrun' for c in cases),xml
report=root/'docs/voidup/INTEGRATION_REPORT.md';assert '_PENDING' not in report.read_text().split('\n---\n',1)[0]
evidence.mkdir(parents=True,exist_ok=True)
source_paths=['src/runtime/host_windows.hpp','tests/host_capabilities/portable.cpp','tests/host_capabilities/portable.py','tests/host_capabilities/portable_source.py','tests/cli/install.py','tests/stage9/workflow.py','tools/test_platform.py','editors/vscode/src/test/config.test.ts','editors/vscode/src/test/runHost.ts']
untracked_sources=['tests/host_capabilities/staged_child.py','editors/vscode/src/test/download.ts']
patch=subprocess.check_output(['git','diff','--binary','--',*source_paths])
for name in untracked_sources:
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',name],capture_output=True);assert r.returncode==1;patch+=r.stdout
(evidence/'source.patch').write_bytes(patch)
(evidence/'documentation.patch').write_bytes(subprocess.check_output(['git','diff','--binary','--','docs/voidup/INTEGRATION_REPORT.md']))
def archive(name,members,scope):
 target=evidence/(name+'.tar.gz');records=[]
 with tarfile.open(target,'w:gz',compresslevel=3) as t:
  for relative,p in sorted(members):
   assert p.is_file() and not p.is_symlink();assert not relative.startswith('/') and '..' not in Path(relative).parts
   assert p.suffix.lower() not in ['.exe','.dll','.lib','.a','.obj','.pdb','.pem','.key']
   data=p.read_bytes();records.append({'path':relative,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});t.add(p,arcname=relative,recursive=False)
 index={'scope':scope,'archive':target.name,'bytes':target.stat().st_size,'sha256':sha(target),'files':records}
 (evidence/(name+'-index.json')).write_text(json.dumps(index,indent=2)+'\n')
artifact_metadata=read(work/'original/artifacts.json')['artifacts']
excluded_artifacts={str(a['id'])+'.zip':a for a in artifact_metadata if a['name'].startswith('void-editor-')}
(work/'excluded-editor-artifacts.json').write_text(json.dumps({'scope':'Built editor VSIX packages are retained in ignored original capture and on the original run, with verified hashes in original-results.json; excluded from permanent engineering evidence because they are binary release payloads, not failure diagnostics.','artifacts':list(excluded_artifacts.values())},indent=2)+'\n')
original=[('original/'+str(p.relative_to(work/'original')),p) for p in (work/'original').rglob('*') if p.is_file() and p.name not in excluded_artifacts]
original.append(('excluded-editor-artifacts.json',work/'excluded-editor-artifacts.json'))
original.append(('original-results.json',work/'original-results.json'))
archive('original-ci',original,'Unmodified hosted logs, metadata and diagnostic artifact ZIPs; all seven jobs individually reviewed. ZIP digests match GitHub metadata. Built editor VSIX artifact ZIPs are excluded with their metadata and original verified hashes retained.')
exclude={'candidate-source.patch','original-results.json','ROOT_PROGRESS.json','patch-reconstruction.json','delivery-verification.json','patch-dry-run.log','patch-apply.log'}
local=[('local/'+p.name,p) for p in work.iterdir() if p.is_file() and p.name not in exclude and p.suffix in ['.json','.xml','.log','.py','.cjs','.txt','.tgz']]
for p in native.rglob('*'):
 if p.is_file() and p.suffix.lower()!='.png' and 'second-volume' not in p.relative_to(native).parts:local.append(('native/'+str(p.relative_to(native)),p))
archive('local-verification',local,'Original standard-token failures, controlled cancellation, native reproductions, corrected full native suites, source/SDK/package verification and Linux focused checks. No executable payloads or private keys.')
source_paths.extend(untracked_sources)
records=sorted(source_paths+['docs/voidup/INTEGRATION_REPORT.md']+['docs/voidup/evidence/ci-42446206797/'+n for n in ['source.patch','documentation.patch','original-ci.tar.gz','original-ci-index.json','local-verification.tar.gz','local-verification-index.json','commit-paths.txt','commit-paths.nul','commit-inventory.json']])
(evidence/'commit-paths.txt').write_text('\n'.join(records)+'\n');(evidence/'commit-paths.nul').write_bytes(b''.join(n.encode()+b'\0' for n in records))
status=subprocess.check_output(['git','status','--porcelain=v1','-z','--untracked-files=all']).split(b'\0');pending=[x.decode()[3:] for x in status if x]
ignored=[]
for n in records:
 if subprocess.run(['git','check-ignore','-q','--',n]).returncode==0:ignored.append(n)
unexpected=sorted(set(pending)-set(records))
inventory={'baseline':'b8776526c83d6c5668490bad8c2c1fc7a35b1f0f','intended_count':len(records),'paths':records,'sha256':{n:sha(root/n) for n in records if not n.endswith('commit-inventory.json')},'ignored_but_intended':ignored,'unexpected_pending_paths_untouched':unexpected,'excluded':['build/ci-42446206797/ (disposable build, raw capture and reconstruction output; required evidence packed above)','.toolchains/ (unchanged pinned SDK/provider caches)','/home/shmellyorc/VM/ci-42446206797/ (external native working transport; required evidence packed above)','All VM executables, libraries, PDBs and private credentials; no binaries published'],'index_unchanged':True,'suggested_title':'Repair Windows CI executable staging and editor download cleanup [skip ci]','recommended_staging_command':'git --literal-pathspecs add -f --pathspec-from-file=docs/voidup/evidence/ci-42446206797/commit-paths.nul --pathspec-file-nul (RECOMMENDATION ONLY; NOT EXECUTED)'}
(evidence/'commit-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
print(json.dumps({'intended_count':len(records),'unexpected':unexpected,'ignored_but_intended':ignored},indent=2))
