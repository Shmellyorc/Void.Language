const fs=require('node:fs'), path=require('node:path'), os=require('node:os'), Module=require('node:module');
const {PassThrough}=require('node:stream'), cp=require('node:child_process'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const filename=path.resolve('editors/vscode/node_modules/@vscode/test-electron/out/download.js');
const mod=new Module(filename,module);mod.filename=filename;mod.paths=Module._nodeModulePaths(path.dirname(filename));
mod._compile(fs.readFileSync(filename,'utf8')+'\nexports.probe=unzipVSCode;\n',filename);
const {downloadEditor}=require(path.resolve('editors/vscode/out/test/download.js'));
const {SilentReporter,ProgressReportStage}=require(path.resolve('editors/vscode/node_modules/@vscode/test-electron'));
(async()=>{
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'VOID-editor-owned-'));const fixture=path.join(tmp,'fixture');fs.mkdirSync(path.join(fixture,'package'),{recursive:true});fs.writeFileSync(path.join(fixture,'package','payload'),'verified editor fixture');
 const archive=path.join(tmp,'fixture.tgz');cp.execFileSync('tar',['-czf',archive,'-C',fixture,'package']);const bytes=fs.readFileSync(archive),digest=crypto.createHash('sha256').update(bytes).digest('hex');
 let attempts=0;const extract=path.join(tmp,'extracted');
 try{
  const result=await downloadEditor(async options=>{
   ++attempts;fs.rmSync(extract,{recursive:true,force:true});
   const stream=attempts===1?new PassThrough():fs.createReadStream(archive);
   if(attempts===1)setTimeout(()=>stream.destroy(new Error('controlled real upstream input abort')),40);
   try{await mod.exports.probe(options.reporter,extract,'linux-x64',{format:'tgz',stream,length:attempts===1?1000:bytes.length,sha256:attempts===1?undefined:digest});return extract;}
   catch(error){options.reporter.report({stage:ProgressReportStage.Retrying,error,attempt:1,totalAttempts:3});throw error;}
  },new SilentReporter());
  assert.equal(attempts,2);assert.equal(fs.readFileSync(path.join(result,'payload'),'utf8'),'verified editor fixture');
  let badAttempts=0;
  await assert.rejects(downloadEditor(async options=>{
   ++badAttempts;fs.rmSync(extract,{recursive:true,force:true});
   try{await mod.exports.probe(options.reporter,extract,'linux-x64',{format:'tgz',stream:fs.createReadStream(archive),length:bytes.length,sha256:'0'.repeat(64)});throw new Error('Wrong checksum was admitted');}
   catch(error){assert.match(String(error),/checksum/i);options.reporter.report({stage:ProgressReportStage.Retrying,error,attempt:1,totalAttempts:3});throw error;}
  },new SilentReporter()),/checksum/i);
  assert.equal(badAttempts,3);
  console.log(JSON.stringify({result:'PASS',pinned_upstream:'@vscode/test-electron 3.1.0',real_tar_abort_retry_attempts:attempts,correct_payload:true,wrong_checksum_rejected_all_attempts:badAttempts,natural_parent_exit:true},null,2));
 }finally{fs.rmSync(tmp,{recursive:true,force:true});}
})().catch(error=>{console.error(error);process.exitCode=1;});
