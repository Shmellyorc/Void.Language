from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();work=root/'build/ci-42446206797';native=Path('/home/shmellyorc/VM/ci-42446206797')
expected={**json.loads((native/'final-source-hashes.json').read_text()),**json.loads((work/'editor-source-hashes.json').read_text())};assert len(expected)==9
tracked=[];untracked=[]
for name,digest in expected.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
 (tracked if subprocess.run(['git','ls-files','--error-unmatch','--',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0 else untracked).append(name)
patch=subprocess.check_output(['git','diff','--binary','--',*tracked])
for n in untracked:
 r=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null',n],capture_output=True);assert r.returncode==1;patch+=r.stdout
file=work/'candidate-complete-source.patch';file.write_bytes(patch);tree=work/'patch-reconstruction-complete';tree.mkdir(exist_ok=False)
for name in tracked:
 p=tree/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show','b8776526c83d6c5668490bad8c2c1fc7a35b1f0f:'+name]))
commands=[]
for label,extra in [('dry-run',['--dry-run']),('apply',[])]:
 args=['patch','--batch','-p1','--directory',str(tree),'--input',str(file),*extra];r=subprocess.run(args,capture_output=True);(work/('patch-complete-'+label+'.log')).write_bytes(r.stdout+r.stderr);commands.append({'argv':args,'status':r.returncode});assert r.returncode==0
actual={n:hashlib.sha256((tree/n).read_bytes()).hexdigest() for n in expected};assert actual==expected
(work/'patch-complete-reconstruction.json').write_text(json.dumps({'source_files':9,'patch_sha256':hashlib.sha256(patch).hexdigest(),'expected':expected,'actual':actual,'matched':True,'commands':commands},indent=2)+'\n');print('9-source baseline reconstruction PASS')
