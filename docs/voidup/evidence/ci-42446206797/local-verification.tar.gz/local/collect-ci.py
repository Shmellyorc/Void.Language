from pathlib import Path
import subprocess,json,time,traceback
out=Path(__file__).resolve().parent/'original';repo='repos/Shmellyorc/Void.Language';run='42446206797'
def api(route):return subprocess.check_output(['gh','api',repo+route])
def save_blob(route,path):
 data=api(route);path.write_bytes(data)
try:
 save_blob('/actions/runs/'+run,out/'run.json')
 while True:
  jobs=json.loads(api('/actions/runs/'+run+'/jobs?per_page=100'));(out/'jobs-latest.json').write_text(json.dumps(jobs,indent=2)+'\n')
  changed=False
  for j in jobs['jobs']:
   path=out/(str(j['id'])+'.log')
   if j['status']=='completed' and not path.exists():
    save_blob('/actions/jobs/'+str(j['id'])+'/logs',path);changed=True;print(j['name'],j['conclusion'],flush=True)
  if changed or all(j['status']=='completed' for j in jobs['jobs']):
   artifacts=json.loads(api('/actions/runs/'+run+'/artifacts?per_page=100'));(out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
   for a in artifacts['artifacts']:
    path=out/(str(a['id'])+'.zip')
    if not a['expired'] and not path.exists():save_blob('/actions/artifacts/'+str(a['id'])+'/zip',path)
  status={'status':'complete' if all(j['status']=='completed' for j in jobs['jobs']) else 'waiting','jobs':[{'name':j['name'],'id':j['id'],'status':j['status'],'conclusion':j['conclusion']} for j in jobs['jobs']]}
  (out.parent/'ci-collector.json').write_text(json.dumps(status,indent=2)+'\n')
  if status['status']=='complete':break
  time.sleep(60)
except BaseException:(out.parent/'ci-collector-error.txt').write_text(traceback.format_exc());raise
