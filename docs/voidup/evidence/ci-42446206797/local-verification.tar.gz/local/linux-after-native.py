from pathlib import Path
import subprocess,json,time,os,traceback
root=Path.cwd();out=root/'build/ci-42446206797';native=Path('/home/shmellyorc/VM/ci-42446206797/final-native-results.json')
r={'status':'waiting for serial Windows chain','commands':[]}
def save():(out/'linux-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args,env):
 r['stage']=label;save();t=time.monotonic()
 with (out/(label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
try:
 save()
 while not native.exists() or json.loads(native.read_text())['status']=='running':time.sleep(10)
 if json.loads(native.read_text())['status']!='PASS':raise RuntimeError('Native qualification did not pass; Linux builds were not started')
 r['status']='running';save()
 for profile,folder in [('Release','llvm23-release'),('Debug','llvm23-debug'),('strict','llvm23-strict')]:
  build=root/'build'/folder;env=dict(os.environ,CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1')
  if profile=='strict':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86')
  run('linux-build-'+profile,['cmake','--build',build,'--target','void_host_portable','voidc','voidls','voidup','--parallel','1'],env)
  run('linux-focused-'+profile,['ctest','--test-dir',build,'-R','^(host_capabilities_dependencies|host_capabilities_portable|host_capabilities_portable_source|cli_install|cli_install_resources|voidup_smoke)$','--output-on-failure','--output-junit',out/('linux-'+profile+'.xml')],env)
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
