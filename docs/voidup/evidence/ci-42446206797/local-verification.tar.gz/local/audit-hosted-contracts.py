from pathlib import Path
import zipfile,json,re,hashlib
w=Path(__file__).resolve().parent;p=w/'original';rows=[]
for a in json.loads((p/'artifacts.json').read_text())['artifacts']:
 if not a['name'].startswith('link-experiment-'):continue
 data=(p/(str(a['id'])+'.zip')).read_bytes();digest=hashlib.sha256(data).hexdigest();assert a['digest']=='sha256:'+digest
 with zipfile.ZipFile(p/(str(a['id'])+'.zip')) as z:
  row={'artifact':a['name'],'sha256':digest,'checks':{}}
  for name in z.namelist():
   if name.endswith(('sodium-properties.log','sodium-static-abi.log','test-suite.log','build-host-providers.json')):
    data=z.read(name);s=data.decode(errors='replace');entry={'path':name,'sha256':hashlib.sha256(data).hexdigest()}
    if name.endswith('sodium-properties.log'):
     d=json.loads(s);entry['properties']=d;entry['llvm_tools_version_23']=str(d.get('Properties',d).get('LLVMToolsVersion',''))=='23';assert entry['llvm_tools_version_23']
    elif name.endswith('sodium-static-abi.log'):
     entry['static_libcmt']=bool(re.search(r'DEFAULTLIB:["\']?libcmt',s,re.I));entry['dynamic_msvcrt']=bool(re.search(r'DEFAULTLIB:["\']?msvcrt',s,re.I));assert entry['static_libcmt'] and not entry['dynamic_msvcrt']
    elif name.endswith('test-suite.log'):
     entry['summary']=[x.strip() for x in s.splitlines() if re.search(r'^# (TOTAL|PASS|SKIP|XFAIL|FAIL|XPASS|ERROR):',x)]
     assert '# TOTAL: 87' in entry['summary'] and '# PASS:  87' in entry['summary']
    else:entry['record']=json.loads(s)
    row['checks'][name.rsplit('/',1)[-1]]=entry
  row['public_certificates_no_private_keys']=all(b'PRIVATE KEY' not in z.read(n) for n in z.namelist() if n.endswith(('.pem','.key')));assert row['public_certificates_no_private_keys'];rows.append(row)
assert len(rows)==7
(w/'hosted-contract-audit.json').write_text(json.dumps(rows,indent=2)+'\n');print('7 hosted profile artifacts: SDK/MSBuild, static ABI, upstream87-test results, certificate/key classification PASS as applicable')
