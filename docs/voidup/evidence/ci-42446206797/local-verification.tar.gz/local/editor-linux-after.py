from pathlib import Path
import subprocess,os,json,time,traceback,signal,hashlib
root=Path.cwd();out=root/'build/ci-42446206797';r={'status':'waiting for serial Linux qualification','commands':[]}
def save():(out/'editor-linux-results.json').write_text(json.dumps(r,indent=2)+'\n')
def read_progress():
 try:return json.loads((out/'linux-results.json').read_text())
 except (OSError,json.JSONDecodeError):return {'status':'waiting'}
try:
 save()
 while read_progress()['status'] not in ['PASS','FAIL']:time.sleep(10)
 assert read_progress()['status']=='PASS','Linux qualification failed; GUI test not started'
 r['status']='running';save()
 env=dict(os.environ,PATH='/home/shmellyorc/.nvm/versions/node/v24.19.0/bin'+os.pathsep+os.environ['PATH'],VOIDLS_PATH=str(root/'build/llvm23-debug/voidls'))
 for name in ['VSCODE_EXECUTABLE_PATH','VSCODE_CLI_PATH','VOID_TEST_VSIX','VOID_TEST_CDP_PORT']:env.pop(name,None)
 r['source_sha256']={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in json.loads((out/'editor-source-hashes.json').read_text())}
 assert r['source_sha256']==json.loads((out/'editor-source-hashes.json').read_text())
 r['node_version']=subprocess.check_output(['node','--version'],env=env,text=True).strip();assert r['node_version']=='v24.19.0'
 args=['npm','run','test:host'];r['stage']='real-editor';save();start=time.monotonic()
 with (out/'editor-linux-host.log').open('wb') as f:
  child=subprocess.Popen(args,cwd=root/'editors/vscode',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 r['commands'].append({'argv':args,'status':code,'seconds':time.monotonic()-start});save();assert code==0
 s=(out/'editor-linux-host.log').read_text(errors='replace');assert all('Editor test begins: '+mode in s for mode in ['trusted','untrusted','multi-root']);assert 'PASS real editor multi-root' in s
 r['scope']='Actual Linux native desktop (Xwayland), pinned Node24.19.0/editor1.141.0, existing Debug voidls; three modes and natural harness exit. Separate from native Ubuntu hosted acceptance.'
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
