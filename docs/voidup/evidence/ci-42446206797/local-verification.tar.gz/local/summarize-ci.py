from pathlib import Path
import json,re,hashlib,zipfile
out=Path(__file__).resolve().parent;original=out/'original';jobs=json.loads((original/'jobs-latest.json').read_text())['jobs'];rows=[]
for j in jobs:
 p=original/(str(j['id'])+'.log');row={'name':j['name'],'job_id':j['id'],'status':j['status'],'conclusion':j['conclusion'],'last_successful_step':next((s['name'] for s in reversed(j['steps']) if s['conclusion']=='success'),None)}
 failures=[s for s in j['steps'] if s['conclusion'] in ['failure','timed_out','cancelled']]
 row['first_failed_or_interrupted_step']=failures[0]['name'] if failures else None
 boundary=failures[0]['number'] if failures else 100000
 row['last_successful_before_failure']=next((s['name'] for s in reversed(j['steps']) if s['conclusion']=='success' and s['number']<boundary and not s['name'].startswith(('Post ','Preserve ','Save ')) and s['name']!='Complete job'),None)
 row['validation_steps']=[{'name':s['name'],'status':s['status'],'conclusion':s['conclusion']} for s in j['steps'] if s['name'].startswith(('Bootstrap and verify','Configure ','Build ','Execute ','Frontend ','Real editor','Verify native host'))]
 if p.exists():
  s=p.read_text(errors='replace');records=[]
  for m in re.finditer(r'\b(\d+)/(\d+)\s+Test\s+#\s*(\d+):\s+(\S+)\s+\.+\s*(.+?)\s+(\d+\.\d+) sec',s):
   records.append({'ordinal':int(m[1]),'registered':int(m[2]),'number':int(m[3]),'name':m[4],'result':m[5].strip(),'seconds':float(m[6])})
  if records:
   total=max(r['registered'] for r in records);full=[r for r in records if r['registered']==total]
   row.update(registered=total,observed=len(full),passed=sum(r['result']=='Passed' for r in full),failures=[r for r in full if r['result'] not in ['Passed','***Skipped']],skips=[r for r in full if r['result']=='***Skipped'],focused=[r for r in full if r['name'] in ['cli_install','cli_install_resources','host_capabilities_dependencies','host_capabilities_portable','host_capabilities_portable_source','voidup_smoke']])
  row['log_sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
 rows.append(row)
artifacts=[]
for a in json.loads((original/'artifacts.json').read_text())['artifacts']:
 p=original/(str(a['id'])+'.zip');h=hashlib.sha256(p.read_bytes()).hexdigest();assert a['digest']=='sha256:'+h
 artifacts.append({'name':a['name'],'id':a['id'],'sha256':h,'github_digest_matches':True})
(out/'original-results.json').write_text(json.dumps({'baseline':json.loads((original/'run.json').read_text())['head_sha'],'jobs':rows,'artifacts':artifacts},indent=2)+'\n')
for r in rows:print(r['name'],r['conclusion'],r.get('passed'),r.get('registered'),[x['name'] for x in r.get('failures',[])],[x['name'] for x in r.get('skips',[])])
