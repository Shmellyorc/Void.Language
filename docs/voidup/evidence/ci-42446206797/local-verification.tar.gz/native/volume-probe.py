from pathlib import Path
import json,os,subprocess,sys,shutil
out=Path(r"\\vboxsvr\VM\ci-42446206797");root=Path.home()/'VoidCI42377496702-Native';second=out/'second-volume';second.mkdir(exist_ok=True)
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_IO_SECOND_VOLUME=str(second),CTEST_PARALLEL_LEVEL='1')
destination=out/'standard-full-Release';destination.mkdir(exist_ok=True)
for n in ['Testing/Temporary/LastTest.log','Testing/Temporary/LastTestsFailed.log','host-capabilities-evidence/portable-Release.json','host-capabilities-evidence/portable-source-Release.json']:
 source=root/'build/Release'/n
 if source.exists():
  target=destination/n;target.parent.mkdir(parents=True,exist_ok=True)
  if not target.exists():shutil.copyfile(source,target)
command=['ctest','--test-dir',str(root/'build/Release'),'-R','^io_cross_volume$','--output-on-failure','--output-junit',str(out/'volume-probe.xml')]
with (out/'volume-probe.log').open('wb') as f:r=subprocess.run(command,env=env,cwd=root,stdout=f,stderr=subprocess.STDOUT)
(out/'volume-probe.json').write_text(json.dumps({'command':command,'status':r.returncode,'primary_device':root.stat().st_dev,'secondary_device':second.stat().st_dev,'secondary':str(second)},indent=2)+'\n')
