from pathlib import Path
import json,os,sys,subprocess,hashlib,traceback,time
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[],'correction':'Existing VOIDLS_TEST_SERVER supplies actual built Debug LSP to copied project. Original missing-default-path failure retained; no repository source changed.'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():(out/'editor-native-resume-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args,env,project):
 r['stage']=label;save();start=time.monotonic()
 with (out/('editor-native-resume-'+label+'.log')).open('wb') as log:
  child=subprocess.Popen(list(map(str,args)),cwd=project,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:code=child.wait(timeout=1800)
  except subprocess.TimeoutExpired:
   subprocess.run([r'C:\Windows\System32\taskkill.exe','/T','/F','/PID',str(child.pid)],stdout=log,stderr=subprocess.STDOUT);child.wait();raise
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':code,'seconds':time.monotonic()-start});save();assert code==0,(label,code)
try:
 save();previous=json.loads((out/'editor-native-initial-context-results.json').read_text());assert previous['commands'][0]['status']==0
 tools=root/'build/ci-42446206797-editor-tools';node=tools/'node-v24.19.0-win-x64/node.exe';npm=node.parent/'node_modules/npm/bin/npm-cli.js'
 assert sha(node)==previous['actual_node_sha256'];project=root/'build/ci-42446206797-editor-root/editors/vscode'
 manifest=json.loads((out/'editor-project-source.json').read_text());assert all(sha(project/n)==digest for n,digest in manifest['files'].items())
 env=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH'],TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOIDLS_TEST_SERVER=str(root/'build/Debug/voidls.exe'),VOIDLS_PATH=str(root/'build/Debug/voidls.exe'))
 for name in ['VSCODE_EXECUTABLE_PATH','VSCODE_CLI_PATH','VOID_TEST_VSIX','VOID_TEST_CDP_PORT']:env.pop(name,None)
 r['actual_lsp']={'path':env['VOIDLS_TEST_SERVER'],'sha256':sha(root/'build/Debug/voidls.exe')};r['node_identity']=previous['node_identity'];r['actual_node_sha256']=sha(node);r['source_files']=manifest['files'];save()
 run('unit',[node,npm,'test'],env,project)
 text=(out/'editor-native-resume-unit.log').read_text(errors='replace');assert 'tests 6' in text and 'fail 0' in text
 run('host',[node,npm,'run','test:host'],env,project)
 text=(out/'editor-native-resume-host.log').read_text(errors='replace');assert all('Editor test begins: '+mode in text for mode in ['trusted','untrusted','multi-root']);assert 'PASS real editor multi-root' in text
 run('package',[node,npm,'run','package'],env,project)
 artifact=project/'dist/void-language-0.1.0.vsix';assert artifact.is_file();r['local_vsix']={'bytes':artifact.stat().st_size,'sha256':sha(artifact),'published':False}
 assert all(sha(project/n)==digest for n,digest in manifest['files'].items()),'Source/lockfile changed'
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
if r['status']=='PASS':
 prior=json.loads((out/'audit-initial-editor-context-results.json').read_text());core=[c for c in prior['commands'] if c['label']!='editor-native'];assert all(c['status']==0 for c in core)
 (out/'audit-final-results.json').write_text(json.dumps({'status':'PASS','core_record':'audit-initial-editor-context-results.json','core_commands':core,'editor_record':'editor-native-resume-results.json','original_context_failure_retained':True,'source_unchanged':True},indent=2)+'\n')
sys.exit(0 if r['status']=='PASS' else 1)
