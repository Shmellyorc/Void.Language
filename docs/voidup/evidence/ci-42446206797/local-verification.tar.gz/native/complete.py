from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'complete-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('complete-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 # Preserve failures and continue independent profile checks.
try:
 while json.loads((out/'repair-results.json').read_text())['status']=='running':time.sleep(5)
 for n in ['src/runtime/host_windows.hpp', 'tests/host_capabilities/portable.cpp', 'tests/host_capabilities/portable.py', 'tests/host_capabilities/portable_source.py', 'tests/host_capabilities/staged_child.py']:
  target=root/n;backup=out/'before'/n;backup.parent.mkdir(parents=True,exist_ok=True)
  if target.exists() and not backup.exists():shutil.copy2(target,backup)
  shutil.copyfile(out/'final-source'/n,target)

 run('resource-tests',[sys.executable,root/'tests/cli/install_resources.py'])
 for profile in ['Release','Debug']:
  run('build-all-'+profile,['cmake','--build',root/'build'/profile,'--parallel','1'])
  run('receipts-'+profile,[sys.executable,root/'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'])
  run('descriptor-'+profile,[root/'build'/profile/'void_host_portable.exe','--server-descriptor'])
  run('full-'+profile,['ctest','--test-dir',root/'build'/profile,'--output-on-failure','--output-junit',out/('complete-'+profile+'.xml')])

 hashes={n:__import__('hashlib').sha256((root/n).read_bytes()).hexdigest() for n in ['src/runtime/host_windows.hpp', 'tests/host_capabilities/portable.cpp', 'tests/host_capabilities/portable.py', 'tests/host_capabilities/portable_source.py', 'tests/host_capabilities/staged_child.py']}
 (out/'guest-final-source-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
