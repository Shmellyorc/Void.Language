from pathlib import Path
import ast,ctypes,hashlib,json,os,shutil,threading,time,tempfile,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native'
name='tests/cli/install.py';target=root/name;backup=out/'before'/name;backup.parent.mkdir(parents=True,exist_ok=True)
if not backup.exists():shutil.copyfile(target,backup)
shutil.copyfile(out/'final-source'/name,target)
record={'scope':'Actual Windows held-child regression against the real test helper; no mocked rename','source_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'administrator':bool(ctypes.windll.shell32.IsUserAnAdmin())}
k=ctypes.WinDLL('kernel32',use_last_error=True);k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p];k.CreateFileW.restype=ctypes.c_void_p;k.CloseHandle.argtypes=[ctypes.c_void_p]
try:
 function=next(n for n in ast.parse(target.read_bytes()).body if isinstance(n,ast.FunctionDef) and n.name=='relocate')
 scope={'os':os,'time':time};exec(compile(ast.Module(body=[function],type_ignores=[]),str(target),'exec'),scope);relocate=scope['relocate']
 with tempfile.TemporaryDirectory(prefix='relocate-controls-',dir=root/'native-private-temp') as folder:
  base=Path(folder)
  def fixture(name):
   before=base/name;before.mkdir();file=before/'held';file.write_bytes(b'identity preserved')
   handle=k.CreateFileW(str(file),0x80000000,3,None,3,0,None);assert handle!=ctypes.c_void_p(-1).value
   return before,file,handle
  before,file,handle=fixture('temporary');identity=(before.stat().st_dev,before.stat().st_ino)
  timer=threading.Timer(.15,lambda:k.CloseHandle(handle));timer.start();started=time.monotonic()
  try:relocate(before,base/'temporary-after')
  finally:timer.join()
  after=base/'temporary-after';assert (after.stat().st_dev,after.stat().st_ino)==identity and (after/'held').read_bytes()==b'identity preserved'
  record['temporary_child']={'result':'PASS','seconds':time.monotonic()-started,'identity_preserved':True}
  before,file,handle=fixture('persistent');identity=(before.stat().st_dev,before.stat().st_ino);started=time.monotonic()
  try:
   try:relocate(before,base/'persistent-after');raise AssertionError('Persistent denial accepted')
   except PermissionError as error:assert error.winerror==5;record['persistent_child']={'native_error':error.winerror,'seconds':time.monotonic()-started}
  finally:k.CloseHandle(handle)
  assert before.is_dir() and not (base/'persistent-after').exists() and (before.stat().st_dev,before.stat().st_ino)==identity and file.read_bytes()==b'identity preserved'
  record['persistent_child']['no_mutation']=True
  try:relocate(base/'missing',base/'must-not-exist');raise AssertionError('Missing source accepted')
  except FileNotFoundError as error:assert error.winerror==2;record['missing_source']={'native_error':error.winerror}
 record['status']='PASS'
except BaseException:record.update(status='FAIL',error=traceback.format_exc())
(out/'relocate-controls.json').write_text(json.dumps(record,indent=2)+'\n')
