from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'repair-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('repair-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 # Preserve failures and continue independent profile checks.
try:
 for n in ['src/runtime/host_windows.hpp', 'tests/host_capabilities/portable.cpp', 'tests/host_capabilities/portable.py', 'tests/host_capabilities/portable_source.py', 'tests/host_capabilities/staged_child.py']:
  target=root/n;backup=out/'before'/n;backup.parent.mkdir(parents=True,exist_ok=True)
  if target.exists() and not backup.exists():shutil.copy2(target,backup)
  shutil.copyfile(out/'source'/n,target)

 run('resource-tests',[sys.executable,root/'tests/cli/install_resources.py'])
 for profile in ['Release','Debug']:
  run('build-portable-'+profile,['cmake','--build',root/'build'/profile,'--target','void_host_portable','voidc','voidls','voidup','--parallel','1'])
  run('descriptor-'+profile,[root/'build'/profile/'void_host_portable.exe','--server-descriptor'])
  run('focused-'+profile,['ctest','--test-dir',root/'build'/profile,'-R','^(cli_install|cli_install_resources|host_capabilities_portable|host_capabilities_portable_source|voidup_smoke)$','--output-on-failure','--output-junit',out/('repair-'+profile+'.xml')])

 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
