@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\symlink-probe.py" standard Release > "\\vboxsvr\VM\ci-42446206797\symlink-probe-standard-console.log" 2>&1
