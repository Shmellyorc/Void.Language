@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42446206797\pre-elevation-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\pre-elevation.py" > "\\vboxsvr\VM\ci-42446206797\pre-elevation-console.log" 2>&1
