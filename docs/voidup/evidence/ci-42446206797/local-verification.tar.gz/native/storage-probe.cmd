@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\storage-probe.py" > "\\vboxsvr\VM\ci-42446206797\storage-probe-console.log" 2>&1
