@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42446206797\debug-storage-resume-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\debug-storage-resume.py" > "\\vboxsvr\VM\ci-42446206797\debug-storage-resume-console.log" 2>&1
