from pathlib import Path
import hashlib,json,os,shutil,subprocess,time,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';p=root/'build/Debug/void_tests.pdb';r={'disk_before':shutil.disk_usage('C:\\')._asdict()}
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
try:
 r['pdb_path']=str(p);r['sha256_before']=digest(p)
 command=[r'C:\Windows\System32\compact.exe','/c','/f','/exe:LZX','/q',str(p)];start=time.monotonic();v=subprocess.run(command,capture_output=True,timeout=180)
 r['probe']={'command':command,'status':v.returncode,'stdout':v.stdout.decode(errors='replace'),'stderr':v.stderr.decode(errors='replace'),'seconds':time.monotonic()-start};r['sha256_after']=digest(p);assert r['sha256_after']==r['sha256_before']
 sizes={}
 for folder in [root/'.toolchains',root/'native-private-temp']:
  for first in folder.iterdir():
   total=0;count=0
   if first.is_symlink() or first.is_junction():sizes[str(first)]={'junction_or_symlink':True};continue
   if first.is_file():total=first.stat().st_size;count=1
   elif first.is_dir():
    for current,dirs,files in os.walk(first,followlinks=False):
     dirs[:]=[n for n in dirs if not (Path(current)/n).is_junction() and not (Path(current)/n).is_symlink()]
     for name in files:
      file=Path(current)/name
      if not file.is_symlink():total+=file.stat().st_size;count+=1
   sizes[str(first)]={'logical_bytes':total,'files':count}
 r['disposable_workspace_sizes']=sizes;r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:r['disk_after']=shutil.disk_usage('C:\\')._asdict();(out/'storage-lzx-probe.json').write_text(json.dumps(r,indent=2)+'\n')
