from pathlib import Path
import ctypes,hashlib,json,os,shutil,subprocess,time,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';build=root/'build/Debug'
r={'status':'running','scope':'Transparent NTFS compression of this disposable Debug build only; SDK, source, ACLs and compiler/debug flags unchanged','disk_before':shutil.disk_usage('C:\\')._asdict(),'files':[],'commands':[]}
def save():(out/'compression-results.json').write_text(json.dumps(r,indent=2)+'\n')
def digest(path):
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetCompressedFileSizeW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_uint32)];k.GetCompressedFileSizeW.restype=ctypes.c_uint32
k.SetLastError.argtypes=[ctypes.c_uint32]
def allocated(path):
 high=ctypes.c_uint32();ctypes.set_last_error(0);low=k.GetCompressedFileSizeW(str(path),ctypes.byref(high))
 if low==0xffffffff and ctypes.get_last_error():raise ctypes.WinError(ctypes.get_last_error())
 return (high.value<<32)|low
def run(label,args):
 r['stage']=label;save()
 with (out/('compression-'+label+'.log')).open('wb') as f:p=subprocess.run(args,cwd=build,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'command':args,'status':p.returncode});save();assert p.returncode==0
try:
 assert build.resolve()==root/'build/Debug' and not build.is_symlink() and not build.is_junction()
 r['stage']='hash-original-pdbs';save()
 for p in sorted(build.rglob('*.pdb')):
  assert not p.is_symlink() and p.stat().st_nlink==1
  r['files'].append({'path':str(p.relative_to(build)),'bytes':p.stat().st_size,'allocated_before':allocated(p),'sha256':digest(p),'identity_before':[p.stat().st_dev,p.stat().st_ino]})
  save()
 compact=r'C:\Windows\System32\compact.exe'
 run('mark-generated-directory',[compact,'/c','/q',str(build)])
 run('compress-pdbs',[compact,'/c','/s:'+str(build),'/q','*.pdb'])
 r['stage']='verify-identical-bytes';save()
 for item in r['files']:
  p=build/item['path'];item['sha256_after']=digest(p);item['allocated_after']=allocated(p);item['identity_after']=[p.stat().st_dev,p.stat().st_ino]
  assert item['sha256']==item['sha256_after'] and item['identity_before']==item['identity_after'];save()
 r['disk_after']=shutil.disk_usage('C:\\')._asdict();r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc();r['disk_after']=shutil.disk_usage('C:\\')._asdict()
finally:save()
