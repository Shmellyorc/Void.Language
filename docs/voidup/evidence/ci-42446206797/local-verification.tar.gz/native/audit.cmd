@echo off
set "TMP=C:\Users\a\VoidCI42377496702-Native\native-private-temp"
set "TEMP=%TMP%"
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42446206797\audit-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\audit.py" > "\\vboxsvr\VM\ci-42446206797\audit-console.log" 2>&1
