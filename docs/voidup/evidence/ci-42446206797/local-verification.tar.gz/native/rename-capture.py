from pathlib import Path
import ctypes,json,os,subprocess,tempfile,time,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native'
os.environ['TMP']=os.environ['TEMP']=str(root/'native-private-temp');tempfile.tempdir=None
record={'scope':'Exact immediate fresh-install rename, before diagnostics or shared-log writes; bounded diagnostic retries only, no production changes','administrator':bool(ctypes.windll.shell32.IsUserAnAdmin()),'iterations':[]}
k=ctypes.WinDLL('kernel32',use_last_error=True);a=ctypes.WinDLL('advapi32',use_last_error=True)
k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p];k.CreateFileW.restype=ctypes.c_void_p;k.CloseHandle.argtypes=[ctypes.c_void_p];k.LocalFree.argtypes=[ctypes.c_void_p]
a.GetNamedSecurityInfoW.argtypes=[ctypes.c_wchar_p,ctypes.c_int,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p)];a.GetNamedSecurityInfoW.restype=ctypes.c_uint32
a.ConvertSecurityDescriptorToStringSecurityDescriptorW.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p),ctypes.c_void_p]
def access(path):
 h=k.CreateFileW(str(path),0x10000|0x80|0x20000,7,None,3,0x02000000,None)
 error=ctypes.get_last_error() if h==ctypes.c_void_p(-1).value else 0
 if not error:k.CloseHandle(h)
 return error
def security(path):
 raw=ctypes.c_void_p();status=a.GetNamedSecurityInfoW(str(path),1,5,None,None,None,None,ctypes.byref(raw))
 if status:return {'query_error':status}
 try:
  text=ctypes.c_void_p()
  if not a.ConvertSecurityDescriptorToStringSecurityDescriptorW(raw,1,5,ctypes.byref(text),None):return {'convert_error':ctypes.get_last_error()}
  try:return {'sddl':ctypes.wstring_at(text)}
  finally:k.LocalFree(text)
 finally:k.LocalFree(raw)
try:
 assert record['administrator']
 # Control: an owned child handle without delete sharing, never a real drive ACL.
 with tempfile.TemporaryDirectory(prefix='rename-held-child-') as folder:
  parent=Path(folder);before=parent/'before';before.mkdir();file=before/'held';file.write_bytes(b'held')
  h=k.CreateFileW(str(file),0x80000000,3,None,3,0,None);assert h!=ctypes.c_void_p(-1).value
  try:
   control={'directory_delete_open':access(before),'child_delete_open':access(file)}
   try:before.rename(parent/'after');control['rename_while_child_held']='PASS'
   except OSError as e:control['rename_error']=e.winerror
  finally:k.CloseHandle(h)
  if before.exists():before.rename(parent/'after')
  control['relocated_after_child_close']=(parent/'after').is_dir();record['held_child_control']=control
 for i in range(5):
  entry={'iteration':i};record['iterations'].append(entry);logs=[]
  with tempfile.TemporaryDirectory(prefix='VOID CLI installation é ') as folder:
   before=Path(folder)/'before move';after=Path(folder)/'after move 雪'
   for component in ['compiler','tooling']:
    r=subprocess.run(['cmake','--install',str(root/'build/Release'),'--prefix',str(before),'--config','Release','--component',component],capture_output=True,timeout=180)
    logs.append((component,r.stdout+r.stderr));assert r.returncode==0
   started=time.monotonic()
   try:before.rename(after);entry['immediate_rename']='PASS'
   except OSError as e:
    entry.update(immediate_rename='FAIL',native_error=e.winerror,error=str(e),directory_delete_open=access(before))
    # Prioritize executable sharing state before slower descriptor inspection.
    candidates=[before/'bin/voidc.exe',before/'bin/voidls.exe']
    entry['child_delete_open']={str(p.relative_to(before)):access(p) for p in candidates if p.exists()}
    entry['directory_security']=security(before);entry['parent_security']=security(Path(folder))
    entry['retries']=[]
    for delay in [0,.01,.025,.05,.1,.2,.5]:
     time.sleep(delay)
     try:before.rename(after);entry['retries'].append({'after_seconds':time.monotonic()-started,'result':'PASS'});break
     except OSError as error:entry['retries'].append({'after_seconds':time.monotonic()-started,'error':error.winerror})
   entry['relocated']=after.is_dir();entry['seconds']=time.monotonic()-started
   for component,data in logs:(out/('rename-capture-'+str(i)+'-'+component+'.log')).write_bytes(data)
   (out/'rename-capture.json').write_text(json.dumps(record,indent=2)+'\n')
except BaseException:record['error']=traceback.format_exc()
finally:(out/'rename-capture.json').write_text(json.dumps(record,indent=2)+'\n')
