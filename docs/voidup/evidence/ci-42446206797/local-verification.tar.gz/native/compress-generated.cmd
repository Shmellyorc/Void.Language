@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\compress-generated.py" > "\\vboxsvr\VM\ci-42446206797\compression-console.log" 2>&1
