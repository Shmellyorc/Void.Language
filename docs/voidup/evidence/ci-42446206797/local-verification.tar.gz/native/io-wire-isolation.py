from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,tarfile,tempfile,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';record={'scope':'Preserve and isolate only known generated IO AOT fixtures; no production or assertion change','administrator':bool(ctypes.windll.shell32.IsUserAnAdmin()),'directories':[],'fresh_executions':[]}
allowed={'little.bin','big.bin','bad.txt','one.txt','two.txt','link.txt','tree/a.txt','tree/nested/b.bin','copy/a.txt','copy/nested/b.bin','moved/a.txt','moved/nested/b.bin'}
directories={'tree','tree/nested','copy','copy/nested','moved','moved/nested','empty'}
try:
 assert record['administrator']
 for mode in ['normal','optimized']:
  binary=root/'build/Release'/('void_io_wire_'+mode+'.exe')
  with tempfile.TemporaryDirectory(prefix='io-wire-fresh-',dir=root/'native-private-temp') as folder:
   r=subprocess.run([str(binary),'7'],cwd=folder,capture_output=True,timeout=180)
   item={'mode':mode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'status':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')};record['fresh_executions'].append(item)
   assert r.returncode==0 and r.stdout.strip()==b'7',item
 for profile in ['Release','Debug']:
  for mode in ['normal','optimized']:
   work=root/'build'/profile/('io wire '+mode)
   assert work.resolve().parent==(root/'build'/profile).resolve() and not work.is_symlink() and not work.is_junction()
   entries=[]
   for p in sorted(work.rglob('*')):
    name=p.relative_to(work).as_posix();item={'path':name,'device':p.lstat().st_dev,'inode':p.lstat().st_ino}
    if p.is_symlink():assert name=='link.txt';item.update(kind='symlink',target=os.readlink(p))
    elif p.is_dir():assert name in directories and not p.is_junction();item['kind']='directory'
    else:assert name in allowed and p.stat().st_size<1048576;item.update(kind='file',bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    entries.append(item)
   item={'profile':profile,'mode':mode,'entries':entries};record['directories'].append(item)
   if entries:
    archive=out/('io-wire-stale-'+profile+'-'+mode+'.tar.gz')
    with tarfile.open(archive,'w:gz') as t:t.add(work,arcname='io wire '+mode)
    saved=root/'build/ci-42446206797-stale-io-wire'/(profile+'-'+mode);saved.parent.mkdir(exist_ok=True);assert not saved.exists()
    work.rename(saved);work.mkdir();item.update(preserved_native_directory=str(saved),archive=archive.name,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),fresh_working_directory_created=True)
 record['status']='PASS'
except BaseException:record.update(status='FAIL',error=traceback.format_exc())
(out/'io-wire-isolation.json').write_text(json.dumps(record,indent=2)+'\n');sys.exit(0 if record['status']=='PASS' else 1)
