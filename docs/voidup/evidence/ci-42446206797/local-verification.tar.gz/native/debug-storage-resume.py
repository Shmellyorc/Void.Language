from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'debug-storage-resume-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('debug-storage-resume-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 return p.returncode
 # Preserve failures and continue independent profile checks.
def digest(path):
 import hashlib
 with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
try:
 import ctypes
 r['administrator']=bool(ctypes.windll.shell32.IsUserAnAdmin());assert r['administrator']
 assert json.loads((out/'compression-results.json').read_text())['status']=='PASS'
 r['disk_before']=shutil.disk_usage(root)._asdict();r['symbol_storage']=[];save()
 build=root/'build/Debug';env['VOID_IO_SECOND_VOLUME']=str(out/'second-volume')
 cache={}
 for line in (build/'CMakeCache.txt').read_text().splitlines():
  if not line.startswith(('#','//')) and ':' in line and '=' in line:
   key,value=line.split('=',1);cache[key.split(':',1)[0]]=value
 inventory=subprocess.run([cache['CMAKE_MAKE_PROGRAM'],'-C',str(build),'-t','targets','all'],capture_output=True,env=env,check=True)
 (out/'debug-native-targets.txt').write_bytes(inventory.stdout)
 targets=[]
 for line in inventory.stdout.decode(errors='strict').splitlines():
  if ': ' in line:
   name,rule=line.rsplit(': ',1)
   if rule.startswith('CXX_EXECUTABLE_LINKER') and name.endswith('.exe'):targets.append(name)
 r['executable_targets']=targets;save()
 for number,name in enumerate(targets):
  label='target-'+str(number)
  assert run(label,['cmake','--build',build,'--target',name,'--parallel','1'])==0
  pdb=(build/name).with_suffix('.pdb')
  if pdb.is_file():
   before=digest(pdb)
   assert run('symbols-'+str(number),[r'C:\Windows\System32\compact.exe','/c','/f','/exe:LZX','/q',pdb])==0
   after=digest(pdb);assert before==after
   r['symbol_storage'].append({'path':str(pdb.relative_to(build)),'sha256_before':before,'sha256_after':after,'free_bytes':shutil.disk_usage(root).free});save()
 assert run('build-all-Debug',['cmake','--build',build,'--parallel','1'])==0
 assert run('receipts-Debug',[sys.executable,root/'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64/Debug','--profile','Debug','--platform','Windows','--architecture','x86_64'])==0
 assert run('symlink-native-code-Debug',[sys.executable,out/'symlink-probe.py','elevated-Debug','Debug'])==0
 run('full-Debug',['ctest','--test-dir',build,'--output-on-failure','--output-junit',out/'debug-storage-resume-full-Debug.xml'])
 r['disk_after']=shutil.disk_usage(root)._asdict()
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
