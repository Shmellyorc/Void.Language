from pathlib import Path
import json,hashlib
out=Path(r"\\vboxsvr\VM\ci-42446206797");root=Path.home()/'VoidCI42377496702-Native'
expected=json.loads((out/'expected-all-source-hashes-revised.json').read_text());actual={n:hashlib.sha256((root/n).read_bytes()).hexdigest() if (root/n).is_file() else None for n in expected}
record={'expected_file':'expected-all-source-hashes-revised.json','count':len(expected),'matched':actual==expected,'differences':{n:{'expected':d,'actual':actual[n]} for n,d in expected.items() if actual[n]!=d},'actual':actual}
(out/'all-source-comparison-final.json').write_text(json.dumps(record,indent=2)+'\n')
