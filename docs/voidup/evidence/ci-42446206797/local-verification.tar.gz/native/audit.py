from pathlib import Path
import json,os,subprocess,sys,time,hashlib,platform,shutil,traceback,re
out=Path(r"\\vboxsvr\VM\ci-42446206797");root=Path.home()/'VoidCI42377496702-Native';sdk=(root/'.toolchains/llvm-23.1.4').resolve()
r={'status':'running','platform':platform.platform(),'windows_version':platform.win32_ver(),'environment':{k:os.environ.get(k) for k in ['WindowsSDKVersion','VCToolsVersion','VSCMD_ARG_TGT_ARCH']},'commands':[]}
def save():(out/'audit-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save()
 with (out/('audit-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode});save()
try:
 expected=json.loads((out/'expected-source-hashes-revised.json').read_text());actual={n:hashlib.sha256((root/n).read_bytes()).hexdigest() if (root/n).is_file() else None for n in expected}
 (out/'native-source-comparison.json').write_text(json.dumps({'expected':expected,'actual':actual,'matched':actual==expected},indent=2)+'\n')
 assert actual==expected,[(n,actual[n],d) for n,d in expected.items() if actual[n]!=d]
 run('all-source-inputs',[sys.executable,out/'source-audit-revised.py'])
 assert json.loads((out/'all-source-comparison-final.json').read_text())['matched'],'Final source/test/tool input mismatch'
 sys.path.insert(0,str(root/'tools'))
 from ci.llvm_sdk import windows_clangcl
 (out/'native-sdk-selection.json').write_text(json.dumps(windows_clangcl(sdk),indent=2)+'\n')
 r['cache_selection']={}
 for profile in ['Release','Debug']:
  cache={}
  for line in (root/'build'/profile/'CMakeCache.txt').read_text().splitlines():
   if not line.startswith(('#','//')) and ':' in line and '=' in line:
    key,value=line.split('=',1);cache[key.split(':',1)[0]]=value
  keys=['CMAKE_BUILD_TYPE','CMAKE_GENERATOR','CMAKE_CXX_FLAGS','CMAKE_CXX_FLAGS_RELEASE','CMAKE_CXX_FLAGS_DEBUG','CMAKE_EXE_LINKER_FLAGS','CMAKE_INTERPROCEDURAL_OPTIMIZATION','CMAKE_C_COMPILER','CMAKE_CXX_COMPILER','CMAKE_LINKER','CMAKE_AR','CMAKE_C_COMPILER_AR','CMAKE_CXX_COMPILER_AR','CMAKE_MSVC_RUNTIME_LIBRARY','LLVM_DIR','VOID_HOST_DEPS_ROOT','VOID_HTTP_DEPS_ROOT','VOID_SANITIZERS']
  r['cache_selection'][profile]={k:cache.get(k) for k in keys}
  assert cache['CMAKE_BUILD_TYPE']==profile
  assert Path(cache['CMAKE_CXX_COMPILER']).resolve()==(sdk/'bin/clang-cl.exe').resolve()
  save()
  run('static-ABI-'+profile,[sdk/'bin/llvm-readobj.exe','--coff-directives',root/'.toolchains/host/prefix/windows-x86_64'/profile/'lib/libsodium.lib'])
  abi=(out/('audit-static-ABI-'+profile+'.log')).read_text(errors='replace')
  assert re.search(r'DEFAULTLIB:["\']?libcmt',abi,re.I),'Missing actual static libcmt ABI'
  assert not re.search(r'DEFAULTLIB:["\']?msvcrt',abi,re.I),'Unexpected dynamic CRT ABI'
  for name in ['voidc','void_host_portable','voidup/voidup']:
   run('PE-'+profile+'-'+name.replace('/','-'),[sdk/'bin/llvm-readobj.exe','--file-headers','--coff-imports',root/'build'/profile/(name+'.exe')])
  evidence=out/('final-'+profile);evidence.mkdir(exist_ok=True)
  for n in ['host-capabilities-evidence/portable-'+profile+'.json','host-capabilities-evidence/portable-source-'+profile+'.json','Testing/Temporary/LastTest.log','Testing/Temporary/LastTestsFailed.log']:
   source=root/'build'/profile/n
   if source.exists():target=evidence/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 run('corresponding-source-package',[sys.executable,out/'package-check.py'])
 run('editor-native',[sys.executable,out/'editor-native.py'])
 assert json.loads((out/'editor-native-results.json').read_text())['status']=='PASS','Native editor verification failed'
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
