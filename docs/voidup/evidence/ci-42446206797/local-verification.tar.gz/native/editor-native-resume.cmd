@echo off
set "TMP=C:\Users\a\VoidCI42377496702-Native\native-private-temp"
set "TEMP=%TMP%"
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\editor-native-resume.py" > "\\vboxsvr\VM\ci-42446206797\editor-native-resume-console.log" 2>&1
