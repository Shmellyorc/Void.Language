from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'final-native-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('final-native-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 return p.returncode
 # Preserve failures and continue independent profile checks.
def previous_result():
 for attempt in range(20):
  try:return json.loads((out/'debug-storage-resume-results.json').read_text())
  except (OSError,json.JSONDecodeError):time.sleep(.05)
 raise RuntimeError('Native progress record could not be read consistently')
try:
 import ctypes
 r['administrator']=bool(ctypes.windll.shell32.IsUserAnAdmin());save();assert r['administrator']
 while previous_result()['status']=='running':time.sleep(10)
 previous=previous_result()
 assert 'error' not in previous,'Interrupted prior chain; do not start another build'
 debug=[c for c in previous['commands'] if c['label'] in ['build-all-Debug','receipts-Debug','full-Debug']]
 r['qualified_debug_commands']=debug;save()
 assert len(debug)==3 and all(c['status']==0 for c in debug),'Debug requires repair before final Release qualification'
 env['VOID_IO_SECOND_VOLUME']=str(out/'second-volume')
 assert run('build-all-Release',['cmake','--build',root/'build/Release','--parallel','1'])==0
 assert run('receipts-Release',[sys.executable,root/'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64/Release','--profile','Release','--platform','Windows','--architecture','x86_64'])==0
 run('full-Release',['ctest','--test-dir',root/'build/Release','--output-on-failure','--output-junit',out/'final-native-Release.xml'])
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
