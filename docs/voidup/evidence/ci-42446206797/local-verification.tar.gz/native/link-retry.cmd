@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 > "\\vboxsvr\VM\ci-42446206797\link-retry-vcvars.log" 2>&1
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\link-retry.py" > "\\vboxsvr\VM\ci-42446206797\link-retry-console.log" 2>&1
