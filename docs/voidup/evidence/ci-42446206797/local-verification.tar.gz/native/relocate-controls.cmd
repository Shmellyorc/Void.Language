@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\relocate-controls.py" > "\\vboxsvr\VM\ci-42446206797\relocate-controls.log" 2>&1
