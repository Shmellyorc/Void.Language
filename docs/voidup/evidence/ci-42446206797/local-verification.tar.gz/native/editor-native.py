from pathlib import Path,PurePosixPath
import json,os,sys,subprocess,urllib.request,zipfile,hashlib,traceback,time,shutil
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native'
r={'status':'running','commands':[],'scope':'Actual Windows Node and editor tests matching existing selected CI pins; portable tools in disposable build tree.'}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():(out/'editor-native-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args,env,cwd,timeout=1800):
 r['stage']=label;save();start=time.monotonic()
 with (out/('editor-native-'+label+'.log')).open('wb') as log:
  child=subprocess.Popen(list(map(str,args)),cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   subprocess.run([r'C:\Windows\System32\taskkill.exe','/T','/F','/PID',str(child.pid)],stdout=log,stderr=subprocess.STDOUT);child.wait();raise
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':code,'seconds':time.monotonic()-start});save();assert code==0,(label,code)
try:
 save();tools=root/'build/ci-42446206797-editor-tools';tools.mkdir(exist_ok=False)
 identity=json.loads((out/'editor-node-identity.json').read_text());archive=tools/'node.zip';r['node_identity']=identity;save()
 with urllib.request.urlopen(identity['archive_url'],timeout=60) as response,archive.open('wb') as f:shutil.copyfileobj(response,f,1024*1024)
 assert sha(archive)==identity['archive_sha256'],'Official Node archive mismatch'
 expected='node-v'+identity['version']+'-win-x64'
 with zipfile.ZipFile(archive) as z:
  assert all(PurePosixPath(n).parts[0]==expected and '..' not in PurePosixPath(n).parts and ':' not in n for n in z.namelist())
  z.extractall(tools)
 node=tools/expected/'node.exe';npm=tools/expected/'node_modules/npm/bin/npm-cli.js'
 env=dict(os.environ,PATH=str(node.parent)+os.pathsep+os.environ['PATH'],TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'))
 for name in ['VSCODE_EXECUTABLE_PATH','VSCODE_CLI_PATH','VOID_TEST_VSIX','VOID_TEST_CDP_PORT']:env.pop(name,None)
 assert subprocess.check_output([node,'--version'],env=env,text=True).strip()=='v'+identity['version']
 assert subprocess.check_output([node,npm,'--version'],env=env,text=True).strip()==identity['npm_version']
 r['actual_node_sha256']=sha(node);save()
 project=root/'build/ci-42446206797-editor-root/editors/vscode';project.mkdir(parents=True,exist_ok=False)
 source=json.loads((out/'editor-project-source.json').read_text());assert sha(out/'editor-project-source.zip')==source['archive_sha256']
 with zipfile.ZipFile(out/'editor-project-source.zip') as z:
  assert set(z.namelist())==set(source['files'])
  assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and ':' not in n for n in z.namelist())
  z.extractall(project)
 assert all(sha(project/n)==digest for n,digest in source['files'].items()),'Native editor source differs'
 r['source_files']=source['files'];save()
 standard=project.parents[1]/'stdlib';standard.mkdir()
 for n in ['time.void','console.void','error.void']:shutil.copyfile(root/'stdlib'/n,standard/n)
 before=sha(project/'package-lock.json')
 run('install',[node,npm,'ci','--cache',tools/'npm-cache'],env,project)
 assert sha(project/'package-lock.json')==before,'npm changed the approved lockfile'
 run('unit',[node,npm,'test'],env,project)
 text=(out/'editor-native-unit.log').read_text(errors='replace');assert 'tests 6' in text and 'fail 0' in text,'Native unit result incomplete'
 env['VOIDLS_PATH']=str(root/'build/Debug/voidls.exe')
 run('host',[node,npm,'run','test:host'],env,project)
 text=(out/'editor-native-host.log').read_text(errors='replace')
 assert all('Editor test begins: '+mode in text for mode in ['trusted','untrusted','multi-root'])
 assert 'PASS real editor multi-root' in text
 run('package',[node,npm,'run','package'],env,project)
 artifact=project/'dist/void-language-0.1.0.vsix';assert artifact.is_file();r['local_vsix']={'bytes':artifact.stat().st_size,'sha256':sha(artifact),'published':False}
 assert sha(project/'package-lock.json')==before
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
sys.exit(0 if r['status']=='PASS' else 1)
