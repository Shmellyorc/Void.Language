from pathlib import Path
import ctypes,hashlib,json,os,subprocess,sys,tempfile
out=Path(r"\\vboxsvr\VM\ci-42446206797");root=Path.home()/'VoidCI42377496702-Native'
label=sys.argv[1];record={'scope':'Diagnostic only; actual native error retained, no acceptance substitution','administrator':bool(ctypes.windll.shell32.IsUserAnAdmin()),'records':[]}
source_text="""use io
use path
use convert
func main():
    var linked = io.create_symlink(convert.unwrap(path.absolute("target")), "link")
    if linked is Err(var problem):
        print(problem.os_code)
    else:
        print(0)
        convert.unwrap(io.remove_file("link"))
"""
with tempfile.TemporaryDirectory(prefix='symlink-code-',dir=root/'native-private-temp') as folder:
 work=Path(folder);(work/'target').write_bytes(b'owned target');source=work/'probe.void';source.write_text(source_text)
 for profile in (sys.argv[2:] or ['Release','Debug']):
  compiler=root/'build'/profile/'voidc.exe';command=[str(compiler),'run',str(source),'--no-opt','--no-cache'];r=subprocess.run(command,cwd=work,capture_output=True,timeout=180)
  record['records'].append({'profile':profile,'command':command,'status':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace'),'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
(out/('symlink-probe-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')

# Continue this authorized native qualification sequentially in the same elevated
# session. A canceled/failed Debug chain cannot start another heavy build.
if label=='elevated-Debug' and not (out/'final-native-launch.json').exists():
 with (out/'io-wire-isolation-console.log').open('wb') as stream:
  subprocess.run([sys.executable,str(out/'io-wire-isolation.py')],cwd=root,stdout=stream,stderr=subprocess.STDOUT,check=True)
 with (out/'final-native-console.log').open('wb') as stream:
  child=subprocess.Popen([sys.executable,str(out/'final-native.py')],cwd=root,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NEW_CONSOLE)
 (out/'final-native-launch.json').write_text(json.dumps({'pid':child.pid,'purpose':'Final clean full Release after successful full Debug; one active build/test chain'},indent=2)+'\n')
