@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\editor-tools-probe.py" > "\\vboxsvr\VM\ci-42446206797\editor-tools-probe.log" 2>&1
