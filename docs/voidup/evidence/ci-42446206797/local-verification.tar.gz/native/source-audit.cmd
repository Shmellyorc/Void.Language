@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42446206797\source-audit.py" > "\\vboxsvr\VM\ci-42446206797\source-audit-console.log" 2>&1
