from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'pre-elevation-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('pre-elevation-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 # Preserve failures and continue independent profile checks.
try:
 query="Get-CimInstance Win32_Process | Where-Object {$_.Name -in @('ninja.exe','cmake.exe','voidc.exe','clang-cl.exe')} | Select-Object ProcessId,ParentProcessId,Name,CommandLine | ConvertTo-Json -Depth 3"
 run('owned-process-query',[r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',query])
 run('standard-symlink-code',[sys.executable,out/'symlink-probe.py','standard','Release'])
 run('real-second-volume',[sys.executable,out/'volume-probe.py'])
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
