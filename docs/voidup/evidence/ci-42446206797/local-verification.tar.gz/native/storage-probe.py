from pathlib import Path
import ctypes,json,os,shutil,subprocess,time,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';record={'time':time.time(),'disk_C':shutil.disk_usage('C:\\')._asdict(),'administrator':bool(ctypes.windll.shell32.IsUserAnAdmin())}
class Memory(ctypes.Structure):
 _fields_=[('length',ctypes.c_uint32),('load',ctypes.c_uint32)]+[(n,ctypes.c_uint64) for n in ['total_physical','available_physical','total_commit','available_commit','total_virtual','available_virtual','available_extended']]
m=Memory();m.length=ctypes.sizeof(m);ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m));record['memory']={n:getattr(m,n) for n,_ in m._fields_}
try:
 record['build_sizes']={}
 for profile in ['Release','Debug']:
  folder=root/'build'/profile;sizes={};largest=[]
  for p in folder.rglob('*'):
   if p.is_file():
    size=p.stat().st_size;sizes[p.suffix.lower()]=sizes.get(p.suffix.lower(),0)+size;largest.append((size,str(p.relative_to(folder))))
  record['build_sizes'][profile]={'by_extension':sizes,'largest':sorted(largest,reverse=True)[:15]}
 command=[r'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe','-NoProfile','-Command',"Get-WinEvent -FilterHashtable @{LogName='System';StartTime=(Get-Date).AddMinutes(-20);Level=2,3} -MaxEvents 20 -ErrorAction SilentlyContinue | Select-Object TimeCreated,Id,ProviderName,Message | ConvertTo-Json -Depth 3"]
 r=subprocess.run(command,capture_output=True,timeout=60);record['system_events']={'status':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')}
except BaseException:record['error']=traceback.format_exc()
(out/'storage-probe.json').write_text(json.dumps(record,indent=2)+'\n')
