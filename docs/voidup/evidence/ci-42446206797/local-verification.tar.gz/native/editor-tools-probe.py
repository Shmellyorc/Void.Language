from pathlib import Path
import json,shutil,subprocess,platform
out=Path(r'\\vboxsvr\VM\ci-42446206797');home=Path.home();candidates=[]
selected=shutil.which('node')
if selected:candidates.append(Path(selected))
for p in [Path('C:/Program Files/nodejs/node.exe'),Path('C:/nodejs/node.exe'),home/'AppData/Local/Programs/nodejs/node.exe']:
 if p.is_file() and p not in candidates:candidates.append(p)
for base in [home/'AppData/Roaming/nvm',home/'AppData/Local/nvm']:
 if base.is_dir():candidates.extend(p for p in base.glob('v*/node.exe') if p not in candidates)
r={'platform':platform.platform(),'node_candidates':[],'disk':shutil.disk_usage(home)._asdict()}
for p in candidates:
 result=subprocess.run([p,'--version'],capture_output=True,timeout=10);r['node_candidates'].append({'path':str(p),'status':result.returncode,'version':result.stdout.decode(errors='replace').strip()})
(out/'editor-tools-probe.json').write_text(json.dumps(r,indent=2)+'\n')
