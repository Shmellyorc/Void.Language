from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'elevated-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('elevated-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 return p.returncode
 # Preserve failures and continue independent profile checks.
def snapshot(profile,label):
 destination=out/(label+'-'+profile);destination.mkdir(exist_ok=True)
 for n in ['Testing/Temporary/LastTest.log','Testing/Temporary/LastTestsFailed.log','host-capabilities-evidence/portable-'+profile+'.json','host-capabilities-evidence/portable-source-'+profile+'.json']:
  source=root/'build'/profile/n
  if source.exists():
   target=destination/n;target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists():shutil.copyfile(source,target)
try:
 import ctypes
 r['administrator']=bool(ctypes.windll.shell32.IsUserAnAdmin());save()
 assert r['administrator'],'Existing elevated caller required for real symlink fixtures'
 assert json.loads((out/'complete-results.json').read_text())['status']!='running','Do not overlap native qualification chains'
 second=out/'second-volume';second.mkdir(exist_ok=True);env['VOID_IO_SECOND_VOLUME']=str(second)
 for profile in ['Release','Debug']:
  snapshot(profile,'pre-elevation')
  if run('build-all-'+profile,['cmake','--build',root/'build'/profile,'--parallel','1'])!=0:continue
  if run('receipts-'+profile,[sys.executable,root/'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'])!=0:continue
  run('symlink-native-code-'+profile,[sys.executable,out/'symlink-probe.py','elevated-'+profile,profile])
  run('full-'+profile,['ctest','--test-dir',root/'build'/profile,'--output-on-failure','--output-junit',out/('elevated-full-'+profile+'.xml')])
  snapshot(profile,'elevated-full')
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
