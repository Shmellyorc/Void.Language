from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback,hashlib,xml.etree.ElementTree as ET
out=Path(r'\\vboxsvr\VM\ci-42446206797');root=Path.home()/'VoidCI42377496702-Native';sdk=(root/'.toolchains/llvm-23.1.4').resolve()
r={'status':'waiting for initial full Release','commands':[]}
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1',VOID_IO_SECOND_VOLUME=str(out/'second-volume'));env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def save():(out/'integration-native-results.json').write_text(json.dumps(r,indent=2)+'\n')
def previous():
 try:return json.loads((out/'final-native-results.json').read_text())
 except (OSError,json.JSONDecodeError):return {'status':'running'}
def run(label,args):
 r['stage']=label;save();start=time.monotonic()
 with (out/('integration-native-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-start});save();assert p.returncode==0,(label,p.returncode)
try:
 import ctypes
 r['administrator']=bool(ctypes.windll.shell32.IsUserAnAdmin());assert r['administrator'];save()
 while previous()['status']=='running':time.sleep(10)
 cases=ET.parse(out/'final-native-Release.xml').getroot().findall('.//testcase');bad=[c.get('name') for c in cases if c.find('failure') is not None or c.find('error') is not None]
 assert len(cases)==351 and bad==['application_workflow_stage9'],('Inspect any additional failure before continuing',bad)
 r['retained_original_release']={'file':'final-native-Release.xml','passed':350,'failed':bad,'source_revision':'Original native six-file candidate before shared relocation utility'}
 expected=json.loads((out/'integration-source-hashes.json').read_text());r['source_sha256']=expected
 for n,digest in expected.items():
  target=root/n
  if sha(target)!=digest:
   backup=out/'before-shared-revision'/n;backup.parent.mkdir(parents=True,exist_ok=True);assert not backup.exists();shutil.copyfile(target,backup)
   shutil.copyfile(out/'integration-source'/n,target)
  assert sha(target)==digest,n
 r['status']='running';save()
 run('held-child-controls',[sys.executable,out/'relocate-shared-controls.py']);assert json.loads((out/'relocate-shared-controls.json').read_text())['status']=='PASS'
 selected='^(application_workflow_stage9|cli_install|cli_install_resources|host_capabilities_dependencies|host_capabilities_portable|host_capabilities_portable_source|voidup_smoke)$'
 for profile in ['Debug','Release']:
  run('focused-'+profile,['ctest','--test-dir',root/'build'/profile,'-R',selected,'--output-on-failure','--output-junit',out/('integration-native-focused-'+profile+'.xml')])
 run('full-Release',['ctest','--test-dir',root/'build/Release','--output-on-failure','--output-junit',out/'integration-native-full-Release.xml'])
 r['status']='PASS'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
