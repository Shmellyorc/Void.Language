from pathlib import Path
import ctypes,json,os,subprocess,tempfile,time,traceback
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';os.environ['TMP']=os.environ['TEMP']=str(root/'native-private-temp');tempfile.tempdir=None
record={'scope':'Three bounded fresh component installations and directory rename probes; no production retry or security changes','iterations':[]}
k=ctypes.WinDLL('kernel32',use_last_error=True);k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p];k.CreateFileW.restype=ctypes.c_void_p;k.CloseHandle.argtypes=[ctypes.c_void_p]
try:
 for i in range(3):
  entry={'iteration':i};record['iterations'].append(entry)
  with tempfile.TemporaryDirectory(prefix='VOID rename capture ') as t:
   before=Path(t)/'before move';after=Path(t)/'after move 雪'
   for component in ['compiler','tooling']:
    r=subprocess.run(['cmake','--install',str(root/'build/Release'),'--component',component,'--prefix',str(before)],capture_output=True,timeout=180)
    (out/('rename-probe-'+str(i)+'-'+component+'.log')).write_bytes(r.stdout+r.stderr)
    assert r.returncode==0
   entry['path']=str(before);entry['attributes']=k.GetFileAttributesW(str(before))
   h=k.CreateFileW(str(before),0x10000|0x80|0x20000,7,None,3,0x02000000,None)
   entry['delete_metadata_open_error']=ctypes.get_last_error() if h==ctypes.c_void_p(-1).value else 0
   if h!=ctypes.c_void_p(-1).value:k.CloseHandle(h)
   try:before.rename(after);entry['rename']='PASS'
   except OSError as e:entry.update(rename='FAIL',winerror=e.winerror,error=str(e))
   (out/'rename-probe.json').write_text(json.dumps(record,indent=2)+'\n')
except BaseException:record['error']=traceback.format_exc()
finally:(out/'rename-probe.json').write_text(json.dumps(record,indent=2)+'\n')
