@echo off
call "C:\BuildTools\VS2022\VC\Auxiliary\Build\vcvarsall.bat" x64 >nul
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42427327049\rename-probe.py" > "\\vboxsvr\VM\ci-42427327049\rename-probe-console.log" 2>&1
