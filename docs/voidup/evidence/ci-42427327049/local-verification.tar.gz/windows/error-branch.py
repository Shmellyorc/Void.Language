from pathlib import Path
import json,os,subprocess,tempfile,zipfile
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';os.environ['TMP']=os.environ['TEMP']=str(root/'native-private-temp');tempfile.tempdir=None;records=[]
for profile in ['Release','Debug']:
 with tempfile.TemporaryDirectory(prefix='VOID native error diagnostic ') as t:
  work=Path(t)
  for n,bad in [('package.zip',False),('hostile.zip',True)]:
   with zipfile.ZipFile(work/n,'w') as z:z.writestr('../escape' if bad else 'data',b'abc')
  args=[root/'build'/profile/'void_host_portable.exe',work,root/'missing-diagnostic-child.exe'];r=subprocess.run(list(map(str,args)),capture_output=True,stdin=subprocess.DEVNULL,timeout=120)
  records.append({'profile':profile,'command':list(map(str,args)),'status':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace'),'expected_failure':r.returncode==1 and b'kind=1 code=2' in r.stderr})
(out/'native-error-branch.json').write_text(json.dumps(records,indent=2)+'\n');assert all(r['expected_failure'] for r in records)
