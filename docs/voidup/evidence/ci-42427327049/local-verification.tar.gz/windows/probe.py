from pathlib import Path
import ctypes,json,os,subprocess,tempfile,traceback
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';record={'platform':__import__('platform').platform(),'commands':[],'queries':[]}
k=ctypes.WinDLL('kernel32',use_last_error=True);k.CreateFileW.argtypes=[ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p];k.CreateFileW.restype=ctypes.c_void_p;k.GetFileInformationByHandle.argtypes=[ctypes.c_void_p,ctypes.c_void_p];k.CloseHandle.argtypes=[ctypes.c_void_p]
try:
 with tempfile.TemporaryDirectory(prefix='VOID process probe ') as t:
  for path in [Path(t),Path(t).parent,root/'build/Release']:
   for mask in [1,1|128]:
    h=k.CreateFileW(str(path),mask,7,None,3,0x02200000,None);entry={'path':str(path),'mask':mask,'open_error':ctypes.get_last_error() if h==ctypes.c_void_p(-1).value else 0}
    if h!=ctypes.c_void_p(-1).value:
     b=ctypes.create_string_buffer(128);ok=k.GetFileInformationByHandle(h,b);entry.update(query_ok=bool(ok),query_error=0 if ok else ctypes.get_last_error());k.CloseHandle(h)
    record['queries'].append(entry)
  import zipfile
  for n,bad in [('package.zip',False),('hostile.zip',True)]:
   with zipfile.ZipFile(Path(t)/n,'w') as z:z.writestr('../escape' if bad else 'data',b'abc')
  for profile in ['Release','Debug']:
   exe=root/'build'/profile/'void_host_portable.exe';work=Path(t)/profile;work.mkdir()
   for n in ['package.zip','hostile.zip']:__import__('shutil').copyfile(Path(t)/n,work/n)
   r=subprocess.run([exe,work,exe],capture_output=True,stdin=subprocess.DEVNULL,timeout=180)
   record['commands'].append({'profile':profile,'argv':[str(exe),str(work),str(exe)],'status':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
except BaseException:record['error']=traceback.format_exc()
finally:(out/'probe.json').write_text(json.dumps(record,indent=2)+'\n')
