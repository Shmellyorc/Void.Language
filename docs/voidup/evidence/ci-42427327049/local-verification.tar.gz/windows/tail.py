from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'tail-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('tail-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 # Preserve failures and continue independent profile checks.
try:
 assert json.loads((out/'retry-results.json').read_text())['status']!='running'
 shutil.copyfile(out/'source/tests/cli/install_resources.py',root/'tests/cli/install_resources.py')
 run('resource-tests-final',[sys.executable,root/'tests/cli/install_resources.py'])
 run('cli-install-Release-isolated',['ctest','--test-dir',root/'build/Release','-R','^cli_install$','--output-on-failure','--output-junit',out/'Release-install-isolated.xml'])
 for profile in ['Release','Debug']:
  run('receipt-'+profile,[sys.executable,root/'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'])
  args=[root/'build'/profile/'voidc.exe','run',root/'tests/host_capabilities/portable_process.void','--no-cache','--',root/'missing-diagnostic-child.exe',root/'native-private-temp']
  t=time.monotonic();result=subprocess.run(list(map(str,args)),cwd=root,env=env,capture_output=True,timeout=180)
  (out/('diagnostic-error-'+profile+'.stdout')).write_bytes(result.stdout);(out/('diagnostic-error-'+profile+'.stderr')).write_bytes(result.stderr)
  r['commands'].append({'label':'expected-native-error-'+profile,'argv':list(map(str,args)),'actual_status':result.returncode,'status':0 if result.returncode==1 and b'process.start diagnostic' in result.stdout else 1,'seconds':time.monotonic()-t});save()
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
