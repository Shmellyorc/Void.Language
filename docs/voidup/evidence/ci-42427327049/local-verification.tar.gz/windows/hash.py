from pathlib import Path
import hashlib,json
root=Path.home()/'VoidCI42377496702-Native';out=Path(r'\\vboxsvr\VM\ci-42427327049');files={}
for folder in ['src','include']:
 for p in (root/folder).rglob('*'):
  if p.is_file():files[p.relative_to(root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
for n in ['CMakeLists.txt','tests/host_capabilities/portable.cpp','tests/cli/install_resources.py','stdlib/process.void','stdlib/system_error.void','tests/cli/install.py','tools/verify_install.py','tools/ci/install_smoke.py','tests/host_capabilities/portable.py','tests/host_capabilities/portable_source.py','tests/host_capabilities/portable_process.void']:
 p=root/n;files[n]=hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None
(out/'guest-source-hashes.json').write_text(json.dumps(files,indent=2)+'\n');(out/'guest-cli-install.py.txt').write_bytes((root/'tests/cli/install.py').read_bytes())
