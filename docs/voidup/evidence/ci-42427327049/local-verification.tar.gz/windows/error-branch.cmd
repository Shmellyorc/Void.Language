@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42427327049\error-branch.py" > "\\vboxsvr\VM\ci-42427327049\error-branch-console.log" 2>&1
