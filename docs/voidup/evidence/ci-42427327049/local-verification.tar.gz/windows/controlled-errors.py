from pathlib import Path
import ctypes,json,os,subprocess,tempfile,zipfile
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';os.environ['TMP']=os.environ['TEMP']=str(root/'native-private-temp');tempfile.tempdir=None
k=ctypes.WinDLL('kernel32',use_last_error=True);a=ctypes.WinDLL('advapi32',use_last_error=True);P=ctypes.c_void_p;D=ctypes.c_uint32
k.GetCurrentProcess.restype=P;k.CloseHandle.argtypes=[P];k.LocalFree.argtypes=[P];a.OpenProcessToken.argtypes=[P,D,ctypes.POINTER(P)];a.GetTokenInformation.argtypes=[P,ctypes.c_int,P,D,ctypes.POINTER(D)];a.ConvertSidToStringSidW.argtypes=[P,ctypes.POINTER(P)]
token=P();assert a.OpenProcessToken(k.GetCurrentProcess(),8,ctypes.byref(token));needed=D();a.GetTokenInformation(token,1,None,0,ctypes.byref(needed));buf=ctypes.create_string_buffer(needed.value);assert a.GetTokenInformation(token,1,buf,needed,ctypes.byref(needed));sid=P();assert a.ConvertSidToStringSidW(P.from_buffer(buf),ctypes.byref(sid));owner=ctypes.wstring_at(sid);k.LocalFree(sid);k.CloseHandle(token)
a.ConvertStringSecurityDescriptorToSecurityDescriptorW.argtypes=[ctypes.c_wchar_p,D,ctypes.POINTER(P),ctypes.POINTER(D)]
class SA(ctypes.Structure):_fields_=[('length',D),('descriptor',P),('inherit',ctypes.c_int)]
k.CreateDirectoryW.argtypes=[ctypes.c_wchar_p,ctypes.POINTER(SA)]
records=[]
for profile in ['Release','Debug']:
 for hostile in [False,True]:
  with tempfile.TemporaryDirectory(prefix='VOID controlled error ') as t:
   work=Path(t)
   for n,bad in [('package.zip',False),('hostile.zip',True)]:
    with zipfile.ZipFile(work/n,'w') as z:z.writestr('../escape' if bad else 'data',b'abc')
   exe=root/'missing-diagnostic-child.exe'
   if hostile:
    parent=work/'controlled-hostile-image';descriptor=P();assert a.ConvertStringSecurityDescriptorToSecurityDescriptorW('O:'+owner+'D:P(A;OICI;FA;;;'+owner+')(A;;0x100;;;WD)',1,ctypes.byref(descriptor),None)
    try:assert k.CreateDirectoryW(str(parent),ctypes.byref(SA(ctypes.sizeof(SA),descriptor,0)))
    finally:k.LocalFree(descriptor)
    exe=parent/'missing.exe'
   args=[root/'build'/profile/'void_host_portable.exe',work,exe];r=subprocess.run(list(map(str,args)),capture_output=True,stdin=subprocess.DEVNULL,timeout=120)
   expected=b'kind=2 code=5 stage=4' if hostile else b'kind=1 code=2 stage=6';ok=r.returncode==1 and expected in r.stderr and (not hostile or b'SDDL:' in r.stderr)
   records.append({'profile':profile,'scenario':'deliberate hostile image ancestry' if hostile else 'deliberate missing image','not_hosted_failure_evidence':True,'command':list(map(str,args)),'status':r.returncode,'stderr':r.stderr.decode(errors='replace'),'expected_failure':ok})
(out/'controlled-errors.json').write_text(json.dumps(records,indent=2)+'\n');assert all(r['expected_failure'] for r in records)
