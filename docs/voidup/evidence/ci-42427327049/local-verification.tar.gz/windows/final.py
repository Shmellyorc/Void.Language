from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'final-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('final-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 # Preserve failures and continue independent profile checks.
try:
 assert json.loads((out/'stage-results.json').read_text())['status']=='PASS'
 shutil.copyfile(root/'CMakeLists.txt',out/'before/CMakeLists.txt');shutil.copyfile(out/'source/CMakeLists.txt',root/'CMakeLists.txt')
 for profile in ['Release','Debug']:
  run('configure-'+profile,['cmake','-S',root,'-B',root/'build'/profile])
  run('inventory-registered-'+profile,['ctest','--test-dir',root/'build'/profile,'-R','^cli_install_resources$','--output-on-failure','--output-junit',out/('inventory-'+profile+'.xml')])
  run('receipt-'+profile,[sys.executable,root/'tools/verify_host_deps.py','--prefix',root/'.toolchains/host/prefix/windows-x86_64'/profile,'--profile',profile,'--platform','Windows','--architecture','x86_64'])
  for label,relative in [('voidc','voidc.exe'),('portable','void_host_portable.exe'),('voidup','voidup/voidup.exe')]:run('PE-'+profile+'-'+label,[sdk/'bin/llvm-readobj.exe','--file-headers',root/'build'/profile/relative])
 run('stage-error-branch',[sys.executable,out/'stage-error-branch.py'])
 run('source-hashes',[sys.executable,out/'hash.py'])
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
