@echo off
"C:\Users\a\AppData\Local\Programs\Python\Python314\python.exe" "\\vboxsvr\VM\ci-42427327049\unit-final.py" > "\\vboxsvr\VM\ci-42427327049\unit-final-console.log" 2>&1
