from pathlib import Path
import json,os,subprocess,sys,time,shutil,traceback
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';r={'status':'running','commands':[]};sdk=(root/'.toolchains/llvm-23.1.4').resolve()
env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'),VOID_CLANG=str(sdk/'bin/clang.exe'),CMAKE_BUILD_PARALLEL_LEVEL='1',CTEST_PARALLEL_LEVEL='1');env['PATH']=str(sdk/'bin')+os.pathsep+env['PATH']+os.pathsep+r'C:\Program Files\Git\usr\bin'
def save():(out/'diagnostic-qualified-results.json').write_text(json.dumps(r,indent=2)+'\n')
def run(label,args):
 r['stage']=label;save();t=time.monotonic()
 with (out/('diagnostic-qualified-'+label+'.log')).open('wb') as f:p=subprocess.run(list(map(str,args)),cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 r['commands'].append({'label':label,'argv':list(map(str,args)),'status':p.returncode,'seconds':time.monotonic()-t});save()
 # Preserve failures and continue independent profile checks.
try:
 assert json.loads((out/'frozen-results.json').read_text())['status']=='PASS'
 shutil.copyfile(out/'source/tests/host_capabilities/portable.cpp',root/'tests/host_capabilities/portable.cpp')
 for profile in ['Release','Debug']:
  run('build-'+profile,['cmake','--build',root/'build'/profile,'--target','void_host_portable','--parallel','1'])
  run('positive-'+profile,['ctest','--test-dir',root/'build'/profile,'-R','^host_capabilities_portable$','--output-on-failure','--output-junit',out/('diagnostic-positive-'+profile+'.xml')])
 run('controlled-error-paths',[sys.executable,out/'controlled-errors.py'])
 run('source-hashes',[sys.executable,out/'hash.py'])
 r['status']='PASS' if all(c['status']==0 for c in r['commands']) else 'FAIL'
except BaseException:r['status']='FAIL';r['error']=traceback.format_exc()
finally:save()
