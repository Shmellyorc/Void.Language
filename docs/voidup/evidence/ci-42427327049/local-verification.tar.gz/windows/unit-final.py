from pathlib import Path
import os,json,shutil,subprocess,sys
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';shutil.copyfile(out/'source/tests/cli/install_resources.py',root/'tests/cli/install_resources.py');env=dict(os.environ,TMP=str(root/'native-private-temp'),TEMP=str(root/'native-private-temp'))
with (out/'inventory-skip-policy-final.log').open('wb') as f:r=subprocess.run([sys.executable,root/'tests/cli/install_resources.py'],env=env,stdout=f,stderr=subprocess.STDOUT)
subprocess.run([sys.executable,out/'hash.py'],check=True);(out/'inventory-skip-policy-final.json').write_text(json.dumps({'status':r.returncode,'scope':'FinaltestskipsonlyWinError1314;unexpectedOSErrorfails.'})+'\n');raise SystemExit(r.returncode)
