from pathlib import Path
import ctypes,hashlib,json,tempfile,sys,os
out=Path(r'\\vboxsvr\VM\ci-42427327049');root=Path.home()/'VoidCI42377496702-Native';os.environ['TMP']=os.environ['TEMP']=str(root/'native-private-temp');tempfile.tempdir=None
sys.path.insert(0,str(root/'tools'));from verify_install import verify_native_resources
s=(out/'before/tools/verify_install.py').read_text();a=s.index('    # Verify every installed archive');b=s.index('    environment = os.environ.copy()',a);ns={};exec('from pathlib import Path\nimport hashlib\ndef original(prefix):\n'+s[a:b],ns)
k=ctypes.WinDLL('kernel32',use_last_error=True);k.GetShortPathNameW.argtypes=[ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_uint32];records=[]
with tempfile.TemporaryDirectory(prefix='VOID real short alias ') as t:
 prefix=Path(t)/'installation long name';(prefix/'lib/void').mkdir(parents=True);(prefix/'bin').mkdir();buf=ctypes.create_unicode_buffer(32768);assert k.GetShortPathNameW(str(prefix),buf,len(buf));alias=Path(buf.value);assert str(alias)!=str(prefix)
 for names in [('void_runtime.lib','fixture.lib'),('libvoid_runtime.a','fixture.a')]:
  lines=['VOID native resources 1']
  for name in names:
   file=prefix/'lib/void'/name;file.write_bytes(b'fixture');lines.append(hashlib.sha256(file.read_bytes()).hexdigest()+'\t@VOID_NATIVE_DIR@/../lib/void/'+name)
  (prefix/'bin/void-native-resources.txt').write_text('\n'.join(lines)+'\n')
  try:ns['original'](alias);raise AssertionError('Original unexpectedly accepted short alias')
  except RuntimeError as error:message=str(error)
  verify_native_resources(alias);records.append({'prefix':str(prefix),'short_alias':str(alias),'resource':names[0],'original_error':message,'corrected':'PASS'})
(out/'real-short-alias.json').write_text(json.dumps(records,indent=2)+'\n')
