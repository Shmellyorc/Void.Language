"""Read-only observation of the authorized existing run; never dispatch/rerun."""
from pathlib import Path
import datetime,hashlib,json,subprocess,time
out=Path(__file__).resolve().parent;original=out/'original';history=[];previous=None
repo='repos/Shmellyorc/Void.Language/actions/'
def get(endpoint):return subprocess.check_output(['gh','api',repo+endpoint])
while True:
    now=datetime.datetime.now(datetime.timezone.utc).isoformat()
    data=get('runs/42427327049/jobs');jobs=json.loads(data)['jobs'];(original/'jobs-latest.json').write_bytes(data)
    state=[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion']} for j in jobs]
    if state!=previous:
        history.append({'time':now,'jobs':state});(out/'job-history.json').write_text(json.dumps(history,indent=2)+'\n');previous=state
        for j in jobs:
            path=original/(str(j['id'])+'.log')
            if j['status']=='completed' and not path.exists():path.write_bytes(get('jobs/'+str(j['id'])+'/logs'))
        data=get('runs/42427327049/artifacts');(original/'artifacts-latest.json').write_bytes(data)
        for a in json.loads(data)['artifacts']:
            if not a['name'].startswith(('tests-','link-experiment-')):continue
            path=original/(str(a['id'])+'.zip')
            if not path.exists():path.write_bytes(get('artifacts/'+str(a['id'])+'/zip'))
            assert 'sha256:'+hashlib.sha256(path.read_bytes()).hexdigest()==a['digest']
    if all(j['status']=='completed' for j in jobs):
        (out/'monitor-result.json').write_text(json.dumps({'status':'COMPLETE','time':now,'jobs':state},indent=2)+'\n');break
    time.sleep(60)
