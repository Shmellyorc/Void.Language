from pathlib import Path
import hashlib,json,subprocess,tarfile,zipfile,re
ROOT=Path(__file__).resolve().parents[2];TASK=Path(__file__).resolve().parent
SHARED=Path('/home/shmellyorc/VM/ci-42427327049');OUT=ROOT/'docs/voidup/evidence/ci-42427327049';OUT.mkdir(exist_ok=True)
BASE='d7dc4b681c2cd5745210bcc49bb3a0d1ddf4c59c'
SOURCE=['CMakeLists.txt','src/runtime/host_process_windows.cpp','tests/host_capabilities/portable.cpp','tests/host_capabilities/portable_process.void','tools/verify_install.py','tests/cli/install_resources.py']
REPORT='docs/voidup/INTEGRATION_REPORT.md'
ARTIFACTS=['original-ci.tar.gz','original-ci-index.json','local-verification.tar.gz','local-verification-index.json','source.patch','documentation.patch','commit-paths.txt','commit-paths.nul','commit-inventory.json']
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==BASE
assert not git('diff','--cached','--name-only')
tracked=set(git('ls-files').decode().splitlines());changed=set(git('diff','--name-only','HEAD').decode().splitlines())
assert changed==set(SOURCE+[REPORT])-{'tests/cli/install_resources.py'},changed
subprocess.run(['git','diff','--check'],cwd=ROOT,check=True)
patch=git('diff','--binary','HEAD','--',*[n for n in SOURCE if n in tracked])
new=subprocess.run(['git','diff','--no-index','--binary','--','/dev/null','tests/cli/install_resources.py'],cwd=ROOT,capture_output=True);assert new.returncode==1
(OUT/'source.patch').write_bytes(patch+new.stdout)
(OUT/'documentation.patch').write_bytes(git('diff','--binary','HEAD','--',REPORT))
patterns={'private-key':rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----','github-token':rb'\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{30,}\b','openai-token':rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{32,}\b','aws-id':rb'\bAKIA[A-Z0-9]{16}\b'}
def scan(data,name):
 for label,pattern in patterns.items():assert not re.search(pattern,data),(name,label)
def archive(label,items):
 target=OUT/(label+'.tar.gz');index={'scope':'Actual preserved CI42427327049 evidence; original failures and unfavorable results retained.','members':[]}
 with tarfile.open(target,'w:gz',compresslevel=6) as tar:
  for name,p in sorted(items.items()):
   data=p.read_bytes()
   if p.suffix!='.zip':scan(data,name)
   else:
    with zipfile.ZipFile(p) as z:
     for member in z.namelist():
      assert not member.lower().endswith(('.key','.pfx','.p12','.kdbx')),member
      if member.endswith(('.log','.json','.xml','.txt','.stdout','.stderr','.pem')):scan(z.read(member),name+'/'+member)
   index['members'].append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});tar.add(p,arcname=name,recursive=False)
 with tarfile.open(target,'r:gz') as tar:
  for m in index['members']:assert hashlib.sha256(tar.extractfile(m['path']).read()).hexdigest()==m['sha256']
 index['archive']={'path':target.name,'bytes':target.stat().st_size,'sha256':digest(target)}
 (OUT/(label+'-index.json')).write_text(json.dumps(index,indent=2)+'\n');return index
original={p.name:p for p in (TASK/'original').iterdir() if p.is_file()};oi=archive('original-ci',original)
suffixes={'.py','.cmd','.json','.xml','.log','.txt','.stdout','.stderr','.cpp','.hpp','.void','.patch'}
items={}
for base,prefix in [(TASK,'local'),(SHARED,'windows')]:
 for p in base.rglob('*'):
  if not p.is_file() or p.is_symlink() or p.suffix not in suffixes:continue
  relative=p.relative_to(base)
  if 'original' in relative.parts or p.name=='ROOT_PROGRESS.json' or '__pycache__' in relative.parts:continue
  items[prefix+'/'+str(relative)]=p
li=archive('local-verification',items)
paths=sorted(set(SOURCE+[REPORT]+[str((OUT/a).relative_to(ROOT)) for a in ARTIFACTS]))
(OUT/'commit-paths.txt').write_text('\n'.join(paths)+'\n');(OUT/'commit-paths.nul').write_bytes(b''.join(n.encode()+b'\0' for n in paths))
assert len(paths)==16
untracked=set(git('ls-files','--others','--exclude-standard').decode().splitlines());expected=set(paths)-changed
assert untracked<=expected and expected-untracked <= {str((OUT/'commit-inventory.json').relative_to(ROOT))},(untracked-expected,expected-untracked)
manifest={'baseline':BASE,'status':'REVISE: installation fix tested; Server2022 process cause/repair blocked on absent native failing diagnostics. Not CI-ready.','tracked_modified':len(changed),'untracked':len(expected),'staged':0,'paths':[],'excluded_roots':['build/','.toolchains/',str(SHARED),'C:\\Users\\a\\VoidCI42377496702-Native'],'unrelated_pending':[],'staging_command_not_executed':'git --literal-pathspecs add --pathspec-from-file=docs/voidup/evidence/ci-42427327049/commit-paths.nul --pathspec-file-nul','suggested_title':'Fix installation aliases and capture Windows launch failures [skip ci]'}
for n in paths:
 p=ROOT/n
 manifest['paths'].append({'path':n,'sha256':None if p.name=='commit-inventory.json' else digest(p),'reason':'Self-hash omitted' if p.name=='commit-inventory.json' else None})
(OUT/'commit-inventory.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert set(git('ls-files','--others','--exclude-standard').decode().splitlines())==expected
print(json.dumps({'original_members':len(oi['members']),'local_members':len(li['members']),'tracked_modified':len(changed),'untracked':len(expected),'staged':0,'total_paths':len(paths)},indent=2))
