"""Read-only download of this run's diagnostics; never dispatches Actions."""
from pathlib import Path
import concurrent.futures,hashlib,json,subprocess,zipfile
OUT=Path(__file__).resolve().parent;REPO='repos/Shmellyorc/Void.Language';RUN='42369685905'
def api(path):return subprocess.check_output(['gh','api',REPO+'/'+path])
run=json.loads(api('actions/runs/'+RUN));jobs=json.loads(api('actions/runs/'+RUN+'/jobs?per_page=100'));artifacts=json.loads(api('actions/runs/'+RUN+'/artifacts?per_page=100'))
for name,value in [('run.json',run),('jobs.json',jobs),('artifacts.json',artifacts)]: (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
assert run['head_sha']=='9521329e7e67f4c8bb5aec38d684fde3f3c887de'
def download(job):
 data=api('actions/jobs/'+str(job['id'])+'/logs');(OUT/(str(job['id'])+'.log')).write_bytes(data);return {'job_id':job['id'],'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records=list(pool.map(download,[j for j in jobs['jobs'] if j['status']=='completed']))
for artifact in artifacts['artifacts']:
 data=api('actions/artifacts/'+str(artifact['id'])+'/zip');actual=hashlib.sha256(data).hexdigest();assert artifact['digest']=='sha256:'+actual
 target=OUT/(str(artifact['id'])+'.zip');target.write_bytes(data)
 records.append({'artifact_id':artifact['id'],'sha256':actual,'bytes':len(data)})
 with zipfile.ZipFile(target) as z:
  # Preserve original ZIP bytes and extract only diagnostic logs, JSON and XML.
  for member in z.infolist():
   path=Path(member.filename)
   if path.is_absolute() or '..' in path.parts:raise ValueError('Unsafe artifact path')
   if member.is_dir() or path.suffix not in ('.log','.json','.xml','.trs','.txt'):continue
   payload=z.read(member)
   if b'\0' in payload:continue
   destination=OUT/'artifacts'/str(artifact['id'])/path;destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(payload)
(OUT/'downloads.json').write_text(json.dumps(records,indent=2)+'\n')
print('Run',run['status'],run['conclusion']);print([(j['id'],j['name'],j['status'],j['conclusion']) for j in jobs['jobs']]);print(len(records),'verified read-only log/artifact downloads')
