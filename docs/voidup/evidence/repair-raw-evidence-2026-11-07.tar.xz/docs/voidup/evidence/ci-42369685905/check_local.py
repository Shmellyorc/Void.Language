"""Focused checks for the qualified host-operation call; providers stay unchanged."""
from pathlib import Path
import concurrent.futures,json,os,shlex,subprocess,sys
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
SDK=ROOT/'.toolchains/llvm-23.1.4';records=[]
old=subprocess.check_output(['git','show','HEAD:tests/host_capabilities/portable.cpp'],cwd=ROOT);current=(ROOT/'tests/host_capabilities/portable.cpp').read_bytes()
for profile in ('Release','Debug','strict'):
 build=ROOT/'build/voidup-backport-integration'/profile
 entry=next(x for x in json.loads((build/'compile_commands.json').read_text()) if x['file'].endswith('/tests/host_capabilities/portable.cpp'))
 args=shlex.split(entry['command']);del args[args.index('-o'):args.index('-o')+2];args.remove('-c');args.remove(entry['file']);args+=['-fsyntax-only','-include','sys/wait.h','-x','c++','-']
 for label,source in [('before',old),('qualified',current)]:
  result=subprocess.run(args,cwd=ROOT/'tests/host_capabilities',input=source,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  text=result.stdout.decode();(OUT/(profile+'-wait-'+label+'.log')).write_text(text)
  expected=(result.returncode!=0 and "reference to 'wait' is ambiguous" in text) if label=='before' else result.returncode==0
  records.append({'profile':profile,'check':'POSIX declaration collision '+label,'command':args,'status':result.returncode,'expected_outcome_observed':expected});assert expected,text

def check_profile(profile):
 build=ROOT/'build/voidup-backport-integration'/profile;env=dict(os.environ)
 if profile=='strict':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86',ASAN_SYMBOLIZER_PATH=str(SDK/'bin/llvm-symbolizer'))
 args=['ctest','--test-dir',str(build),'-R','^(host_capabilities_(portable|dependencies'+('|install' if profile=='Release' else '')+')|voidup_ci_integration)$','--output-on-failure']
 with (OUT/(profile+'-focused-ctest.log')).open('wb') as log:result=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 return {'profile':profile,'check':'focused CTest','command':args,'status':result.returncode,'environment':{k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','ASAN_SYMBOLIZER_PATH') if k in env}}
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:records+=list(pool.map(check_profile,('Release','Debug','strict')))
(OUT/'local-results.json').write_text(json.dumps(records,indent=2)+'\n')
assert all(x['status']==0 for x in records if x['check']=='focused CTest')
print('Before/after POSIX collision checks PASS in 3 profiles; focused CTest Release 4/4, Debug 3/3, strict 3/3')
