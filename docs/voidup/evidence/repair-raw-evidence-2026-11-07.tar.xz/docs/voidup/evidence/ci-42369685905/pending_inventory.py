"""Exact pending allowlist for Boss review; never stages or changes Git state."""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
EXACT=set('''CMakeLists.txt
cmake/InstallLicenses.cmake
cmake/host-sodium.targets
tests/host_capabilities/dependencies.py
tests/host_capabilities/install.py
tests/host_capabilities/portable.cpp
tests/voidup/ci_integration.py
tools/bench/buffer_preparation.py
tools/bench/heap_legacy.py
tools/ci/llvm_sdk.py
tools/ci/voidup_bootstrap.py
tools/setup_host_deps.py
tools/setup_host_deps_native.py
tools/verify_discovery_engines.py
tools/verify_host_deps.py
tools/verify_website_examples.py
docs/release/NOTICE_INVENTORY.json
third_party/host-patches/libsodium-1.0.22/PROVENANCE.json
third_party/host-patches/libsodium-1.0.22/asan-alignment.patch'''.splitlines())
EVIDENCE=('docs/voidup/evidence/llvm23-repair/','docs/voidup/evidence/dependencies-linux-Debug-1794048450915212606/','docs/voidup/evidence/dependencies-linux-Release-1794048450866525653/','docs/voidup/evidence/dependencies-linux-strict-1794048451142739185/','docs/voidup/evidence/ci-42369685905/')
EXCLUDE={'docs/net/TCP_UDP_HANDOFF.md','website/dist/assets/style.css','website/dist/getting-started/index.html','website/public/assets/style.css','website/public/getting-started/index.html','website/scripts/check.py','website/scripts/test_check.py'}
GENERATED={str((OUT/n).relative_to(ROOT)) for n in ('PENDING_PATHS.txt','PENDING_PATHS.nul','PENDING_INVENTORY.json','INDEX.json')}
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def names(*args):return {n.decode() for n in git(*args).split(b'\0') if n}
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def cache(n):return '__pycache__' in Path(n).parts or '.void' in Path(n).parts or n.endswith('.pyc')
base=json.loads((OUT/'baseline.json').read_text());prior_docs={n for n in base['hashes'] if n.endswith('.md') and (n.startswith('docs/') or n=='tools/ci/STORAGE_SHAPE_PROOF.md')}
def accepted(n):return n in EXACT or n in prior_docs or n.startswith(EVIDENCE)
tracked=names('diff','--name-only','-z')|names('diff','--cached','--name-only','-z')
untracked=names('ls-files','--others','--exclude-standard','-z')
ignored=names('ls-files','--others','--ignored','--exclude-standard','-z','--',*EVIDENCE)
visible=tracked|untracked
unknown=sorted(n for n in visible if not accepted(n) and n not in EXCLUDE and not cache(n));assert not unknown,unknown
paths={n for n in visible|ignored if accepted(n) and not cache(n)}|GENERATED
archives={
'docs/voidup/evidence/llvm23-repair/original-ci/13558653075.zip':'8a4dd5d9e49ccd8240d6b18bf1e85af914054c34487cc7938579cc7f9b853d13',
'docs/voidup/evidence/llvm23-repair/original-ci/13558638061.zip':'9ee4f916532e9e3763270c421162feca809aed33ff07b33bcd3b9e2226d878a0',
'docs/voidup/evidence/llvm23-repair/original-ci/13558802832.zip':'65a37d6dd16cc349da545638afa465ef33a64bf8c6ba661a06f69d066e7c3ad4'}
for a in json.loads((OUT/'artifacts.json').read_text())['artifacts']:archives[str((OUT/(str(a['id'])+'.zip')).relative_to(ROOT))]=a['digest'].removeprefix('sha256:')
files={}
for n in sorted(paths-GENERATED):
 p=ROOT/n;assert p.is_file() and not p.is_symlink(),n
 if p.suffix.lower() in {'.pem','.key','.exe','.dll','.so','.a','.o','.obj','.gz','.xz','.zip','.pyc'}:
  assert n in archives and sha(p)==archives[n],('Unexpected key/build/archive',n)
 with p.open('rb') as f:head=f.read(128)
 assert not head.startswith((b'\x7fELF',b'MZ')) and b'PRIVATE KEY' not in head,('Executable/private key',n)
 files[n]=sha(p)
ordered=sorted(paths)
(OUT/'PENDING_PATHS.txt').write_text('\n'.join(ordered)+'\n');(OUT/'PENDING_PATHS.nul').write_bytes(b'\0'.join(n.encode() for n in ordered)+b'\0')
patches={'integration-repair-pending-source.patch':['CMakeLists.txt','cmake/InstallLicenses.cmake','cmake/host-sodium.targets',*[n for n in tracked if n.startswith(('tools/','tests/')) and not n.endswith('.md')]],'documentation-pending.patch':[n for n in tracked if n.endswith('.md') or n=='docs/release/NOTICE_INVENTORY.json']}
# Diffs are generated before final inventory in the caller, and hashed here.
for n in patches:assert (OUT/n).is_file(),n
required={'tools/ci/llvm_sdk.py','tools/setup_host_deps.py','tools/setup_host_deps_native.py','tools/verify_host_deps.py','cmake/host-sodium.targets','third_party/host-patches/libsodium-1.0.22/PROVENANCE.json','third_party/host-patches/libsodium-1.0.22/asan-alignment.patch','cmake/InstallLicenses.cmake','CMakeLists.txt','tests/host_capabilities/portable.cpp'};assert required<=paths
metadata={'schema':1,'scope':'All current pending accepted LLVM 23.1.4 repair, integrated backport, accepted documentation revision, macOS call-site correction and retained evidence; Phase A/B already in HEAD are not restaged wholesale.','head':git('rev-parse','HEAD').decode().strip(),'intended_paths':ordered,'intended_count':len(ordered),'tracked_pending_count':len(tracked),'new_visible_count':len(paths&untracked),'ignored_evidence_count':len(paths&ignored),'file_sha256':files,'self_hashes_omitted':sorted(GENERATED),'required_integration_paths':sorted(required),'explicit_evidence_archive_exceptions':archives,'excluded_visible_paths':sorted(visible&EXCLUDE),'excluded_protected_paths':sorted(EXCLUDE),'excluded_roots':['build*/','.toolchains/','**/__pycache__/','**/.void/'],'excluded_private_keys':['build/voidup-fixtures/keys/offline-1.pem','build/voidup-fixtures/keys/offline-2.pem','build/voidup-fixtures/keys/offline-3.pem'],'unclassified_pending_paths':unknown,'earlier_inventory':'docs/voidup/COMMIT_PATHS.* retained as historical; use this current pending allowlist for review','suggested_title':'Repair VOIDUP provider provenance, LLVM 23.1.4 selection and host test portability [skip ci]','recommended_staging_command':'git --literal-pathspecs add -f --pathspec-from-file=docs/voidup/evidence/ci-42369685905/PENDING_PATHS.nul --pathspec-file-nul','staging_performed':False,'staged_paths':names('diff','--cached','--name-only','-z') and sorted(names('diff','--cached','--name-only','-z')) or []}
assert not metadata['staged_paths']
(OUT/'PENDING_INVENTORY.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(len(ordered),'exact pending paths;',len(tracked),'tracked;',len(paths&ignored),'ignored evidence; no unclassified paths, build outputs or keys; no staging')
