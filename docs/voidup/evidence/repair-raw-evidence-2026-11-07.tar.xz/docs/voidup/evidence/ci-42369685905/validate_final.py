"""Final bounded repair checks; emits an allowlist/index but never stages files."""
from pathlib import Path
import hashlib,json,re,subprocess,urllib.parse
ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent

def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
base=json.loads((OUT/'baseline.json').read_text());allowed={'tests/host_capabilities/portable.cpp','docs/voidup/INTEGRATION_REPORT.md'}
changes=[n for n,h in base['hashes'].items() if not (ROOT/n).is_file() or sha(ROOT/n)!=h];assert set(changes)==allowed,changes
report=ROOT/'docs/voidup/INTEGRATION_REPORT.md';before=json.loads((OUT/'report-before.json').read_text());assert hashlib.sha256(report.read_bytes()[:before['bytes']]).hexdigest()==before['sha256']
previous=json.loads((ROOT/'docs/voidup/evidence/llvm23-repair/integration-2026-11-07/INDEX.json').read_text());assert all((ROOT/n).is_file() and sha(ROOT/n)==h for n,h in previous['files'].items())
old=subprocess.check_output(['git','show','HEAD:tests/host_capabilities/portable.cpp'],cwd=ROOT);current=(ROOT/'tests/host_capabilities/portable.cpp').read_bytes();assert old.replace(b'q=request(wait);',b'q=request(vd::host::wait);')==current
links=[];text=re.sub(r'```.*?```','',report.read_text(),flags=re.S)
for target in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',text):
 u=urllib.parse.urlsplit(target)
 if u.scheme or target.startswith('//'):continue
 p=(report.parent/urllib.parse.unquote(u.path)).resolve() if u.path else report
 assert p.exists(),target;links.append(target)
syntax=['fetch_ci.py','check_local.py','pending_inventory.py','validate_final.py']
for n in syntax:compile((OUT/n).read_text(),n,'exec')
whitespace=subprocess.run(['git','diff','--check'],cwd=ROOT,capture_output=True,text=True);assert whitespace.returncode==0,whitespace.stdout+whitespace.stderr
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True);head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip();assert not staged and head==base['head']
local=json.loads((OUT/'local-results.json').read_text());assert all(x.get('expected_outcome_observed',x['status']==0) for x in local)
package=json.loads((OUT/'license-package/validation.json').read_text());assert all(x['result']=='PASS' for x in package['results']) and len(package['results'])==5
result={'new_tracked_changes_this_assignment':changes,'only_source_change':'Qualify vd::host::wait in portable test; no production API change','previous_report_preserved_as_exact_prefix':True,'accepted_prior_integration_evidence_files_unchanged':len(previous['files']),'accepted_dependency_toolchain_source_and_pins_unchanged':True,'local_markdown_path_references_checked':len(links),'syntax':'PASS','git_diff_check_status':whitespace.returncode,'head':head,'head_unchanged':True,'staged_paths':[],'native_integrated_windows_macos':'UNQUALIFIED / NOT RUN','prior_full_provider_suites':'Retained 87/87 per Release/Debug/fatal strict; unchanged receipts reverified, suites not repeated for test-only edit','new_ctest_results':{'Release':'4/4','Debug':'3/3','strict':'3/3'},'package_audit':'5/5'}
(OUT/'final-verification.json').write_text(json.dumps(result,indent=2)+'\n')
subprocess.run(['python3',OUT/'pending_inventory.py'],cwd=ROOT,check=True)
metadata=json.loads((OUT/'PENDING_INVENTORY.json').read_text());assert all((ROOT/n).exists() for n in metadata['intended_paths'] if n!=str((OUT/'INDEX.json').relative_to(ROOT)))
assert all(sha(ROOT/n)==h for n,h in metadata['file_sha256'].items())
evidence={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='INDEX.json'}
index={'scope':'Read-only CI 42369685905 review, minimal host-test repair and exact pending integration inventory','report':'docs/voidup/INTEGRATION_REPORT.md','report_sha256':sha(report),'files':evidence,'pending_inventory':str((OUT/'PENDING_INVENTORY.json').relative_to(ROOT)),'pending_count':metadata['intended_count'],'self_omitted':True,'staging_or_hosted_dispatch_performed':False}
(OUT/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
assert all((ROOT/n).exists() for n in metadata['intended_paths'])
print('Final PASS:',len(previous['files']),'accepted evidence files preserved;',len(links),'local reference paths;',metadata['intended_count'],'exact pending paths; unchanged HEAD and empty index')
