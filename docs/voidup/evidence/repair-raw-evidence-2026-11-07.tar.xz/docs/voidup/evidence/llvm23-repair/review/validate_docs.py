from pathlib import Path
import json,re,subprocess,hashlib,urllib.parse,os,collections
ROOT=Path.cwd();E=ROOT/'docs/voidup/evidence/llvm23-repair';R=E/'review';BEFORE=ROOT/'build/llvm23-review/before'
baseline=json.loads((E/'documentation-baseline.json').read_text());moves=json.loads((R/'documentation-moves.json').read_text());originals={}
tracked=subprocess.check_output(['git','ls-files','*.md'],text=True).splitlines()
for name in tracked:originals[name]=subprocess.check_output(['git','show','HEAD:'+name],text=True)
pattern=re.compile(r'(!?\[[^\]\n]*\]\()([^\s)]+)(\))')
def codefree(s):return re.sub(r'(?ms)^```[^\n]*\n.*?^```[^\n]*$','',s)
def anchors(s):
 found=set();counts={}
 for text in re.findall(r'^#{1,6}\s+(.+)$',codefree(s),re.M):
  text=re.sub(r'\[([^\]]+)\]\([^)]*\)',r'\1',text)
  text=re.sub(r'[`*~]','',text).strip().lower();slug=re.sub(r'[^\w\- ]','',text).replace(' ','-')
  n=counts.get(slug,0);counts[slug]=n+1;found.add(slug+(f'-{n}' if n else ''))
 found.update(re.findall(r'<(?:a|span)\s+(?:name|id)=[\"\']([^\"\']+)',s))
 return found
# Old fragments that refer to one of the four now-concise handoffs remain at the immutable original.
for file in (ROOT/'docs').rglob('*.md'):
 if 'evidence' in file.parts or ('engineering' in file.parts and 'before' in file.parts):continue
 s=file.read_text()
 def redirect(m):
  name,sep,fragment=m[2].partition('#')
  if not sep or m[2].startswith(('#','/')) or ':' in name:return m[0]
  target=(file.parent/name).resolve()
  rel=target.relative_to(ROOT).as_posix() if target.is_relative_to(ROOT) else ''
  if rel.removeprefix('docs/') in moves['checkpoint_source_hashes'] and fragment not in anchors(target.read_text()):
   url='https://github.com/Shmellyorc/Void.Language/blob/'+moves['checkpoint_commit']+'/'+rel+'#'+fragment
   return m[1]+url+m[3]
  return m[0]
 result=pattern.sub(redirect,s)
 if result!=s:file.write_text(result)
# Enumerate repository Markdown with the same broad scope as the original baseline.
current={}
for parent,dirs,files in os.walk(ROOT):
 relative=Path(parent).relative_to(ROOT)
 dirs[:]=[name for name in dirs if name not in ['.git','.toolchains'] and not (len(relative.parts)==0 and name.startswith('build'))]
 for name in files:
  if name.endswith('.md'):
   path=Path(parent)/name;current[path.relative_to(ROOT).as_posix()]=path
added=sorted(set(current)-set(baseline));removed=sorted(set(baseline)-set(current))
protected=[]
for name,digest in baseline.items():
 parts=Path(name).parts
 if name=='README.md' or name.startswith(('third_party/','website/','experiments/')) or 'node_modules' in parts or 'evidence' in parts or ('engineering' in parts and 'before' in parts):
  if name not in current or hashlib.sha256(current[name].read_bytes()).hexdigest()!=digest:protected.append(name)
# Proposal bodies and labels remain exact, allowing only corrected relative URLs.
normalize=lambda s:pattern.sub(lambda m:m[1]+'<URL>'+m[3],s)
proposal_proof=[]
for name in moves['proposals_restored_at_stable_paths']:
 text=(ROOT/'docs'/name).read_text().split('\n\n',1)[1];old=originals['docs/'+name]
 good=normalize(text)==normalize(old);assert good,name
 proposal_proof.append({'path':'docs/'+name,'original_body_preserved_except_urls':good})
checkpoint_proof=[]
for name,digest in moves['checkpoint_source_hashes'].items():
 data=subprocess.check_output(['git','show',moves['checkpoint_commit']+':docs/'+name]);assert hashlib.sha256(data).hexdigest()==digest
 checkpoint_proof.append({'path':'docs/'+name,'commit':moves['checkpoint_commit'],'sha256':digest,'original_available_in_git':True})
# Validate maintained documentation, excluding immutable captured evidence. Compare all anchor/path problems with HEAD.
def links(file,text,old=False):
 rows=[]
 for m in pattern.finditer(codefree(text)):
  url=urllib.parse.unquote(m[2]);name,sep,fragment=url.partition('#')
  if re.match(r'[a-zA-Z][\w+.-]*:',url) or url.startswith('/'):continue
  target=(file.parent/name).resolve() if name else file
  rel=target.relative_to(ROOT).as_posix() if target.is_relative_to(ROOT) else str(target)
  if old and target.suffix=='.md':exists=rel in originals;body=originals.get(rel,'')
  else:exists=target.exists();body=target.read_text() if exists and target.suffix=='.md' else ''
  kind='missing-path' if not exists else ('missing-anchor' if fragment and target.suffix=='.md' and fragment not in anchors(body) else None)
  if kind:rows.append({'source':file.relative_to(ROOT).as_posix(),'target':m[2],'kind':kind})
 return rows
pre=[];post=[]
for file in (ROOT/'docs').rglob('*.md'):
 if 'evidence' in file.parts or ('engineering' in file.parts and 'before' in file.parts):continue
 name=file.relative_to(ROOT).as_posix();post+=links(file,file.read_text())
 if name in originals:pre+=links(file,originals[name],True)
prekeys={(v['source'],v['target'],v['kind']) for v in pre}
introduced=[v for v in post if (v['source'],v['target'],v['kind']) not in prekeys]
# Fixed-commit historical URLs: resolve their paths and anchors in the already-existing local Git tree.
remote=[];prefix='https://github.com/Shmellyorc/Void.Language/blob/'+moves['checkpoint_commit']+'/'
for file in (ROOT/'docs').rglob('*.md'):
 if 'evidence' in file.parts:continue
 for m in pattern.finditer(codefree(file.read_text())):
  if m[2].startswith(prefix):
   path,sep,fragment=urllib.parse.unquote(m[2][len(prefix):]).partition('#')
   text=subprocess.check_output(['git','show',moves['checkpoint_commit']+':'+path],text=True)
   ok=not fragment or fragment in anchors(text)
   remote.append({'source':file.relative_to(ROOT).as_posix(),'url':m[2],'git_target_and_anchor_valid':ok})
   if not ok:introduced.append({'source':file.relative_to(ROOT).as_posix(),'target':m[2],'kind':'missing-fixed-commit-anchor'})
result={'baseline_markdown_count':len(baseline),'current_markdown_count':len(current),'net_added_markdown':len(current)-len(baseline),'added_markdown':added,'removed_baseline_markdown':removed,'removed_since_previous_review':moves['removed_prior_added_markdown'],'protected_changes':protected,'proposal_preservation':proposal_proof,'checkpoint_preservation':checkpoint_proof,'fixed_commit_references':remote,'preexisting_maintained_link_problems':pre,'final_maintained_link_problems':post,'introduced_link_problems':introduced,'scope':'all maintained docs/ inline Markdown local paths/anchors outside fenced code; immutable fixed-commit targets verified in local Git, remote URLs were also fetched; raw evidence unchanged'}
(R/'documentation-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:len(value) if isinstance(value,list) else value for key,value in result.items() if key not in ['fixed_commit_references','scope']},indent=2))
for row in introduced[:30]:print(row)
assert not added and not removed and not protected
