from pathlib import Path
import subprocess,json,shutil
r=Path.cwd();root=r/'build/voidup-backport-integration/ubuntu-source';out=r/'docs/voidup/evidence/llvm23-repair/integration-2026-11-07/ubuntu-integrated';out.mkdir()
target=root/'tests/host_capabilities/dependencies.py';target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(r/'tests/host_capabilities/dependencies.py',target)
commands=[]
for label,args in [('identity',['python3','-c','import platform,json;print(json.dumps({"platform":platform.platform(),"libc":platform.libc_ver(),"os_release":open("/etc/os-release").read()}))']),('verify',['python3',str(root/'tools/verify_host_deps.py'),'--prefix',str(root/'.toolchains/host/prefix/Release'),'--profile','Release','--platform','Linux','--architecture','x86_64']),('receipt-negatives',['python3',str(root/'tests/host_capabilities/dependencies.py'),str(root/'.toolchains/host/prefix/Release'),'Release','Linux','x86_64'])]:
 with (out/(label+'.log')).open('wb') as log:result=subprocess.run(['podman','exec','voidup-portability-ubuntu',*args],stdout=log,stderr=subprocess.STDOUT)
 commands.append({'command':['podman','exec','voidup-portability-ubuntu',*args],'status':result.returncode})
 # The common negative script imports the live verifier; root-dependent recipe
 # paths differ, so its standalone invocation requires the copied test layout.
 if result.returncode:break
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for evidence in (root/'docs/voidup/evidence').iterdir():shutil.copytree(evidence,out/evidence.name)
assert all(c['status']==0 for c in commands)
