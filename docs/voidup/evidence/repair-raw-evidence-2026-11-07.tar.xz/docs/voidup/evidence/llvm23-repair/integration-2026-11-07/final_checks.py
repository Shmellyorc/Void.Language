"""Final read-only source checks and self-omitting integration evidence index."""
from pathlib import Path
import json,hashlib,subprocess
r=Path(__file__).resolve().parents[5];o=Path(__file__).resolve().parent

def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
files=['tools/setup_host_deps.py','tools/setup_host_deps_native.py','tools/verify_host_deps.py','tests/host_capabilities/dependencies.py','tests/host_capabilities/install.py']
for n in files:compile((r/n).read_text(),n,'exec')
whitespace=subprocess.run(['git','diff','--check'],cwd=r,capture_output=True,text=True);assert whitespace.returncode==0,whitespace.stderr+whitespace.stdout
patch=r/'third_party/host-patches/libsodium-1.0.22/asan-alignment.patch';prior=o.parent/'isolated-candidate-2026-11-07/libsodium-candidate-final.patch';assert patch.read_bytes()==prior.read_bytes()
summary=json.loads((o/'qualification-summary.json').read_text());preserved=json.loads((o/'preservation-final.json').read_text());review=json.loads((o/'review-validation.json').read_text());assert not preserved['unexpected_changes'] and not review['broken_links']
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=r,text=True).split('\0');markdown={n for n in tracked if n.endswith('.md')}
baseline={n for n in json.loads((o/'tracked-before.json').read_text()) if n.endswith('.md')};assert markdown==baseline
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','--','*.md'],cwd=r,text=True).strip()
checks={'syntax_files':files,'syntax':'PASS','git_diff_check_status':whitespace.returncode,'exact_accepted_patch_preserved':True,'tracked_markdown_baseline_count':len(baseline),'tracked_markdown_current_count':len(markdown),'new_untracked_markdown_files':0,'windows_selector_helper_and_targets_unchanged_this_assignment':preserved['windows_selector_implementation_preserved'],'native_windows_macos':'UNQUALIFIED / NOT RUN','staged_paths':preserved['staged_paths'],'head_unchanged':preserved['head_unchanged']}
(o/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
evidence={p.relative_to(r).as_posix():digest(p) for p in sorted(o.rglob('*')) if p.is_file() and p.name!='INDEX.json'}
index={'scope':'Controlled permanent integration of exact reviewed libsodium three-file candidate; no hosted/native Windows/macOS acceptance','report':'docs/voidup/INTEGRATION_REPORT.md','report_sha256':digest(r/'docs/voidup/INTEGRATION_REPORT.md'),'source_diff':str((o/'integrated-source.patch').relative_to(r)),'documentation_diff':str((o/'documentation-integration.patch').relative_to(r)),'files':evidence,'companion_provider_evidence_directories':[str(p.relative_to(r)) for p in sorted((r/'docs/voidup/evidence').glob('dependencies-linux-*-179404*'))],'note':'Earlier evidence is preserved separately; this self-omitting index does not replace original manifests or rewrite old results.'}
(o/'INDEX.json').write_text(json.dumps(index,indent=2)+'\n')
print('Final checks PASS; exact approved patch,',len(markdown),'tracked Markdown paths unchanged, clean whitespace, unchanged HEAD/index; indexed',len(evidence),'evidence files')
print('Results',{k:(v['upstream_targets_passed'],v['focused_ctest_passed']) for k,v in summary['profiles'].items()},'Ubuntu',summary['ubuntu_24_04_5_release']['upstream_targets_passed'])
