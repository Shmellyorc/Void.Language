from pathlib import Path
import subprocess,json,shutil
root=Path.cwd();base=root/'build/llvm23-review';before=base/'before';review=root/'docs/voidup/evidence/llvm23-repair/review'
# This comparison uses temporary snapshots, never the index or a Git object write.
old=base/'doc-before';new=base/'doc-after';old.mkdir(exist_ok=True);new.mkdir(exist_ok=True)
manifest=json.loads((before/'manifest.json').read_text())
for name in manifest:
 if not name.endswith('.md'):continue
 source=before/name;target=old/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
 if (root/name).exists():
  target=new/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/name,target)
command=['git','diff','--no-index','--no-ext-diff','--no-color','--break-rewrites','--find-renames=70%',str(old.relative_to(root)),str(new.relative_to(root))]
r=subprocess.run(command,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert r.returncode in [0,1],r.stderr
patch=r.stdout.replace('a/'+old.relative_to(root).as_posix()+'/','a/').replace('b/'+new.relative_to(root).as_posix()+'/','b/')
# Extended rename headers have no a/ or b/ prefix.
patch=patch.replace('rename from '+old.relative_to(root).as_posix()+'/','rename from ').replace('rename to '+new.relative_to(root).as_posix()+'/','rename to ')
(review/'documentation-revision.patch').write_text(patch)
md=subprocess.check_output(['git','diff','--no-ext-diff','--no-color','--','*.md'],cwd=root,text=True)
(review/'documentation-final.patch').write_text(md)
source=[name for name in subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines() if not name.endswith('.md')]
r=subprocess.check_output(['git','diff','--no-ext-diff','--no-color','--',*source],cwd=root,text=True)
(review/'windows-and-build-source.patch').write_text(r)
records={'documentation_revision_command':command,'documentation_revision_exit':1 if patch else 0,'documentation_revision_files':len([line for line in patch.splitlines() if line.startswith('diff --git')]),'documentation_final_files':len([line for line in md.splitlines() if line.startswith('diff --git')]),'retained_source_files':source,'proposal_separate_and_unapplied':'libsodium-candidate.patch'}
(review/'review-diffs.json').write_text(json.dumps(records,indent=2)+'\n')
print('Actual review diffs written:',records['documentation_revision_files'],'revision entries;',records['documentation_final_files'],'final Markdown entries;',len(source),'retained source entries.')
