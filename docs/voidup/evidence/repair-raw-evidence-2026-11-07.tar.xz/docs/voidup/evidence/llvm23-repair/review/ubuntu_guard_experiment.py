from pathlib import Path
import subprocess,json,time,shutil
root=Path.cwd();src=root/'build/llvm23-review/guard-experiment/source';build=root/'build/llvm23-review/ubuntu-guard-build';build.mkdir(exist_ok=True);evidence=root/'docs/voidup/evidence/llvm23-repair/review/ubuntu-guard-only';evidence.mkdir(exist_ok=True)
cc=root/'build/voidup-ubuntu-source/.toolchains/llvm-23.1.4/bin/clang';env={'CC':str(cc),'CFLAGS':'-g -O2 -fsanitize=address,undefined -fno-omit-frame-pointer','LDFLAGS':'-fsanitize=address,undefined','ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:exitcode=87','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1:exitcode=86','ASAN_SYMBOLIZER_PATH':str(cc.parent/'llvm-symbolizer')}
prefix=['podman','exec','-w',str(build)]
for key,value in env.items():prefix+=['-e',key+'='+value]
prefix+=['voidup-portability-ubuntu'];records=[]
for label,argv in [('configure',[src/'configure','--disable-shared','--enable-static','--enable-minimal','--disable-dependency-tracking']),('build',['make','-j3']),('check',['make','check','-j3'])]:
 command=[*prefix,*map(str,argv)];start=time.monotonic()
 with (evidence/(label+'.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,command=command,status=result.returncode,seconds=time.monotonic()-start));(evidence/'commands.json').write_text(json.dumps({'provider_sources_unchanged':True,'changed_source':['test/default/cmptest.h'],'no_install_performed':True,'environment':env,'results':records},indent=2)+'\n')
 if result.returncode:break
for pattern in ['*.log','*.trs']:
 for path in (build/'test/default').glob(pattern):shutil.copy2(path,evidence/path.name)
print(json.dumps(records[-1]))
