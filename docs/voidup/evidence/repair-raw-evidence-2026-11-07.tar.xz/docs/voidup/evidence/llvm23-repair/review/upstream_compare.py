from pathlib import Path
import json,urllib.request,hashlib,concurrent.futures
base=Path('build/llvm23-review/upstream');pins=json.loads(Path('third_party/host-versions.json').read_text());files=['src/libsodium/crypto_stream/salsa20/xmm6int/u1.h','src/libsodium/sodium/utils.c','src/libsodium/include/sodium/crypto_aead_aegis128l.h','src/libsodium/include/sodium/utils.h','test/default/cmptest.h','test/default/aead_aegis128l.c','test/default/codecs.c','test/default/generichash.c','test/default/generichash3.c','test/default/misuse.c','test/default/pwhash_argon2id.c','ChangeLog']
def get(item):
 branch,path=item;sha=json.loads((base/(branch+'.json')).read_text())['sha'];url=f'https://raw.githubusercontent.com/jedisct1/libsodium/{sha}/{path}'
 data=urllib.request.urlopen(url).read();out=base/branch/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 original=Path('.toolchains/host/sources/libsodium-1.0.22')/path
 return dict(branch=branch,commit=sha,path=path,url=url,sha256=hashlib.sha256(data).hexdigest(),identical_to_pin=data==original.read_bytes())
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(get,[(branch,path) for branch in ['master','stable'] for path in files]))
(base/'comparison.json').write_text(json.dumps(records,indent=2)+'\n')
for record in records:print(record['branch'],record['identical_to_pin'],record['path'])
for path in [files[0],files[1],files[4]]:
 url='https://api.github.com/repos/jedisct1/libsodium/commits?per_page=20&path='+path
 data=urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'VOID-local-review'})).read();(base/('history-'+Path(path).name+'.json')).write_bytes(data)
 print('history',path,[(v['sha'][:12],v['commit']['message'].splitlines()[0]) for v in json.loads(data)[:7]])
