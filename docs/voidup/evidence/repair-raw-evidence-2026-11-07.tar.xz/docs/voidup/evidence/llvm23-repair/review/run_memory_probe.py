from pathlib import Path
import subprocess,os,json
root=Path.cwd();base=root/'build/llvm23-review';evidence=root/'docs/voidup/evidence/llvm23-repair/review';sdk=root/'.toolchains/llvm-23.1.4/bin';source=base/'memory_contract_probe.c';build=base/'guard-experiment/build';pin=root/'.toolchains/host/sources/libsodium-1.0.22'
argv=list(map(str,[sdk/'clang','-O2','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-DCONFIGURED=1','-DNATIVE_LITTLE_ENDIAN=1','-I'+str(build/'src/libsodium/include'),'-I'+str(pin/'src/libsodium/include'),source,build/'src/libsodium/.libs/libsodium.a','--ld-path='+str(sdk/'ld.lld'),'-o',base/'memory-contract-probe']))
r=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(evidence/'memory-probe-build.log').write_text(r.stdout);assert r.returncode==0,r.stdout
records=[dict(command=argv,status=r.returncode)];env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86',ASAN_SYMBOLIZER_PATH=str(sdk/'llvm-symbolizer'))
for label,args,expected in [('valid',[],0),('invalid-null-zero',['invalid-null-zero'],86)]:
 command=[str(base/'memory-contract-probe'),*args];r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(evidence/('memory-probe-'+label+'.log')).write_text(r.stdout);assert r.returncode==expected,(label,r.returncode,r.stdout);records.append(dict(label=label,command=command,status=r.returncode,expected=expected))
(evidence/'memory-probe.json').write_text(json.dumps({'scope':'existing unmodified provider and existing endian helpers only; not the proposed cryptographic provider patch','results':records},indent=2)+'\n')
print('Existing helper/clear probe: valid calls PASS; original NULL/zero invalid call still fails with UBSan exit 86.')
