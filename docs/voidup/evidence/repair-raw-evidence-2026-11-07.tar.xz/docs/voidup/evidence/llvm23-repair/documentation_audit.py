from pathlib import Path
import json,re,os,hashlib,subprocess,urllib.parse
ROOT=Path.cwd();E=ROOT/'docs/voidup/evidence/llvm23-repair'
baseline=json.loads((E/'documentation-baseline.json').read_text())
archives=json.loads((E/'documentation-archives.json').read_text())
pat=re.compile(r'\[[^\]\n]*\]\(([^\s)]+)\)')
oldversion=re.compile(r'\b(?:LLVM|Clang|LLD)(?:/(?:LLVM|Clang|LLD))*[ *_`/-]*(?:(?:version|remains)[ *_`/-]*)?19(?:\b|\.)|\bLLVM19\b|llvm-19|clang\+\+-19|clang-19|llvmorg-19',re.I)
tracked=subprocess.check_output(['git','ls-files','*.md'],text=True).splitlines()
original={p:subprocess.check_output(['git','show','HEAD:'+p],text=True) for p in tracked}
for name in baseline:
 if name not in original and Path(name).exists():original[name]=Path(name).read_text()
# Markdown path references outside code fences; local target existence, plus heading anchors for moved docs.
def stripcode(s):return re.sub(r'(?ms)^```[^\n]*\n.*?^```[^\n]*$','',s)
def slug(title):return re.sub(r'[^\w\- ]','',re.sub(r'[*`_]','',title).lower()).replace(' ','-')
def anchors(text):
 out=set();counts={}
 for title in re.findall(r'^#{1,6}\s+(.+)$',stripcode(text),re.M):
  item=slug(title);count=counts.get(item,0);out.add(item+(f'-{count}' if count else ''));counts[item]=count+1
 out.update(re.findall(r'<a\s+(?:name|id)=[\"\']([^\"\']+)',text))
 return out

def links(paths,old=False):
 missing=[]
 for p,s in paths.items():
  for m in pat.finditer(stripcode(s)):
   target=m[1]
   if re.match(r'[a-zA-Z][\w+.-]*:',target) or target.startswith(('#','/')):continue
   name,_,fragment=urllib.parse.unquote(target).partition('#')
   resolved=(ROOT/Path(p).parent/name).resolve()
   rel=os.path.relpath(resolved,ROOT)
   exists=rel in original if old and resolved.suffix=='.md' else resolved.exists()
   if not exists:missing.append({'source':p,'target':target,'kind':'missing-path'})
   elif fragment and (rel in ['docs/'+v for v in archives] or rel.startswith('docs/history/')):
    body=original.get(rel,'') if old else resolved.read_text()
    if fragment not in anchors(body):missing.append({'source':p,'target':target,'kind':'missing-moved-anchor'})
 return missing
changed={}
for p in tracked:
 if Path(p).exists() and Path(p).read_text()!=original[p]:changed[p]=Path(p).read_text()
for p in (ROOT/'docs/history').rglob('*.md'):changed[str(p.relative_to(ROOT))]=p.read_text()
for p in ['docs/TOOLCHAIN.md','docs/DOCUMENTATION_CLEANUP.md','docs/voidup/LLVM23_CI_REPAIR.md']:
 if Path(p).exists():changed[p]=Path(p).read_text()
pre=links(original,True);post=links({**original,**changed})
prekeys={(v['source'],v['target'],v['kind']) for v in pre}
new=[v for v in post if (v['source'],v['target'],v['kind']) not in prekeys]
# Rebased existing historical links may retain pre-existing absent files.
archive_new=[]
reverse={v['archive']:'docs/'+k for k,v in archives.items()}
for row in new:
 old=reverse.get(row['source'])
 if old:
  target,sep,fragment=row['target'].partition('#')
  absolute=(ROOT/Path(row['source']).parent/target).resolve()
  original_url=Path(os.path.relpath(absolute,(ROOT/old).parent)).as_posix()+(sep+fragment if sep else '')
  if (old,original_url,row['kind']) in prekeys:archive_new.append(row)
new=[row for row in new if row not in archive_new]
archive_integrity=[]
for name,record in archives.items():
 before=original['docs/'+name];after=Path(record['archive']).read_text().split('\n\n',1)[1]
 # Only relative URLs change in preserved bodies; their labels and all surrounding text remain exact.
 normalize=lambda text: re.sub(r'(\[[^\]\n]*\]\()([^\s)]+)(\))',r'\1<URL>\3',text)
 equal=normalize(before)==normalize(after)
 archive_integrity.append({'original':'docs/'+name,'archive':record['archive'],'source_sha256':record['sha256'],'body_preserved_except_relative_urls':equal})
 assert equal,name
protected=[]
for name,digest in baseline.items():
 if name=='README.md' or name.startswith(('third_party/','website/','experiments/')) or 'node_modules' in Path(name).parts or 'evidence' in Path(name).parts or ('engineering' in Path(name).parts and 'before' in Path(name).parts):
  if not Path(name).exists() or hashlib.sha256(Path(name).read_bytes()).hexdigest()!=digest:protected.append(name)
inventory=[]
for name in sorted(set(original)|set(changed)):
 if not Path(name).exists():continue
 text=Path(name).read_text();p=Path(name)
 if name.startswith('third_party/') or 'node_modules' in p.parts:kind='vendored dependency documentation (immutable)'
 elif name.startswith('experiments/'):kind='historical experiment/captured documentation (immutable)'
 elif name.startswith('website/'):kind='website documentation (out of scope, unchanged)'
 elif 'evidence' in p.parts or ('engineering' in p.parts and 'before' in p.parts):kind='historical evidence (immutable)'
 elif name.startswith('docs/history/') or any(x in name for x in ['/stage7/','/stage8/','/stage9/','/stage10/','/stage11/','/research/','tests/research/']):kind='historical record'
 elif p.name.endswith('_PROPOSAL.md'):kind='historical proposal redirect'
 elif p.name in ['RESEARCH.md','ROADMAP.md','ACCEPTANCE.md','HANDOFF.md','IMPLEMENTATION.md','BENCHMARKS.md','VALIDATION.md'] or any(x in p.name for x in ['REPORT','REPAIR','QUALIFICATION','INCIDENT','FAILURE','REVIEW','EVIDENCE']) or p.name in ['WORK_LOG.md','DECISIONS.md','LANGUAGE_COMPLETENESS_APPROVALS.md','LANGUAGE_COMPLETENESS_AUDIT.md','LANGUAGE_COMPLETENESS_ROADMAP.md','CI_NODE24_MAINTENANCE.md','CI_SANITIZER_ABI.md']:
  kind='engineering decision/evidence record (dated scope)'
 else:kind='canonical/reference or current engineering navigation'
 hits=[{'line':n,'text':line} for n,line in enumerate(text.splitlines(),1) if oldversion.search(line)]
 inventory.append({'path':name,'classification':kind,'older_toolchain_references':hits})
(E/'documentation-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
result={'baseline_markdown_count':len(baseline),'tracked_or_new_markdown_count':len(inventory),'changed_markdown_count':len(changed),'archive_count':len(archives),'archive_integrity':archive_integrity,'protected_changes':protected,'void_owned_original_missing_references':[r for r in pre if r['source'].startswith('docs/') and 'evidence' not in Path(r['source']).parts and not ('engineering' in Path(r['source']).parts and 'before' in Path(r['source']).parts)],'void_owned_final_missing_references':[r for r in post if r['source'].startswith('docs/') and 'evidence' not in Path(r['source']).parts and not ('engineering' in Path(r['source']).parts and 'before' in Path(r['source']).parts)],'original_missing_references':pre,'final_missing_references':post,'new_missing_references':new,'rebased_historical_missing_references':archive_new,'scope':'local Markdown path links outside fenced code; moved-document heading anchors; external HTTP availability not asserted'}
(E/'documentation-links.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in result.items() if k not in ['archive_integrity','original_missing_references','final_missing_references','rebased_historical_missing_references']},indent=2))
for row in new[:25]:print(row)
