from pathlib import Path
import re,os,json,subprocess,hashlib
ROOT=Path.cwd();DOC=ROOT/'docs';BEFORE=ROOT/'build/llvm23-review/before';REVIEW=DOC/'voidup/evidence/llvm23-repair/review';REVIEW.mkdir(parents=True,exist_ok=True)
commit='82e97f541fab7eec760083383569ab9c9ce8f355';github='https://github.com/Shmellyorc/Void.Language/blob/'+commit+'/'
archives=json.loads((DOC/'voidup/evidence/llvm23-repair/documentation-archives.json').read_text())
# Exactly the 22 Markdown files introduced by the prior pass; no baseline files are removed.
new=[DOC/'TOOLCHAIN.md',DOC/'DOCUMENTATION_CLEANUP.md',DOC/'voidup/LLVM23_CI_REPAIR.md',*(DOC/'history').rglob('*.md')]
assert len(new)==22
tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines())
assert not any(p.relative_to(ROOT).as_posix() in tracked for p in new)
# Preserve the 14 original proposals at their existing stable locations, with explicit historical scope.
proposals=[];mapping={}
for name,record in archives.items():
 old=ROOT/record['archive']
 if name.endswith('_PROPOSAL.md'):
  target=DOC/name;original=subprocess.check_output(['git','show','HEAD:docs/'+name],text=True)
  target.write_text('> **Historical proposal.** Original decisions, approvals and dated evidence\n> below retain their scope. Earlier toolchain pins and activation gates are\n> superseded; current operations require [LLVM/Clang/LLD 23.1.4](SOURCE_COMPILER.md#active-toolchain).\n> The delivered contract is linked from the [documentation index](README.md).\n\n'+original)
  mapping[old]=(target,None);proposals.append(name)
 else:
  # These four originals already exist, byte-for-byte, in committed history.
  original=subprocess.check_output(['git','show',commit+':docs/'+name])
  assert hashlib.sha256(original).hexdigest()==record['sha256'],name
  mapping[old]=(None,github+'docs/'+name)
# A single active toolchain section in the existing build guide; preserve the useful Windows detail.
p=DOC/'SOURCE_COMPILER.md';s=p.read_text();assert '## Active toolchain\n' not in s
section='''## Active toolchain

VOID.Language uses **LLVM/Clang/LLD 23.1.4 exclusively**. Use the complete SDK
from the [existing verified archive recipe](../tools/ci/llvm_sdk.py); no ambient
LLVM selection or older-version fallback is permitted. The platform prerequisites
and commands below remain authoritative. Historical results retain their actual
LLVM versions and cannot serve as current build recipes.

For Windows host providers, derive MSBuild's `LLVMToolsVersion` from the pinned
`clang-cl.exe /clang:-print-resource-dir` result. Its directory leaf can differ
from the full release version. Pass the verified `LLVMInstallDir` and explicit
compiler/linker/librarian paths together; preserve `/MT` for Debug and Release.
Missing or mismatched components fail before compilation. [The integration record](voidup/INTEGRATION_REPORT.md#llvm-2314-ci-repair)
separates the source correction from unverified native execution.

'''
s=s.replace('## Building the compiler\n',section+'## Building the compiler\n',1);p.write_text(s)
mapping[DOC/'TOOLCHAIN.md']=(p,'#active-toolchain')
# Current repair details move into the already-existing integration report.
p=DOC/'voidup/INTEGRATION_REPORT.md';s=p.read_text();current=(DOC/'voidup/LLVM23_CI_REPAIR.md').read_text()
current=current.replace('# LLVM 23.1.4 host-provider CI repair\n','#PLACEHOLDER\n',1).replace('#PLACEHOLDER','## LLVM 23.1.4 CI repair',1)
# Avoid duplicate subsection anchors under the older integration report.
current=re.sub(r'^## (?!LLVM 23\.1\.4 CI repair)', '### ',current,flags=re.M)
s+='\n\n'+current
p.write_text(s);mapping[DOC/'voidup/LLVM23_CI_REPAIR.md']=(p,'#llvm-2314-ci-repair')
# Consolidation evidence belongs in this report, rather than another active document.
mapping[DOC/'DOCUMENTATION_CLEANUP.md']=(p,'#documentation-review-revision')
mapping[DOC/'history/README.md']=(DOC/'README.md','#historical-records')
# Rebase every local Markdown reference to a relocated document. Raw evidence stays immutable.
link=re.compile(r'(!?\[[^\]\n]*\]\()([^\s)]+)(\))')
for file in DOC.rglob('*.md'):
 if file in new or 'evidence' in file.parts or ('engineering' in file.parts and 'before' in file.parts):continue
 text=file.read_text()
 def change(m):
  value=m[2]
  if re.match(r'[a-zA-Z][\w+.-]*:',value) or value.startswith(('#','/')):return m[0]
  name,sep,fragment=value.partition('#');target=(file.parent/name).resolve()
  if target not in mapping:return m[0]
  local,destination=mapping[target]
  if local is None:url=destination+(sep+fragment if sep else '')
  else:
   url=Path(os.path.relpath(local,file.parent)).as_posix()
   # Existing anchors in the moved CI report are retained; its main title is redirected.
   url+=('#'+fragment if fragment else (destination or ''))
  return m[1]+url+m[3]
 file.write_text(link.sub(change,text))
# Replace the archival navigation with references to records that already exist.
p=DOC/'README.md';s=p.read_text();start=s.index('## Historical records\n');end=s.index('## Clanker entry point',start)
s=s[:start]+'''## Historical records

[Work log](WORK_LOG.md), [decisions](DECISIONS.md),
[approval ledger](LANGUAGE_COMPLETENESS_APPROVALS.md), module implementation reports
and Stage 7–11 acceptance records retain original decisions, CI links and failures.
Original proposal bodies remain at their existing `*_PROPOSAL.md` paths, labeled
historical; API guides above define delivered behavior.

The earlier index, Wrench, Research and strategy checkpoints already exist at
immutable commit `82e97f541fab7eec760083383569ab9c9ce8f355`:
[chronology]('''+github+'''docs/README.md),
[Wrench/workshop]('''+github+'''docs/WRENCH_CLANKER.md),
[Research]('''+github+'''docs/RESEARCH_CLANKER.md),
[strategy]('''+github+'''docs/DEVELOPMENT_STRATEGY.md).
The same originals are available offline with `git show <commit>:docs/<file>`.
Their old toolchain recipes and pending-stage holds are historical, not current
instructions. No second set of full checkpoint copies is maintained.

'''+s[end:];p.write_text(s)
# State the independent architecture role and workshop continuity plainly.
p=DOC/'WRENCH_CLANKER.md';s=p.read_text();s=s.replace('Wrench reviews decisions and evidence; Keyboard implements the authorized work','Wrench independently reviews architecture, source changes, complexity and evidence;\nKeyboard implements the authorized work')
s=s.replace('## Permanent workflow for every new development stage','''## Workshop continuity

Boss owns VOID and the final architecture/product decisions. Golden Wrench is the
architecture partner, independent source/evidence reviewer, planning partner and
keeper of the engineering thread. Research investigates concrete uncertainties;
Keyboard builds the authorized work. Implementation does not review itself into
acceptance, and Wrench does not claim Keyboard's changes as its own. Preserve the
known incidents, owner decisions and native qualification limits when handing off.

**THREE CLANKERS. ONE VOID. STRONG BOLTS. NO GHOST BOLTS!**

## Permanent workflow for every new development stage''',1)
s=s.replace('Its dated\nassignments','Those dated\nassignments').replace('The [archived Wrench record]','The [original Wrench/workshop record]')
s=s.replace('## Current integration review\n','## Current integration review\n\nGolden Wrench returned **REVISE**. Retain the Windows LLVM 23.1.4 selector\ncandidate for actual native verification. The proposed libsodium correction\nrequires Boss/Wrench approval before any provider or pin change.\n')
p.write_text(s)
# Only remove the explicitly enumerated, newly-created redundant Markdown files.
for file in new:file.unlink()
record={'prior_added_markdown':22,'removed_prior_added_markdown':[v.relative_to(ROOT).as_posix() for v in new],'baseline_markdown_removed':[],'proposals_restored_at_stable_paths':proposals,'checkpoint_commit':commit,'checkpoint_source_hashes':{name:r['sha256'] for name,r in archives.items() if name not in proposals},'toolchain_destination':'docs/SOURCE_COMPILER.md#active-toolchain','repair_destination':'docs/voidup/INTEGRATION_REPORT.md#llvm-2314-ci-repair','documentation_destination':'docs/voidup/INTEGRATION_REPORT.md#documentation-review-revision'}
(REVIEW/'documentation-moves.json').write_text(json.dumps(record,indent=2)+'\n')
print('Removed 22 prior-added Markdown files; 14 original proposals restored; 4 checkpoints retained at verified immutable Git revision.')
