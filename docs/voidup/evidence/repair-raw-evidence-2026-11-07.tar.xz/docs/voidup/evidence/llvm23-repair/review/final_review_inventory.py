from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();base=root/'docs/voidup/evidence/llvm23-repair';review=base/'review';out=review/'changed-files.json'
modified=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();paths=set(modified)|{p.relative_to(root).as_posix() for p in base.rglob('*') if p.is_file()};records=[]
for name in sorted(paths):
 p=root/name
 assert not name.startswith(('.toolchains/','build/','src/','include/','stdlib/','apps/','third_party/','website/','.github/')),name
 assert p.suffix.lower() not in ['.exe','.obj','.o','.a','.lib','.key','.pem','.pfx','.p12'],name
 records.append({'path':name,'status':'modified' if name in modified else 'new','sha256':None if p==out else hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':None if p==out else p.stat().st_size})
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'current_modified_tracked':modified,'removed_since_previous_review':json.loads((review/'documentation-moves.json').read_text())['removed_prior_added_markdown'],'removed_from_original_git_tree':subprocess.check_output(['git','diff','--diff-filter=D','--name-only'],text=True).splitlines(),'files':records,'pin_file_changed':bool(subprocess.check_output(['git','diff','--','third_party/host-versions.json'],text=True)),'staged_paths':subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines(),'proposal_integration_status':'NOT APPLIED; retained Windows/build sources unchanged since first review; only a disposable test-harness copy was edited','scope':'Exact current local review paths, including ignored evidence. Previous review inventory/diagnostics are immutable historical snapshots; no generated native binaries, private keys or unrelated paths included.'}
assert not record['staged_paths'] and not record['pin_file_changed'] and not record['removed_from_original_git_tree']
out.write_text(json.dumps(record,indent=2)+'\n');print('Current review inventory:',len(records),'paths;',len(modified),'tracked modifications; no staged paths or original file removals.')
