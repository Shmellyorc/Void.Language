"""Repeat retained supplemental fault controls against the installed strict archive."""
from pathlib import Path
import json,subprocess,os,hashlib
ROOT=Path(__file__).resolve().parents[5];OUT=Path(__file__).resolve().parent/'strict-controls';OUT.mkdir()
SDK=ROOT/'.toolchains/llvm-23.1.4';prefix=ROOT/'.toolchains/host/prefix/strict';source=Path(__file__).resolve().parent.parent/'isolated-candidate-2026-11-07/negative_coverage_probe.c';executable=ROOT/'build/voidup-backport-integration/strict-negative-probe'
environment={'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:exitcode=87','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1:exitcode=86','ASAN_SYMBOLIZER_PATH':str(SDK/'bin/llvm-symbolizer')};env=dict(os.environ,**environment)
records=[]
compile=[str(SDK/'bin/clang'),'-O2','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(prefix/'include'),str(source),str(prefix/'lib/libsodium.a'),'--ld-path='+str(SDK/'bin/ld.lld'),'-o',str(executable)]
for name,command in [('compile',compile)]+[(case,[str(executable),*([case] if case!='valid' else [])]) for case in ('valid','overflow','underflow','guard-read')]:
 r=subprocess.run(command,env=env,capture_output=True,text=True);(OUT/(name+'.log')).write_text(r.stdout+r.stderr)
 expected=r.returncode==0 if name in ('compile','valid') else r.returncode in (86,87) and 'AddressSanitizer' in r.stderr+r.stdout
 records.append({'name':name,'command':command,'status':r.returncode,'expected_outcome_observed':expected})
 (OUT/'results.json').write_text(json.dumps({'scope':'Supplemental controls, not additional upstream passes or complete coverage of their two oracle bypasses','probe_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'environment':environment,'records':records},indent=2)+'\n')
 assert expected,(name,r.returncode,r.stdout,r.stderr)
print('Strict installed provider: valid guard/no-op exit 0; three invalid accesses fatal with ASan diagnostics')
