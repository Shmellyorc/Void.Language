from pathlib import Path
import difflib,json,hashlib,subprocess
root=Path.cwd();source=root/'.toolchains/host/sources/libsodium-1.0.22';research=root/'build/llvm23-review/upstream';out=root/'docs/voidup/evidence/llvm23-repair/review';out.mkdir(parents=True,exist_ok=True)
pin=json.loads((root/'third_party/host-versions.json').read_text())['libsodium'];upstream=json.loads((research/'alignment-fix.json').read_text());changes={}
name='test/default/cmptest.h';before=(source/name).read_text();needle='# if defined(__EMSCRIPTEN__) || defined(__SANITIZE_ADDRESS__)';assert before.count(needle)==1;changes[name]=(before,before.replace(needle,'# if defined(__EMSCRIPTEN__)'))
for file in upstream['files']:
 name=file['filename'];before=(source/name).read_text();assert (research/'alignment-before'/name).read_text()==before
 changes[name]=(before,(research/'alignment-after'/name).read_text())
patch=f'''PROPOSAL ONLY: requires explicit Boss / Golden Wrench approval before application.
No production provider source, installed library, pin, archive hash or sanitizer setting has been changed.
Base: libsodium {pin['version']}, revision {pin['revision']}
Archive SHA-256: {pin['sha256']}
Alignment: exact source hunks from upstream {upstream['sha']} (ISC).
Test harness: local one-line candidate; upstream uses the same guarded allocation in its non-ASan branch.
All 87 test targets, assertions and expected outputs remain; no suppressions or annotation changes.

'''
records=[]
for name,(before,after) in changes.items():
 patch+='diff --git a/'+name+' b/'+name+'\n'+''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 records.append({'path':name,'before_sha256':hashlib.sha256(before.encode()).hexdigest(),'proposed_sha256':hashlib.sha256(after.encode()).hexdigest(),'origin':'local test-harness candidate' if name.startswith('test/') else 'exact upstream '+upstream['sha'],'applied_to_production':False})
path=out/'libsodium-candidate.patch';path.write_text(patch)
command=['patch','--dry-run','--batch','--fuzz=0','-p1','-i',str(path)]
result=subprocess.run(command,cwd=source,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/'candidate-dry-run.log').write_text(result.stdout);assert result.returncode==0,result.stdout
(out/'candidate.json').write_text(json.dumps({'status':'PROPOSED / NOT APPLIED','pin_unchanged':pin,'alignment_commit':upstream['sha'],'files':records,'dry_run':{'command':command,'status':result.returncode},'full_candidate_test_status':'UNTESTED: applying cryptographic provider hunks requires Boss / Golden Wrench approval','test_harness_only_experiment':'83/87 PASS, four alignment failures, zero skips; provider sources unchanged'},indent=2)+'\n')
print('Prepared unapplied 3-file source proposal; patch --dry-run --fuzz=0 accepts every hunk.')
