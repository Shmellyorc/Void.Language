"""One isolated three-file candidate experiment; never installs or updates recipes."""
from pathlib import Path
import concurrent.futures, hashlib, json, os, re, shutil, subprocess, sys, tarfile, time

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
WORK = ROOT / 'build/llvm23-isolated-candidate-2026-11-07'
REVIEW = ROOT / 'docs/voidup/evidence/llvm23-repair/review'
sys.path.insert(0, str(ROOT / 'tools'))
from verify_host_deps import source_tree
sys.path.insert(0, str(ROOT / 'tools/ci'))
import llvm_sdk


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def entries(directory):
    return {p.relative_to(directory).as_posix():
            ('symlink', os.readlink(p)) if p.is_symlink() else ('file', sha(p))
            for p in sorted(directory.rglob('*')) if p.is_symlink() or p.is_file()}


def protected_snapshot():
    tracked = subprocess.check_output(['git', 'ls-files', '-z']).decode().split('\0')
    paths = {ROOT / name for name in tracked if name}
    paths.update(p for p in (ROOT / 'docs').rglob('*') if p.is_file() and not p.is_relative_to(OUT))
    for folder in ['.toolchains/host/downloads', '.toolchains/host/sources', '.toolchains/host/prefix']:
        paths.update(p for p in (ROOT / folder).rglob('*') if p.is_file() or p.is_symlink())
    return {p.relative_to(ROOT).as_posix():
            ('symlink', os.readlink(p)) if p.is_symlink() else ('file', sha(p))
            for p in sorted(paths)}


def execute(folder, label, argv, *, cwd=ROOT, env=None, timeout=1200):
    command = list(map(str, argv))
    start = time.monotonic()
    with (folder / (label + '.log')).open('wb') as log:
        try:
            result = subprocess.run(command, cwd=cwd, env=env, stdout=log,
                                    stderr=subprocess.STDOUT, timeout=timeout)
            status = result.returncode
        except subprocess.TimeoutExpired:
            status = 'TIMEOUT'
    record = dict(command=command, cwd=str(cwd), status=status,
                  seconds=time.monotonic() - start)
    save(folder / (label + '.json'), record)
    print(folder.name, label, status, flush=True)
    return record


def experiment(label, sdk, baseline_names, archive, candidate):
    folder = OUT / label
    folder.mkdir()
    base = WORK / label
    source_parent = base / 'extract'
    source_parent.mkdir(parents=True)
    # Fresh independent extraction on both platforms, not a reused prior build.
    with tarfile.open(archive) as package:
        package.extractall(source_parent, filter='data')
    source = source_parent / 'libsodium-1.0.22'
    source_tree(archive, source)
    pristine = entries(source)
    plan = {item['path']: item for item in candidate['files']}
    for name, item in plan.items():
        assert sha(source / name) == item['before_sha256'], name
    applied = execute(folder, 'apply-reviewed-patch',
                      ['patch', '--batch', '--fuzz=0', '-p1', '-i', OUT / 'libsodium-candidate-final.patch'],
                      cwd=source)
    assert applied['status'] == 0
    patched = entries(source)
    changed = [name for name in pristine.keys() | patched.keys()
               if pristine.get(name) != patched.get(name)]
    assert set(changed) == set(plan), changed
    for name, item in plan.items():
        assert sha(source / name) == item['proposed_sha256'], name
    save(folder / 'source-provenance.json', dict(
        archive_sha256=sha(archive), patch_sha256=sha(OUT / 'libsodium-candidate-final.patch'),
        changed_files=sorted(changed), before=pristine, after=patched,
        patched_tree_sha256=hashlib.sha256(json.dumps(patched, sort_keys=True).encode()).hexdigest(),
        assertions_and_expected_vectors_unchanged=True,
        permanent_sources_and_recipes_modified=False))
    build = base / 'build'
    build.mkdir()
    tools = {name: sdk / 'bin' / name for name in
             ['clang', 'clang++', 'ld.lld', 'llvm-ar', 'llvm-ranlib', 'llvm-symbolizer']}
    assert json.loads((sdk / 'void-sdk-identity.json').read_text()) == llvm_sdk.archive_identity()
    environment = dict(CC=str(tools['clang']), CXX=str(tools['clang++']),
        AR=str(tools['llvm-ar']), RANLIB=str(tools['llvm-ranlib']), LD=str(tools['ld.lld']),
        CFLAGS='-g -O2 -fsanitize=address,undefined -fno-omit-frame-pointer',
        LDFLAGS='-fsanitize=address,undefined --ld-path=' + str(tools['ld.lld']),
        ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',
        UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86',
        ASAN_SYMBOLIZER_PATH=str(tools['llvm-symbolizer']))
    prefix = []
    if label == 'ubuntu':
        prefix = ['podman', 'exec', '-w', str(build)]
        for key, value in environment.items():
            prefix += ['-e', key + '=' + value]
        prefix += ['voidup-portability-ubuntu']
    env = dict(os.environ, **environment) if not prefix else None
    versions = {}
    for name, path in tools.items():
        command = [*prefix, str(path), '--version']
        output = subprocess.check_output(command, cwd=build, env=env, text=True)
        assert re.search(r'\b23\.1\.4(?:\D|$)', output), (name, output)
        versions[name] = dict(path=str(path), version=output.strip(), sha256=sha(path))
    save(folder / 'toolchain.json', dict(identity=llvm_sdk.archive_identity(), tools=versions,
                                        environment=environment))
    for file, argv in [('os', ['cat', '/etc/os-release']), ('kernel', ['uname', '-a']),
                       ('libc', ['getconf', 'GNU_LIBC_VERSION'])]:
        execute(folder, file, [*prefix, *argv], cwd=build, env=env)
    steps = []
    for stage, argv in [
        ('configure', [source / 'configure', '--prefix=' + str(base / 'NOT-INSTALLED'),
                       '--disable-shared', '--enable-static', '--enable-minimal',
                       '--disable-dependency-tracking']),
        ('build', ['make', '-j3']), ('check', ['make', 'check', '-j3'])]:
        row = execute(folder, stage, [*prefix, *map(str, argv)], cwd=build, env=env)
        steps.append(row)
        save(folder / 'commands.json', steps)
        if stage != 'check' and row['status'] != 0:
            return dict(platform=label, build_blocked=stage, status=row['status'])
    testdir = build / 'test/default'
    statuses = {}
    for path in sorted(testdir.glob('*.trs')):
        text = path.read_text()
        match = re.search(r'^:test-result: (\S+)', text, re.M)
        statuses[path.stem] = match[1] if match else 'MISSING_RESULT'
    assert set(statuses) == set(baseline_names), (label, set(statuses) ^ set(baseline_names))
    for name in ['config.log', 'config.status', 'test/default/Makefile', 'src/libsodium/Makefile']:
        path = build / name
        if path.is_file():
            dest = folder / 'build-metadata' / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, dest)
    for pattern in ['*.log', '*.trs', '*.res']:
        for path in testdir.glob(pattern):
            shutil.copy2(path, folder / path.name)
    vectors = {}
    for name in statuses:
        expected, actual = source / 'test/default' / (name + '.exp'), testdir / (name + '.res')
        vectors[name] = dict(expected_exists=expected.is_file(), actual_exists=actual.is_file())
        if expected.is_file() and actual.is_file():
            vectors[name].update(expected_sha256=sha(expected), actual_sha256=sha(actual),
                                 exact_match=expected.read_bytes() == actual.read_bytes())
    save(folder / 'existing-vector-results.json', vectors)
    assert entries(source) == patched, 'Build changed candidate source tree'
    assert not (base / 'NOT-INSTALLED').exists(), 'Unexpected installation'
    # Inspect the test archive, never install/copy it into a permanent prefix.
    archive_file = build / 'src/libsodium/.libs/libsodium.a'
    summary = dict(platform=label, statuses=statuses,
                   passed=sorted(n for n, status in statuses.items() if status == 'PASS'),
                   failures=sorted(n for n, status in statuses.items() if status == 'FAIL'),
                   skipped=sorted(n for n, status in statuses.items() if status == 'SKIP'),
                   vector_mismatches=sorted(n for n, row in vectors.items() if not row.get('exact_match', False)),
                   archive_sha256=sha(archive_file), check_status=steps[-1]['status'],
                   unchanged_source_after_build=True, installed=False)
    save(folder / 'results.json', summary)
    return summary


def main():
    assert llvm_sdk.VERSION == '23.1.4'
    assert not WORK.exists(), 'Refusing to overwrite an existing experiment'
    WORK.mkdir(parents=True)
    before = protected_snapshot()
    save(OUT / 'protected-before.json', before)
    save(OUT / 'git-before.json', dict(
        head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        status=subprocess.check_output(['git', 'status', '--short'], text=True),
        staged=subprocess.check_output(['git', 'diff', '--cached', '--name-only'], text=True)))
    pins = json.loads((ROOT / 'third_party/host-versions.json').read_text())
    candidate = json.loads((REVIEW / 'candidate.json').read_text())
    assert pins['libsodium'] == candidate['pin_unchanged']
    archive = ROOT / '.toolchains/host/downloads/libsodium-1.0.22.tar.gz'
    assert sha(archive) == pins['libsodium']['sha256']
    source_tree(archive, ROOT / '.toolchains/host/sources/libsodium-1.0.22')
    shutil.copy2(REVIEW / 'libsodium-candidate.patch', OUT / 'libsodium-candidate-final.patch')
    assert sha(OUT / 'libsodium-candidate-final.patch') == 'f0de9004b8129626e14750437f51eb9524f030149607b50bb75ce0b6c998af74'
    expected = sorted(p.stem for p in (REVIEW / 'guard-only').glob('*.trs'))
    assert len(expected) == 87
    labels = {'pikaos': ROOT / '.toolchains/llvm-23.1.4',
              'ubuntu': ROOT / 'build/voidup-ubuntu-source/.toolchains/llvm-23.1.4'}
    results = {}
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures = {pool.submit(experiment, label, sdk, expected, archive, candidate): label
                       for label, sdk in labels.items()}
            for future in concurrent.futures.as_completed(futures):
                label = futures[future]
                try:
                    results[label] = future.result()
                except Exception as error:
                    results[label] = dict(exception=type(error).__name__, diagnostic=str(error))
                save(OUT / 'results.json', results)
    finally:
        after = protected_snapshot()
        changed = [name for name in before.keys() | after.keys() if before.get(name) != after.get(name)]
        save(OUT / 'preservation.json', dict(protected_file_count=len(before), changed=changed,
             existing_production_and_documentation_preserved=not changed,
             staged=subprocess.check_output(['git', 'diff', '--cached', '--name-only'], text=True)))
        assert not changed, changed
    print(json.dumps({label: {'passed': len(row.get('passed', [])),
        'failures': row.get('failures', []), 'skipped': row.get('skipped', []),
        'exception': row.get('exception')} for label, row in results.items()}), flush=True)


if __name__ == '__main__':
    main()
