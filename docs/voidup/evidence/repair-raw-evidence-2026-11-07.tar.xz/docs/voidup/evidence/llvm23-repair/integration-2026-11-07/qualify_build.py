from pathlib import Path
import subprocess,json,sys,os,time
ROOT=Path.cwd();profile=sys.argv[1];OUT=ROOT/'docs/voidup/evidence/llvm23-repair/integration-2026-11-07'/profile;OUT.mkdir();BUILD=ROOT/'build/voidup-backport-integration'/profile;SDK=ROOT/'.toolchains/llvm-23.1.4';assert not BUILD.exists()
env=dict(os.environ,PATH=str(ROOT/'.toolchains/ninja-1.13.2')+os.pathsep+os.environ['PATH'])
if profile=='strict':env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86',ASAN_SYMBOLIZER_PATH=str(SDK/'bin/llvm-symbolizer'))
commands=[]
def run(label,args):
 start=time.monotonic();args=list(map(str,args))
 with (OUT/(label+'.log')).open('wb') as log:r=subprocess.run(args,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
 commands.append({'label':label,'command':args,'status':r.returncode,'seconds':time.monotonic()-start});(OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(profile,label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('configure',['cmake','-S',ROOT,'-B',BUILD,'-G','Ninja','-DCMAKE_BUILD_TYPE='+('RelWithDebInfo' if profile=='strict' else profile),'-DBUILD_TESTING=ON','-DVOID_SANITIZERS='+('ON' if profile=='strict' else 'OFF'),'-DLLVM_DIR='+str(SDK/'lib/cmake/llvm'),'-DCMAKE_C_COMPILER='+str(SDK/'bin/clang'),'-DCMAKE_CXX_COMPILER='+str(SDK/'bin/clang++'),'-DVOID_CLANG='+str(SDK/'bin/clang'),'-DVOID_LINKER='+str(SDK/'bin/ld.lld'),'-DCMAKE_EXE_LINKER_FLAGS=--ld-path='+str(SDK/'bin/ld.lld')])
run('build',['cmake','--build',BUILD,'--target','voidc','voidls','void_host_portable','void_host_capabilities','void_host_child','voidup','--parallel','2'])
run('test-plan',[sys.executable,ROOT/'tools/ci/voidup_bootstrap.py','test-plan','--configuration','Sanitizers' if profile=='strict' else profile,'--build',BUILD,'--evidence',OUT/'test-plan'])
run('focused-ctest',['ctest','--test-dir',BUILD,'-R','^(host_capabilities.*|voidup_.*)$','--output-on-failure'])
print(profile,'focused qualification complete',flush=True)
