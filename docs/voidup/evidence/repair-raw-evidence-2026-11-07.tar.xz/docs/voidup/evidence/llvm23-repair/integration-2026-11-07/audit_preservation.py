"""Compare protected inputs from the accepted isolated experiment to integration."""
from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path(__file__).resolve().parents[5];OUT=Path(__file__).resolve().parent
before=json.loads((OUT.parent/'isolated-candidate-2026-11-07/protected-before.json').read_text())
allowed=set('''CMakeLists.txt
cmake/InstallLicenses.cmake
tools/setup_host_deps.py
tools/setup_host_deps_native.py
tools/verify_host_deps.py
tests/host_capabilities/dependencies.py
tests/host_capabilities/install.py
docs/ADVANCED_LANGUAGE.md
docs/WRENCH_CLANKER.md
docs/voidup/INTEGRATION_REPORT.md
docs/release/NOTICE_INVENTORY.json
docs/release/REDISTRIBUTION_NOTICES.md'''.splitlines())
retained=json.loads((OUT/'retained-original-prefixes.json').read_text())
changes=[];unexpected=[];relocated=0
for name,expected in before.items():
 path=ROOT/name
 for row in retained:
  old=Path(row['old'])
  if row['kind']=='prefix' and path.is_relative_to(old):path=Path(row['retained'])/path.relative_to(old);relocated+=1;break
 actual=['symlink',os.readlink(path)] if path.is_symlink() else ['file',hashlib.file_digest(path.open('rb'),'sha256').hexdigest()] if path.is_file() else ['missing',None]
 if actual!=expected:
  record={'path':name,'before':expected,'after':actual}
  (changes if name in allowed else unexpected).append(record)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=ROOT,text=True).splitlines()
previous=json.loads((OUT/'git-before.json').read_text())
result={'protected_inputs':len(before),'authorized_changes':changes,'unexpected_changes':unexpected,'retained_original_prefix_files':relocated,'head':head,'head_unchanged':head==previous['head'],'staged_paths':staged,'root_readme_website_archives_pristine_sources_prior_evidence_preserved':not unexpected,'windows_selector_implementation_preserved':all(x['path'] not in ('cmake/host-sodium.targets','tools/ci/llvm_sdk.py') for x in changes+unexpected)}
(OUT/'preservation-final.json').write_text(json.dumps(result,indent=2)+'\n')
print('Protected',len(before),'authorized changes',len(changes),'unexpected',len(unexpected),'retained prefix files',relocated,'HEAD unchanged',result['head_unchanged'],'staged',len(staged))
assert not unexpected and result['head_unchanged'] and not staged
