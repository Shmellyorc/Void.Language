from pathlib import Path
import json,subprocess,os,hashlib
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;WORK=ROOT/'build/llvm23-isolated-candidate-2026-11-07'
results={}
for label in ['pikaos','ubuntu']:
 folder=OUT/label;source=WORK/label/'extract/libsodium-1.0.22';build=WORK/label/'build';toolchain=json.loads((folder/'toolchain.json').read_text());environment=toolchain['environment'];prefix=[]
 if label=='ubuntu':
  prefix=['podman','exec','-w',str(build)]
  for key,value in environment.items():prefix+=['-e',key+'='+value]
  prefix+=['voidup-portability-ubuntu']
 env=dict(os.environ,**environment) if not prefix else None
 executable=WORK/label/'negative-coverage-probe'
 compile=[*prefix,environment['CC'],'-O2','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(source/'src/libsodium/include'),str(OUT/'negative_coverage_probe.c'),str(build/'src/libsodium/.libs/libsodium.a'),'--ld-path='+toolchain['tools']['ld.lld']['path'],'-o',str(executable)]
 r=subprocess.run(compile,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(folder/'negative-probe-build.log').write_text(r.stdout);records=[{'label':'compile','command':compile,'status':r.returncode}];assert r.returncode==0,r.stdout
 for case,expected in [('valid',[0]),('overflow',[86,87]),('underflow',[86,87]),('guard-read',[86,87])]:
  command=[*prefix,str(executable),*([] if case=='valid' else [case])];r=subprocess.run(command,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);(folder/('negative-probe-'+case+'.log')).write_text(r.stdout)
  matched=r.returncode in expected and (case=='valid' or 'AddressSanitizer' in r.stdout)
  records.append({'label':case,'command':command,'status':r.returncode,'expected':expected,'expected_outcome_observed':matched});assert matched,(label,case,r.returncode,r.stdout)
 results[label]=records
 (OUT/'negative-probes.json').write_text(json.dumps({'scope':'separate supplemental fault controls; upstream 87 targets/sources/options unchanged','results':results},indent=2)+'\n')
 print(label,'guard mapping/no-op PASS; overflow, underflow and guard-read rejected fatally; exact exit codes recorded')
