"""Produce review diffs and validate their exact replay, without Git mutations."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,tempfile,urllib.parse,shutil
ROOT=Path(__file__).resolve().parents[5];OUT=Path(__file__).resolve().parent;BEFORE=ROOT/'build/voidup-backport-integration/before'
new=['third_party/host-patches/libsodium-1.0.22/PROVENANCE.json','third_party/host-patches/libsodium-1.0.22/asan-alignment.patch']
changed=[p.relative_to(BEFORE).as_posix() for p in sorted(BEFORE.rglob('*')) if p.is_file() and p.read_bytes()!=(ROOT/p.relative_to(BEFORE)).read_bytes()]
doc=lambda n:n.startswith('docs/')
groups={'integrated-source.patch':[n for n in changed if not doc(n)]+new,'documentation-integration.patch':[n for n in changed if doc(n)]}
replays=[]
for filename,names in groups.items():
 text=''
 for n in sorted(names):
  old=(BEFORE/n).read_text().splitlines(keepends=True) if (BEFORE/n).exists() else []
  current=(ROOT/n).read_text().splitlines(keepends=True)
  text+='diff --git a/'+n+' b/'+n+'\n'+('new file mode 100644\n' if not (BEFORE/n).exists() else '')+''.join(difflib.unified_diff(old,current,fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
 (OUT/filename).write_text(text)
 with tempfile.TemporaryDirectory(prefix='VOID approved diff replay ') as t:
  t=Path(t)
  for n in names:
   if (BEFORE/n).exists():(t/n).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BEFORE/n,t/n)
  for options in (['--check'],[]):
   result=subprocess.run(['git','apply','--no-index',*options,str(OUT/filename)],cwd=t,capture_output=True)
   assert result.returncode==0,result.stderr.decode()
  assert all((t/n).read_bytes()==(ROOT/n).read_bytes() for n in names)
 replays.append({'patch':filename,'paths':sorted(names),'check_and_apply_to_disposable_before_snapshot':'PASS','exact_postimages':'PASS'})
# Copy the exact cryptographic/harness source patch separately for direct review.
shutil.copy2(ROOT/new[1],OUT/'libsodium-approved.patch')
entries={n:hashlib.sha256((ROOT/n).read_bytes()).hexdigest() for n in sorted(changed+new)}
(OUT/'changed-files.json').write_text(json.dumps({'scope':'Delta from accepted isolated-candidate tree; earlier unrelated/local revisions retained','changed_or_added':entries,'new_paths':new,'prior_windows_selector_paths_retained':['cmake/host-sodium.targets','tools/ci/llvm_sdk.py'],'excluded':'build/, .toolchains/, compiled outputs, private signing keys; no change to compiler/Runtime production sources, HTTP recipes/transport, workflows, root README or website'},indent=2)+'\n')
links=[];broken=[]
for n in [n for n in changed if n.endswith('.md')]:
 p=ROOT/n;s=p.read_text()
 # Fenced examples are not navigation links.
 s=re.sub(r'```.*?```','',s,flags=re.S)
 for ref in re.findall(r'(?<!!)\[[^\]]*\]\(([^)]+)\)',s):
  ref=ref.split(' "',1)[0].strip('<>');url=urllib.parse.urlsplit(ref)
  if url.scheme or ref.startswith('//'):continue
  path=(p.parent/urllib.parse.unquote(url.path)).resolve() if url.path else p
  issue=None
  if not path.exists() and path!=OUT/'review-validation.json':issue='missing path'
  elif url.fragment and path.suffix.lower()=='.md':
   target=path.read_text();anchors=[];counts={}
   for heading in re.findall(r'^#{1,6}\s+(.+?)\s*#*$',target,re.M):
    heading=re.sub(r'\[([^\]]+)\]\([^)]+\)',r'\1',heading)
    slug=re.sub(r'[^\w\- ]','',heading.lower(),flags=re.UNICODE).replace(' ','-')
    count=counts.get(slug,0);counts[slug]=count+1;anchors.append(slug+('-'+str(count) if count else ''))
   anchors+=re.findall(r'<a\s+(?:name|id)=[\"\']([^\"\']+)',target)
   if urllib.parse.unquote(url.fragment) not in anchors:issue='missing anchor'
  row={'document':n,'reference':ref}
  links.append(row)
  if issue:broken.append(dict(row,issue=issue))
validation={'diff_replay':replays,'local_markdown_references_checked':len(links),'broken_links':broken}
(OUT/'review-validation.json').write_text(json.dumps(validation,indent=2)+'\n')
assert not broken,broken
print('Actual diff replay PASS;',len(changed),'changed,',len(new),'new paths;',len(links),'links checked')
