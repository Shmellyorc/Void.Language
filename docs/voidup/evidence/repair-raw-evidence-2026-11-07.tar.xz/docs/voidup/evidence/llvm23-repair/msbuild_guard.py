from pathlib import Path
import subprocess,json,xml.etree.ElementTree as ET
ROOT=Path.cwd();base=ROOT/'build/llvm23-repair-checks/msbuild';base.mkdir(exist_ok=True)
for relative in ['bin/clang-cl.exe','bin/lld-link.exe','bin/llvm-lib.exe','lib/clang/23/include/stddef.h']:
 p=base/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('fixture only; never executed\n')
props={'PlatformToolset':'ClangCL','LLVMToolsVersion':'23','VoidPinnedLLVMToolsVersion':'23','VoidPinnedResourceDir':str(base/'lib/clang/23'),'CLToolPath':str(base/'bin')+'/','CLToolExe':'clang-cl.exe','LinkToolPath':str(base/'bin')+'/','LinkToolExe':'lld-link.exe','LibToolPath':str(base/'bin')+'/','LibToolExe':'llvm-lib.exe'}
project=ET.Element('Project');group=ET.SubElement(project,'PropertyGroup')
for key,value in props.items():ET.SubElement(group,key).text=value
ET.SubElement(project,'Import',Project=str(ROOT/'cmake/host-sodium.targets'));fixture=base/'guard.proj';ET.ElementTree(project).write(fixture)
results=[]
for label,args,expected in [('matched',[],0),('wrong-selector',['/p:LLVMToolsVersion=0'],1),('missing-resource',['/p:VoidPinnedResourceDir=/nonexistent/void-sdk'],1),('ambient-compiler',['/p:CLToolExe=ambient-cl.exe'],1),('ambient-linker',['/p:LinkToolExe=ambient-link.exe'],1)]:
 command=['dotnet','msbuild',str(fixture),'/nologo','/t:VoidVerifyPinnedClangCL',*args]
 result=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (ROOT/f'docs/voidup/evidence/llvm23-repair/msbuild-{label}.log').write_text(result.stdout)
 assert (result.returncode!=0)==bool(expected),(label,result.stdout)
 results.append(dict(label=label,command=command,status=result.returncode,expected_failure=bool(expected)))
(ROOT/'docs/voidup/evidence/llvm23-repair/msbuild-guard.json').write_text(json.dumps({'scope':'Linux .NET MSBuild XML guard fixtures only; not Visual C++ targets or Windows acceptance','results':results},indent=2)+'\n')
print('MSBuild guard fixtures: matched passed; four mismatches failed closed; no compiler executed.')
