from pathlib import Path
import json,subprocess,shutil,time,hashlib,sys
root=Path.cwd();base=root/'build/llvm23-review/guard-experiment';src=base/'source';build=base/'build';evidence=root/'docs/voidup/evidence/llvm23-repair/review/guard-only';evidence.mkdir(parents=True,exist_ok=True)
if src.exists():raise SystemExit('Refusing to reuse prior experiment source')
shutil.copytree(root/'.toolchains/host/sources/libsodium-1.0.22',src);build.mkdir(parents=True)
header=src/'test/default/cmptest.h';before=header.read_text();needle='# if defined(__EMSCRIPTEN__) || defined(__SANITIZE_ADDRESS__)';assert before.count(needle)==1;header.write_text(before.replace(needle,'# if defined(__EMSCRIPTEN__)'))
# The only altered source is the test harness. No provider/crypto code is edited.
changes=[p.relative_to(src).as_posix() for p in src.rglob('*') if p.is_file() and p.read_bytes()!=(root/'.toolchains/host/sources/libsodium-1.0.22'/p.relative_to(src)).read_bytes()];assert changes==['test/default/cmptest.h'],changes
compiler=root/'.toolchains/llvm-23.1.4/bin/clang';env=dict(__import__('os').environ,CC=str(compiler),CFLAGS='-g -O2 -fsanitize=address,undefined -fno-omit-frame-pointer',LDFLAGS='-fsanitize=address,undefined',ASAN_OPTIONS='detect_leaks=1:halt_on_error=1:exitcode=87',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1:exitcode=86',ASAN_SYMBOLIZER_PATH=str(compiler.parent/'llvm-symbolizer'))
records=[]
for label,cmd in [('configure',[src/'configure','--disable-shared','--enable-static','--enable-minimal','--disable-dependency-tracking']),('build',['make','-j3']),('check',['make','check','-j3'])]:
 start=time.monotonic()
 with (evidence/(label+'.log')).open('wb') as log:result=subprocess.run(list(map(str,cmd)),cwd=build,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append(dict(label=label,command=list(map(str,cmd)),cwd=str(build),status=result.returncode,seconds=time.monotonic()-start))
 (evidence/'commands.json').write_text(json.dumps({'changed_source':changes,'provider_sources_unchanged':True,'no_install_performed':True,'environment':{k:env[k] for k in ['CC','CFLAGS','LDFLAGS','ASAN_OPTIONS','UBSAN_OPTIONS','ASAN_SYMBOLIZER_PATH']},'results':records},indent=2)+'\n')
 if result.returncode:break
for pattern in ['*.log','*.trs']:
 for p in (build/'test/default').glob(pattern):shutil.copy2(p,evidence/p.name)
print(json.dumps(records[-1]))
