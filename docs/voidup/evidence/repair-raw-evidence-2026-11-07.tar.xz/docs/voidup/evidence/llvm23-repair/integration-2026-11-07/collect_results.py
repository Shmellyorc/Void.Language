"""Read-only evidence collection for this bounded integration qualification."""
from pathlib import Path
import hashlib,json,re,shutil,sys
ROOT=Path(__file__).resolve().parents[5]
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools'))
from verify_host_deps import sha,verify_prefix,verify_sodium_copy,source_tree,RECIPES

def put(name,value): (OUT/name).write_text(json.dumps(value,indent=2)+'\n')

def results(root,profile,receipt):
 build=root/'.toolchains/host/build'/profile
 verify_sodium_copy(build/'sodium-source',receipt['source_provenance'])
 rows=[]
 for name,status in sorted(receipt['upstream_tests']['targets'].items()):
  actual=build/'sodium/test/default'/(name+'.res');expected=build/'sodium-source/test/default'/(name+'.exp')
  rows.append({'name':name,'target_status':status,'actual_sha256':sha(actual),'expected_sha256':sha(expected),'actual_bytes':actual.stat().st_size,'expected_bytes':expected.stat().st_size,'output_matches':actual.read_bytes()==expected.read_bytes()})
 assert len(rows)==87 and all(x['target_status']=='PASS' for x in rows)
 assert [x['name'] for x in rows if not x['output_matches']]==['sodium_utils2','sodium_utils3']
 return {'upstream_targets_passed':87,'failed':0,'skipped':0,'output_matches':85,'output_oracle_exceptions':[x for x in rows if not x['output_matches']],'tests':rows}

profiles={}
for profile in ('Release','Debug','strict'):
 receipt=verify_prefix(ROOT/'.toolchains/host/prefix'/profile,profile,'Linux','x86_64')
 data=results(ROOT,profile,receipt)
 build=ROOT/'build/voidup-backport-integration'/profile
 commands=json.loads((OUT/profile/'commands.json').read_text())
 assert len(commands)==4 and all(c['status']==0 for c in commands)
 log=(OUT/profile/'focused-ctest.log').read_text();assert '100% tests passed, 0 tests failed out of 11' in log
 for name in ('host-capabilities-evidence','voidup-smoke-evidence'):
  shutil.copytree(build/name,OUT/profile/name,dirs_exist_ok=True)
 shutil.copy2(build/'Testing/Temporary/LastTest.log',OUT/profile/'LastTest.log')
 for name in (f'cache-inputs-{profile if profile!="strict" else "RelWithDebInfo"}.txt','void-native-resources.txt',f'native-resources-install-{profile if profile!="strict" else "RelWithDebInfo"}.txt'):
  shutil.copy2(build/name,OUT/profile/name)
 cache=next((OUT/profile).glob('cache-inputs-*.txt')).read_text()
 for name in RECIPES:
  if name!='tools/ci/llvm_sdk.py':assert str(ROOT/name) in cache,name
 assert str(ROOT/'.toolchains/host/prefix'/profile/'VOID-HOST-DEPENDENCIES.json') in cache
 assert 'tools/ci/llvm_sdk.py' in receipt['recipe_sha256']
 installed=json.loads((OUT/profile/'host-capabilities-evidence/installed-host-capabilities.json').read_text())
 assert all(installed[k] for k in ('installed_and_relocated','aot_checkout_and_installed_compiler_inaccessible','approved_source_bundle_reconstructed','tampered_bundle_rejected'))
 data.update(receipt_sha256=sha(ROOT/'.toolchains/host/prefix'/profile/'VOID-HOST-DEPENDENCIES.json'),build_identity=receipt['build_identity'],source_provenance=receipt['source_provenance'],recipe_sha256=receipt['recipe_sha256'],provider_files_verified=len(receipt['files']),focused_ctest_passed=11,commands=commands,installed_source_reconstruction=True,tampered_package_rejected=True)
 put(profile+'/qualification.json',data);profiles[profile]={k:v for k,v in data.items() if k not in ('tests','commands','recipe_sha256')}
ubuntu=ROOT/'build/voidup-backport-integration/ubuntu-source'
receipt_path=ubuntu/'.toolchains/host/prefix/Release/VOID-HOST-DEPENDENCIES.json'
receipt=json.loads(receipt_path.read_text());data=results(ubuntu,'Release',receipt)
commands=json.loads((OUT/'ubuntu-integrated/commands.json').read_text());assert all(c['status']==0 for c in commands)
assert receipt['recipe_sha256']==json.loads((ROOT/'.toolchains/host/prefix/Release/VOID-HOST-DEPENDENCIES.json').read_text())['recipe_sha256']
data.update(build_identity=receipt['build_identity'],receipt_sha256=sha(receipt_path),source_provenance=receipt['source_provenance'],receipt_checks=18,commands=commands,platform_identity=json.loads((OUT/'ubuntu-integrated/identity.log').read_text()))
shutil.copy2(receipt_path,OUT/'ubuntu-integrated/VOID-HOST-DEPENDENCIES.json')
put('ubuntu-integrated/qualification.json',data)
put('qualification-summary.json',{'platform':'PikaOS Linux x86_64','llvm':'23.1.4','profiles':profiles,'ubuntu_24_04_5_release':{k:v for k,v in data.items() if k not in ('tests','commands')},'native_windows_macos':'UNQUALIFIED / NOT RUN','two_upstream_output_oracle_limitations_retained':True})
print('Collected 3 x 87 upstream targets, 3 x 11 focused checks and installed source reconstruction/tamper evidence; Ubuntu Release 87/87 and receipt checks')
