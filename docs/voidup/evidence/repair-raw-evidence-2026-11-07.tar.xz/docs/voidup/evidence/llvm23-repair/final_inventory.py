from pathlib import Path
import subprocess,json,hashlib
root=Path.cwd();e=root/'docs/voidup/evidence/llvm23-repair';target=e/'changed-files.json'
existing=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines();tracked=set(subprocess.check_output(['git','ls-files'],text=True).splitlines())
new=[root/'docs/TOOLCHAIN.md',root/'docs/DOCUMENTATION_CLEANUP.md',root/'docs/voidup/LLVM23_CI_REPAIR.md',*(root/'docs/history').rglob('*'),*e.rglob('*')]
paths=set(existing)|{p.relative_to(root).as_posix() for p in new if p.is_file()}|{target.relative_to(root).as_posix()}
records=[]
for relative in sorted(paths):
 p=root/relative
 if p==target:
  records.append({'path':relative,'status':'new','sha256':None,'note':'this manifest; self hash excluded'});continue
 assert p.exists(),relative
 assert p.suffix.lower() not in ['.key','.pem','.pfx','.p12','.exe','.obj','.o','.a','.so','.dll','.lib'],relative
 assert not relative.startswith(('build/','.toolchains/','website/','src/','include/','stdlib/','apps/','third_party/','.github/')),relative
 records.append({'path':relative,'status':'modified' if relative in tracked else 'new','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
for path in existing:assert path in paths
result={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'staged_paths':subprocess.check_output(['git','diff','--cached','--name-only'],text=True).splitlines(),'files':records,'excluded':['root README.md (protected and unchanged)','.github/workflows/ (unchanged)','compiler/Runtime production, stdlib and application sources (unchanged)','website/ (unchanged)','pinned third_party/ sources, versions, hashes and notices (unchanged)','build/, .toolchains/, generated binary/object files','private signing credentials (none added)'],'note':'Exact local review inventory, including ignored logs. No staging or Git mutation performed.'}
assert result['staged_paths']==[]
target.write_text(json.dumps(result,indent=2)+'\n')
print(f'Inventory: {len(records)} paths, {len(existing)} modified tracked files; no staged paths.')
