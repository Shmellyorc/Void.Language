/* Supplemental fault probes; no edits to the upstream test suite/provider. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sodium/core.h>
#include <sodium/utils.h>

static void check_guard(void)
{
    unsigned char *allocation = sodium_malloc(0);
    assert(allocation != NULL);
    unsigned char *guard = allocation + 1;
    FILE *maps = fopen("/proc/self/maps", "r");
    assert(maps != NULL);
    char line[512], permissions[5];
    unsigned long low, high;
    int protected = 0;
    while (fgets(line, sizeof line, maps) != NULL) {
        if (sscanf(line, "%lx-%lx %4s", &low, &high, permissions) == 3 &&
            (uintptr_t) guard >= low && (uintptr_t) guard < high) {
            protected = permissions[0] == '-' && permissions[1] == '-';
            printf("nonnull_guard=1 mapping=%s\n", permissions);
            break;
        }
    }
    fclose(maps);
    assert(protected);
    sodium_memzero(guard, 0);
    sodium_free(allocation);
    puts("guard protection and nonnull zero-length clear PASS");
}

int main(int argc, char **argv)
{
    assert(sodium_init() >= 0);
    if (argc == 1) {
        check_guard();
        return 0;
    }
    unsigned char *buffer = sodium_malloc(17);
    assert(buffer != NULL);
    memset(buffer, 0x5a, 17);
    if (strcmp(argv[1], "overflow") == 0) {
        sodium_memzero(buffer + 17, 1); /* Same intended overflow as utils2. */
    } else if (strcmp(argv[1], "underflow") == 0) {
        sodium_memzero(buffer - 8, 8);  /* Same intended canary damage as utils3. */
        assert(sodium_mprotect_readonly(buffer) == 0);
        sodium_free(buffer);
    } else if (strcmp(argv[1], "guard-read") == 0) {
        unsigned char *empty = sodium_malloc(0);
        assert(empty != NULL);
        printf("unexpected guard byte=%u\n", *(volatile unsigned char *)(empty + 1));
    } else {
        return 98;
    }
    fputs("ERROR: intended invalid access was not rejected\n", stderr);
    return 99;
}
