from pathlib import Path
import subprocess,sys,json
root=Path.cwd();sys.path.insert(0,str(root/'tools'))
from setup_host_deps_native import verify_static_crt
sdk=root/'.toolchains/llvm-23.1.4/bin';base=root/'build/llvm23-repair-checks';source=base/'abi.c';source.write_text('int void_abi_probe(void) { return 0; }\n');evidence=root/'docs/voidup/evidence/llvm23-repair';results=[]
for option in ['MT','MD','MTd']:
 obj=base/('abi-'+option+'.obj');command=[sdk/'clang','--target=x86_64-pc-windows-msvc','--driver-mode=cl','/'+option,'/c','/Fo'+str(obj),source]
 build=subprocess.run(list(map(str,command)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True);assert build.returncode==0,build.stdout
 inspect=[sdk/'llvm-readobj','--coff-directives',obj];directives=subprocess.check_output(list(map(str,inspect)),text=True)
 (evidence/('coff-'+option+'.log')).write_text(directives)
 try:verify_static_crt(directives);accepted=True
 except ValueError:accepted=False
 assert accepted==(option=='MT'),(option,directives)
 results.append(dict(command=list(map(str,command)),inspection=list(map(str,inspect)),status=build.returncode,abi_accepted=accepted))
(evidence/'coff-abi.json').write_text(json.dumps({'scope':'Linux SDK Clang 23.1.4 cross-target COFF C objects; no native Windows link/build acceptance','results':results},indent=2)+'\n')
print('Real cross-target COFF: /MT accepted; /MD and /MTd rejected.')
