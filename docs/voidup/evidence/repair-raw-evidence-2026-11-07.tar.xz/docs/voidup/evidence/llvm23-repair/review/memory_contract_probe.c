#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <sodium/utils.h>
#include "sodium/private/common.h"

int main(int argc, char **argv)
{
    unsigned char input[32], output[32];
    (void) argv;
    if (argc > 1) {
        sodium_memzero(NULL, 0); /* Original-invalid-call negative control. */
        return 99;
    }
    for (unsigned int i = 0; i < sizeof input; ++i) input[i] = (unsigned char) i;
    for (unsigned int offset = 0; offset < 16; ++offset) {
        uint32_t expected = ((uint32_t) input[offset]) |
                            ((uint32_t) input[offset+1] << 8) |
                            ((uint32_t) input[offset+2] << 16) |
                            ((uint32_t) input[offset+3] << 24);
        assert(LOAD32_LE(input + offset) == expected);
        memset(output, 0xa5, sizeof output);
        STORE32_LE(output + offset, expected);
        assert(memcmp(input + offset, output + offset, 4) == 0);
        sodium_memzero(output + offset, 0);
        assert(memcmp(input + offset, output + offset, 4) == 0);
        sodium_memzero(output + offset, 4);
        for (unsigned int i = 0; i < 4; ++i) assert(output[offset+i] == 0);
        for (unsigned int i = 0; i < offset; ++i) assert(output[i] == 0xa5);
        for (unsigned int i = offset+4; i < sizeof output; ++i) assert(output[i] == 0xa5);
    }
    puts("16 offsets: unaligned helpers and valid zero/nonzero clears PASS");
    return 0;
}
