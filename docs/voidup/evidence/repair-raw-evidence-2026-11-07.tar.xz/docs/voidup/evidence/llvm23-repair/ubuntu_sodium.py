from pathlib import Path
import subprocess,json,time,shutil
root=Path.cwd();base=root/'build/llvm23-repair-checks/ubuntu-sodium';base.mkdir(exist_ok=True)
evidence=root/'docs/voidup/evidence/llvm23-repair/ubuntu-strict';evidence.mkdir(exist_ok=True)
cc=root/'build/voidup-ubuntu-source/.toolchains/llvm-23.1.4/bin/clang'
prefix=['podman','exec','-w',str(base),'-e','CC='+str(cc),'-e','CFLAGS=-g -O2 -fsanitize=address,undefined -fno-omit-frame-pointer','-e','LDFLAGS=-fsanitize=address,undefined','-e','ASAN_OPTIONS=detect_leaks=1:halt_on_error=1:exitcode=87','-e','UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1:exitcode=86','voidup-portability-ubuntu']
results=[]
for label,cmd in [('compiler',[cc,'--version']),('configure',[root/'.toolchains/host/sources/libsodium-1.0.22/configure','--disable-shared','--enable-static','--enable-minimal','--disable-dependency-tracking']),('build',['make','-j2']),('check',['make','check','-j2'])]:
 start=time.monotonic();command=[*prefix,*map(str,cmd)]
 with (evidence/(label+'.log')).open('wb') as log:result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 results.append(dict(label=label,command=command,status=result.returncode,seconds=time.monotonic()-start))
 (evidence/'commands.json').write_text(json.dumps(results,indent=2)+'\n')
 if result.returncode:break
for pattern in ['*.log','*.trs']:
 for source in (base/'test/default').glob(pattern):shutil.copy2(source,evidence/source.name)
print(json.dumps(results[-1]))
