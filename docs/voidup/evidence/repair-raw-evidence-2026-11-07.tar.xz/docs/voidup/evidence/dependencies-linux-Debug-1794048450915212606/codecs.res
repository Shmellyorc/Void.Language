30313233343536373839414243444546
bin2hex(..., guard_page, 0):
bin2hex(..., "", 0):
4:cafe6942
dt1: 11
4:cafe6942
dt2: 2
dt3: 11
dt4: 11
dt5: 11
dt6: 11
+/DxMDEyMzQ1Njc4OUFCQ0RFRmFi
+/DxMDEyMzQ1Njc4OUFCQ0RFRmFiYw
-_DxMDEyMzQ1Njc4OUFCQ0RFRmFi
-_DxMDEyMzQ1Njc4OUFCQ0RFRmFiYw

YQ==
YWI=
YWJj

YQ
YWI
YWJj
[]
[BpcyBhIGpvdXJu
ZXkgaW50by Bzb3VuZA==]
[This is a journey into sound]
[This is a journ]
[
ZXkgaW50by Bzb3VuZA==]
ip2bytes(192.168.1.1): OK
ip2bytes IPv4 basic: OK
ip2bytes IPv4 invalid: OK
ip2bytes(2001:db8:85a3:0:0:8a2e:370:7334): OK
ip2bytes IPv6 compressed: OK
ip2bytes IPv6 zone: OK
ip2bytes IPv6 invalid: OK
ip2bytes IPv4-mapped: OK
ip NULL handling: OK
bytes2ip IPv4: OK
bytes2ip IPv6: OK
bytes2ip buffer size: OK
ip round-trip: OK
ip case insensitive: OK
ip IPv4-mapped equivalence: OK
ip src_len larger than string: OK
ip src_len shorter than IP: OK
