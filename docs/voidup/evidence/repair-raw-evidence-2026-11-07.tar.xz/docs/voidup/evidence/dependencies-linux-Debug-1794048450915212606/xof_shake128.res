All SHAKE-128 tests passed
