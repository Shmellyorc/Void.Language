SHA3-256("") = a7ffc6f8bf1ed76651c14756a061d662f580ff4de43b49fa82d80a4b80f8434a
SHA3-256("abc") = 3a985da74fe225b2045c172d6bd390bd855f086e3e9d525b46bfe24511431532
SHA3-256("The quick brown fox...") = 69070dda01975c8c120c3aada1b282394e7f032fa9cf32f4cb2259a0897dfc04
Streaming API test passed
Chunked update test passed
Rate boundary test passed
Rate+1 boundary test passed
Rate-1 boundary test passed
Update-after-final recovery test passed
Final-after-final test passed
OK
