misuse_handler()
