primitive: xwing
constants: ok
shared secrets match: ok
random keypair test: ok
