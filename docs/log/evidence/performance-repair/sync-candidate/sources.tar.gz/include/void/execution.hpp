#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
namespace vd {
class ValidatedAnalysis;
class Runtime;
// Per-invocation storage: generated code only borrows it until normal return.
struct RuntimeFailure {
    const char* message = nullptr;
    std::uint32_t count = 0;
    const char* frames[32] = {};
};
// Native failures may survive reached cleanup and a callback generation's release.
// Own the bounded diagnostic rather than borrowing mutable bridge scratch storage.
class OwnedRuntimeFailure {
    std::string message_;
    std::vector<std::string> frames_;
    RuntimeFailure value_;
public:
    void assign(const RuntimeFailure&) noexcept;
    const RuntimeFailure& value() const noexcept{return value_;}
};
void retain_native_failure(const RuntimeFailure&,RuntimeFailure*) noexcept;
void export_native_failure(RuntimeFailure*) noexcept;
struct Compatibility {
    std::string function_id;
    std::string signature = "c:i32(i32)";
    std::uint64_t layout = 0, captures = 0, constants = 0;
    std::string constant_contract = {};
    std::string source_contract = {};
    std::shared_ptr<const ValidatedAnalysis> analysis = {};
    std::uintptr_t runtime_identity = 0;
    bool async_root = false;
    bool operator==(const Compatibility& other) const {
        return function_id == other.function_id && signature == other.signature &&
            layout == other.layout && captures == other.captures && constants == other.constants &&
            constant_contract == other.constant_contract && source_contract == other.source_contract && runtime_identity == other.runtime_identity && async_root == other.async_root;
    }
};
class NativeCode {
public:
    using CheckedEntry = std::int32_t (*)(std::int32_t, RuntimeFailure*);
    using Entry = std::int32_t (*)(std::int32_t);
    NativeCode(Entry entry, std::shared_ptr<void> owner, Compatibility compatibility);
    NativeCode(CheckedEntry entry, std::shared_ptr<void> owner, Compatibility compatibility, std::shared_ptr<Runtime> runtime = {});
    std::int32_t invoke(std::int32_t value) const;
    static std::shared_ptr<void> active_lease();
    class LeaseScope {
        struct FailureRecord;
        std::unique_ptr<FailureRecord> failures_;
        LeaseScope* previous_failures_=nullptr;
        std::shared_ptr<void> previous_;
        friend void retain_native_failure(const RuntimeFailure&,RuntimeFailure*) noexcept;
    public: explicit LeaseScope(std::shared_ptr<void>);~LeaseScope();
        LeaseScope(const LeaseScope&)=delete;LeaseScope& operator=(const LeaseScope&)=delete;
    };
    const std::shared_ptr<Runtime>& runtime_owner() const { return runtime_; }
    const Compatibility& compatibility() const { return compatibility_; }
private:
    Entry entry_ = nullptr;
    CheckedEntry checked_ = nullptr;
    std::shared_ptr<void> owner_;
    Compatibility compatibility_;
    std::shared_ptr<Runtime> runtime_;
};
// A lease keeps its generation alive through the entire call, including native reentry.
class ReloadSlot {
public:
    explicit ReloadSlot(std::shared_ptr<const NativeCode> initial);
    std::shared_ptr<const NativeCode> acquire() const;
    bool replace(std::shared_ptr<const NativeCode> replacement);
    std::int32_t invoke(std::int32_t value) const;

private:
    mutable std::mutex mutex_;
    std::shared_ptr<const NativeCode> current_;
};
}
