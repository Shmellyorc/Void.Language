# Logging engineering record

Boss's attached 28 October 2026 mission supersedes the research-only authorization
status in the preserved RESEARCH, DESIGN and ROADMAP documents. The approved
contract is DESIGN.md, with trusted exclusive-writer namespaces, explicit adoption,
checked results, conservative faults and the three additional native safeguards.
Baseline: f9ac49f1558f326129948bc06c829263448b7714. No Git mutations or hosted CI.

Implementation and focused local acceptance are complete: **93/93** selected
Debug/Release/strict CTests passed. [Acceptance](ACCEPTANCE.md),
[measurements](BENCHMARKS.md) and [handoff](HANDOFF.md) record exact scope and
limits. Engineering stops for independent Golden Wrench review; that review and
native Windows/macOS acceptance are not claimed.

The source module uses ordinary Runtime globals, managed guards, byte arrays and
existing console/io/time/path/convert APIs. Concrete synchronous and asynchronous
I/O methods share admission, framing, receipts and state policies. The development
expansion script in tests/log/expand_io.py retains generation provenance; installed
applications execute only stdlib/log.void.

A source-level check exposed an existing compiler omission: explicit enum/callable
field defaults were treated as missing required initialization in no-init
construction. The narrow frontend correction recognizes the same complete defaults
already recognized by value initializer validation. Missing defaults remain required.
No logging intrinsic, new provider, scheduler or permission bypass was added.

Original unsuccessful engineering checks remain under evidence/crashes with exact
launch-time source snapshots and generator provenance. Initial source rejections
were ordinary diagnostics, not native crashes. They included unsupported enum ==,
local/import naming collisions, private field access outside its owning receiver,
standalone propagation expressions, and readonly diagnostic-cause forwarding.
Each was corrected using existing source contracts; no compiler change was made
for those expected restrictions. H1–H7 remain distinct historical unresolved incidents.

## Cancelled acquisition ownership repair

The preserved native AOT observation in
`evidence/crashes/incident-7rh_igd0/` measured an entered opening followed by
cancellation: descriptor count **4 -> 5**, an empty newly created active file,
and zero explicit native closes before Runtime teardown. The existing io child
task retained its published acquisition, but the logger had not yet observed its
return value. This was a real gap in the logger's deterministic acquisition cleanup.
It was not an unexplained compiler crash or loss of the Runtime provider ledger.

Two internal ordinary-source io helpers now prepare a fresh unopened file identity
and complete its existing async acquisition. Logger and temporary-tail guards retain
that identity before suspension. Native operations, cancellation/drain, publication,
readonly checks and provider ownership remain in the established io subsystem.
No new public logging signature, native provider or Runtime protocol was introduced.
The normal native AOT cancellation rerun measured exactly **one close** for each
entered open, adoption read, write, move and close boundary. Final profile receipts
confirm both JIT modes and both independently linked AOT modes, including forced
GC, completion races and unpublished default replacement.

The post-transfer fault test originally assumed another managed object construction
would occur after a successful native write. Its preserved observation was
`failed=0 state=7 bytes=32`: both complete records succeeded, so no Runtime failure
had actually been injected. It now forces a real bad_alloc at the second native
one-byte chunk, after the first byte reaches the file. Both JIT modes retain that
one byte, fault the logger and reject automatic replay. This correction strengthens
the actual failure boundary; it does not establish a production defect in the
successful original transport.

Emergency close now reserves its final-release fallback before receipt allocation.
It marks the instance closed when the native handle retires, including cancellation,
and preserves ownership when native close is busy. The initial consolidated native
run retained all earlier passes but its old cancellation assertion expected faulted
after a retired close. The source now asserts **closed** specifically for retired
close and **faulted** specifically for uncertain write/rotation. The preserved
failure is `evidence/crashes/incident-piwcm854/`; it showed zero subsequent output,
not an unsafe successful retry.

Reconfiguration also keeps the successfully configured absolute path snapshot
separate from the namespace whose acquisition was most recently attempted.
A failed path replacement cannot redirect recovery of the prior configuration to
the failed new destination. Native tests observe both file identities and sentinel
contents before/after explicit adoption and recovery.

Default replacement now reserves the old default before its first await. It also
retains the unpublished replacement identity in the caller's reached acquisition
guard before awaiting activation. This prevents concurrent reconfiguration from
using a stale old-default reference and closes a cancelled candidate even when an
internal activation task has already completed. Public close and default replacement
share the same reserved-close helper. This uses ordinary source guards and existing
io operations, without another global lock or Runtime service.

Failed acquisition cleanup closes without introducing a flush of unchanged data.
The primary acquisition error and its checked close error retain their separate
typed causes. Normal rotation/lifecycle still flush before close; simultaneous
flush/close failures are checked independently by native source assertions.

## Shared async readiness repair

The final forced-GC cancellation matrix exposed `Async await dependency cycle`
after a native acquisition had entered. The diagnostic rerun is preserved in
`evidence/crashes/incident-rs9b9ass/`. A seventh scenario in the existing
`tests/io/native_jobs.cpp` reproduces the failure without importing logging:
an enclosing activation awaits an opening activation that cancels itself after
native publication, requiring asynchronous acquisition abandonment. Its original
failure is `evidence/crashes/incident-ej4p6can/`.

The scheduler scans parents before later-created children. When a child in
`finishing` becomes `finished` during that scan, an earlier waiting/joining parent
can become ready after its readiness check. The old empty-ready-queue path could
diagnose a cycle before rescanning. `src/runtime/async.cpp` now records this actual retirement progress and
rescans before cycle diagnosis. It adds no task state, queue, lock or privilege.
The isolated seven-scenario regression and both JIT cancellation modes pass after
this repair; the final matrix also covers existing async source, IR, parallel,
lifecycle and I/O acquisition checks.

The superseded profile runs are retained. Release reported the cancellation
assertion; Debug/strict selection orchestration was deliberately stopped before
rebuilding. The still-running strict native host was terminated with its original
files retained under `evidence/stopped-native-1466352/`. The action and exact
process identities are recorded in `evidence/superseded-profile-stop.json`.
No spontaneous crash or hang is inferred from this operator stop; its snapshot
shows work had progressed into the second optimization mode. The deterministic
standalone regression establishes the shared readiness defect independently.
