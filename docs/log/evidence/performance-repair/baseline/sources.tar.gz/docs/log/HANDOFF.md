# VOID logging — Golden Wrench handoff

28 October 2026. Baseline **`f9ac49f1558f326129948bc06c829263448b7714`**.
The complete approved logging module is implemented. **Local acceptance passed
93/93 selected CTests: Debug 31/31, Release 31/31, strict ASan/UBSan/leaks 31/31.**
Engineering stops here for independent Golden Wrench review. No independent
acceptance lock or native Windows/macOS pass is claimed.

## Delivered behavior

[stdlib/log.void](../../stdlib/log.void) implements the exact [approved API](DESIGN.md):
five severities/off, a Runtime-local default, independent managed instances,
copied/validated configuration, stderr/stdout/none, persistent owned files,
explicit reject/adopt, bounded escaped UTF-8 records, fixed UTC timestamps,
eager/lazy emission, all explicit async variants, bounded rotation, reconfiguration
and recovery, checked flush/close/shutdown, terminal deinit and typed failures with
actual per-sink progress. There is no new logging provider, scheduler, queue,
sink registry or compiler intrinsic.

The source uses reached guards before reservation/acquisition. Async acquisitions
retain unopened file identities before suspension; unpublished default replacement
has its own reached guard while the previous default stays reserved. Partial or
uncertain transport faults admitted writes and never replays a whole record.
Rotation uses exact authorized names, close-before-rename, no-replace moves and
exclusive creation. Completed mutations remain visible after failure.

The default remains stderr-only and creates no files/directories. Seven examples
cover stderr, explicit development `.void/logs`, application-created
`os.state_dir(app_id)/logs`, lazy construction, rotation, checked shutdown and an
explicit async root. See the [API guide](API.md) and [example directory](../../examples/log/).

## Review the shared changes

Most production work is ordinary VOID source. The supporting changes are narrow
and have preserved reproductions:

| File | Change and evidence |
| --- | --- |
| [stdlib/io.void](../../stdlib/io.void) | Two internal source helpers prepare an unopened identity and complete its existing async open. This closes the cancellation gap between child-result publication and the logger observing its handle. The original AOT descriptor observation was 4→5 with zero explicit closes; final entered acquisition cases close exactly once. Public io signatures/native operations are unchanged. |
| [src/frontend/compiler.cpp](../../src/frontend/compiler.cpp) | No-init construction now recognizes complete enum/callable field defaults using the same rule already present in value initialization. Required missing defaults still reject. This enables the approved `log.config()` defaults without a logging-specific bypass. |
| [src/runtime/async.cpp](../../src/runtime/async.cpp) | Rescan after a finishing child retires before diagnosing an empty-ready-queue dependency cycle. A parent may have been checked earlier in that same scan. The existing native-job suite now has a deterministic nested cancellation/acquisition-abandonment regression, independent of logging. No scheduler state/queue/privilege was added. |
| [src/runtime/filesystem.cpp](../../src/runtime/filesystem.cpp) | Extend the existing test `Hooks.before` barrier to seek/length/flush and namespace operations. Null-hook production behavior is unchanged; tests can hold or fail real native boundaries. |
| [tests/io/native_jobs.cpp](../../tests/io/native_jobs.cpp) | Seventh native-job scenario reproduces the shared readiness defect and requires cancellation, native abandonment and released roots. |
| [tests/io/runner.cpp](../../tests/io/runner.cpp) | Add compiler-owned logging inventory output to the existing explicit source/AOT runner. |
| [CMakeLists.txt](../../CMakeLists.txt) | Register 11 logging tests and two separately linked native probe targets using existing managed/native test seams. |

`tests/log/expand_io.py` expands concrete sync/async I/O boundaries from one
development template while common source helpers own admission, framing, receipts
and state. Regeneration is byte-idempotent. Installed applications use the normal
source module only. [Engineering history](IMPLEMENTATION.md) explains the ownership,
default-publication and acquisition/cleanup-cause decisions in detail.

## Acceptance evidence

[ACCEPTANCE.md](ACCEPTANCE.md) maps the complete ROADMAP to tests and records
commands, sanitizer settings, counts and platform limits. Per profile, the native
host performs **1,686** checks across JIT modes; each independently linked AOT probe
performs **826**. Further suites exercise exact byte/UTC oracles, real redirected
console/broken pipes, 244 filesystem observations, cache, reload, installed and
relocated execution, frontend restrictions and 38 compiler-owned LSP checks.
The seven examples pass 25 check/execution/emission/link commands.

All three additional safeguards have direct native observations: no lost
acquisition ownership across cancellation/unwind; inode/content preservation and
untouched external sentinels across partial rotation; and conservative fault
transitions after partial writes and Runtime failures. Tests cover both race
orderings of open/read/write/move/close cancellation, forced GC, allocation budgets,
unpublished default replacement, failed startup and forgotten resources.

Native logging hosts read back **soft=hard=1,048,576-byte** kernel stack limits.
Emitted applications execute independently; async cases use explicit root adapters.
Strict checks instrument compiler/Runtime/C++ host code; generated VOID instructions
do not independently receive Clang sanitizer passes.

| Evidence | Purpose |
| --- | --- |
| [Acceptance index](evidence/acceptance-index.json) | All 93 selected outcomes, durations and profile tool/library hashes |
| [Debug](evidence/ctest-debug-verified.log), [Release](evidence/ctest-release-verified.log), [strict](evidence/ctest-strict-verified.log) | Full final CTest stdout and per-suite counts |
| [Public inventory](evidence/public-api.tsv) | 83 compiler-owned public declarations; all written parameters documented |
| [Validation source hashes](evidence/validation-source-freeze.json) | Exact production/native-test source identity for final validation |
| [Source/file inventory](evidence/source-inventory.json) | Every current source/document file, size and SHA-256; includes preserved research files without claiming authorship |
| [Process receipt index](evidence/receipt-index.json) | Commands, cwd, output, timing, stack settings and source/tool hashes, including earlier engineering runs |
| [Incident index](evidence/incident-index.json), [diagnoses](INCIDENTS.md) | Original shared-recorder failures and dispositions; no replacement by passing retries |
| [Environment](evidence/environment.json) | Platform, HEAD, strict settings and protected README hash |

## Measured costs and remaining gates

[BENCHMARKS.md](BENCHMARKS.md) records **216** final samples: 18 bounded workloads,
three repetitions and four JIT/AOT modes, with compilation separate from execution,
CPU/wall times, managed-construction counts, native operations, bytes and repeated
root memory/handle observations. The normal execution GC budget is 256. The original
216 GC-stress samples and 157 complete samples from an interrupted unbudgeted
measurement remain separately preserved with their exact source and commands.

The measurements do not support a zero-cost-disabled or high-throughput claim.
In JIT O2, 200 logged 64-byte file records took a median **265.32 ms**, versus
**3.04 ms** for direct io with identical bytes. Framing cost was approximately
linear in input bytes over the measured sizes. A 1,000-call async root cost
**3318.72 ms**, versus **68.57 ms** for 100 calls; no constant per-call async cost
is claimed. Post-root GC payloads and host handles returned to baseline in every
repetition. The raw observations include concurrent local validation activity and
do not isolate individual helpers for a justified further optimization.

Native Windows/macOS verification remains a separate pending gate, including
Windows sharing/case/close-before-rename behavior and native platform path/storage
semantics. The trusted exclusive-writer/alias warranty remains essential; metadata
does not establish hostile-namespace safety. There is no power-loss/directory-sync
or cross-process exactly-once guarantee beyond the approved contract.

The original research/design/roadmap and unrelated local changes remain preserved.
The root README and Git index are unchanged; HEAD remains the stated baseline.
No Git staging, commits, branches, pushes, hosted CI or ptrace occurred.
Historical H1–H7 remain distinct and unresolved. **Stop for Golden Wrench review.**
