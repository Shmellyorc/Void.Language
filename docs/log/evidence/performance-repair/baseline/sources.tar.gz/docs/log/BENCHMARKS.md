# Logging bounded measurements

28 October 2026, local Linux x86-64 Release, pinned LLVM/Clang 19.1.7.
AMD Ryzen 7 1700X, 16 logical CPUs, about 31 GiB RAM. Other local acceptance
processes ran concurrently; these are bounded observations, not isolated-machine
throughput qualification. [Environment](evidence/benchmark-environment.json),
[raw 216 samples](evidence/benchmarks.json), [workloads](../../tests/log/benchmark.void),
[host](../../tests/log/host.cpp), [measurement driver](../../tests/log/benchmarks_default.py).

Each of 18 workloads has a warmup and three measured repetitions in each of four
modes. JIT source analysis/lowering/compilation occurs before execution timing.
AOT probes are emitted and linked independently before launch and link Runtime
without LLVM. The host's actual soft/hard stack limits are both 1,048,576 bytes.
Counts/checksums prevent discarded work; caller message construction, acquisition
and final checked close remain inside each execution interval.

The final timing host uses **Runtime(256)**, matching production JIT creation and
native bootstrap. Its [exact source overlay](evidence/benchmark-default-host.cpp)
changes only the test host's Runtime budget (1→256) and resolves its probe include.
All production libraries, source programs, optimization flags and probe behavior
are shared. The original [216 collection-at-every-allocation samples](evidence/benchmarks-gc-stress.json)
remain separate. An intermediate Runtime(0) experiment disabled automatic GC;
its completed JIT samples and interrupted AOT samples are preserved separately
and excluded from the tables below. The [stop journal](evidence/benchmark-unbudgeted-stop.json)
records the measurement correction; it was not a logger failure.

## Execution wall and CPU time

Milliseconds per whole workload, **median [minimum, maximum]**, three samples.
Payload sizes exclude framing. Console measurements use the existing isolated
output adapter; real OS redirection and broken pipes are functional acceptance
tests, not terminal-rendering performance measurements. File measurements use
actual temporary native files and checked synchronization.

| Workload | JIT normal | JIT O2 | AOT normal | AOT O2 |
| --- | ---: | ---: | ---: | ---: |
| Disabled direct / 10,000 | 26.62 [26.51, 26.82] | 26.47 [26.37, 27.23] | 22.45 [22.40, 22.50] | 22.78 [22.69, 22.86] |
| Disabled eager display / 10,000 | 60.07 [59.64, 64.06] | 59.02 [58.28, 59.81] | 50.56 [50.52, 51.20] | 51.43 [51.30, 51.59] |
| Disabled enabled-guard / 10,000 | 11.78 [11.70, 11.99] | 12.08 [12.04, 12.75] | 10.42 [10.39, 10.46] | 10.88 [10.81, 10.91] |
| Disabled named lazy / 10,000 | 20.43 [20.38, 20.57] | 21.26 [21.23, 21.40] | 18.80 [18.69, 19.01] | 19.52 [19.50, 19.78] |
| Disabled captured lazy / 10,000 | 30.98 [29.82, 32.82] | 29.26 [29.00, 29.39] | 25.46 [25.45, 25.66] | 26.00 [25.84, 26.33] |
| Console 64 B / 200 | 262.50 [261.43, 344.54] | 257.91 [257.22, 259.78] | 235.93 [235.92, 242.94] | 263.55 [254.59, 277.06] |
| File 64 B / 200 | 260.08 [258.94, 260.75] | 265.32 [263.77, 276.18] | 238.71 [238.28, 241.64] | 261.47 [260.30, 261.71] |
| File 1 KiB / 100 | 1867.17 [1860.99, 1963.68] | 1935.46 [1930.53, 1992.38] | 1778.64 [1769.75, 1781.15] | 1899.56 [1894.26, 1900.69] |
| File 65,500 B / 3 | 3521.21 [3451.80, 3534.42] | 3706.83 [3681.49, 3776.20] | 3369.69 [3349.76, 3401.93] | 3659.74 [3587.76, 3686.50] |
| File 64 B + UTC / 200 | 266.23 [265.52, 267.88] | 284.32 [281.80, 288.20] | 251.37 [250.86, 268.26] | 272.61 [271.12, 273.13] |
| 20 rotations / 0 backups | 29.76 [29.30, 29.76] | 30.81 [30.65, 33.88] | 27.86 [27.69, 27.90] | 29.14 [29.13, 29.27] |
| 20 rotations / 3 backups | 31.32 [31.22, 31.88] | 32.56 [32.09, 32.90] | 28.84 [28.77, 28.89] | 30.58 [30.56, 30.78] |
| 20 rotations / 32 backups | 48.32 [47.89, 48.96] | 49.04 [48.82, 49.78] | 42.33 [42.25, 42.55] | 44.69 [44.43, 44.82] |
| Direct io identical bytes / 200 | 3.02 [2.89, 3.02] | 3.04 [3.03, 3.21] | 2.65 [2.65, 2.84] | 2.82 [2.80, 2.86] |
| Direct console identical bytes / 200 | 1.39 [1.33, 1.46] | 1.41 [1.37, 1.46] | 1.26 [1.25, 1.43] | 1.39 [1.32, 1.42] |
| File + 20 explicit flushes / 200 | 254.27 [252.64, 255.47] | 264.70 [263.86, 266.31] | 239.05 [237.33, 243.23] | 263.35 [259.27, 267.40] |
| Sequential async / 100 | 67.68 [59.68, 70.20] | 68.57 [59.35, 75.59] | 55.42 [53.54, 60.47] | 63.43 [62.45, 63.65] |
| Sequential async / 1,000 | 3486.77 [3279.27, 3537.78] | 3318.72 [3294.34, 3344.30] | 2431.33 [2264.83, 2463.65] | 2450.96 [2234.76, 2456.01] |

Process CPU milliseconds, with the same ordering and sample range:

| Workload | JIT normal | JIT O2 | AOT normal | AOT O2 |
| --- | ---: | ---: | ---: | ---: |
| Disabled direct / 10,000 | 26.41 [26.30, 26.59] | 26.32 [26.24, 27.05] | 22.17 [22.14, 22.25] | 22.66 [22.60, 22.75] |
| Disabled eager display / 10,000 | 59.68 [59.23, 63.29] | 58.69 [57.98, 59.46] | 50.26 [50.07, 50.75] | 51.23 [51.09, 51.38] |
| Disabled enabled-guard / 10,000 | 11.69 [11.61, 11.92] | 12.01 [11.98, 12.65] | 10.33 [10.32, 10.37] | 10.78 [10.77, 10.84] |
| Disabled named lazy / 10,000 | 20.29 [20.26, 20.35] | 21.14 [21.13, 21.28] | 18.68 [18.58, 18.89] | 19.38 [19.33, 19.61] |
| Disabled captured lazy / 10,000 | 30.69 [29.55, 32.42] | 29.07 [28.84, 29.19] | 25.23 [25.17, 25.53] | 25.88 [25.76, 26.06] |
| Console 64 B / 200 | 260.69 [259.79, 341.10] | 256.69 [256.10, 258.43] | 234.39 [234.37, 241.14] | 260.65 [253.22, 274.23] |
| File 64 B / 200 | 257.31 [256.37, 257.95] | 264.06 [262.48, 274.81] | 237.38 [237.15, 240.39] | 258.95 [258.81, 260.32] |
| File 1 KiB / 100 | 1857.06 [1851.66, 1952.41] | 1927.75 [1922.32, 1982.58] | 1767.94 [1760.25, 1772.38] | 1888.58 [1886.62, 1890.68] |
| File 65,500 B / 3 | 3505.31 [3436.73, 3514.61] | 3685.19 [3666.37, 3747.86] | 3353.46 [3332.65, 3384.43] | 3635.97 [3573.52, 3665.48] |
| File 64 B + UTC / 200 | 264.74 [264.02, 266.47] | 282.63 [280.18, 286.43] | 250.08 [249.56, 266.51] | 270.88 [269.79, 271.07] |
| 20 rotations / 0 backups | 29.52 [29.06, 29.53] | 30.58 [30.41, 33.55] | 27.63 [27.48, 27.65] | 28.94 [28.94, 29.06] |
| 20 rotations / 3 backups | 31.04 [30.96, 31.58] | 32.30 [31.87, 32.61] | 28.58 [28.52, 28.63] | 30.35 [30.32, 30.51] |
| 20 rotations / 32 backups | 47.79 [47.42, 48.44] | 48.56 [48.36, 49.27] | 41.98 [41.87, 42.12] | 44.22 [44.01, 44.35] |
| Direct io identical bytes / 200 | 3.00 [2.88, 3.01] | 3.03 [3.01, 3.18] | 2.64 [2.63, 2.79] | 2.80 [2.78, 2.80] |
| Direct console identical bytes / 200 | 1.34 [1.33, 1.46] | 1.40 [1.36, 1.45] | 1.26 [1.25, 1.42] | 1.36 [1.31, 1.38] |
| File + 20 explicit flushes / 200 | 252.72 [251.02, 253.85] | 263.30 [262.49, 264.84] | 237.42 [235.83, 241.82] | 261.60 [257.85, 265.34] |
| Sequential async / 100 | 67.68 [60.00, 70.95] | 69.49 [60.43, 76.02] | 56.38 [54.73, 61.33] | 64.35 [63.58, 64.52] |
| Sequential async / 1,000 | 3512.74 [3309.19, 3555.82] | 3348.49 [3323.24, 3370.67] | 2457.53 [2289.17, 2489.61] | 2465.17 [2256.25, 2484.61] |

## Operations and allocations

A single value means all modes/samples agree. Otherwise values are in the four
mode columns' order above. Managed constructions count the existing construction
probe, not every string/buffer/native allocation. Retained output bytes include
console capture and remaining managed files; deleted rotation history is excluded.

| Workload | Managed constructions | Retained output B | Console calls | Native writes | Flushes | Metadata | Moves | Deletes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Disabled direct / 10,000 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Disabled eager display / 10,000 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Disabled enabled-guard / 10,000 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Disabled named lazy / 10,000 | 5 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Disabled captured lazy / 10,000 | 10005 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| Console 64 B / 200 | 1017 | 15000 | 200 | 0 | 0 | 0 | 0 | 0 |
| File 64 B / 200 | 1839 | 15000 | 0 | 200 | 1 | 4 | 0 | 0 |
| File 1 KiB / 100 | 939 | 103500 | 0 | 100 | 1 | 4 | 0 | 0 |
| File 65,500 B / 3 | 66 | 196533 | 0 | 3 | 1 | 4 | 0 | 0 |
| File 64 B + UTC / 200 | 1839 | 20000 | 0 | 200 | 1 | 4 | 0 | 0 |
| 20 rotations / 0 backups | 565 | 75 | 0 | 21 | 21 | 1 | 0 | 20 |
| 20 rotations / 3 backups | 571 | 300 | 0 | 21 | 21 | 4 | 60 | 20 |
| 20 rotations / 32 backups | 1027 | 1575 | 0 | 21 | 21 | 33 | 640 | 20 |
| Direct io identical bytes / 200 | 816 | 15000 | 0 | 200 | 1 | 0 | 0 | 0 |
| Direct console identical bytes / 200 | 0 | 15000 | 200 | 0 | 0 | 0 | 0 | 0 |
| File + 20 explicit flushes / 200 | 2019 | 15000 | 0 | 200 | 21 | 4 | 0 | 0 |
| Sequential async / 100 | 935 | 2300 | 0 | 100 | 1 | 4 | 0 | 0 |
| Sequential async / 1,000 | 9035 | 23000 | 0 | 1000 | 1 | 4 | 0 | 0 |

## Compilation and memory observations

| Mode | Analysis/lower/JIT compile ms | Admission/preparation ms | Process high-water RSS range KiB |
| --- | ---: | ---: | ---: |
| JIT normal | 8939.23 | 8939.23 | 174192–174192 |
| JIT O2 | 11090.26 | 11090.26 | 183180–183180 |
| AOT normal | 0.00 | 0.57 | 14532–15736 |
| AOT O2 | 0.00 | 0.59 | 20028–20028 |

AOT's zero compile column means compilation occurred in the earlier emitter/link
commands; it does not mean compilation was free. Their exact wall times, source
and executable hashes are in process receipts. JIT preparation includes its
compilation interval. RSS is the cumulative process high-water mark, including
compilation, warmups and prior workloads, not per-record live memory.

Async repeated-root memory snapshots, bytes and host handles (three repetitions):

| Mode / calls | Heap before | Heap at root return | Heap after explicit GC | Handles before → after |
| --- | ---: | ---: | ---: | --- |
| JIT normal / 100 | 128, 128, 128 | 42319, 42319, 42319 | 128, 128, 128 | 3→3, 3→3, 3→3 |
| JIT normal / 1000 | 128, 128, 128 | 251311, 251311, 251311 | 128, 128, 128 | 3→3, 3→3, 3→3 |
| JIT O2 / 100 | 128, 128, 128 | 42319, 42319, 42319 | 128, 128, 128 | 3→3, 3→3, 3→3 |
| JIT O2 / 1000 | 128, 128, 128 | 251311, 251311, 251311 | 128, 128, 128 | 3→3, 3→3, 3→3 |
| AOT normal / 100 | 234, 234, 234 | 42713, 42713, 42713 | 234, 234, 234 | 7→7, 7→7, 7→7 |
| AOT normal / 1000 | 234, 234, 234 | 251705, 251705, 251705 | 234, 234, 234 | 7→7, 7→7, 7→7 |
| AOT O2 / 100 | 234, 234, 234 | 42713, 42713, 42713 | 234, 234, 234 | 7→7, 7→7, 7→7 |
| AOT O2 / 1000 | 234, 234, 234 | 251705, 251705, 251705 | 234, 234, 234 | 7→7, 7→7, 7→7 |

These are explicit boundary snapshots, not a continuous peak-live-heap trace.
The existing async root retains task results/ordering records until root exit;
the logger adds no message queue. Post-GC payloads and host handles return to their
per-mode baseline across repeated roots. No constant-RSS or total-allocation-free
claim follows from that observation.

The measured costs are material. In JIT O2, 200 logged 64-byte file records took
265.32 ms versus 3.04 ms for direct io with identical bytes. The 64-byte, 1-KiB
and 65,500-byte cases cost approximately 20.7, 18.9 and 18.9 microseconds per input
byte, respectively: the bounded framing path scales approximately linearly here,
but has substantial overhead. These whole-path measurements do not isolate an
individual helper for a justified implementation optimization.

The JIT O2 async workload took 68.57 ms for 100 records and 3318.72 ms for 1000.
That is superlinear within this bounded range; no constant per-record async cost
is claimed. The measurement includes the established scheduler and root-lifetime
task retention and does not isolate their individual contributions. The repeated
post-root memory/handle baselines above show no unexplained retained growth.

The disabled cases perform no output. Eager custom display still runs 10,000 times;
both lazy bodies run zero times, while captured callback construction remains
visible. Ordinary file records do not perform per-record path metadata calls.
Rotation's counts grow with the exact configured backup set. The framing source
makes bounded linear UTF-8 passes and appends to one byte builder; larger-message
rows expose its actual cost, including caller construction. Direct console/io
rows use identical record bytes and show the framing/admission cost separately
from transport. No fixed throughput target or speculative Runtime optimization
was introduced. The source-generation and GC-policy choices remain reviewable
alongside the raw data rather than hidden behind a single throughput number.
