#include "void/backend.hpp"
#include "void/frontend.hpp"
#include "../managed/probe.hpp"
#include "../native/probe.hpp"
#include <cstring>
#include <iostream>
#include <stdexcept>
namespace {
unsigned checks=0;
void check(bool yes,const char* message){if(!yes)throw std::runtime_error(message);++checks;}
auto analyze(const std::string& text){auto a=vd::analyze_source({"/compound.void",text});if(!a.succeeded())throw vd::CompilationError(a.diagnostics);++checks;return a.program;}
auto file(const std::filesystem::path& path){auto a=path.stem().string().starts_with("operator_native")?vd::analyze_project(path,vd::native_fixture_project()):vd::analyze_project(path);if(!a.succeeded())throw vd::CompilationError(a.diagnostics);++checks;return a.program;}
void empty(vd::Runtime& runtime){vd::Runtime::Attachment a(runtime);vd::Runtime::Managed m(runtime);check(runtime.collect()==vd::Runtime::Collection::completed && runtime.snapshot().objects==0,"compound roots retained after return/failure");}
void run(const std::string& text,int expected){auto a=analyze(text);for(bool optimized:{false,true}){vd::Jit jit;auto module=a->lower();vd::ir::validate(module);auto runtime=std::make_shared<vd::Runtime>(1);auto code=jit.compile(module,module.entry_symbol,optimized,{},runtime);managed_test::Probe p;p.inspect_roots=true;p.collect_before=true;p.frames.reserve(1024);{managed_test::Observe observe(p);check(code->invoke(4)==expected,"wrong compound result");}check(p.roots_valid && p.commits_valid && p.frames.empty(),"compound precise roots/frame failure");empty(*runtime);}}
void reject(const std::string& text){auto a=vd::analyze_source({"/compound.void",text});if(a.succeeded())throw std::runtime_error("invalid compound accepted: "+text);++checks;}
const std::string number="value struct number:\n    value: i32\n    operator +(const left: number, const right: i32) -> number:\n        return number(value = left.value + right)\n    operator /(const left: number, const right: i32) -> number:\n        return number(value = left.value / right)\n";
const std::string entry="func entry(input: i32) -> i32:\n";
std::vector<int> events;
void event(std::int32_t value){events.push_back(value);}
struct Events{Events(){events.clear();events.reserve(64);native_test::scalar_poll=event;}~Events(){native_test::scalar_poll=nullptr;}};
}
int main(int argc,char** argv){try{
    if(argc!=2)throw std::invalid_argument("repository root required");auto fixtures=std::filesystem::path(argv[1])/"tests/stage10";
    for(const auto& [name,answer,async]:{std::tuple{"operator_compounds",4,false},std::tuple{"operator_compound_conversions",4,false},std::tuple{"operator_compound_suspension",4,true},std::tuple{"operator_compound_workers",7,true}}){auto a=file(fixtures/(std::string(name)+".void"));for(bool optimized:{false,true}){vd::Jit jit;auto code=async?jit.compile_async(*a,optimized):jit.compile(*a,optimized);managed_test::Probe p;p.inspect_roots=true;p.collect_before=true;p.frames.reserve(1024);{managed_test::Observe observe(p);check(code->invoke(4)==answer,"source compound fixture");}check(p.roots_valid && p.frames.empty(),"source compound fixture roots");empty(*code->runtime_owner());}}
    run(number+"struct holder:\n    item: number\n"+entry+"    var original = holder(item = number(value = 10))\n    var current = original\n    var rhs = func() -> i32:\n        current = holder(item = number(value = 90))\n        return 2\n    current.item += rhs()\n    return original.item.value * 100 + current.item.value\n",1290);
    run(number+entry+"    var original = [number(value = 10)]\n    var current = original\n    var rhs = func() -> i32:\n        current = [number(value = 90)]\n        return 2\n    current[0] += rhs()\n    return original[0].value * 100 + current[0].value\n",1290);
    run(number+entry+"    var original = [number(value = 10)]\n    var current = original\n    var index = func() -> i32:\n        current = [number(value = 90)]\n        return 0\n    current[index()] += 2\n    return original[0].value * 100 + current[0].value\n",1290);
    run(number+entry+"    var original = {\"x\": number(value = 10)}\n    var current = original\n    var rhs = func() -> i32:\n        current = {\"x\": number(value = 90)}\n        return 2\n    current[\"x\"] += rhs()\n    return original[\"x\"].value * 100 + current[\"x\"].value\n",1290);
    run(number+"value struct pair:\n    item: number\n    other: i32\n"+entry+"    var object = pair(item = number(value = 10))\n    var rhs = func() -> i32:\n        object.other = 9\n        return 2\n    object.item += rhs()\n    return object.item.value * 10 + object.other\n",129);
    run(number+entry+"    var items: [number, 2] = [number(value = 10), number(value = 20)]\n    var rhs = func() -> i32:\n        items[1] = number(value = 99)\n        return 2\n    items[0] += rhs()\n    return items[0].value * 100 + items[1].value\n",1299);
    run(number+"struct owner:\n    item: number\nproperty (self owner) value: number:\n    get:\n        return self.item\n    set(value):\n        self.item = value\n"+entry+"    var original = owner(item = number(value = 10))\n    var current = original\n    var rhs = func() -> i32:\n        current = owner(item = number(value = 90))\n        return 2\n    current.value += rhs()\n    return original.item.value * 100 + current.item.value\n",1290);
    run("struct node:\n    value: i32\n    operator +(const left: node, const right: i32) -> node:\n        return node(value = left.value + right)\n"+entry+"    var object = node(value = 10)\n    var alias = object\n    object += input\n    object.value++\n    return object.value * 100 + alias.value\n",1510);
    run("value struct delta:\n    value: i32\n    operator +(const left: [i32, 2], const right: delta) -> [i32, 2]:\n        return [left[0] + right.value, left[1]]\n"+entry+"    var values: [i32, 2] = [5, 7]\n    var rhs = func() -> delta:\n        values[1] = 99\n        return delta(value = 2)\n    values += rhs()\n    return values[0] * 10 + values[1]\n",77);
    run(number+"struct owner:\n    private item: number\nfunc (self owner) total() -> i32:\n    self.item += 2\n    return self.item.value\n"+entry+"    return owner().total()\n",2);
    run("struct node:\n    value: i32\n    operator -(const left: node) -> node:\n        return left\n    operator +(const left: node, const right: i32) -> node:\n        return node(value = left.value + right)\n"+entry+"    var original = node(value = 10)\n    var view = -original\n    view += 2\n    return view.value * 100 + original.value\n",1210);
    run("struct node:\n    value: i32\n    operator +(const left: node, const right: i32) -> node:\n        return node(value = left.value + right)\n"+entry+"    var object = node(value = 10)\n    var rhs = func() -> i32:\n        object.value = 20\n        var garbage = node(value = 99)\n        return 2\n    object += rhs()\n    return object.value\n",22);
    run("value struct unit:\n    value: f64\n    operator %(const left: f64, const right: unit) -> f64:\n        return left + right.value\n"+entry+"    var amount = 1.0d\n    amount %= unit(value = 2.0d)\n    return amount as i32\n",3);
    run("struct base:\n    value: i32\n    operator +(const left: base, const right: i32) -> child:\n        return child(value = left.value + right)\nstruct child extends base:\n    extra: i32\n"+entry+"    var object = base(value = 10)\n    object += 2\n    return object.value\n",12);
    run("interface view:\n    func read() -> i32\nstruct number:\n    value: i32\n    operator +(const left: view, const right: number) -> number:\n        return number(value = left.read() + right.value)\nfunc (self number) read() -> i32:\n    return self.value\n"+entry+"    var value: view = number(value = 10)\n    value += number(value = 2)\n    return value.read()\n",12);
    reject(number+entry+"    const object = number()\n    object += 1\n    return input\n");
    reject(number+"struct owner:\n    const item: number\n"+entry+"    var object = owner()\n    object.item += 1\n    return input\n");
    reject(number+"struct owner:\n    private item: number\n"+entry+"    var object = owner()\n    object.item += 1\n    return input\n");
    reject(number+"struct owner:\n    item: number\nproperty (self owner) value: number:\n    get:\n        return self.item\n"+entry+"    var object = owner()\n    object.value += 1\n    return input\n");
    reject(number+entry+"    var object = number()\n    object++\n    return input\n");
    reject(number+entry+"    var object = number()\n    object += 1 as i64\n    return input\n");
    reject("value struct number:\n    value: i32\n    operator +(const left: number, const right: i32) -> i32:\n        return right\n"+entry+"    var object = number()\n    object += 1\n    return input\n");
    reject(number+"func change(const items: [number]):\n    items[0] += 1\n"+entry+"    return input\n");
    reject("struct node:\n    value: i32\n    operator +(const left: node, const right: i32) -> node:\n        return left\n"+entry+"    var object = node()\n    object += 1\n    return input\n");
    reject(entry+"    var value = 1.0\n    value %= 2.0\n    return input\n");
    for(const auto& container:{std::string("var items = [number(value = 10)]\n"),std::string("var items = {\"x\": number(value = 10)}\n")}){
        bool dict=container.find("{")!=std::string::npos;std::string index=dict?"\"x\"":"0";auto mutator=dict?"items[\"new\"] = number(value = 99)":"items.push(number(value = 99))";
        auto source=number+entry+"    "+container+"    var rhs = func() -> i32:\n        "+mutator+"\n        return 2\n    items["+index+"] += rhs()\n    return 0\n";auto a=analyze(source);
        for(bool optimized:{false,true}){vd::Jit jit;auto code=jit.compile(*a,optimized);std::string error;try{code->invoke(4);}catch(const std::runtime_error& e){error=e.what();}if(error.empty())throw std::runtime_error("invalidated compound place committed: "+source);if(error.find("structural")==std::string::npos && error.find("invalidated")==std::string::npos)throw std::runtime_error("Unexpected invalidation diagnostic: "+error);++checks;empty(*code->runtime_owner());}
    }
    auto trace=file(fixtures/"operator_native_compounds.void");auto failure=file(fixtures/"operator_native_compound_failure.void");
    for(bool optimized:{false,true}){
        vd::Jit jit;auto code=jit.compile(*trace,optimized);{Events observe;check(code->invoke(4)==4,"native property/index compounds result");check(events==std::vector<int>({20,30,35,40,10,30,36}),"compound getter/setter/index/RHS/operator count/order");}empty(*code->runtime_owner());
        auto failing=jit.compile(*failure,optimized);managed_test::Probe p;p.inspect_roots=true;p.capture=true;p.collect_before=true;p.frames.reserve(1024);std::string error;
        {Events observe;managed_test::Observe roots(p);try{failing->invoke(0);}catch(const std::runtime_error& e){error=e.what();}check(events==std::vector<int>({20,30,35,50}),"failed compound called setter or skipped reached cleanup");}
        check(error.find("Division by zero")!=std::string::npos && error.find("operator /")!=std::string::npos,"compound failure source/callee frames");
        check(p.retained && p.roots_valid && p.frames.empty(),"failed compound receiver/roots");{auto runtime=failing->runtime_owner();vd::Runtime::Attachment a(*runtime);vd::Runtime::Managed m(*runtime);int value;std::memcpy(&value,p.retained->get(),4);check(value==20,"failed property operator replaced storage");p.retained.reset();}empty(*failing->runtime_owner());check(failing->invoke(4)==5,"compound failure retry");empty(*failing->runtime_owner());
    }
    auto invalidation=file(fixtures/"operator_native_compound_invalidation.void");
    for(bool optimized:{false,true}){vd::Jit jit;auto code=jit.compile(*invalidation,optimized);for(int input:{0,1}){Events observe;std::string error;try{code->invoke(input);}catch(const std::runtime_error& e){error=e.what();}check(error.find("structural")!=std::string::npos,"selected collection failure lost Runtime diagnostic");check(events==std::vector<int>({30,35,10}),"invalidated compound partially committed replacement");empty(*code->runtime_owner());}}
    auto selected=analyze(number+entry+"    var value = number()\n    value += input\n    return value.value\n");bool reference=false;for(const auto& r:selected->references())if(!r.implicit && r.to.find("::operator::")!=std::string::npos)reference|=r.source.source->text().substr(r.source.begin,r.source.end-r.source.begin)=="+=";check(reference,"compound glyph reference missing");auto module=selected->lower();
    for(int variant:{0,1,2}){auto bad=module;bool changed=false;for(auto& f:bad.functions)for(auto& b:f.blocks)for(auto& i:b.instructions)if(!changed && !i.operator_glyph.empty()){if(variant==0)i.operator_glyph.clear();else if(variant==1)i.operator_glyph="%";else i.callee=module.entry_symbol;changed=true;}bool denied=false;try{vd::ir::validate(bad);}catch(const std::invalid_argument&){denied=true;}check(changed && denied,"forged compound target/proof accepted");}
    auto writes=analyze(number+entry+"    var list = [number()]\n    var dict = {\"x\": number()}\n    list[0] += input\n    dict[\"x\"] += input\n    return 0\n")->lower();
    for(auto op:{vd::ir::Op::list_commit,vd::ir::Op::dict_set}){auto bad=writes;bool changed=false;for(auto& f:bad.functions)for(auto& b:f.blocks)for(auto& i:b.instructions)if(!changed && i.op==op){if(op==vd::ir::Op::list_commit)i.arguments[0]=i.arguments[1];else i.b=i.arguments[0];changed=true;}bool denied=false;try{vd::ir::validate(bad);}catch(const std::invalid_argument&){denied=true;}check(changed && denied,"malformed compound collection write accepted");}
    // Actual inferred return authority must govern the commit even if a callee
    // body is forged after frontend selection; no mutable promise may thaw it.
    const std::string managed="struct node:\n    value: i32\n    operator +(const left: node, const right: i32) -> node:\n        return ";
    auto fresh=analyze(managed+"node(value = left.value + right)\n"+entry+"    var object = node()\n    object += input\n    return object.value\n")->lower();
    auto alias=analyze(managed+"left\n"+entry+"    var object = node()\n    var ignored = object + input\n    return input\n")->lower();
    for(auto& f:fresh.functions)if(!f.operator_glyph.empty())for(const auto& a:alias.functions)if(a.name==f.name)f.blocks=a.blocks;
    {bool denied=false;try{vd::ir::validate(fresh);}catch(const std::invalid_argument&){denied=true;}check(denied,"forged compound return authority bypassed storage validation");}
    auto suspension=file(fixtures/"operator_compound_suspension.void")->lower();
    auto suspension_source=vd::read_source(fixtures/"operator_compound_suspension.void");
    auto compound_line=suspension_source.location(suspension_source.text().find("items[0] %=")).line;
    unsigned capture_mutants=0;
    for(unsigned fn=0;fn<suspension.functions.size();++fn){const auto& f=suspension.functions[fn];if(f.name!=suspension.entry_symbol)continue;
        for(unsigned block=0;block<f.blocks.size();++block)for(unsigned instruction=0;instruction<f.blocks[block].instructions.size();++instruction){const auto& i=f.blocks[block].instructions[instruction];
            // Growable captures use ordinary stores; fixed arrays use
            // array_capture. Remove each actual compound capture write.
            if(i.source.line!=compound_line || !(i.op==vd::ir::Op::array_capture || (i.op==vd::ir::Op::store && vd::ir::array_type(f.locals.at(i.a)))))continue;
            auto bad=suspension;bad.functions[fn].blocks[block].instructions[instruction]=vd::ir::Instruction{vd::ir::Op::gc_poll};
            bool denied=false;try{vd::ir::validate(bad);}catch(const std::invalid_argument&){denied=true;}
            check(denied,"async capture initialization was trusted without a write");++capture_mutants;
        }
    }
    check(capture_mutants>0,"async compound capture mutation found no writes");
    auto worker=vd::analyze_project(fixtures/"operator_native_compound_worker.void",vd::native_fixture_project());check(!worker.succeeded(),"compound call edge omitted from worker effect graph");bool effect=false;for(const auto& d:worker.diagnostics)effect|=d.description.find("Worker")!=std::string::npos;check(effect,"compound worker rejection unrelated to effects");
    auto allocations=file(fixtures/"operator_compounds.void");
    for(bool optimized:{false,true}){vd::Jit jit;auto code=jit.compile(*allocations,optimized);bool success=false;unsigned failures=0;for(int budget=0;budget<=8192 && !success;budget=budget<128?budget+1:budget*2){managed_test::Probe p;p.inspect_roots=true;p.frames.reserve(1024);{managed_test::Observe observe(p);try{managed_test::AllocationFailure fault(budget);if(code->invoke(4)!=4)throw std::logic_error("compound allocation retry result");success=true;}catch(const std::bad_alloc&){++failures;}catch(const std::runtime_error&){++failures;}}check(p.roots_valid && p.commits_valid && p.frames.empty(),"compound allocation failure roots/frames");empty(*code->runtime_owner());}check(success && failures>0,"compound allocation sweep did not reach failure and success");}
    std::cout<<checks<<" captured-place compound checks passed\n";
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
