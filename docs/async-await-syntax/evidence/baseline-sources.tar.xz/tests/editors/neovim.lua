local root=assert(vim.env.VOID_STAGE7_FIXTURE)
local repo=assert(vim.env.VOID_REPO)
local output=assert(vim.env.VOID_STAGE7_OUTPUT)
local function check(ok,msg)if not ok then error(msg)end end
local function wait(fn)check(vim.wait(10000,fn,10),'timeout: '..debug.traceback())end
local function main()
  vim.opt.runtimepath:prepend(repo..'/editors/neovim')
  vim.opt.runtimepath:prepend(repo..'/editors/vim')
  vim.cmd('filetype plugin indent on')
  local adapter=require('void');adapter.setup({server=vim.env.VOIDLS_PATH,workspace=root,entry=vim.env.VOID_STAGE8_EXPLICIT_ENTRY=='1' and root..'/main.void' or nil})
  vim.cmd.edit(vim.fn.fnameescape(root..'/main.void'))
  wait(function()return #vim.lsp.get_clients({bufnr=0,name='voidls'})==1 and vim.lsp.get_clients({bufnr=0,name='voidls'})[1].initialized end)
  local c=vim.lsp.get_clients({bufnr=0,name='voidls'})[1]
  local buf=vim.api.nvim_get_current_buf()
  local uri=vim.uri_from_fname(root..'/main.void')
  local function request(method,params)
    local result=c:request_sync(method,params,10000,vim.api.nvim_get_current_buf())
    check(result and not result.err,'request failed: '..method..' '..vim.inspect(result));return result.result
  end
  local function point(line,char)return {textDocument={uri=uri},position={line=line,character=char}}end
  check(c.server_capabilities.renameProvider,'guarded adapter rename unavailable')
  local def=request('textDocument/definition',point(2,18));check(vim.uri_to_fname(def.uri)==root..'/worker.void','definition '..vim.inspect(def)..' '..vim.inspect(vim.diagnostic.get()))
  check(request('textDocument/hover',point(2,18)).contents.value:find('calculate',1,true),'hover')
  check(vim.bo.expandtab and vim.bo.shiftwidth==4,'filetype indentation')
  local symbols=request('workspace/symbol',{query='calc'});check(#symbols==1,'workspace symbol')
  local original=vim.api.nvim_buf_get_lines(buf,0,-1,false)
  for _,case in ipairs({{'use ','io/'},{'use io/','files'},{'use "','app/'},{'use "app/','systems/'},{'use "app/systems/','player.void'}})do
    vim.api.nvim_buf_set_lines(buf,0,-1,false,{case[1]})
    local menu=request('textDocument/completion',point(0,#case[1])).items
    local chosen=nil;for _,item in ipairs(menu)do if item.label==case[2] then chosen=item end end
    check(chosen,'nested import menu '..case[1]);vim.lsp.util.apply_text_edits({chosen.textEdit},buf,'utf-16')
    if case[2]=='player.void' then check(vim.api.nvim_buf_get_lines(buf,0,1,false)[1]=='use "app/systems/player.void"','valid import acceptance')end
  end
  vim.api.nvim_buf_set_lines(buf,0,-1,false,{'use io/files as files','func entry(x: i32) -> i32:','    return files.read(x)'})
  local documented=request('textDocument/hover',point(2,19));check(documented.contents.value:find('Editor fixture API.',1,true),'standard source documentation')
  check(vim.uri_to_fname(request('textDocument/definition',point(2,19)).uri)==root..'/standard/io/files.void','standard navigation')
  local composite={'use console','enum parcel:','    empty','    data(value: [i32])','func entry(x: i32) -> i32:','    var p = parcel.data([x])','    print(p)','    var r = console.stdout.write("é😀")','    if p is parcel.data(var numbers):','        return numbers.count as i32','    return x'}
  vim.api.nvim_buf_set_lines(buf,0,-1,false,composite)
  check(request('textDocument/hover',point(7,29)).contents.value:find('Write UTF-8',1,true),'console source documentation')
  check(vim.uri_to_fname(request('textDocument/definition',point(7,29)).uri)==root..'/standard/console.void','console source navigation')
  check(request('textDocument/definition',point(8,20)).range.start.line==3,'enum pattern navigation')
  check(request('textDocument/hover',point(6,6)).contents.value:find('*values',1,true),'public print hover')
  vim.api.nvim_buf_set_lines(buf,5,6,false,{'    var p = parcel.'})
  local cases=request('textDocument/completion',point(5,19));local names={};for _,item in ipairs(cases)do names[item.label]=true end
  check(names.data and names.empty and not names['$tag'],'enum completion')
  vim.api.nvim_buf_set_lines(buf,0,-1,false,composite)
  vim.api.nvim_buf_set_lines(buf,6,7,false,{'    print(p, flush = '})
  local print_help=request('textDocument/signatureHelp',point(6,21))
  check(print_help.activeParameter==4 and print_help.signatures[1].label:find('file: console.output',1,true),'print signature')
  vim.api.nvim_buf_set_lines(buf,0,-1,false,original)
  vim.api.nvim_buf_set_lines(buf,2,3,false,{'    return worker.'})
  local items=request('textDocument/completion',point(2,18));check(#items==1 and items[1].label=='calculate','incomplete member completion')
  vim.lsp.util.apply_text_edits({items[1].textEdit},buf,'utf-16')
  check(vim.api.nvim_buf_get_lines(buf,2,3,false)[1]=='    return worker.calculate','completion selection')
  vim.api.nvim_buf_set_lines(buf,2,3,false,{'    return worker.calculate('})
  local sig=request('textDocument/signatureHelp',point(2,28));check(sig==nil or sig==vim.NIL,'undocumented signature must be null')
  -- Exercise real owned windows, not only protocol results.
  local documentation={'## Save plain_name <value> é😀.','## @param name Name payload. plain_name <value> é😀','## @param last Last payload.','func save(name: string, middle: i32 = 1, last: i32 = 2):','    pass','func main():','    save('}
  local function floats()
    local out={}
    for _,win in ipairs(vim.api.nvim_list_wins())do
      if vim.api.nvim_win_get_config(win).relative~='' then
        out[#out+1]={win=win,text=table.concat(vim.api.nvim_buf_get_lines(vim.api.nvim_win_get_buf(win),0,-1,false),'\n')}
      end
    end
    return out
  end
  vim.opt.virtualedit='onemore'
  local function call(prefix)
    documentation[7]='    '..prefix
    vim.api.nvim_buf_set_lines(buf,0,-1,false,documentation)
    vim.api.nvim_win_set_cursor(0,{7,#documentation[7]})
    vim.cmd('doautocmd CursorMoved')
    request('workspace/symbol',{query='save'})
  end
  call('save(');adapter.signature_help()
  wait(function()return #floats()==1 end)
  check(floats()[1].text:find('Name payload.',1,true) and floats()[1].text:find('plain_name <value> é😀',1,true) and not floats()[1].text:find('Last payload.',1,true),'active-only visible docs')
  call('save("hero", ')
  wait(function()return #floats()==0 end)
  adapter.signature_help();request('workspace/symbol',{query='save'})
  check(#floats()==0,'manual undocumented popup remained')
  call('save(');adapter.signature_help();wait(function()return #floats()==1 end)
  -- Same cursor, source-only edit reproduces the builtin null/old-float defect.
  vim.api.nvim_buf_set_lines(buf,1,2,false,{'## plain description without a parameter tag'})
  adapter.signature_help();request('workspace/symbol',{query='save'})
  wait(function()return #floats()==0 end)
  call('save(');adapter.signature_help();wait(function()return #floats()==1 end)
  call('save("hero", last = ');adapter.signature_help();wait(function()return #floats()==1 end)
  check(floats()[1].text:find('Last payload.',1,true) and not floats()[1].text:find('Name payload.',1,true),'named last visible docs')
  -- Hold a real server response, issue a newer null request, then release it.
  call('save(')
  local send=c.request;local delayed
  c.request=function(self,method,params,handler,...)
    if method=='textDocument/signatureHelp' then
      return send(self,method,params,function(...)
        local args={...};delayed=function()handler(unpack(args))end
      end,...)
    end
    return send(self,method,params,handler,...)
  end
  adapter.signature_help();wait(function()return delayed~=nil end);c.request=send
  call('save("hero", ');adapter.signature_help();request('workspace/symbol',{query='save'})
  delayed();check(#floats()==0,'stale documented reply reopened a window')
  -- Changed source alone also rejects a delayed reply without a second request.
  call('save(');delayed=nil
  c.request=function(self,method,params,handler,...)
    if method=='textDocument/signatureHelp' then return send(self,method,params,function(...)local args={...};delayed=function()handler(unpack(args))end end,...)end
    return send(self,method,params,handler,...)
  end
  adapter.signature_help();wait(function()return delayed~=nil end);c.request=send
  vim.api.nvim_buf_set_lines(buf,1,2,false,{'## source changed'})
  delayed();check(#floats()==0,'stale source reply reopened a window')
  vim.api.nvim_buf_set_lines(buf,0,-1,false,original)
  vim.api.nvim_buf_set_lines(buf,2,3,false,{'    return worker.calculate(x)'})
  wait(function()return #vim.diagnostic.get(buf)==0 end)
  local worker=vim.fn.bufadd(root..'/worker.void');vim.fn.bufload(worker)
  vim.api.nvim_set_current_buf(worker)
  wait(function()return #vim.lsp.get_clients({bufnr=worker})==1 end)
  vim.api.nvim_buf_set_lines(worker,1,2,false,{'    return missing'})
  wait(function()for _,d in ipairs(vim.diagnostic.get(worker))do if d.code=='VOID2002' then return true end end end)
  local stale=request('textDocument/definition',point(2,18));check(stale==vim.NIL or stale==nil,'stale definition '..vim.inspect(stale))
  vim.api.nvim_buf_set_lines(worker,1,2,false,{'    return x + 1'})
  wait(function()return #vim.diagnostic.get(worker)==0 end)
  local rename=request('textDocument/rename',{textDocument={uri=vim.uri_from_fname(root..'/worker.void')},position={line=0,character=7},newName='compute'})
  check(adapter.versioned_edit(rename),'rename application')
  check(vim.api.nvim_buf_get_lines(buf,2,3,false)[1]=='    return worker.compute(x)','cross-file rename')
  check(not adapter.versioned_edit({documentChanges={{textDocument={uri=vim.uri_from_bufnr(worker),version=vim.NIL},edits={}}}}),'unversioned dirty target accepted')
  local before=vim.api.nvim_buf_get_lines(worker,0,-1,false)
  check(not adapter.versioned_edit({documentChanges={{textDocument={uri=vim.uri_from_bufnr(worker),version=-1},edits={}}}}),'stale edit accepted')
  check(vim.deep_equal(before,vim.api.nvim_buf_get_lines(worker,0,-1,false)),'stale edit mutated source')
  vim.api.nvim_buf_set_lines(worker,1,2,false,{'  return x + 1'})
  adapter.format()
  wait(function()return vim.api.nvim_buf_get_lines(worker,1,2,false)[1]=='    return x + 1'end)
  check(#request('textDocument/formatting',{textDocument={uri=vim.uri_from_bufnr(worker)},options={tabSize=4,insertSpaces=true}})==0,'format idempotence')
  vim.api.nvim_buf_set_lines(worker,1,2,false,{'  return x + 1'})
  adapter.format()
  vim.api.nvim_buf_set_lines(worker,1,2,false,{'    return x + 99'})
  request('workspace/symbol',{query='compute'})
  check(vim.api.nvim_buf_get_lines(worker,1,2,false)[1]=='    return x + 99','stale formatting overwrote a newer edit')
  adapter.refresh()
  vim.cmd('VoidRestart')
  wait(function()local all=vim.lsp.get_clients({bufnr=worker,name='voidls'});return #all==1 and all[1].id~=c.id and all[1].initialized end)
  wait(function()return c:is_stopped()end)
  local replacement=vim.lsp.get_clients({bufnr=worker,name='voidls'})[1]
  replacement:stop();wait(function()return replacement:is_stopped()end)
  vim.fn.writefile({vim.json.encode({editor=vim.version(),passed={'documentation window transitions/manual/source edits/stale replies','shipped adapter','console source docs/navigation','enum pattern navigation/completion','public print hover/signature','shared entry preflight','nested import edits','standard docs/navigation','completion selection','incomplete call signature','hover','symbols','navigation','dirty repair','cross-file guarded rename','stale edit rejection','stale formatting rejection','formatting','refresh','restart','stop'}})},output)
end
local ok,err=pcall(main)
if not ok then vim.fn.writefile({tostring(err)},output..'.error');vim.cmd('cquit 1')else vim.cmd('qa!')end
