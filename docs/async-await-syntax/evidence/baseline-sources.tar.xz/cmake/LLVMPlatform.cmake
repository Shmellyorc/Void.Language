# LLVM 19's Windows release exports the producer's absolute DIA SDK path.
# Resolve that dependency to the real consumer SDK; never drop the library.
function(void_resolve_llvm_dia)
  if(NOT WIN32)
    return()
  endif()
  get_property(imported_targets DIRECTORY PROPERTY IMPORTED_TARGETS)
  foreach(imported IN LISTS imported_targets)
    if(NOT imported MATCHES "^LLVM")
      continue()
    endif()
    get_target_property(dependencies "${imported}" INTERFACE_LINK_LIBRARIES)
    if(NOT dependencies)
      continue()
    endif()
    set(resolved_dependencies)
    foreach(dependency IN LISTS dependencies)
      file(TO_CMAKE_PATH "${dependency}" normalized)
      string(TOLOWER "${normalized}" normalized)
      if(normalized MATCHES "(^|/)diaguids\\.lib$" AND NOT EXISTS "${dependency}")
        if("$ENV{VSCMD_ARG_TGT_ARCH}" STREQUAL "arm64")
          set(dia_arch arm64)
        elseif(CMAKE_SIZEOF_VOID_P EQUAL 8)
          set(dia_arch amd64)
        else()
          set(dia_arch "")
        endif()
        find_library(VOID_DIA_GUIDS_LIBRARY NAMES diaguids
          HINTS "$ENV{VSINSTALLDIR}/DIA SDK/lib/${dia_arch}"
                "${MSVC_DIA_SDK_DIR}/lib/${dia_arch}"
          DOC "Actual DIA SDK GUID library for the selected Windows target"
          REQUIRED)
        if(NOT EXISTS "${VOID_DIA_GUIDS_LIBRARY}")
          message(FATAL_ERROR "LLVM requires a real DIA SDK diaguids.lib; install the Visual Studio DIA SDK")
        endif()
        message(STATUS "LLVM DIA dependency: ${dependency} -> ${VOID_DIA_GUIDS_LIBRARY}")
        list(APPEND resolved_dependencies "${VOID_DIA_GUIDS_LIBRARY}")
      else()
        list(APPEND resolved_dependencies "${dependency}")
      endif()
    endforeach()
    set_property(TARGET "${imported}" PROPERTY INTERFACE_LINK_LIBRARIES "${resolved_dependencies}")
  endforeach()
endfunction()

# Pinned libc++ 19 includes stop_token but gates it as experimental. Probe the
# actual Apple SDK link before enabling its supported opt-in. No replacement
# cancellation implementation, newer stdlib, or experimental link archive.
function(void_enable_libcxx_stop_token target)
  if(NOT APPLE)
    return()
  endif()
  include(CheckCXXSourceCompiles)
  include(CMakePushCheckState)
  cmake_push_check_state(RESET)
  set(CMAKE_REQUIRED_LIBRARIES Threads::Threads)
  file(READ "${PROJECT_SOURCE_DIR}/cmake/probes/StopToken.cpp" stop_token_probe)
  check_cxx_source_compiles("${stop_token_probe}" VOID_HAS_STANDARD_STOP_TOKEN)
  if(NOT VOID_HAS_STANDARD_STOP_TOKEN)
    set(CMAKE_REQUIRED_DEFINITIONS -D_LIBCPP_ENABLE_EXPERIMENTAL)
    check_cxx_source_compiles("#include <version>
#if !defined(_LIBCPP_VERSION) || _LIBCPP_VERSION != 190107
#error This opt-in is only verified for pinned libc++ 19.1.7
#endif
${stop_token_probe}" VOID_HAS_LIBCXX19_EXPERIMENTAL_STOP_TOKEN)
    if(NOT VOID_HAS_LIBCXX19_EXPERIMENTAL_STOP_TOKEN)
      message(FATAL_ERROR "The native C++20 stop-token compile/link probe failed; inspect CMakeConfigureLog.yaml. VOID requires real cancellation support.")
    endif()
    target_compile_definitions(${target} INTERFACE _LIBCPP_ENABLE_EXPERIMENTAL)
    message(STATUS "VOID: verified pinned libc++ 19 stop-token experimental opt-in")
  endif()
  cmake_pop_check_state()
endfunction()
